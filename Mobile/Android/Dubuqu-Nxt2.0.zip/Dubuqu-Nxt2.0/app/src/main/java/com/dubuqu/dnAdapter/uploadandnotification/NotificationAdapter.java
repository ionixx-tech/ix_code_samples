package com.dubuqu.dnAdapter.uploadandnotification;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.support.v7.widget.RecyclerView;
import android.text.format.DateUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.dubuqu.R;
import com.dubuqu.dnModels.commonModel.NotificationModel;
import com.dubuqu.dnRestServices.RestServiceController;
import com.dubuqu.dnRestServices.RestServiceProvider;
import com.dubuqu.dnUtils.RestServiceUtils;
import com.dubuqu.dnUtils.Utils;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import de.hdodenhof.circleimageview.CircleImageView;
import okhttp3.OkHttpClient;
import retrofit2.Retrofit;

/**
 * Created by Yogaraj subramanian on 2/1/18
 */

public class NotificationAdapter extends RecyclerView.Adapter<NotificationAdapter.NotificationViewHolder> {

    Context context;

    List<NotificationModel> notificationModelList;

    NotificationCallback notificationCallback;

    public NotificationAdapter(Context context, List<NotificationModel> notificationModelList,
                               NotificationCallback notificationCallback) {
        this.context = context;
        this.notificationModelList = notificationModelList;
        this.notificationCallback = notificationCallback;
    }

    @Override
    public NotificationViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.notification_view_holder, parent, false);
        return new NotificationViewHolder(view);
    }

    @Override
    public void onBindViewHolder(NotificationViewHolder holder, int position) {
        try {
            if (position % 8 == 0)
                notificationCallback.startPaginating();

            holder.onBindPosition(position);
        } catch (Exception e) {
            Log.e(NotificationAdapter.class.getName(), e.getMessage());
        }
    }

    @Override
    public int getItemCount() {
        return notificationModelList.size();
    }

    @Override
    public long getItemId(int position) {
        return notificationModelList.get(position).hashCode();
    }

    @Override
    public int getItemViewType(int position) {
        return notificationModelList.get(position).hashCode();
    }

    class NotificationViewHolder extends RecyclerView.ViewHolder {

        CircleImageView notificationType;

        ImageView notificationImv;

        TextView time, notificationtext;

        String notificationData;

        NotificationViewHolder(View itemView) {
            super(itemView);
            notificationType = itemView.findViewById(R.id.notification_background);
            notificationImv = itemView.findViewById(R.id.notification_type_imv);
            time = itemView.findViewById(R.id.notification_time);
            notificationtext = itemView.findViewById(R.id.notification_text);
        }

        void onBindPosition(final int position) throws Exception {

            final NotificationModel notificationModel = notificationModelList.get(position);

            if (notificationModel != null) {

                int color = R.color.red_color_picker;
                Drawable drawable = context.getResources().getDrawable(R.drawable.dn_ic_gallery_selected);

                notificationData = notificationModel.getMessage();

                if (notificationModel.getIsNotificationRead().equalsIgnoreCase("true")) {
                    itemView.findViewById(R.id.notification_content_rl).setAlpha(0.4f);
                }

                switch (notificationModel.getType()) {

                    case "SHARED_MEDIA":
                        color = R.color.notification_share_media;
                        drawable = context.getResources().getDrawable(R.drawable.dn_ic_gallery_selected);
                        break;

                    case "SOCIAL_CIRCLE":
                        color = R.color.notification_social_circle;
                        drawable = context.getResources().getDrawable(R.drawable.dn_ic_social_circle_selected);
                        break;

                    case "COMMENT_MEDIA":
                        color = R.color.notification_comment_media;
                        drawable = context.getResources().getDrawable(R.drawable.ic_chat);
                        if (!notificationData.contains("sticker")) {
                            String commentData = notificationModel.getMessage();
                            String substring = notificationData.substring(0, commentData.lastIndexOf("~") - 1);
                            notificationData = substring.concat("\n\"" +
                                    commentData.substring(commentData.lastIndexOf("~") + 1, commentData.length()) + "\"");
                        }
                        break;

                    case "LIKE_MEDIA":
                        color = R.color.notification_like_media;
                        drawable = context.getResources().getDrawable(R.drawable.ic_like);
                        break;

                    case "SCREENSHOT_TAKEN":
                        color = R.color.red_color_picker;
                        drawable = context.getResources().getDrawable(R.drawable.ic_screenshot);
                        break;
                }
                notificationType.setImageResource(color);

                notificationImv.setBackground(drawable);

                notificationtext.setText(notificationData);

                time.setText(parseTime(notificationModel.getCreatedStamp()));

                notificationtext.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {
                            if (!(notificationModel.getType().equalsIgnoreCase("SOCIAL_CIRCLE")
                                    || notificationData.contains("profile"))) {

                                notificationCallback.onClick(position,
                                        notificationModel.getType().equalsIgnoreCase("COMMENT_MEDIA"));

                            }

                            if (notificationModel.getIsNotificationRead().equalsIgnoreCase("false")) {
                                notificationModel.setIsNotificationRead("true");
                                notifyItemChanged(position);
                                postNotificationRead(notificationModel.getNotificationId());
                            }
                        } catch (Exception e) {
                            Log.e(NotificationAdapter.class.getName(), e.getMessage());
                        }

                    }
                });
                loadImage(notificationModel.getSignedUrl());
            }

        }

        private void loadImage(String thumbnailSignedUrl) throws Exception {
            if (Utils.isVaildString(thumbnailSignedUrl)) {

                ImageLoader.getInstance().displayImage(thumbnailSignedUrl, notificationType, new ImageLoadingListener() {
                    @Override
                    public void onLoadingStarted(String imageUri, View view) {

                    }

                    @Override
                    public void onLoadingFailed(String imageUri, View view, FailReason failReason) {

                    }

                    @Override
                    public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                        notificationImv.setVisibility(View.GONE);
                        notificationType.setImageBitmap(loadedImage);
                    }

                    @Override
                    public void onLoadingCancelled(String imageUri, View view) {

                    }
                });
            }
        }

        String parseTime(String value) throws Exception {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

            sdf.setTimeZone(TimeZone.getTimeZone("UTC"));

            Date date = sdf.parse(value);

            long millis = date.getTime();
            long timeInMillis = System.currentTimeMillis();

            CharSequence text = DateUtils.getRelativeTimeSpanString(millis, timeInMillis,
                    0, DateUtils.FORMAT_ABBREV_ALL);
            if (text.toString().equalsIgnoreCase("0 sec.ago")) {
                return "just now";
            } else {
                return text.toString();
            }
        }

        void postNotificationRead(String notificationIdentifier) throws Exception {
            String data = "{}";
            OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, context);
            Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
            RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
            RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
            mRetrofitCallBacks.markNotificationAsRead(notificationIdentifier);
        }
    }

    public interface NotificationCallback {

        void startPaginating();

        void onClick(int positon, boolean toOpenChat);
    }
}
