package com.dubuqu.dnRestServices;

import android.support.annotation.Nullable;
import android.util.Log;

import com.dubuqu.R;
import com.dubuqu.dnActivity.home.HomeDetailImageViewer;
import com.dubuqu.dnApplication.AppController;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnModels.commonModel.ErrorBodyModel;
import com.dubuqu.dnModels.commonModel.NotificationModel;
import com.dubuqu.dnModels.requestModel.Captions;
import com.dubuqu.dnModels.requestModel.CreateGroupRequest;
import com.dubuqu.dnModels.requestModel.CreateUserRequest;
import com.dubuqu.dnModels.requestModel.DubuquShareMediaRequest;
import com.dubuqu.dnModels.requestModel.DubuquUserRequestModel;
import com.dubuqu.dnModels.requestModel.GifResponse;
import com.dubuqu.dnModels.requestModel.PhoneNumberVerificationRequest;
import com.dubuqu.dnModels.requestModel.PostMediaComment;
import com.dubuqu.dnModels.requestModel.PublicShareRequestModel;
import com.dubuqu.dnModels.responseModel.BlockedUserModel;
import com.dubuqu.dnModels.responseModel.CreateGroupResponse;
import com.dubuqu.dnModels.responseModel.CreateUserResponse;
import com.dubuqu.dnModels.responseModel.DubuquGetGroupResponse;
import com.dubuqu.dnModels.responseModel.DubuquUserModel;
import com.dubuqu.dnModels.responseModel.DubuquUserResponseModel;
import com.dubuqu.dnModels.responseModel.FetchAllUserEvent;
import com.dubuqu.dnModels.responseModel.FollwoingUserResponse;
import com.dubuqu.dnModels.responseModel.GetAllMediaTimeLine;
import com.dubuqu.dnModels.responseModel.GetAllSharedMediaModel;
import com.dubuqu.dnModels.responseModel.GetTimeLineStory;
import com.dubuqu.dnModels.responseModel.MediaComment;
import com.dubuqu.dnModels.responseModel.MediaLikeDetails;
import com.dubuqu.dnModels.responseModel.PublicMediaResponseModel;
import com.dubuqu.dnModels.responseModel.SearchUserModel;
import com.dubuqu.dnModels.responseModel.SharedMedia;
import com.dubuqu.dnModels.responseModel.SharedMedias;
import com.dubuqu.dnModels.responseModel.SignedUrlResponseModel;
import com.dubuqu.dnModels.responseModel.SocialGroupDetailsResponseModel;
import com.dubuqu.dnModels.responseModel.UpdateGroupProfileRequest;
import com.dubuqu.dnModels.responseModel.UserDetails;
import com.dubuqu.dnModels.responseModel.WhatsHappeningModel;
import com.dubuqu.dnUtils.EncryptionUtils;
import com.dubuqu.dnUtils.Utils;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.content.ContentValues.TAG;


/**
 * Created by Yogaraj subramanian on 19/4/17
 */

public class RestServiceController {

    private RestServiceProvider mRestServiceProvider;
    private EncryptionUtils encryptionUtils;
    private List<DubuquGetGroupResponse> getDubuquResponse = new ArrayList<>();
    private List<DubuquGetGroupResponse> getOpenDubuquResponse = new ArrayList<>();
    private List<GetAllSharedMediaModel> getAllSharedMediaModelList = new ArrayList<>();
    private List<SharedMedia> fetchUserMediaModelList = new ArrayList<>();

    public RestServiceController(RestServiceProvider mRestServiceProvider) {
        this.mRestServiceProvider = mRestServiceProvider;
    }


    /*---------------------------------Registration-----------------------------------------*/

    public void generateVerificationCode(final ResponseCallBacks responseCallBacks,
                                         PhoneNumberVerificationRequest phoneNumberVerificationRequest) throws Exception {


        Call<ResponseBody> responseBodyCall = mRestServiceProvider.generateVerificationCode(phoneNumberVerificationRequest);
        responseBodyCall.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                switch (response.code()) {
                    case 200:
                        responseCallBacks.onResponse(response);
                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                handleApiError(t);
            }
        });

    }

    public void checkIsVerificationCodeIsValid(final ResponseCallBacks responseCallBacks,
                                               PhoneNumberVerificationRequest phoneNumberVerificationRequest) throws Exception {

        Call<ResponseBody> responseBodyCall = mRestServiceProvider.checkIsVerificationCodeIsvalid(phoneNumberVerificationRequest);
        responseBodyCall.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                switch (response.code()) {
                    case 200:
                        responseCallBacks.onResponse(response);
                        break;
                    default:
                        responseCallBacks.onFailure(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                handleApiError(t);
            }
        });

    }

    public void createUser(final ResponseCallBacks responseCallBacks,
                           CreateUserRequest createUserRequest) throws Exception {

        Call<CreateUserResponse> responseCall = mRestServiceProvider.createUser(createUserRequest);

        responseCall.enqueue(new Callback<CreateUserResponse>() {
            @Override
            public void onResponse(Call<CreateUserResponse> call, Response<CreateUserResponse> response) {
                switch (response.code()) {
                    case 200:
                        responseCallBacks.onResponse(response.body());
                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<CreateUserResponse> call, Throwable t) {
                handleApiError(t);
            }
        });

    }

    /*--------------------------------------------------------------------------------------------*/

    /*make http call to api to ftech all the  dubuq users
    *
    * @params callback to handke response
    * @params dubuquUserRequestModels :RequestBody
    * */
    public void getDubuqUserList(final ResponseCallBacks responseCallBacks,

                                 DubuquUserRequestModel dubuquUserRequestModels) {


        Call<List<DubuquUserResponseModel>> requestModel = mRestServiceProvider.getDubuqUsersList(dubuquUserRequestModels);
        requestModel.enqueue(new Callback<List<DubuquUserResponseModel>>() {
            @Override
            public void onResponse(Call<List<DubuquUserResponseModel>> call, Response<List<DubuquUserResponseModel>> response) {

                switch (response.code()) {
                    case 200:
                        responseCallBacks.onResponse(response.body());
                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<List<DubuquUserResponseModel>> call, Throwable t) {
                handleApiError(t);
            }
        });
    }


    /**
     * fetch user profile image for the given user identifier
     *
     * @param userIdentifier    identifier of the user
     * @param responseCallBacks Object call back .
     */
    public void fetchUserProfileImage(String userIdentifier, final ResponseCallBacks<ResponseBody> responseCallBacks) {

        Call<ResponseBody> responseBodyCall = mRestServiceProvider.getUserProfileImage(userIdentifier);

        responseBodyCall.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                switch (response.code()) {
                    case 200:
                        responseCallBacks.onResponse(response.body());
                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                handleApiError(t);
            }
        });
    }


    /* Update User Details */
    public void updateUserDetails(final String userIdentifier, final UserDetails userDetails, final ResponseCallBacks responseCallBacks) {
        try {
            Call<ResponseBody> responseBodyCall = mRestServiceProvider.updateUserDetails(userIdentifier, userDetails);
            responseBodyCall.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    switch (response.code()) {
                        case 200:

                            responseCallBacks.onResponse(response.body());
                            break;
                        default:
                            handleApiError(response);
                            break;
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    handleApiError(t);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*update user profile photo */
    public void uploadUserProfileImageToDubuquServer(UpdateGroupProfileRequest request, String userIdentifier) {
        try {
            Call<ResponseBody> responseBodyCall = mRestServiceProvider.updateUserProfileImage(userIdentifier, request);
            responseBodyCall.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    switch (response.code()) {
                        case 200:
                            Log.d(TAG, "onResponse: response code : " + response.code()
                                    + "messagee" + response.body());

                            break;
                        default:
                            handleApiError(response);
                            break;
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    handleApiError(t);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void getDubuqUserList(final ResponseCallBacks<List<DubuquUserResponseModel>> responseCallBacks,
                                 String data) throws Exception {
        String encryptData = EncryptionUtils.encrypt_data("This is test msg");
        final String decryptedData = EncryptionUtils.decrypt_data("1sbe9XCLlCSl6CyI200+eA==");

        final Call<String> requestModel = mRestServiceProvider.getDubuqUsersList(EncryptionUtils.encrypt_data(data));
        requestModel.enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {
                switch (response.code()) {
                    case 200:
                        try {
                            String decyptedresponse = EncryptionUtils.decrypt_data(response.body());
                            Gson s = new Gson();
                            List<DubuquUserResponseModel> res = s.fromJson(decyptedresponse, new TypeToken<List<DubuquUserResponseModel>>() {
                            }.getType());
                            responseCallBacks.onResponse(res);
                        } catch (Exception e) {
                            e.getMessage();
                            e.getCause();
                        }
                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<String> call, Throwable t) {
                handleApiError(t);
            }
        });
    }

    /**
     * make http call to api to ftech all the  dubuq grouplist
     *
     * @params responseCallbacks
     */
    public void getDubuqGroupList(final ResponseCallBacks responseCallBacks) {
        Call<List<DubuquGetGroupResponse>> requestModel = mRestServiceProvider.getDubuqGroupResponse();
        requestModel.enqueue(new Callback<List<DubuquGetGroupResponse>>() {
            @Override
            public void onResponse(Call<List<DubuquGetGroupResponse>> call, Response<List<DubuquGetGroupResponse>> response) {
                switch (response.code()) {
                    case 200:
                        try {
                            okhttp3.Headers headerList = response.headers();
                            int resourceCount = Integer.parseInt(headerList.get(Constants.X_RESOURCE_COUNT));
                            String s = headerList.get(Constants.X_PAGE_INFO);
                            JSONObject js = new JSONObject("{" + s + "}");
                            int offset = Integer.parseInt(js.getString("current-offset"));

                            if (getDubuquResponse.size() > 0) {
                                getDubuquResponse.clear();
                            }
                            getDubuquResponse.addAll(response.body());
                            if (resourceCount == getDubuquResponse.size()) {
                                responseCallBacks.onResponse(getDubuquResponse);
                            } else {
                                paginateSocialGroupList(getDubuquResponse.size(), 10, new ResponseCallBacks() {
                                    @Override
                                    public void onResponse(Object o) {
                                        responseCallBacks.onResponse(getDubuquResponse);
                                    }

                                    @Override
                                    public void onFailure(Object o) {
                                        responseCallBacks.onFailure(o);
                                    }
                                });
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<List<DubuquGetGroupResponse>> call, Throwable t) {
                handleApiError(t);
            }
        });
    }


    /*make http call to get all dubuq open groups*/
    public void getAllOpenGroupList(final ResponseCallBacks responseCallBacks) {
        Call<List<DubuquGetGroupResponse>> requestModel = mRestServiceProvider.getOpenGroupResponse();
        requestModel.enqueue(new Callback<List<DubuquGetGroupResponse>>() {
            @Override
            public void onResponse(Call<List<DubuquGetGroupResponse>> call, Response<List<DubuquGetGroupResponse>> response) {
                switch (response.code()) {
                    case 200:
                        try {
                            okhttp3.Headers headerList = response.headers();
                            int resourceCount = Integer.parseInt(headerList.get(Constants.X_RESOURCE_COUNT));
                            String s = headerList.get(Constants.X_PAGE_INFO);
                            JSONObject js = new JSONObject("{" + s + "}");
                            int offset = Integer.parseInt(js.getString("current-offset"));
                            if (getOpenDubuquResponse.size() > 0) {
                                getOpenDubuquResponse.clear();
                            }
                            getOpenDubuquResponse.addAll(response.body());
                            if (resourceCount == getOpenDubuquResponse.size()) {
                                responseCallBacks.onResponse(getOpenDubuquResponse);
                            } else {
                                paginateOpenSocialGroupList(getOpenDubuquResponse.size(), 10, new ResponseCallBacks() {
                                    @Override
                                    public void onResponse(Object o) {
                                        responseCallBacks.onResponse(getOpenDubuquResponse);
                                    }

                                    @Override
                                    public void onFailure(Object o) {
                                        handleApiError(o);
                                    }

                                });
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<List<DubuquGetGroupResponse>> call, Throwable t) {
                handleApiError(t);
            }
        });
    }

    private void paginateOpenSocialGroupList(int offset, int limit, final ResponseCallBacks responseCallBacks) {
        Call<List<DubuquGetGroupResponse>> requestModel = mRestServiceProvider.getPaginateOpenGroupRespone(offset, limit);
        requestModel.enqueue(new Callback<List<DubuquGetGroupResponse>>() {
            @Override
            public void onResponse(Call<List<DubuquGetGroupResponse>> call, Response<List<DubuquGetGroupResponse>> response) {
                switch (response.code()) {
                    case 200:
                        try {

                            okhttp3.Headers headerList = response.headers();
                            int resourceCount = Integer.parseInt(headerList.get(Constants.X_RESOURCE_COUNT));
                            String s = headerList.get(Constants.X_PAGE_INFO);
                            JSONObject js = new JSONObject("{" + s + "}");
                            int offset = Integer.parseInt(js.getString("current-offset"));

                            getOpenDubuquResponse.addAll(response.body());
                            if (resourceCount == getOpenDubuquResponse.size()) {
                                responseCallBacks.onResponse(getOpenDubuquResponse);
                            } else {
                                paginateOpenSocialGroupList(getOpenDubuquResponse.size(), 10, responseCallBacks);
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<List<DubuquGetGroupResponse>> call, Throwable t) {
                handleApiError(t);
            }
        });
    }

    private void paginateOpenGroups(int offset, int limit, final ResponseCallBacks<List<DubuquGetGroupResponse>> re) {
        Call<List<DubuquGetGroupResponse>> requestModel = mRestServiceProvider.getPaginateOpenGroupRespone(offset, limit);
        requestModel.enqueue(new Callback<List<DubuquGetGroupResponse>>() {
            @Override
            public void onResponse(Call<List<DubuquGetGroupResponse>> call, Response<List<DubuquGetGroupResponse>> response) {
                switch (response.code()) {
                    case 200:
                        try {

                            okhttp3.Headers headerList = response.headers();
                            int resourceCount = Integer.parseInt(headerList.get(Constants.X_RESOURCE_COUNT));
                            String s = headerList.get(Constants.X_PAGE_INFO);
                            JSONObject js = new JSONObject("{" + s + "}");
                            int offset = Integer.parseInt(js.getString("current-offset"));

                            getDubuquResponse.addAll(response.body());
                            if (resourceCount == getDubuquResponse.size()) {
                                re.onResponse(getDubuquResponse);
                            } else {
                                paginateOpenGroups(getDubuquResponse.size(), 10, re);
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<List<DubuquGetGroupResponse>> call, Throwable t) {
                handleApiError(t);
            }
        });

    }

    private List<DubuquGetGroupResponse> paginateSocialGroupList(int offset, int limit, final ResponseCallBacks re) {
        Call<List<DubuquGetGroupResponse>> requestModel = mRestServiceProvider.getPaginatedGroupResponse(offset, limit);
        requestModel.enqueue(new Callback<List<DubuquGetGroupResponse>>() {
            @Override
            public void onResponse(Call<List<DubuquGetGroupResponse>> call, Response<List<DubuquGetGroupResponse>> response) {
                switch (response.code()) {
                    case 200:
                        try {

                            okhttp3.Headers headerList = response.headers();
                            int resourceCount = Integer.parseInt(headerList.get(Constants.X_RESOURCE_COUNT));
                            String s = headerList.get(Constants.X_PAGE_INFO);
                            JSONObject js = new JSONObject("{" + s + "}");
                            int offset = Integer.parseInt(js.getString("current-offset"));

                            getDubuquResponse.addAll(response.body());
                            if (resourceCount == getDubuquResponse.size()) {
                                re.onResponse(getDubuquResponse);
                            } else {
                                paginateSocialGroupList(getDubuquResponse.size(), 10, re);
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<List<DubuquGetGroupResponse>> call, Throwable t) {
                handleApiError(t);
            }
        });

        return null;
    }

    private List<GetAllSharedMediaModel> paginateMediaAvailable(int offset, int limit, final ResponseCallBacks re) {
        Call<List<GetAllSharedMediaModel>> requestModel = mRestServiceProvider.getPaginatedVaultHomeResponse(offset, limit);
        requestModel.enqueue(new Callback<List<GetAllSharedMediaModel>>() {
            @Override
            public void onResponse(Call<List<GetAllSharedMediaModel>> call, Response<List<GetAllSharedMediaModel>> response) {
                switch (response.code()) {
                    case 200:
                        try {
                            re.onResponse(response.body());

                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<List<GetAllSharedMediaModel>> call, Throwable t) {
                handleApiError(t);
            }
        });

        return null;
    }

    public void paginateUserMediaAvailable(int offset, int limit, String userIdentifier, final ResponseCallBacks<List<SharedMedia>> re) {
        Call<List<SharedMedia>> requestModel = mRestServiceProvider.paginateMediaAvailable(userIdentifier, offset, limit);
        requestModel.enqueue(new Callback<List<SharedMedia>>() {
            @Override
            public void onResponse(Call<List<SharedMedia>> call, Response<List<SharedMedia>> response) {
                switch (response.code()) {
                    case 200:
                        try {
                            re.onResponse(response.body());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<List<SharedMedia>> call, Throwable t) {
                handleApiError(t);
            }
        });

    }

    public void paginateMediashareByGorup(int offset, int limit, String userIdentifier, final ResponseCallBacks<List<SharedMedia>> re) {
        Call<List<SharedMedia>> requestModel = mRestServiceProvider.paginateGroupMediaAvailable(userIdentifier, offset, limit);
        requestModel.enqueue(new Callback<List<SharedMedia>>() {
            @Override
            public void onResponse(Call<List<SharedMedia>> call, Response<List<SharedMedia>> response) {
                switch (response.code()) {
                    case 200:
                        try {

                            re.onResponse(response.body());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<List<SharedMedia>> call, Throwable t) {
                handleApiError(t);
            }
        });

    }

    public void paginateEventMediaAvailable(int offset, int limit, String userIdentifier, final ResponseCallBacks<List<SharedMedia>> re) {
        Call<List<SharedMedia>> requestModel = mRestServiceProvider.paginateEventFullView(userIdentifier, offset, limit);
        requestModel.enqueue(new Callback<List<SharedMedia>>() {
            @Override
            public void onResponse(Call<List<SharedMedia>> call, Response<List<SharedMedia>> response) {
                switch (response.code()) {
                    case 200:
                        try {
                            re.onResponse(response.body());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<List<SharedMedia>> call, Throwable t) {
                handleApiError(t);
            }
        });

    }

    public void paginateMediaSharedToPublic(int offset, int limit, String userIdentifier, final ResponseCallBacks<List<SharedMedia>> responseCallBacks) {
        Call<List<SharedMedia>> requestModel = mRestServiceProvider.paginatePublicUserMedia(userIdentifier, offset, limit);
        requestModel.enqueue(new Callback<List<SharedMedia>>() {
            @Override
            public void onResponse(Call<List<SharedMedia>> call, Response<List<SharedMedia>> response) {
                switch (response.code()) {
                    case 200:
                        try {
                            if (response.body() != null) {
                                responseCallBacks.onResponse(response.body());
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<List<SharedMedia>> call, Throwable t) {
                handleApiError(t);
            }
        });
    }

    public void paginateEventMediaGroupAvailable(int offset, int limit, String userIdentifier, final ResponseCallBacks<List<SharedMedia>> re) {
        Call<List<SharedMedia>> requestModel = mRestServiceProvider.paginateEventGroupFullView(userIdentifier, offset, limit);
        requestModel.enqueue(new Callback<List<SharedMedia>>() {
            @Override
            public void onResponse(Call<List<SharedMedia>> call, Response<List<SharedMedia>> response) {
                switch (response.code()) {
                    case 200:
                        try {
                            re.onResponse(response.body());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<List<SharedMedia>> call, Throwable t) {
                handleApiError(t);
            }
        });

    }


    /* to get the pre-signed parameter for uploading media to Amazon S3.
    MOETHOd: GET
    media_type	String	Type of the media to upload.

    Allowed values: "media", "profile_image", "audio"

    content_type	String	File content-type to be uploaded. It should be urlencoded value.

    file_extension	String	File extension to be uploaded.

    */
    public void getSignedUrl(final ResponseCallBacks responseCallBacks, String media_type, String content_type, String file_extension,
                             String width, String height) {
        try {
            Call<SignedUrlResponseModel> responseModelCall = mRestServiceProvider.getSignedUrl(media_type, content_type, file_extension,
                    width, height);
            responseModelCall.enqueue(new Callback<SignedUrlResponseModel>() {
                @Override
                public void onResponse(Call<SignedUrlResponseModel> call, Response<SignedUrlResponseModel> response) {
                    switch (response.code()) {
                        case 200:
                            responseCallBacks.onResponse(response.body());
                            break;
                        default:
                            responseCallBacks.onFailure(response.body());
                            break;
                    }
                }

                @Override
                public void onFailure(Call<SignedUrlResponseModel> call, Throwable t) {
                    responseCallBacks.onFailure(t);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*upload images to s3
    * @params are paams are build as request body inorder to make error free request
    * @retrun null
    *mulipart post call
    * STATUS CODE:204 inidcate succes full indication of media upload
    * */
    public void uploadMediaToS3(final RequestBody X_AMZ_CREDEN, final RequestBody X_Amz_Algorithm,
                                final RequestBody X_Amz_Date, final RequestBody acl,
                                final RequestBody Policy, final RequestBody X_Amz_Signature,
                                final RequestBody key, final RequestBody content_type, final RequestBody file,
                                final ResponseCallBacks responseCallBacks,
                                final CallEvents callEvents) {
        try {
            Call<ResponseBody> responseModelCall = mRestServiceProvider.uploadImgaeToS3(X_AMZ_CREDEN,
                    X_Amz_Algorithm, X_Amz_Date, acl, Policy, X_Amz_Signature, key, content_type, file);
            responseModelCall.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    switch (response.code()) {
                        case 200:
                            Log.d(TAG, "onResponse: response code : " + response.code()
                                    + "messagee" + response.message());
                            responseCallBacks.onResponse(response.body());
                            break;
                        case 204:
                            Log.d(TAG, "onResponse: Media Uploaded sucessfully.");
                            responseCallBacks.onResponse(response.body());
                            break;
                        default:
                            Log.d(TAG, "onResponse: response code : " + response.code()
                                    + "messagee" + response.raw());
                            responseCallBacks.onFailure(response.body());
                            break;
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    Log.d(TAG, "onFailure: " + t.getMessage());
                    responseCallBacks.onFailure(t.getCause());
/*
                    uploadMediaToS3(X_AMZ_CREDEN, X_Amz_Algorithm, X_Amz_Date, acl, Policy, X_Amz_Signature, key, content_type, file, responseCallBacks, callEvents);
*/
                }
            });
            callEvents.onCallCreated(responseModelCall);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*This API is used for sharing media to people. After uploading media to S3, then it needs to be called.
    POST
    http://52.76.204.166/dubuqu-nxt/api/media/share
    media_identifiers	JSON_Array	Array of unique identifiers of the media. The media identifier will be retrieved when hitting signed-url API.
    recipient	JSON_Array	Actual audience to show the shared media. It might be mobile number and social group identifiers.*/
    public void shareMediaRequestToDubuqu(DubuquShareMediaRequest dubuquShareMediaRequest) {
        try {
            Call<ResponseBody> responseModelCall = mRestServiceProvider.shareMediaRequest(dubuquShareMediaRequest);
            responseModelCall.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    switch (response.code()) {
                        case 200:
                            Log.d(TAG, "onResponse: response code : " + response.code()
                                    + "messagee" + response.message());
                            break;
                        default:
                            handleApiError(response);
                            break;
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    handleApiError(t);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void reshareMediaRequestToDubuqu(DubuquShareMediaRequest dubuquShareMediaRequest) {
        try {
            Call<ResponseBody> responseModelCall = mRestServiceProvider.reshareMediaRequest(dubuquShareMediaRequest);
            responseModelCall.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    switch (response.code()) {
                        case 200:
                            Log.d(TAG, "onResponse: response code : " + response.code()
                                    + "messagee" + response.message());
                            break;
                        default:
                            handleApiError(response);
                            break;
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    handleApiError(t);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void reshreMediatoPublic(String mediaIdentifier) {
        try {
            Call<ResponseBody> responseModelCall = mRestServiceProvider.reshareMediaPublicrequest(mediaIdentifier);
            responseModelCall.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    switch (response.code()) {
                        case 200:
                            Log.d(TAG, "onResponse: response code : " + response.code()
                                    + "messagee" + response.message());
                            break;
                        default:
                            handleApiError(response);
                            break;
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    handleApiError(t);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * This API is used for sharing media to public. After uploading media to S3 (Using signed-url API), then it needs to be called.
     * <p>
     * POST
     * http://52.76.204.166/dubuqu-nxt/api/public-media/share
     * Request-Response
     * <p>
     * Request:
     * <p>
     * {
     * "media_identifier": "b6d767d2f8ed5d21a44b0e5886680cb9"
     * }
     * <p>
     * Response:
     * <p>
     * HTTP/1.1 200 OK
     * {
     * }
     */

    public void shareMediaToPublic(PublicShareRequestModel publicShareRequestModel) {
        try {
            Call<ResponseBody> responseModelCall = mRestServiceProvider.shareMediaPublicrequest(
                    publicShareRequestModel.getMediaIdentifier(), publicShareRequestModel);
            responseModelCall.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    switch (response.code()) {
                        case 200:
                            Log.d(TAG, "onResponse: response code : " + response.code()
                                    + "messagee" + response.message());
                            break;
                        default:
                            handleApiError(response);
                            break;
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    handleApiError(t);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * get number of users avilable in the social groups
     *
     * @param groupIdentifier:the unique identifier of the social group
     *                            call GET url:baseurl/social-group/
     */
    public void getGroupDetails(String groupIdentifier, final ResponseCallBacks responseCallBacks) {
        try {
            Call<SocialGroupDetailsResponseModel> responseBodyCall = mRestServiceProvider.getGroupDetails(groupIdentifier);
            responseBodyCall.enqueue(new Callback<SocialGroupDetailsResponseModel>() {
                @Override
                public void onResponse(Call<SocialGroupDetailsResponseModel> call, Response<SocialGroupDetailsResponseModel> response) {
                    switch (response.code()) {
                        case 200:
                            responseCallBacks.onResponse(response.body());
                            break;
                        default:
                            handleApiError(response);
                            break;
                    }
                }

                @Override
                public void onFailure(Call<SocialGroupDetailsResponseModel> call, Throwable t) {
                    handleApiError(t);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * This API is used to create a social group
     * <p>
     * POST
     * http://52.76.204.166/dubuqu-nxt/api/social-group/
     */

    public void createsocialGroup(CreateGroupRequest createGroupRequest, final ResponseCallBacks responseCallBacks) {
        try {
            Call<CreateGroupResponse> responseCall = mRestServiceProvider.createGroup(createGroupRequest);
            responseCall.enqueue(new Callback<CreateGroupResponse>() {
                @Override
                public void onResponse(Call<CreateGroupResponse> call, Response<CreateGroupResponse> response) {
                    switch (response.code()) {
                        case 200:
                            responseCallBacks.onResponse(response.body());
                            break;
                        default:
                            handleApiError(response);
                            break;
                    }
                }

                @Override
                public void onFailure(Call<CreateGroupResponse> call, Throwable t) {
                    handleApiError(t);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*Send group profile photo to the user*/
    public void uploadProfileImageToDubuquServer(UpdateGroupProfileRequest request, String groupIdentifier) {
        try {
            Call<ResponseBody> responseBodyCall = mRestServiceProvider.updategroupProfileImage(groupIdentifier, request);
            responseBodyCall.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    switch (response.code()) {
                        case 200:
                            Log.d(TAG, "onResponse: response code : " + response.code()
                                    + "messagee" + response.body());

                            break;
                        default:
                            handleApiError(response);
                            break;
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    handleApiError(t);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*delete group*/
    public void deleteGroup(String groupIdentifier, final ResponseCallBacks responseCallBacks) {
        try {
            Call<ResponseBody> responseBodyCall = mRestServiceProvider.deleteGroup(groupIdentifier);
            responseBodyCall.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    switch (response.code()) {
                        case 200:
                            responseCallBacks.onResponse(response.body());

                            break;
                        default:
                            handleApiError(response);
                            break;
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    handleApiError(t);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /*update group*/
    public void updateGroup(String groupIdentifier, CreateGroupRequest createGroupRequest, final ResponseCallBacks responseCallBacks) {
        try {
            final Call<ResponseBody> responseBodyCall = mRestServiceProvider.updateGroup(groupIdentifier, createGroupRequest);
            responseBodyCall.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    switch (response.code()) {
                        case 200:

                            responseCallBacks.onResponse(response);
                            break;
                        default:
                            handleApiError(response);
                            break;
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    handleApiError(t);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public List<PublicMediaResponseModel> fetchPublicSharedMedias(final ResponseCallBacks<List<PublicMediaResponseModel>> responseCallBacks) {
        Call<List<PublicMediaResponseModel>> call = mRestServiceProvider.getAllPublicMedia();
        call.enqueue(new Callback<List<PublicMediaResponseModel>>() {
            @Override
            public void onResponse(Call<List<PublicMediaResponseModel>> call, Response<List<PublicMediaResponseModel>> response) {
                switch (response.code()) {
                    case 200:
                        responseCallBacks.onResponse(response.body());
                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<List<PublicMediaResponseModel>> call, Throwable t) {
                handleApiError(t);
            }
        });
        return null;
    }

    public void fetchDubuquUserDetails(final ResponseCallBacks responseCallBacks, String userIdentifier) {
        Call<DubuquUserModel> calls = mRestServiceProvider.getUserDetails(userIdentifier);
        calls.enqueue(new Callback<DubuquUserModel>() {
            @Override
            public void onResponse(Call<DubuquUserModel> call, Response<DubuquUserModel> response) {
                switch (response.code()) {
                    case 200:
                        responseCallBacks.onResponse(response.body());
                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<DubuquUserModel> call, Throwable t) {
                handleApiError(t);
            }
        });
    }


    public void getMediaDetails(String mediaIdentifier, final ResponseCallBacks responseCallBacks) {
        try {
            Call<SharedMedias> responseBodyCall = mRestServiceProvider.getMediaDetails(mediaIdentifier);
            responseBodyCall.enqueue(new Callback<SharedMedias>() {
                @Override
                public void onResponse(Call<SharedMedias> call, Response<SharedMedias> response) {
                    switch (response.code()) {
                        case 200:
                            responseCallBacks.onResponse(response.body());
                            break;
                        default:
                            responseCallBacks.onFailure(response.errorBody());
                            handleApiError(response);
                            break;
                    }
                }

                @Override
                public void onFailure(Call<SharedMedias> call, Throwable t) {
                    responseCallBacks.onFailure(t);
                    handleApiError(t);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void getMediaLikeDetails(String mediaIdentifier, final ResponseCallBacks responseCallBacks) {
        try {
            Call<ResponseBody> responseBodyCall = mRestServiceProvider.getMediaLikeDetails(mediaIdentifier);
            responseBodyCall.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    switch (response.code()) {
                        case 200:
                            responseCallBacks.onResponse(response.body());
                            break;
                        default:
                            handleApiError(response);
                            break;
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    handleApiError(t);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void getMediaComments(String mediaIdentifier, int offset, int limit, final ResponseCallBacks responseCallBacks) {
        try {
            Call<List<MediaComment>> responseBodyCall = mRestServiceProvider.getMediaComments(mediaIdentifier, offset, limit);
            responseBodyCall.enqueue(new Callback<List<MediaComment>>() {
                @Override
                public void onResponse(Call<List<MediaComment>> call, Response<List<MediaComment>> response) {
                    switch (response.code()) {
                        case 200:

                            List<MediaComment> mediaComment = new ArrayList<>();
                            mediaComment.addAll(response.body());
                            responseCallBacks.onResponse(mediaComment);
                            break;
                        default:
                            handleApiError(response);
                            break;
                    }
                }

                @Override
                public void onFailure(Call<List<MediaComment>> call, Throwable t) {
                    handleApiError(t);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void getMediaStoryComments(String mediaIdentifier, int offset, int limit,
                                      final ResponseCallBacks responseCallBacks) throws Exception {

        Call<List<MediaComment>> responseBodyCall = mRestServiceProvider.getMediaStoryComments(mediaIdentifier, offset, limit);
        responseBodyCall.enqueue(new Callback<List<MediaComment>>() {
            @Override
            public void onResponse(Call<List<MediaComment>> call, Response<List<MediaComment>> response) {
                switch (response.code()) {
                    case 200:

                        List<MediaComment> mediaComment = new ArrayList<>();
                        mediaComment.addAll(response.body());
                        responseCallBacks.onResponse(mediaComment);
                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<List<MediaComment>> call, Throwable t) {
                handleApiError(t);
            }
        });
    }

    public void postMediaComments(String mediaIdentifier, final PostMediaComment postMediaComment, final ResponseCallBacks responseCallBacks) {
        try {
            Call<HomeDetailImageViewer.CommentIdentifier> responseBodyCall = mRestServiceProvider.postMediaComments(mediaIdentifier, postMediaComment);
            responseBodyCall.enqueue(new Callback<HomeDetailImageViewer.CommentIdentifier>() {
                @Override
                public void onResponse(Call<HomeDetailImageViewer.CommentIdentifier> call, Response<HomeDetailImageViewer.CommentIdentifier> response) {
                    switch (response.code()) {
                        case 200:
                            Log.d(TAG, "onResponse: response code : media details");
                            responseCallBacks.onResponse(response.body());
                            break;
                        default:
                            handleApiError(response);
                            break;
                    }
                }

                @Override
                public void onFailure(Call<HomeDetailImageViewer.CommentIdentifier> call, Throwable t) {
                    handleApiError(t);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void postMediaLikeAction(String mediaIdentifier, final String action, final MediaLikeDetails data, final ResponseCallBacks responseCallBacks) {
        try {
            Call<ResponseBody> responseBodyCall = mRestServiceProvider.postMediaLike(mediaIdentifier, action, data);
            responseBodyCall.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    switch (response.code()) {
                        case 200:
                            Log.d(TAG, "onResponse: response code : media details");
                            responseCallBacks.onResponse(response.body());
                            break;
                        default:
                            handleApiError(response);
                            break;
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    handleApiError(t);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void readComments(final String mediaIdentifier) {
        try {
            Call<ResponseBody> responseBodyCall = mRestServiceProvider.readCommets(mediaIdentifier);
            responseBodyCall.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    switch (response.code()) {
                        case 200:
                            Log.d(TAG, "onResponse: response code : media details");

                            break;
                        default:
                            handleApiError(response);
                            break;
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    handleApiError(t);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /*--------------------------------vault-----------------------------------------------------*/

    /*Need To Paginate to get All details*/
    public void fetchAllMediaSharedToUser(final ResponseCallBacks responseCallBacks) {

        Call<List<GetAllSharedMediaModel>> getAllSharedMediaModel = mRestServiceProvider.getAllSharedMedia();

        getAllSharedMediaModel.enqueue(new Callback<List<GetAllSharedMediaModel>>() {
            @Override
            public void onResponse(Call<List<GetAllSharedMediaModel>> call, final Response<List<GetAllSharedMediaModel>> response) {
                switch (response.code()) {
                    case 200:
                        try {
                            okhttp3.Headers headerList = response.headers();
                            int resourceCount = Integer.parseInt(headerList.get(Constants.X_RESOURCE_COUNT));
                            String s = headerList.get(Constants.X_PAGE_INFO);
                            JSONObject js = new JSONObject("{" + s + "}");
                            int offset = Integer.parseInt(js.getString("current-offset"));

                            if (getAllSharedMediaModelList.size() > 0) {
                                getAllSharedMediaModelList.clear();
                            }
                            getAllSharedMediaModelList.addAll(response.body());
                            if (resourceCount == getAllSharedMediaModelList.size()) {
                                responseCallBacks.onResponse(getAllSharedMediaModelList);
                            } else {
                                paginateMediaAvailable(getAllSharedMediaModelList.size(), 10, new ResponseCallBacks() {
                                    @Override
                                    public void onResponse(Object o) {
                                        responseCallBacks.onResponse(getAllSharedMediaModelList);
                                    }

                                    @Override
                                    public void onFailure(Object o) {
                                        responseCallBacks.onResponse(o);
                                    }

                                });
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<List<GetAllSharedMediaModel>> call, Throwable t) {
                handleApiError(t);
            }
        });
    }

    public void fetchMediasShareByGroup(String groupIdentifier, final ResponseCallBacks<List<SharedMedia>> responseCallBacks,
                                        final ImageAndVideoCountCallBack imageAndVideoCountCallBack) {
        Call<List<SharedMedia>> call = mRestServiceProvider.getMediaSharedByGroup(groupIdentifier);
        call.enqueue(new Callback<List<SharedMedia>>() {
            @Override
            public void onResponse(Call<List<SharedMedia>> call, Response<List<SharedMedia>> response) {
                switch (response.code()) {
                    case 200:
                        try {
                            okhttp3.Headers headerList = response.headers();
                            int resourceCount = Integer.parseInt(headerList.get(Constants.X_RESOURCE_COUNT));
                            String s = headerList.get(Constants.X_Media_Count);
                            if (s != null) {
                                JSONObject js = new JSONObject("{" + s + "}");
                                imageAndVideoCountCallBack.imageandvideocountCallback(
                                        js.getString("image"),
                                        js.getString("video")
                                );
                            }
                            responseCallBacks.onResponse(response.body());

                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<List<SharedMedia>> call, Throwable t) {
                handleApiError(t);
            }
        });

    }


    public void fetchMediaSharedByUser(String userIdentifier, final ResponseCallBacks<List<SharedMedia>> responseCallBacks,
                                       final ImageAndVideoCountCallBack imageAndVideoCountCallBack) {
        Call<List<SharedMedia>> call = mRestServiceProvider.getMediaSharedByUser(userIdentifier);
        call.enqueue(new Callback<List<SharedMedia>>() {
            @Override
            public void onResponse(Call<List<SharedMedia>> call, Response<List<SharedMedia>> response) {
                switch (response.code()) {
                    case 200:
                        try {
                            okhttp3.Headers headerList = response.headers();
                            int resourceCount = Integer.parseInt(headerList.get(Constants.X_RESOURCE_COUNT));
                            String s = headerList.get(Constants.X_Media_Count);
                            if (s != null) {
                                JSONObject js = new JSONObject("{" + s + "}");
                                imageAndVideoCountCallBack.imageandvideocountCallback(
                                        js.getString("image"),
                                        js.getString("video")
                                );
                            }
                            responseCallBacks.onResponse(response.body());

                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<List<SharedMedia>> call, Throwable t) {
                handleApiError(t);
            }
        });
    }

    public void fetchMediasSharedByUserEvents(String userIdentifier, final ResponseCallBacks<List<SharedMedia>> responseCallBacks,
                                              final ImageAndVideoCountCallBack imageAndVideoCountCallBack) {
        Call<List<SharedMedia>> call = mRestServiceProvider.getUserMEdiaEvents(userIdentifier);
        call.enqueue(new Callback<List<SharedMedia>>() {
            @Override
            public void onResponse(Call<List<SharedMedia>> call, Response<List<SharedMedia>> response) {
                switch (response.code()) {
                    case 200:
                        try {
                            okhttp3.Headers headerList = response.headers();
                            int resourceCount = Integer.parseInt(headerList.get(Constants.X_RESOURCE_COUNT));
                            String s = headerList.get(Constants.X_Media_Count);
                            if (s != null) {
                                JSONObject js = new JSONObject("{" + s + "}");
                                imageAndVideoCountCallBack.imageandvideocountCallback(
                                        js.getString("image"),
                                        js.getString("video")
                                );
                            }
                            responseCallBacks.onResponse(response.body());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<List<SharedMedia>> call, Throwable t) {
                handleApiError(t);
            }
        });
    }


    public void fetchMediasSharedByGroupEvents(String group_identifier, final ResponseCallBacks<List<SharedMedia>> responseCallBacks,
                                               final ImageAndVideoCountCallBack imageAndVideoCountCallBack) {
        Call<List<SharedMedia>> call = mRestServiceProvider.getGroupMEdiaEvents(group_identifier);
        call.enqueue(new Callback<List<SharedMedia>>() {
            @Override
            public void onResponse(Call<List<SharedMedia>> call, Response<List<SharedMedia>> response) {
                switch (response.code()) {
                    case 200:
                        try {
                            okhttp3.Headers headerList = response.headers();
                            int resourceCount = Integer.parseInt(headerList.get(Constants.X_RESOURCE_COUNT));
                            String s = headerList.get(Constants.X_Media_Count);
                            if (s != null) {
                                JSONObject js = new JSONObject("{" + s + "}");
                                imageAndVideoCountCallBack.imageandvideocountCallback(
                                        js.getString("image"),
                                        js.getString("video")
                                );
                            }

                           /* if (fetchUserMediaModelList.size() > 0) {
                                fetchUserMediaModelList.clear();
                            }
                            fetchUserMediaModelList.addAll(response.body());
                            if (resourceCount == fetchUserMediaModelList.size()) {
                                responseCallBacks.onResponse(fetchUserMediaModelList);
                            } else {
                                paginateMediaAvailable(fetchUserMediaModelList.size(), 10, new ResponseCallBacks() {
                                    @Override
                                    public void onResponse(Object o) {
                                        responseCallBacks.onResponse(fetchUserMediaModelList);
                                    }

                                    @Override
                                    public void onFailure() {
                                        responseCallBacks.onFailure();
                                    }
                                });
                            }*/
                            responseCallBacks.onResponse(response.body());

                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<List<SharedMedia>> call, Throwable t) {
                handleApiError(t);
            }
        });
    }


    public void fetchWhatsHappingValues(final ResponseCallBacks<List<WhatsHappeningModel>> responseCallBacks) {
        Call<List<WhatsHappeningModel>> request = mRestServiceProvider.getWhatsHappening();
        request.enqueue(new Callback<List<WhatsHappeningModel>>() {
            @Override
            public void onResponse(Call<List<WhatsHappeningModel>> call, Response<List<WhatsHappeningModel>> response) {
                switch (response.code()) {
                    case 200:
                        responseCallBacks.onResponse(response.body());
                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<List<WhatsHappeningModel>> call, Throwable t) {
                handleApiError(t);
            }
        });
    }

    public void fetchPublicSharedMediaByUser(final ResponseCallBacks<List<SharedMedia>> responseCallBacks, String userIdentifier,
                                             final ResourceCountCallBack resourceCountCallBack) {
        Call<List<SharedMedia>> call = mRestServiceProvider.fetchMediaSharedByUser(userIdentifier);
        call.enqueue(new Callback<List<SharedMedia>>() {
            @Override
            public void onResponse(Call<List<SharedMedia>> call, Response<List<SharedMedia>> response) {
                switch (response.code()) {
                    case 200:
                        try {
                            okhttp3.Headers headerList = response.headers();
                            int resourceCount = Integer.parseInt(headerList.get(Constants.X_RESOURCE_COUNT));
                            String s = headerList.get(Constants.X_PAGE_INFO);
                            JSONObject js = new JSONObject("{" + s + "}");
                            int offset = Integer.parseInt(js.getString("current-offset"));
                            resourceCountCallBack.mediaResponse(headerList.get(Constants.X_RESOURCE_COUNT));
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        responseCallBacks.onResponse(response.body());
                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<List<SharedMedia>> call, Throwable t) {
                handleApiError(t);
            }
        });

    }


    /*------------------------------------Search User---------------------------------------------*/
    public void seachUser(String userKey, final ResponseCallBacks<List<SearchUserModel>> responseCallBacks) {
        Call<List<SearchUserModel>> mRetrofit = mRestServiceProvider.searchUser(userKey);
        mRetrofit.enqueue(new Callback<List<SearchUserModel>>() {
            @Override
            public void onResponse(Call<List<SearchUserModel>> call, Response<List<SearchUserModel>> response) {
                switch (response.code()) {
                    case 200:
                        try {
                            responseCallBacks.onResponse(response.body());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<List<SearchUserModel>> call, Throwable t) {
                handleApiError(t);
            }
        });
    }
    /*--------------------------------------followers----------------------------------------------*/

    public void fetchFollowingList(final ResponseCallBacks<List<FollwoingUserResponse>> responseCallBacks, String userIDentifier) {
        Call<List<FollwoingUserResponse>> mRetrofit = mRestServiceProvider.fetchFollowingList(userIDentifier);
        mRetrofit.enqueue(new Callback<List<FollwoingUserResponse>>() {
            @Override
            public void onResponse(Call<List<FollwoingUserResponse>> call, Response<List<FollwoingUserResponse>> response) {
                switch (response.code()) {
                    case 200:
                        try {
                            responseCallBacks.onResponse(response.body());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<List<FollwoingUserResponse>> call, Throwable t) {
                handleApiError(t);
            }
        });
    }


    public void fetchFollowersList(final ResponseCallBacks<List<FollwoingUserResponse>> responseCallBacks, String userIDentifier) {
        Call<List<FollwoingUserResponse>> mRetrofit = mRestServiceProvider.getFollowersList(userIDentifier);
        mRetrofit.enqueue(new Callback<List<FollwoingUserResponse>>() {
            @Override
            public void onResponse(Call<List<FollwoingUserResponse>> call, Response<List<FollwoingUserResponse>> response) {
                switch (response.code()) {
                    case 200:
                        try {
                            responseCallBacks.onResponse(response.body());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<List<FollwoingUserResponse>> call, Throwable t) {
                handleApiError(t);
            }
        });
    }


    public void unfollowUser(String userIdentifier) {

        Call<ResponseBody> responseBodyCall = mRestServiceProvider.unFollowUser(userIdentifier);
        responseBodyCall.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                switch (response.code()) {
                    case 200:
                        try {
                            Log.d(TAG, "onResponse:unfollowed user");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                handleApiError(t);
            }
        });
    }

    public void followUser(String userIdentifier) {

        Call<ResponseBody> responseBodyCall = mRestServiceProvider.followUser(userIdentifier);
        responseBodyCall.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                switch (response.code()) {
                    case 200:
                        try {
                            Log.d(TAG, "onResponse:followed user");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                handleApiError(t);
            }
        });
    }

    /*----------------------------------------------Events----------------------------------------*/
    public void fetchAllUserEvents(final ResponseCallBacks<List<FetchAllUserEvent>> responseCallBacks) {
        Call<List<FetchAllUserEvent>> call = mRestServiceProvider.fetchAlluserEvents();
        call.enqueue(new Callback<List<FetchAllUserEvent>>() {
            @Override
            public void onResponse(Call<List<FetchAllUserEvent>> call, Response<List<FetchAllUserEvent>> response) {
                switch (response.code()) {
                    case 200:
                        try {
                            responseCallBacks.onResponse(response.body());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<List<FetchAllUserEvent>> call, Throwable t) {

                handleApiError(t);
            }
        });
    }

    public void deleteMedia(String mediaIdentifier) {
        Call<ResponseBody> call = mRestServiceProvider.deleteMedia(mediaIdentifier);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                switch (response.code()) {
                    case 200:
                        try {
                            Log.d(TAG, "onResponse:deleted Media");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                handleApiError(t);
            }
        });
    }

    /*__________________________________TIME LINE NEW API CALLS___________________________________*/

    public void fetchAllMediasSharedToUserTimeLine(final ResponseCallBacks responseCallBacks,
                                                   final ResourceCountCallBack resourceCountCallBack) {

        Call<List<GetAllMediaTimeLine>> call = mRestServiceProvider.getMediasSharedToUserTimeline();
        call.enqueue(new Callback<List<GetAllMediaTimeLine>>() {
            @Override
            public void onResponse(Call<List<GetAllMediaTimeLine>> call, Response<List<GetAllMediaTimeLine>> response) {
                switch (response.code()) {
                    case 200:
                        try {
                            okhttp3.Headers headerList = response.headers();
                            resourceCountCallBack.mediaResponse(headerList.get(Constants.X_RESOURCE_COUNT));
                            responseCallBacks.onResponse(response.body());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                    default:
                        handleApiError(response);
                        responseCallBacks.onFailure(null);
                        break;
                }
            }

            @Override
            public void onFailure(Call<List<GetAllMediaTimeLine>> call, Throwable t) {
                responseCallBacks.onFailure(null);
                handleApiError(t);
            }
        });
    }


    public void fetchAllMediasSharedToUserTimeLine(final ResponseCallBacks responseCallBacks,
                                                   String groupIdentifier,
                                                   final ResourceCountCallBack resourceCountCallBack) {

        Call<List<GetAllMediaTimeLine>> call = mRestServiceProvider.getMediasSharedToUserTimeline(groupIdentifier);
        call.enqueue(new Callback<List<GetAllMediaTimeLine>>() {
            @Override
            public void onResponse(Call<List<GetAllMediaTimeLine>> call, Response<List<GetAllMediaTimeLine>> response) {
                switch (response.code()) {
                    case 200:
                        try {
                            okhttp3.Headers headerList = response.headers();

                            resourceCountCallBack.mediaResponse(headerList.get(Constants.X_RESOURCE_COUNT));

                            responseCallBacks.onResponse(response.body());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                    default:

                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<List<GetAllMediaTimeLine>> call, Throwable t) {

                handleApiError(t);
            }
        });
    }

    public void paginatetTimeLineResouces(String timeLineIdentifier,
                                          final ResponseCallBacks responseCallBacks,
                                          @Nullable final ResourceCountCallBack resourceCountCallBack,
                                          int offset) {

        Call<List<SharedMedias>> call = mRestServiceProvider.paginateTimeLineReource(
                timeLineIdentifier, offset);
        call.enqueue(new Callback<List<SharedMedias>>() {
            @Override
            public void onResponse(Call<List<SharedMedias>> call, Response<List<SharedMedias>> response) {
                switch (response.code()) {
                    case 200:
                        try {
                            okhttp3.Headers headerList = response.headers();

                            responseCallBacks.onResponse(response.body());
                            if (resourceCountCallBack != null) {
                                resourceCountCallBack.mediaResponse(headerList.get(Constants.X_RESOURCE_COUNT));
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                    default:
                        responseCallBacks.onFailure(null);
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<List<SharedMedias>> call, Throwable t) {
                responseCallBacks.onFailure(null);
                handleApiError(t);
            }
        });
    }

    public void getStoryMedias(String timeLineIdentifier, final ResponseCallBacks responseCallBacks, int offset) {

        Call<List<SharedMedias>> call = mRestServiceProvider.getStoryMedias(
                timeLineIdentifier, offset, 10);
        call.enqueue(new Callback<List<SharedMedias>>() {
            @Override
            public void onResponse(Call<List<SharedMedias>> call, Response<List<SharedMedias>> response) {
                switch (response.code()) {
                    case 200:
                        try {
                            responseCallBacks.onResponse(response.body());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<List<SharedMedias>> call, Throwable t) {
                handleApiError(t);
            }
        });
    }

    public void paginateTimelineList(final ResponseCallBacks responseCallBacks, int offset) {

        Call<List<GetAllMediaTimeLine>> call = mRestServiceProvider.paginateTimeLineList(offset);
        call.enqueue(new Callback<List<GetAllMediaTimeLine>>() {
            @Override
            public void onResponse(Call<List<GetAllMediaTimeLine>> call,
                                   Response<List<GetAllMediaTimeLine>> response) {
                switch (response.code()) {
                    case 200:
                        try {
                            responseCallBacks.onResponse(response.body());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<List<GetAllMediaTimeLine>> call, Throwable t) {
                handleApiError(t);
            }
        });

    }


    public void paginateTimelineList(final ResponseCallBacks responseCallBacks, int offset,
                                     String groupIdentifier) {

        Call<List<GetAllMediaTimeLine>> call = mRestServiceProvider.paginateTimeLineList(
                offset,
                groupIdentifier);
        call.enqueue(new Callback<List<GetAllMediaTimeLine>>() {
            @Override
            public void onResponse(Call<List<GetAllMediaTimeLine>> call,
                                   Response<List<GetAllMediaTimeLine>> response) {
                switch (response.code()) {
                    case 200:
                        try {
                            responseCallBacks.onResponse(response.body());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<List<GetAllMediaTimeLine>> call, Throwable t) {
                handleApiError(t);
            }
        });
    }

    public void addCaptions(String captions, String mediaIdentifier) {

        Call<ResponseBody> call = mRestServiceProvider.updateCaptions(new Captions(captions), mediaIdentifier);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                handleApiError(t);
            }
        });
    }

    public void getTimelineStories(int offset,
                                   final ResourceCountCallBack countCallBack,
                                   final ResponseCallBacks responseCallBacks) throws Exception {
        Call<List<GetTimeLineStory>> call = mRestServiceProvider.getTimelineStory(offset, 10);
        call.enqueue(new Callback<List<GetTimeLineStory>>() {
            @Override
            public void onResponse(Call<List<GetTimeLineStory>> call,
                                   Response<List<GetTimeLineStory>> response) {
                switch (response.code()) {
                    case 200:
                        try {
                            okhttp3.Headers headerList = response.headers();

                            countCallBack.mediaResponse(headerList.get(Constants.X_RESOURCE_COUNT));

                            responseCallBacks.onResponse(response.body());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                    default:
                        responseCallBacks.onFailure(response.errorBody());
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<List<GetTimeLineStory>> call, Throwable t) {
                responseCallBacks.onFailure(t);
                handleApiError(t);
            }
        });
    }

    public void postParnetMediaComment(String commentIdentifier, PostMediaComment postMediaComment,
                                       final ResponseCallBacks responseCallBacks) {

        Call<HomeDetailImageViewer.CommentIdentifier> responseBodyCall = mRestServiceProvider.postParnetComment(commentIdentifier, postMediaComment);
        responseBodyCall.enqueue(new Callback<HomeDetailImageViewer.CommentIdentifier>() {
            @Override
            public void onResponse(Call<HomeDetailImageViewer.CommentIdentifier> call,
                                   Response<HomeDetailImageViewer.CommentIdentifier> response) {
                switch (response.code()) {
                    case 200:
                        Log.d(TAG, "onResponse: response code : media details");
                        responseCallBacks.onResponse(response.body());
                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<HomeDetailImageViewer.CommentIdentifier> call, Throwable t) {
                handleApiError(t);
            }
        });
    }



    /*----------------------------------Notification----------------------------------------------*/

    public void getNotification(final ResponseCallBacks responseCallBacks,
                                final ResourceCountCallBack resourceCountCallBack,
                                int offset) {
        /*offset, 10*/
        Call<List<NotificationModel>> call = mRestServiceProvider.getAllNotifications(offset, 10);

        call.enqueue(new Callback<List<NotificationModel>>() {
            @Override
            public void onResponse(Call<List<NotificationModel>> call,
                                   Response<List<NotificationModel>> response) {
                switch (response.code()) {
                    case 200:
                        try {
                            okhttp3.Headers headerList = response.headers();

                            resourceCountCallBack.mediaResponse(headerList.get(Constants.X_RESOURCE_COUNT));

                            responseCallBacks.onResponse(response.body());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<List<NotificationModel>> call, Throwable t) {
                handleApiError(t);
            }
        });
    }

    public void markNotificationAsRead(final String notificationIdentifier) {
        Call<ResponseBody> call = mRestServiceProvider.markNotificationRead(notificationIdentifier);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                switch (response.code()) {
                    case 200:
                        Log.e(RestServiceController.class.getName(), "Notification Read" + notificationIdentifier);
                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                handleApiError(t);
            }
        });
    }

    /*----------------------------------Block-Report_exit----------------------------------*/


    public void getBlockedUserList(final ResponseCallBacks responseCallBacks,
                                   final ResourceCountCallBack resourceCountCallBack,
                                   int offset) {
        /*offset, 10*/
        Call<List<BlockedUserModel>> call = mRestServiceProvider.getBlockedUserlist(offset, 10);

        call.enqueue(new Callback<List<BlockedUserModel>>() {
            @Override
            public void onResponse(Call<List<BlockedUserModel>> call,
                                   Response<List<BlockedUserModel>> response) {
                switch (response.code()) {
                    case 200:
                        try {
                            okhttp3.Headers headerList = response.headers();

                            resourceCountCallBack.mediaResponse(headerList.get(Constants.X_RESOURCE_COUNT));

                            responseCallBacks.onResponse(response.body());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<List<BlockedUserModel>> call, Throwable t) {
                handleApiError(t);
            }
        });
    }

    public void blockUser(String userIdentifer) {
        final Call<ResponseBody> blockUserCall = mRestServiceProvider.blockUser(userIdentifer);
        blockUserCall.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                switch (response.code()) {
                    case 200:
                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                handleApiError(t);
            }
        });
    }

    public void unblockUser(String userIdentifier) {
        final Call unblockUser = mRestServiceProvider.unblockUser(userIdentifier);
        unblockUser.enqueue(new Callback() {
            @Override
            public void onResponse(Call call, Response response) {
                switch (response.code()) {
                    case 200:
                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call call, Throwable t) {
                handleApiError(t);
            }
        });
    }

    public void exitgroup(String groupIdentifier) {
        final Call<ResponseBody> exitGroup = mRestServiceProvider.exitGroup(groupIdentifier);
        exitGroup.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                switch (response.code()) {
                    case 200:
                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                handleApiError(t);
            }
        });
    }


    public void reportSpam(String mediaIdentifier) {
        final Call<ResponseBody> reportSpam = mRestServiceProvider.reportSpam(mediaIdentifier);
        reportSpam.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                switch (response.code()) {
                    case 200:
                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                handleApiError(t);
            }
        });
    }

    /*--------------------------------GIF--------------------------------------------------------*/

    public void getRandomGifs(int offset, int limit, final ResponseCallBacks responseCallBacks) {
        Call<GifResponse> randomGifCall = mRestServiceProvider.getRandomGif(offset, limit, Constants.TENOR_APIL_KEY);
        randomGifCall.enqueue(new Callback<GifResponse>() {
            @Override
            public void onResponse(Call<GifResponse> call, Response<GifResponse> response) {
                switch (response.code()) {
                    case 200:
                        responseCallBacks.onResponse(response);
                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<GifResponse> call, Throwable t) {

                handleApiError(t);
            }
        });
    }

    public void searchGifs(String query, int offset, int limit, final ResponseCallBacks responseCallBacks) {

        Call<GifResponse> randomGifCall = mRestServiceProvider.searchGif(offset, limit, Constants.TENOR_APIL_KEY, query);
        randomGifCall.enqueue(new Callback<GifResponse>() {
            @Override
            public void onResponse(Call<GifResponse> call, Response<GifResponse> response) {
                switch (response.code()) {
                    case 200:
                        responseCallBacks.onResponse(response);
                        break;
                    default:
                        handleApiError(response);
                        break;
                }
            }

            @Override
            public void onFailure(Call<GifResponse> call, Throwable t) {

                handleApiError(t);
            }
        });
    }
    /*-------------------------------callbacks---------------------------------------------------*/

    public interface CallEvents {
        void onCallCreated(Call<ResponseBody> responseBodyCall);
    }

    public interface ResourceCountCallBack {
        void mediaResponse(String count);
    }

    public interface ImageAndVideoCountCallBack {
        void imageandvideocountCallback(String imageCount, String videoCount);
    }

    /*
    *response call backs
    * */
    public interface ResponseCallBacks<T> {
        void onResponse(T t);


        void onFailure(T t);
    }

    private void handleApiError(Object o) {
        if (o != null) {

            try {
                if (o instanceof retrofit2.Response) {
                    ResponseBody responseBody = ((Response) o).errorBody();
                    if (responseBody != null) {
                        String value = responseBody.string();
                        ErrorBodyModel errorBodyModel = new Gson().fromJson(value, ErrorBodyModel.class);
                        if (errorBodyModel != null) {

                            Utils.showNegativeTost(AppController.getInstance(), errorBodyModel.getMessage());
                        }

                    }
                } else if (o instanceof Throwable) {

                    Utils.showNegativeTost(AppController.getInstance(),
                            AppController.getInstance().getString(R.string.sp_no_internet_connection)
                    );
                }

            } catch (Exception e) {
                Log.e(RestServiceController.class.getName(), e.getMessage());
            }
        }
    }
}
