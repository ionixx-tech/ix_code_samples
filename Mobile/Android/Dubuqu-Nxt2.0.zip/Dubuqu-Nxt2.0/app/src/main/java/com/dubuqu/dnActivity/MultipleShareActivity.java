package com.dubuqu.dnActivity;

import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.MimeTypeMap;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.dubuqu.R;
import com.dubuqu.dnAdapter.common.MultiShareAdapter;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnModels.commonModel.DubuqContactsShareModel;
import com.dubuqu.dnModels.requestModel.DubuquShareMediaRequest;
import com.dubuqu.dnRestServices.RestServiceController;
import com.dubuqu.dnRestServices.RestServiceProvider;
import com.dubuqu.dnStorage.DbHelper;
import com.dubuqu.dnStorage.RecentShareDbModel;
import com.dubuqu.dnUtils.RestServiceUtils;
import com.dubuqu.dnUtils.Utils;
import com.dubuqu.dnViews.linearStickView.StickyLayoutManager;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;

/**
 * Created by Yogaraj subramanian on 12/10/17
 */

public class MultipleShareActivity extends BaseActivity {

    private final String TAG = MultipleShareActivity.class.getName();

    private List<DubuqContactsShareModel> dubuqContactsShareModels = new ArrayList<>();

    private ImageView shareMediaImageView, popBackImv;

    private SearchView searchView;

    private List<String> selectedUsers = new ArrayList<>();

    private List<String> selectedMediaPath = new ArrayList<>();

    private boolean shouldDelteOriginalMedia = false, isRepostMedia = false;

    private TextView textView, selecteAlltTxV;

    private MultiShareAdapter multiShareAdapter;

    private String mediaIdentifier = null;

    private int[] memeberCount = new int[]{0, 0, 0};

    Intent intent;

    FrameLayout loader;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        setContentView(R.layout.muliplesharefragmentview);

        try {

            intent = getIntent();

            readDetails();

            initalizeView();

        } catch (Exception e) {
            super.writeCrashReport(TAG, e.getMessage());
        }
    }


    @Override
    protected void onResume() {
        super.onResume();

        if (Constants.RESTRICT_SREENSHOT)
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
    }

    /**
     * intialviews for the activity
     */
    private void initalizeView() throws Exception {

        RecyclerView recyclerView = findViewById(R.id.multishare_activity_rcv);

        multiShareAdapter = new MultiShareAdapter(dubuqContactsShareModels, dubuqContactsShareModels,
                MultipleShareActivity.this,
                new MultiShareAdapter.OnuserSelectedListener() {
                    @Override
                    public void onUserSelected(int p) {
                        if (p != 0) {
                            shareMediaImageView.setVisibility(View.VISIBLE);
                            textView.setText(String.valueOf(p).concat("\t Contact Selected"));
                        } else {
                            textView.setText(getString(R.string.contacts));
                            shareMediaImageView.setVisibility(View.GONE);

                        }
                    }

                    @Override
                    public void onSelectAll(boolean toSelect, Utils.DUBUQU_CATEGORY dubuqu_category) {
                        try {
                            selectOrDeselectAll(toSelect, dubuqu_category);
                        } catch (Exception e) {
                            writeCrashReport(TAG, e.getMessage());
                        }
                    }
                }, memeberCount);

        StickyLayoutManager stickyLayoutManager =
                new StickyLayoutManager(MultipleShareActivity.this, multiShareAdapter);

        recyclerView.setLayoutManager(stickyLayoutManager);

        recyclerView.setAdapter(multiShareAdapter);

        multiShareAdapter.setStickyLayoutManager(stickyLayoutManager);

        shareMediaImageView = findViewById(R.id.multishare_activity_toolbar_send);

        shareMediaImageView.setVisibility(View.GONE);

        textView = findViewById(R.id.multishare_activity_toolbar_text);

        selecteAlltTxV = findViewById(R.id.selectAllTextView);

        popBackImv = findViewById(R.id.multishare_activity_toolbar_back);

        loader = findViewById(R.id.multishare_activity_loader);
        loader.setVisibility(View.GONE);

        /*searchView = findViewById(R.id.search_layout);
        searchView.setVisibility(View.GONE);*/

        searchView = findViewById(R.id.socialcircleactionsearch);

       /* searchUser = findViewById(R.id.socialcircle_search_edittext);

        searchUser = findViewById(R.id.socialcircle_search_edittext);
        */
        initializeListeners();
    }

    private void initializeListeners() throws Exception {


        shareMediaImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                try {

                    searchView.setVisibility(View.GONE);

                    loader.setVisibility(View.VISIBLE);

                    shareMedias();

                } catch (Exception e) {
                    MultipleShareActivity.super.writeCrashReport(TAG,
                            e.getMessage());
                }
            }
        });

        popBackImv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Utils.hideSoftKeyBoard(MultipleShareActivity.this);
                finish();
            }
        });

        selecteAlltTxV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (selecteAlltTxV.getText().toString().equalsIgnoreCase(getString(R.string.select_all))) {
                    //select
                    selecteAlltTxV.setText(getString(R.string.deselect_all));
                    try {
                        selectOrDeselectAll(true);
                    } catch (Exception e) {
                        MultipleShareActivity.super.writeCrashReport(TAG,
                                e.getMessage());
                    }
                } else {
                    //deselect
                    selecteAlltTxV.setText(getString(R.string.select_all));
                    try {
                        selectOrDeselectAll(false);
                    } catch (Exception e) {
                        MultipleShareActivity.super.writeCrashReport(TAG,
                                e.getMessage());
                    }
                }
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                try {
                    actionSearch(newText);
                } catch (Exception e) {
                    MultipleShareActivity.super.writeCrashReport(TAG, e.getMessage());
                }
                return true;
            }
        });
      /*  searchView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

              *//*  if (searchView.getVisibility() == View.GONE)
                    searchView.setVisibility(View.VISIBLE);*//*

                searchView.setVisibility(View.GONE);

                *//*searchUser.requestFocus();*//*

                Utils.showSoftKeyBoard(MultipleShareActivity.this);
            }
        });*/

    }

    private void actionSearch(CharSequence s) {
        multiShareAdapter.getFilter().filter(s);
    }


    private void shareMedias() throws Exception {

        getSelectedUsers();

        sendBroadcast(new Intent(Constants.UPDATERECENTSHARE));

        handleIntentContent();

        if (selectedUsers.size() < 0) {

            Toast.makeText(MultipleShareActivity.this, "Please Select atleast one contact to share", Toast.LENGTH_LONG).show();
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    loader.setVisibility(View.GONE);
                }
            });

        } else if (!isRepostMedia) {

            Gson g = new Gson();

            String json = null;

            json = g.toJson(selectedMediaPath);

            String SselectedUsers = g.toJson(selectedUsers);

            RestServiceUtils.scheduleUploadMediaFile(MultipleShareActivity.this,
                    json,
                    SselectedUsers,
                    shouldDelteOriginalMedia);

            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    loader.setVisibility(View.GONE);
                }
            });

            onBackPressed();
        } else {
            repostMedia();
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    loader.setVisibility(View.GONE);
                }
            });
        }

    }


    private void handleIntentContent() throws Exception {

        String action = intent.getAction();
        String type = intent.getType();

        Bundle extras = intent.getExtras();

        if (extras != null) {
            isRepostMedia = extras.getBoolean(Constants.RESHAREMEDIA);
            mediaIdentifier = extras.getString(Constants.MEDIA_IDENTIFIER);
        }

            /*single image is send to from other applications*/
        if (Intent.ACTION_SEND.equals(action) && type != null) {

            if (type.startsWith("image/")) {
                handleSendImage(intent);
            }

            if (type.startsWith("video/")) {
                handleSendImage(intent);
            }

        } else if (Intent.ACTION_SEND_MULTIPLE.equals(action)) {
            handleSendMultipleImages(intent);
        } else if (!isRepostMedia) {

            Bundle bundle = getIntent().getExtras();
            if (bundle != null) {
                String mediaListString = bundle.getString(Constants.EXTRASTRINGS);

                selectedMediaPath = new Gson().fromJson(mediaListString, new TypeToken<List<String>>() {
                }.getType());
            }
        }
    }

    private void repostMedia() throws Exception {
        List<String> mediaIdentifierList = new ArrayList<String>();
        mediaIdentifierList.add(mediaIdentifier);
        DubuquShareMediaRequest dubuquShareMediaRequest = new DubuquShareMediaRequest();
        dubuquShareMediaRequest.setMediaIdentifiers(mediaIdentifierList);
        dubuquShareMediaRequest.setRecipient(selectedUsers);
        Gson gson = new Gson();
        String shareData = gson.toJson(dubuquShareMediaRequest);
        OkHttpClient okHttpClient = RestServiceUtils.getHeader(shareData, MultipleShareActivity.this);
        Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
        RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
        RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
        mRetrofitCallBacks.reshareMediaRequestToDubuqu(dubuquShareMediaRequest);
        Utils.showToast(MultipleShareActivity.this, "Reposted successfully");
        onBackPressed();
    }

    private void getSelectedUsers() throws Exception {
        for (DubuqContactsShareModel dubuqShareMediaModel : dubuqContactsShareModels) {
            if (dubuqShareMediaModel.isSelected()) {

                switch (dubuqShareMediaModel.getCategory()) {
                    case DUBUQU_CONTACT:
                        selectedUsers.add(dubuqShareMediaModel.getModileNumber());
                        break;
                    case PHONE_CONTACT:
                        selectedUsers.add(dubuqShareMediaModel.getModileNumber());
                        break;
                    case SOCIAL_GROUP:
                        selectedUsers.add(dubuqShareMediaModel.getIdentifier());
                        break;
                    case SOCIAL_OPEN_GROUP:
                        selectedUsers.add(dubuqShareMediaModel.getIdentifier());
                        break;
                }
                updateTodatabase(dubuqShareMediaModel);
            }
        }
    }

    //check if any user selected
    private boolean checkIfanyUSerisSelected() {
        for (DubuqContactsShareModel dubuqShareMediaModel : dubuqContactsShareModels) {
            if (dubuqShareMediaModel.isSelected()) {
                return true;
            }
        }
        return false;
    }

    private void handleSendMultipleImages(Intent intent) throws Exception {

        ArrayList<Uri> imageUris = intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
        if (imageUris != null) {
            for (Uri uri : imageUris) {

                String type = getMimeType(uri);

                String filePath = "";

                if (type != null && Utils.checkIsImageType(type)) {

                    filePath = getRealPathFromURI(uri, true);

                    if (!Utils.isVaildString(filePath)) {

                        filePath = getLocalFilePath(uri);

                        if (!Utils.isVaildString(filePath)) {
                            super.showToastMessage("Invalid Media is Send", false);
                            finish();
                        } else {
                            selectedMediaPath.add(filePath);
                        }
                    } else {
                        selectedMediaPath.add(filePath);
                    }
                } else if (type != null && Utils.checkIsVideoType(type)) {

                    filePath = getRealPathFromURI(uri, false);

                    if (Utils.isVaildString(filePath)) {
                        selectedMediaPath.add(filePath);
                    } else {
                        selectedMediaPath.add(uri.toString());
                    }

                }
            }
        }
    }

    private void handleSendImage(Intent intent) throws Exception {
        if (intent.getType().contains("image/")) {
            Uri imageUri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            if (imageUri != null) {

                String filePath = "";

                if (imageUri.toString().contains("content://")) {
                    filePath = getRealPathFromURI(imageUri, true);
                } else {
                    filePath = imageUri.getPath();
                }

                if (Utils.isVaildString(filePath)) {
                    selectedMediaPath.add(filePath);
                } else {
                    filePath = getLocalFilePath(imageUri);
                    if (Utils.isVaildString(filePath)) {
                        selectedMediaPath.add(filePath);
                    } else {
                        super.showToastMessage("Invalid Media Send", false);
                        finish();
                    }
                }

            }
        } else if (intent.getType().contains("video/")) {

            Uri imageUri = intent.getData();

            if (imageUri != null) {
                selectedMediaPath.add(imageUri.getPath());
            } else {
                imageUri = intent.getParcelableExtra(Intent.EXTRA_STREAM);

                if (imageUri.toString().contains("content://")) {
                    String mediaContentPath = getRealPathFromURI(imageUri, false);
                    if (mediaContentPath != null) {
                        selectedMediaPath.add(mediaContentPath);
                    } else {

                        checkIfMediaIsavailableInLocal(imageUri);

                        selectedMediaPath.add(imageUri.toString());
                    }
                } else {
                    selectedMediaPath.add(imageUri.getPath());
                }

            }
        }
    }


    public String getLocalFilePath(Uri imageUri) throws Exception {

        if (imageUri.toString().contains("content://")) {

            InputStream inputStream =
                    getContentResolver().openInputStream(imageUri);

            File filesDir = getCacheDir();
            File imageFile = new File(filesDir, Math.random() + ".jpg");

            if (inputStream != null) {

                OutputStream os = new FileOutputStream(imageFile);

                byte[] buffer = new byte[1024];
                int bytesRead;
                //read from is to buffer
                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    os.write(buffer, 0, bytesRead);
                }
                inputStream.close();
                //flush OutputStream to write any buffered data to file
                os.flush();
                os.close();
            }

            return imageFile.getPath();
        }

        return null;
    }


    public String getRealPathFromURI(Uri contentUri, boolean isImage) {

        Cursor cursor = null;
        String[] proj;
        try {

            if (isImage) {
                proj = new String[]{MediaStore.Images.Media.DATA};
            } else {
                proj = new String[]{MediaStore.Video.Media.DATA};
            }
            cursor = getContentResolver().query(contentUri, null,
                    null, null,
                    null);

            int columnCount = cursor.getColumnCount();
            int count = cursor.getCount();

            int column_index = cursor.getColumnIndexOrThrow(isImage ?
                    MediaStore.Images.Media.DATA :
                    MediaStore.Video.Media.DATA);

            cursor.moveToFirst();

            return cursor.getString(column_index);
        } catch (Exception e) {
            return null;
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    private void checkIfMediaIsavailableInLocal(Uri contentUri) throws Exception {
        Cursor cursor = null;
        String[] proj;
        try {

            cursor = getContentResolver().query(contentUri,
                    null,
                    null,
                    null,
                    null);

            if (cursor.getCount() > 0) {

                cursor.moveToFirst();

                int columnCOunt;

                String selection = MediaStore.Files.FileColumns.DISPLAY_NAME + "="
                        + cursor.getString(1);

                String[] projection = new String[]{
                        MediaStore.Files.FileColumns.DATA
                };

                cursor.close();


                cursor = getContentResolver().query(contentUri,
                        projection,
                        selection
                        , null, null);

                if (cursor != null && cursor.getCount() > 0 && cursor.moveToFirst()) {

                    String coumnValue = cursor.getColumnName(cursor.getColumnIndex("_data"));

                    writeCrashReport(TAG, coumnValue);
                }

            }
            cursor.close();

        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        }
    }

    /**
     * read phone and group contacts available
     */
    private void readDetails() throws Exception {
        try {
            File file = new File(getCacheDir(), Constants.JSONFILENAME);
            FileInputStream fis = new FileInputStream(file.getAbsolutePath());
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader bufferedReader = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                sb.append(line);
            }
            Gson gson = new Gson();

            List<DubuqContactsShareModel> dubuqContactsShareModelList = gson.fromJson(sb.toString(),
                    new TypeToken<List<DubuqContactsShareModel>>() {
                    }.getType());
            updateValues(dubuqContactsShareModelList);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * since inital value must be public contact so the first value is inserted as public
     *
     * @param dubuqContactsShareModelList the available contact and groups{both open and closed}
     */
    private void updateValues(List<DubuqContactsShareModel> dubuqContactsShareModelList) {

        List<DubuqContactsShareModel> phoneContacts = new ArrayList<>();
        List<DubuqContactsShareModel> dubuquContacts = new ArrayList<>();
        List<DubuqContactsShareModel> ownGroup = new ArrayList<>();


        for (DubuqContactsShareModel dubuqContactsShareModel : dubuqContactsShareModelList) {

            switch (dubuqContactsShareModel.getCategory()) {

                case DUBUQU_CONTACT:
                    dubuquContacts.add(dubuqContactsShareModel);
                    break;
                case PHONE_CONTACT:
                    phoneContacts.add(dubuqContactsShareModel);
                    break;
                case SOCIAL_GROUP:
                    ownGroup.add(dubuqContactsShareModel);
                    break;
                case SOCIAL_OPEN_GROUP:
                    ownGroup.add(dubuqContactsShareModel);
                    break;
            }
        }

        if (ownGroup.size() > 0) {
            DubuqContactsShareModel dubuqContactsShareModel = new DubuqContactsShareModel(
                    Constants.OWNGROUPS,
                    "", "", "", Utils.DUBUQU_CATEGORY.HEADER);
            dubuqContactsShareModels.add(dubuqContactsShareModel);
            dubuqContactsShareModels.addAll(ownGroup);
            memeberCount[0] = ownGroup.size();
        }

        if (dubuquContacts.size() > 0) {
            DubuqContactsShareModel dubuqContactsShareModel = new DubuqContactsShareModel(Constants.DUBUQUCONTACTS,
                    "", "", "", Utils.DUBUQU_CATEGORY.HEADER);
            dubuqContactsShareModels.add(dubuqContactsShareModel);
            dubuqContactsShareModels.addAll(dubuquContacts);
            memeberCount[1] = dubuquContacts.size();
        }

        if (phoneContacts.size() > 0) {
            DubuqContactsShareModel dubuqContactsShareModel = new DubuqContactsShareModel(Constants.CONTACTS,
                    "", "", "", Utils.DUBUQU_CATEGORY.HEADER);
            dubuqContactsShareModels.add(dubuqContactsShareModel);
            dubuqContactsShareModels.addAll(phoneContacts);
            memeberCount[2] = phoneContacts.size();
        }

    }


    private void updateTodatabase(DubuqContactsShareModel dubuqContactsShareModel) throws Exception {

        DbHelper helper = new DbHelper(MultipleShareActivity.this);

        RecentShareDbModel recentShare = new RecentShareDbModel();
        recentShare.setUserName(dubuqContactsShareModel.getUserName());
        recentShare.setProfilePic(dubuqContactsShareModel.getProfilePicture());
        switch (dubuqContactsShareModel.getCategory()) {
            case DUBUQU_CONTACT:
                recentShare.setIdentifier(dubuqContactsShareModel.getModileNumber());
                break;
            case PHONE_CONTACT:
                recentShare.setIdentifier(dubuqContactsShareModel.getModileNumber());
                break;
            case SOCIAL_GROUP:
                recentShare.setIdentifier(dubuqContactsShareModel.getIdentifier());
                break;
            case SOCIAL_OPEN_GROUP:
                recentShare.setIdentifier(dubuqContactsShareModel.getIdentifier());
                break;
        }
        helper.insertUser(recentShare);

    }

    /**
     * Select or De-Select all contacts avaliable in multi share view
     *
     * @param isToSelectAllContact true =>  select all false=> deselect all
     * @throws Exception {Runtime Stub Exception}
     */
    private void selectOrDeselectAll(boolean isToSelectAllContact) throws Exception {

        for (int i = 0; i < dubuqContactsShareModels.size(); i++)
            dubuqContactsShareModels.get(i).setSelected(isToSelectAllContact);

        multiShareAdapter.notifyDataSetChanged();

        if (isToSelectAllContact) {
            shareMediaImageView.setVisibility(View.VISIBLE);
            textView.setText(String.valueOf(dubuqContactsShareModels.size()).concat("\t Contact Selected"));
        } else {
            textView.setText(getString(R.string.contacts));
            shareMediaImageView.setVisibility(View.GONE);
        }
    }

    /**
     * Select or De-Select all contacts avaliable under a particular section
     *
     * @param isToSelectAllContact {@link Boolean} the state of check box
     * @param category             {@link Utils.DUBUQU_CATEGORY} the category that need to be selected
     * @throws Exception {Runtime Stub Exception}
     */
    private void selectOrDeselectAll(boolean isToSelectAllContact, Utils.DUBUQU_CATEGORY category) throws Exception {
        for (DubuqContactsShareModel shareModel : dubuqContactsShareModels) {
            if (shareModel.getCategory() == category) {
                shareModel.setSelected(isToSelectAllContact);
            }
        }
        multiShareAdapter.notifyDataSetChanged();
    }

    private String getMimeType(Uri uri) {

        String extension;
        //Check uri format to avoid null
        if (uri.getScheme().equals(ContentResolver.SCHEME_CONTENT)) {
            //If scheme is a content
            final MimeTypeMap mime = MimeTypeMap.getSingleton();
            extension = mime.getExtensionFromMimeType(getContentResolver().getType(uri));
        } else {
            //If scheme is a File
            //This will replace white spaces with %20 and also other special characters. This will avoid returning null values on file name with spaces and special characters.
            extension = MimeTypeMap.getFileExtensionFromUrl(Uri.fromFile(new File(uri.getPath())).toString());

        }

        return extension;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        finish();

    }
}
