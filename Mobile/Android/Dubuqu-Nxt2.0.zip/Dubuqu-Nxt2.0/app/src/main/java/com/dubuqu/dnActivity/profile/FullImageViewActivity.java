package com.dubuqu.dnActivity.profile;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.WindowManager;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.dubuqu.R;
import com.dubuqu.dnActivity.BaseActivity;
import com.dubuqu.dnConstants.Constants;
import com.github.chrisbanes.photoview.PhotoView;

/**
 * Created by Yogaraj subramanian on 22/1/18
 */

public class FullImageViewActivity extends BaseActivity {

    PhotoView imageView;

    String profileUri;

    @Override
    protected void onResume() {
        super.onResume();
        if (Constants.RESTRICT_SREENSHOT)
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fullview);

        profileUri = getIntent().getStringExtra(Constants.IMAGEURI);

        imageView = findViewById(R.id.fullview_imageview);
        imageView.setMaximumScale(10f);

        if (profileUri != null) {
            Glide.with(FullImageViewActivity.this)
                    .load(profileUri)
                    .dontAnimate()
                    .dontTransform()
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(imageView);
        }
    }

}
