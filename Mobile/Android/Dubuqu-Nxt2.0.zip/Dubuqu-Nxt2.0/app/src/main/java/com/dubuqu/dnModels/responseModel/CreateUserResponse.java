package com.dubuqu.dnModels.responseModel;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Yogaraj subramanian on 25/10/17
 */

public class CreateUserResponse {

    @SerializedName("user_identifier")
    private String user_identifier;

    @SerializedName("secret_key")
    private String secret_key;


    public String getUser_identifier() {
        return user_identifier;
    }

    public void setUser_identifier(String user_identifier) {
        this.user_identifier = user_identifier;
    }

    public String getSecret_key() {
        return secret_key;
    }

    public void setSecret_key(String secret_key) {
        this.secret_key = secret_key;
    }
}
