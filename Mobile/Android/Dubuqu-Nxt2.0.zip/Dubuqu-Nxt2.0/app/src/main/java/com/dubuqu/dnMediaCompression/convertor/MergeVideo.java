package com.dubuqu.dnMediaCompression.convertor;

import android.content.Context;
import android.os.Environment;
import android.util.Log;

import com.dubuqu.dnApplication.AppController;
import com.github.hiteshsondhi88.libffmpeg.FFmpeg;
import com.github.hiteshsondhi88.libffmpeg.FFmpegExecuteResponseHandler;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Yogaraj subramanian on 16/11/17
 */

public class MergeVideo {

    private Context context;

    private List<String> filePaths;

    private OnVideoMergeListener onVideoMergeListener;

    FFmpeg ffmpeg;

    public MergeVideo(Context context, List<String> filePaths,
                      OnVideoMergeListener onVideoMergeListener) {

        this.context = context;
        this.filePaths = filePaths;
        this.onVideoMergeListener = onVideoMergeListener;

        try {
            inialzieFFmeg();
        } catch (Exception e) {
            Log.e(MergeVideo.class.getName(), e.getMessage());
        }
    }

    private void inialzieFFmeg() throws Exception {

        ffmpeg = AppController.getfFmpeg();

        try {
            convertVideo();
            deleteLocalMedia();
        } catch (Exception e) {
            onVideoMergeListener.onVideoMergeFailed(e.getMessage());
        }

    }


    private void convertVideo() throws Exception {

        final String outPutFile = context.getCacheDir() + "/" + String.valueOf(System.currentTimeMillis()) + ".mp4";

        List<String> cmdList = new ArrayList<>();
       /* StringBuilder sb = new StringBuilder();
        for (int i = 0; i < filePaths.size(); i++) {
            cmdList.add("-i");
            cmdList.add(filePaths.get(i));
            sb.append("[").append(i).append(":0] [").append(i).append(":1]");
        }

        sb.append(" concat=n=").append(filePaths.size()).append(":v=1:a=1 [v] [a]");
        cmdList.add("-filter_complex");
        cmdList.add(sb.toString());
        cmdList.add("-map");
        cmdList.add("[v]");
        cmdList.add("-map");
        cmdList.add("[a]");
        cmdList.add("-preset");
        cmdList.add("ultrafast");

        cmdList.add(outPutFile);

        sb = new StringBuilder();
        for (String str : cmdList) {
            sb.append(str).append(" ");
        }*/
        cmdList.add("-f");
        cmdList.add("concat");
        cmdList.add("-safe");
        cmdList.add("0");
        cmdList.add("-i");
        cmdList.add(getInputFilePaths());
//        -vcodec,mpeg4,-preset,ultrafast
        cmdList.add("-c");
        cmdList.add("copy");
        cmdList.add(outPutFile);

        String[] cmd = cmdList.toArray(new String[cmdList.size()]);


        ffmpeg.execute(cmd, new FFmpegExecuteResponseHandler() {
            @Override
            public void onSuccess(String message) {
                try {
                    onVideoMergeListener.onVideoMerged(outPutFile);
                    deleteLocalMedia();
                } catch (Exception e) {
                    Log.d(MergeVideo.class.getName(), message);
                }
            }

            @Override
            public void onProgress(String message) {
                Log.d(MergeVideo.class.getName(), message);
            }

            @Override
            public void onFailure(String message) {
                Log.d(MergeVideo.class.getName(), message);
            }

            @Override
            public void onStart() {
                Log.d(MergeVideo.class.getName(), "Started.");
            }

            @Override
            public void onFinish() {
                Log.d(MergeVideo.class.getName(), "Finised");
            }
        });
    }

    private String getInputFilePaths() throws Exception {

        File file = new File(Environment.getExternalStorageDirectory() + "/" + "filepaths.txt");

        String fileName = "file\t";
        String duration = "duration\t";
        String output = "";
        for (String filePath : filePaths) {
            output = output.concat(fileName.concat(filePath).concat("\n"));
        }
        for (String filePath : filePaths) {
            output = output.concat(fileName.concat(filePath).concat("\n"));
        }

        FileOutputStream fos = new FileOutputStream(file.getAbsolutePath());
        fos.write(output.getBytes());
        fos.flush();
        fos.close();
        return file.getPath();
    }

    private void deleteLocalMedia() throws Exception {

        if (filePaths != null && filePaths.size() > 0) {

            for (String files : filePaths)
                new File(files).deleteOnExit();
        }
    }

    public interface OnVideoMergeListener {
        void onVideoMerged(String filePath);

        void onVideoMergeFailed(String errorMessage);
    }
}
