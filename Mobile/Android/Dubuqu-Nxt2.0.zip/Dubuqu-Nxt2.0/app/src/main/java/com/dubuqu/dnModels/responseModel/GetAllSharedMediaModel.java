package com.dubuqu.dnModels.responseModel;

/**
 * Created by ionixx on 11/7/17.
 */


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class GetAllSharedMediaModel {

    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("type")
    @Expose
    private String type;

    @SerializedName("user_identifier")
    @Expose
    private String userIdentifier;
    @SerializedName("group_identifier")
    @Expose
    private String gorupIdentifier;
    @SerializedName("profile_image")
    @Expose
    private String profileImage;
    @SerializedName("shared_medias")
    @Expose
    private List<SharedMedia> sharedMedias = null;
    @SerializedName("allow_repost")
    @Expose
    private String allow_repost;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<SharedMedia> getSharedMedias() {
        return sharedMedias;
    }

    public String getUserIdentifier() {
        return userIdentifier;
    }

    public void setUserIdentifier(String userIdentifier) {
        this.userIdentifier = userIdentifier;
    }

    public void setSharedMedias(List<SharedMedia> sharedMedias) {
        this.sharedMedias = sharedMedias;
    }

    public String getProfileImage() {
        return profileImage;
    }

    public void setProfileImage(String profileImage) {
        this.profileImage = profileImage;
    }

    public String getGorupIdentifier() {
        return gorupIdentifier;
    }

    public void setGorupIdentifier(String gorupIdentifier) {
        this.gorupIdentifier = gorupIdentifier;
    }

    public String getAllow_repost() {
        return allow_repost;
    }

    public void setAllow_repost(String allow_repost) {
        this.allow_repost = allow_repost;
    }
}