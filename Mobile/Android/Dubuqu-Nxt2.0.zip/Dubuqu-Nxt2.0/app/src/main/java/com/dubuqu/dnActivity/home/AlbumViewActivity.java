package com.dubuqu.dnActivity.home;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.content.FileProvider;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.dubuqu.R;
import com.dubuqu.dnActivity.BaseActivity;
import com.dubuqu.dnAdapter.group.GroupParticipantAdapter;
import com.dubuqu.dnAdapter.home.HomeAdapter;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnModels.commonModel.DubuqContactsShareModel;
import com.dubuqu.dnModels.commonModel.ErrorBodyModel;
import com.dubuqu.dnModels.requestModel.DubuquUserRequestModel;
import com.dubuqu.dnModels.responseModel.DubuquUserResponseModel;
import com.dubuqu.dnModels.responseModel.GetAllMediaTimeLine;
import com.dubuqu.dnModels.responseModel.SharedMedias;
import com.dubuqu.dnModels.responseModel.SignedUrlResponseModel;
import com.dubuqu.dnModels.responseModel.SocialGroupDetailsResponseModel;
import com.dubuqu.dnModels.responseModel.UpdateGroupProfileRequest;
import com.dubuqu.dnRestServices.RestServiceController;
import com.dubuqu.dnRestServices.RestServiceProvider;
import com.dubuqu.dnUtils.RestServiceUtils;
import com.dubuqu.dnUtils.Utils;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;
import com.yalantis.ucrop.UCrop;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;
import retrofit2.Response;
import retrofit2.Retrofit;

import static com.dubuqu.dnUtils.Utils.DUBUQU_CATEGORY.DUBUQU_CONTACT;
import static com.dubuqu.dnUtils.Utils.DUBUQU_CATEGORY.PHONE_CONTACT;

/**
 * Created by Yogaraj subramanian on 5/12/17
 * <p>
 * AlbumView Activity is used to show the list of medias that are shared to the group by various user
 * in various period of time.
 * </p>
 * <p>
 * The group owner has the permission to edit the profile image of the group in album detail activity.
 * </p>
 */

public class AlbumViewActivity extends BaseActivity implements HomeAdapter.HomeAdapterCallback {

    private final String TAG = AlbumViewActivity.class.getName();

    ImageView groupProfile, back, editGroupImage;

    TextView userName, groupName, mediaCount, memberCount, memberReminingCount;

    RecyclerView mediaList;

    String groupIdentifier = null;

    List<GetAllMediaTimeLine> getAllMediaTimeLines = new ArrayList<>();

    HomeAdapter homeAdapter;

    int resourceCount = 0;

    Context context;

    private Uri outputFileUri = null, profileUri = null;

    private String deviceName;

    List<DubuqContactsShareModel> availableContactinGroup = new ArrayList<>();

    private boolean isPaginating = false;

    ProgressBar progressBar;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            setContentView(R.layout.activity_album_view);
            groupIdentifier = getIntent().getStringExtra(Constants.GROUP_IDENTIFIER);
            intitializeView();
            context = AlbumViewActivity.this;
        } catch (Exception e) {
            writeCrashReport(e.getMessage());
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(receive, new IntentFilter(Constants.REFRESHHOMEDATA));
        if (Constants.RESTRICT_SREENSHOT)
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(receive);
    }

    @Override
    public void removeTimelineMedia(int postion) {
        getAllMediaTimeLines.remove(postion);
        homeAdapter.notifyItemRemoved(postion);
    }

    private void intitializeView() throws Exception {
        groupName = findViewById(R.id.group_name);

        userName = findViewById(R.id.shared_user_name);

        String name = getIntent().getStringExtra(Constants.DUBUQU_USER_NAME);

        assert name != null;
        userName.setText(name);

        mediaCount = findViewById(R.id.media_count);

        memberCount = findViewById(R.id.member_count);

        mediaList = findViewById(R.id.album_view_rcv);
        mediaList.setLayoutManager(new LinearLayoutManager(AlbumViewActivity.this));

        groupProfile = findViewById(R.id.album_view_group_profile_image);

        back = findViewById(R.id.album_view_back);

        editGroupImage = findViewById(R.id.edit_profile_image);
        editGroupImage.setVisibility(View.GONE);

        deviceName = android.os.Build.MANUFACTURER;

        progressBar = findViewById(R.id.albumviewactivity_loader);
        progressBar.setProgress(0);


        getMediaTimeline();

        intitilaizeListeners();

        findViewById(R.id.border_indicator).setVisibility(View.GONE);
    }

    private void intitilaizeListeners() throws Exception {

        homeAdapter = new HomeAdapter(AlbumViewActivity.this, this);
        homeAdapter.setAlbumView(true);

        mediaList.setAdapter(homeAdapter);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        editGroupImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    openImageViewContent();
                } catch (Exception e) {
                    writeCrashReport(e.getMessage());
                }
            }
        });

        memberCount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (availableContactinGroup.size() > 0) {
                    try {
                        openFullList(availableContactinGroup);
                    } catch (Exception e) {
                        writeCrashReport(e.getMessage());
                    }
                }
            }
        });

        mediaList.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                try {
                    RecyclerView.LayoutManager layoutManager = recyclerView.getLayoutManager();
                    if (!isPaginating && layoutManager instanceof LinearLayoutManager) {
                        if (((LinearLayoutManager) layoutManager).findLastVisibleItemPosition()
                                == getAllMediaTimeLines.size() - 1) {
                            isPaginating = true;
                            paginateResource();
                        }
                    }
                } catch (Exception e) {
                    writeCrashReport(e.getMessage());
                }
            }
        });

        getGroupDetails();
    }

    private void writeCrashReport(String message) {
        super.writeCrashReport(TAG, message);
    }

    private void getGroupDetails() throws Exception {
        String data = "{}";
        OkHttpClient okHttpClient = null;
        try {
            okHttpClient = RestServiceUtils.getHeader(data, getApplicationContext());
            Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
            RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
            RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
            mRetrofitCallBacks.getGroupDetails(groupIdentifier,
                    new RestServiceController.ResponseCallBacks() {
                        @Override
                        public void onResponse(Object o) {
                            final SocialGroupDetailsResponseModel socialGroupDetailsResponseModel = (SocialGroupDetailsResponseModel) o;
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    try {
                                        if (socialGroupDetailsResponseModel.getGroupType() == null) {
                                            findViewById(R.id.group_details_rl).setVisibility(View.GONE);
                                        } else {
                                            if (socialGroupDetailsResponseModel.getGroupType().equalsIgnoreCase("closed")) {
                                                findViewById(R.id.group_details_rl).setVisibility(View.GONE);
                                            } else {
                                                if (socialGroupDetailsResponseModel.getGroupOwnerIdnetifer() == null) {
                                                    editGroupImage.setVisibility(View.VISIBLE);
                                                    findViewById(R.id.border_indicator).setVisibility(View.VISIBLE);
                                                } else {
                                                    editGroupImage.setVisibility(View.GONE);
                                                    findViewById(R.id.border_indicator).setVisibility(View.GONE);
                                                }

                                                groupName.setText(socialGroupDetailsResponseModel.getGroupName());

                                                memberCount.setText(
                                                        String.valueOf(socialGroupDetailsResponseModel.getMembers().size())
                                                );

                                                mediaCount.setText(
                                                        String.valueOf(socialGroupDetailsResponseModel.getMediaCount())
                                                );

                                                dispalyGroupProfile(socialGroupDetailsResponseModel.getProfileImage(),
                                                        socialGroupDetailsResponseModel.getGroupName());


                                                fetchavilableDubuquUsersInthegroup(socialGroupDetailsResponseModel);
                                            }
                                        }
                                    } catch (Exception e) {
                                        writeCrashReport(e.getMessage());
                                    }
                                }
                            });
                        }

                        @Override
                        public void onFailure(Object o) {
                            showApiErrorMessage(o);
                        }
                    });
        } catch (Exception e) {
            writeCrashReport(e.getMessage());
        }

    }

    private void getMediaTimeline() throws Exception {
        String data = "{}";
        OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, AlbumViewActivity.this);
        Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
        RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
        RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
        progressBar.setVisibility(View.VISIBLE);
        mRetrofitCallBacks.fetchAllMediasSharedToUserTimeLine(new RestServiceController.ResponseCallBacks() {
            @Override
            public void onResponse(final Object o) {
                if (o != null) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (getAllMediaTimeLines != null && getAllMediaTimeLines.size() > 0) {
                                getAllMediaTimeLines.clear();
                                getAllMediaTimeLines.addAll((List<GetAllMediaTimeLine>) o);
                            } else {
                                getAllMediaTimeLines = new ArrayList<>();
                                getAllMediaTimeLines.addAll((List<GetAllMediaTimeLine>) o);
                            }

                            homeAdapter.setGetAllMediaTimeLineList(getAllMediaTimeLines);
                            homeAdapter.notifyDataSetChanged();
                            progressBar.setVisibility(View.GONE);
                        }
                    });

                }
            }

            @Override
            public void onFailure(Object o) {
                showApiErrorMessage(o);
            }
        }, groupIdentifier, new RestServiceController.ResourceCountCallBack() {
            @Override
            public void mediaResponse(String count) {
                resourceCount = Integer.parseInt(count);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        progressBar.setVisibility(View.GONE);
                        try {
                            memberCount.setText(resourceCount);
                        } catch (Exception e) {
                            writeCrashReport(e.getMessage());
                        }
                    }
                });
            }
        });
    }

    private void dispalyGroupProfile(String profileImage, String groupName) {
        try {
            final Bitmap bitmap = Utils.textAsBitmapRoundRect(groupName, AlbumViewActivity.this, 10);
            if (profileImage != null &&
                    !profileImage.equalsIgnoreCase("")) {
                ImageLoader.getInstance().displayImage(profileImage, groupProfile, new ImageLoadingListener() {
                    @Override
                    public void onLoadingStarted(String imageUri, View view) {
                        groupProfile.setImageBitmap(bitmap);
                    }

                    @Override
                    public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
                        groupProfile.setImageBitmap(bitmap);
                    }

                    @Override
                    public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                        groupProfile.setImageBitmap(loadedImage);
                    }

                    @Override
                    public void onLoadingCancelled(String imageUri, View view) {
                        groupProfile.setImageBitmap(bitmap);
                    }
                });
            } else {
                groupProfile.setImageBitmap(bitmap);
            }
        } catch (Exception e) {
            writeCrashReport(e.getMessage());
        }

    }

    @Override
    public void startPaginating() {

    }

    @Override
    public void refreshHomeContent() {

    }

    private void showApiErrorMessage(Object o) {
        if (o != null) {
            try {
                if (o instanceof retrofit2.Response) {
                    ResponseBody responseBody = ((Response) o).errorBody();
                    if (responseBody != null) {
                        String value = responseBody.string();
                        ErrorBodyModel errorBodyModel = new Gson().fromJson(value, ErrorBodyModel.class);
                        if (errorBodyModel != null)
                            AlbumViewActivity.super.showToastMessage(errorBodyModel.getMessage(), false);
                    }
                } else if (o instanceof Throwable) {
                    AlbumViewActivity.super.showToastMessage(((Throwable) o).getMessage(), false);
                }

            } catch (Exception e) {
                writeCrashReport(e.getMessage());
            }

        }
    }

    private void paginateResource() throws Exception {
        if (resourceCount != getAllMediaTimeLines.size()) {
            String data = "{}";
            OkHttpClient okHttpClient = null;
            try {
                okHttpClient = RestServiceUtils.getHeader(data, AlbumViewActivity.this);
                Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
                RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
                RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
                progressBar.setVisibility(View.VISIBLE);

                mRetrofitCallBacks.paginateTimelineList(new RestServiceController.ResponseCallBacks() {
                    @Override
                    public void onResponse(Object o) {
                        if (o != null) {
                            if (getAllMediaTimeLines != null && getAllMediaTimeLines.size() > 0) {
                                int previusPosition = getAllMediaTimeLines.size();

                                getAllMediaTimeLines.addAll((List<GetAllMediaTimeLine>) o);
                                homeAdapter.notifyItemRangeInserted(previusPosition, 10);
                            } else {
                                getAllMediaTimeLines = new ArrayList<>();
                                getAllMediaTimeLines.addAll((List<GetAllMediaTimeLine>) o);
                                homeAdapter.notifyDataSetChanged();
                            }

                        }
                        isPaginating = false;

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                progressBar.setVisibility(View.GONE);
                            }
                        });
                    }

                    @Override
                    public void onFailure(Object o) {
                        showApiErrorMessage(o);
                        isPaginating = false;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                progressBar.setVisibility(View.GONE);
                            }
                        });
                    }
                }, getAllMediaTimeLines.size(), groupIdentifier);


            } catch (Exception e) {
                writeCrashReport(e.getMessage());
                isPaginating = false;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        progressBar.setVisibility(View.GONE);
                    }
                });
            }
        }
    }

    /**
     * Open Crop Activity which allows user to crop their images.
     *
     * @param cropImageUri {@link Uri} the pic user has picked
     * @throws Exception {Runtime Stub Exception}
     */
    private void cropImage(Uri cropImageUri) throws Exception {
        String destinationFileName = String.valueOf(System.currentTimeMillis());
        destinationFileName += ".png";

        UCrop uCrop = UCrop.of(cropImageUri
                , Uri.fromFile(new File(getCacheDir(), destinationFileName)));
        UCrop.Options options = new UCrop.Options();
        options.setCompressionFormat(Bitmap.CompressFormat.PNG);
        options.setCompressionQuality(100);
        options.setHideBottomControls(false);
        options.setFreeStyleCropEnabled(true);
        options.setStatusBarColor(getResources().getColor(R.color.colorPrimaryDark));
        options.setToolbarColor(getResources().getColor(R.color.colorPrimary));
        options.setActiveWidgetColor(getResources().getColor(R.color.colorPrimary));
        uCrop.withOptions(options);
        //uCrop = basisConfig(uCrop);
        //uCrop = advancedConfig(uCrop);
        uCrop.start(AlbumViewActivity.this);
    }

    /**
     * Add Image Media Intents
     *
     * @throws Exception {Run time stub Exception.}
     */
    private void openImageViewContent() throws Exception {
        // Determine Uri of camera image to save.
        final File root = new File(Utils.getRootFolderForProfilePicture(context));
        root.mkdirs();
        final String fname = Utils.getAppName(context) + "_" + System.currentTimeMillis() + "." +
                Utils.getAppName(context);
        final File sdImageMainDirectory = new File(root.getPath(), fname);
        outputFileUri = Uri.fromFile(sdImageMainDirectory);

        Intent chooserIntent = null;

        List<Intent> intentList = new ArrayList<>();
        Intent pickIntent = new Intent(Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        pickIntent.setType("image/*");

        Intent takePhotoIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (!deviceName.contains("samsung")) {
            Uri photoURI = FileProvider.getUriForFile(context,
                    com.dubuqu.BuildConfig.APPLICATION_ID + ".provider",
                    sdImageMainDirectory);
            takePhotoIntent.putExtra("return-data", true);
            takePhotoIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
        }
        intentList = addIntentsToList(context, intentList, pickIntent);
        intentList = addIntentsToList(context, intentList, takePhotoIntent);

        if (intentList.size() > 0) {
            for (int i = 0; i < intentList.size(); i++) {
            }
            chooserIntent = Intent.createChooser(intentList.remove(intentList.size() - 1),
                    ("Pick image From"));
            chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, intentList.toArray(new Parcelable[]{}));
        }

        startActivityForResult(chooserIntent, Constants.IMAGECPATURE_REQUEST);
    }

    /**
     * add avialable camera nad gallery apps that can provide images
     *
     * @param context {Context of the Activity}
     * @param list    {package name list}
     * @param intent  {intnet to trigger}
     * @return {List}
     */
    private static List<Intent> addIntentsToList(Context context, List<Intent> list, Intent intent) {
        List<ResolveInfo> resInfo = context.getPackageManager().queryIntentActivities(intent, 0);
        for (ResolveInfo resolveInfo : resInfo) {
            String packageName = resolveInfo.activityInfo.packageName;
            Intent targetedIntent = new Intent(intent);
            targetedIntent.setPackage(packageName);
            list.add(targetedIntent);
        }
        return list;
    }

    @Override
    public void
    onActivityResult(int requestCode, int resultCode, Intent result) {
        super.onActivityResult(requestCode, resultCode, result);
        if (resultCode == RESULT_OK) {
            try {
                switch (requestCode) {
                    case Constants.IMAGECPATURE_REQUEST:

                        final boolean isCamera;
                        if (result != null && result.hasExtra("remove_image")) {
                                /*remove image */
                            profileUri = null;
                            groupProfile.setImageResource(R.drawable.ic_profile);
                            return;
                        } else if (result == null) {
                            isCamera = true;
                        } else {
                            final String action = result.getAction();
                            isCamera = action != null;
                        }

                        if (isCamera) {

                            if (result != null) {
                                profileUri = outputFileUri;
                            } else {
                                profileUri = outputFileUri;
                            }

                        } else {
                            profileUri = result.getData();
                        }

                        cropImage(profileUri);
                        profileUri = null;
                        break;

                    case UCrop.REQUEST_CROP:
                        if (UCrop.getOutput(result) != null)
                            profileUri = UCrop.getOutput(result);

                        Glide.with(context).load(profileUri).into(groupProfile);

                        getSignedUrlfromServer(profileUri.getPath());

                        break;

                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * get signedurl and other datas from dubuqu server to upload the profile image
     *
     * @param filepath the file that need to be uploaded
     * @throws Exception {Runtime stub excepton}
     */
    private void getSignedUrlfromServer(final String filepath) throws Exception {

        String[] resolution = Utils.getResolution(filepath);
        String width = "320";
        String height = "640";
        if (resolution.length == 2) {
            width = resolution[1];
            height = resolution[0];
        }

        String data = "{}";
        OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, context);
        Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
        RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
        RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
        mRetrofitCallBacks.getSignedUrl(
                new RestServiceController.ResponseCallBacks() {
                    @Override
                    public void onResponse(Object o) {
                        SignedUrlResponseModel response = (SignedUrlResponseModel) o;

                        try {
                            updateProfilePicture(response, filepath);
                        } catch (Exception e) {
                            writeCrashReport(e.getMessage());
                        }
                    }

                    @Override
                    public void onFailure(Object o) {
                    }
                }, "profile_image", Utils.getContentType(filepath),
                Utils.getFileExtension(filepath), width, height);


    }

    private void updateProfilePicture(SignedUrlResponseModel response, final String filepath) throws Exception {
        Gson gson = new Gson();

        UpdateGroupProfileRequest updateGroupProfileRequest = new UpdateGroupProfileRequest();

        updateGroupProfileRequest.setProfileImageIdentifier(response.getMediaIdentifier());

        String data = gson.toJson(updateGroupProfileRequest);
        OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, context);
        Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
        RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
        RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);

        mRetrofitCallBacks.uploadProfileImageToDubuquServer(updateGroupProfileRequest,
                groupIdentifier);

        uploadMediaToAmazonS3(response, filepath);
    }

    private void uploadMediaToAmazonS3(SignedUrlResponseModel response, String filePath) {
        Gson gson = new Gson();
        String json = gson.toJson(response);
        try {
            RestServiceUtils.fileUploadService(context, 130, json, filePath);
        } catch (Exception e) {
            writeCrashReport(e.getMessage());
        }
    }


    BroadcastReceiver receive = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String timelineIdentifier = intent.getStringExtra(Constants.TIMELINE_IDENTIFIER);
            int positon = intent.getIntExtra(Constants.SHAREMEDA_POSITON, 0);
            String sharedMediasString = intent.getStringExtra(Constants.SELECTEDIMAGES);
            int po = 0;
            if (intent.getBooleanExtra(Constants.ISREPORTEDDATA, false)) {
                for (GetAllMediaTimeLine getallmediatimeline : getAllMediaTimeLines) {
                    if (getallmediatimeline.getTimelineIdentifier().equalsIgnoreCase(timelineIdentifier)) {
                        List<SharedMedias> sharedMedias = new Gson().fromJson(sharedMediasString,
                                new TypeToken<List<SharedMedias>>() {
                                }.getType());
                        getAllMediaTimeLines.get(po).setSharedMedias(sharedMedias);
                        getAllMediaTimeLines.get(po).setSharedMediaCount(intent.getIntExtra(Constants.SHAREDMEDIA_COUNT, 4));
                        if (sharedMedias.size() == 0) {
                            getAllMediaTimeLines.remove(po);
                        }
                        homeAdapter.setGetAllMediaTimeLineList(getAllMediaTimeLines);
                        homeAdapter.notifyDataSetChanged();
                        break;
                    }
                    po++;
                }
            } else {
                for (GetAllMediaTimeLine getallmediatimeline : getAllMediaTimeLines) {
                    if (getallmediatimeline.getTimelineIdentifier().equalsIgnoreCase(timelineIdentifier)) {
                        SharedMedias sharedMedias = new Gson().fromJson(sharedMediasString, SharedMedias.class);
                        if (positon <= 3) {
                            getAllMediaTimeLines.get(po).getSharedMedias().set(positon, sharedMedias);
                            break;
                        }
                        if (positon >= 4) {
                            break;
                        }
                        break;
                    }
                    po++;
                }
            }
        }
    };


    /**
     * Fetch available user avilable in the group and seperate whether it is dubuqu user or non bubuqu user
     *
     * @param socialGroupDetailsResponseModel List of mobile numbers which are available in the social groups.
     */
    private void fetchavilableDubuquUsersInthegroup(final SocialGroupDetailsResponseModel
                                                            socialGroupDetailsResponseModel) throws Exception {


        final DubuquUserRequestModel dubuquUserRequestModel = new DubuquUserRequestModel();
        dubuquUserRequestModel.setMobileNumbers(socialGroupDetailsResponseModel.getMembers());

        Gson gson = new Gson();

        String data = gson.toJson(dubuquUserRequestModel);
        OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, getApplicationContext());
        Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
        RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
        RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);

        mRetrofitCallBacks.getDubuqUserList(new RestServiceController.ResponseCallBacks() {
            @Override
            public void onResponse(Object o) {
                if (o != null) {
                    List<DubuquUserResponseModel> userResponseModels = new ArrayList<>();

                    userResponseModels.addAll((List<DubuquUserResponseModel>) o);

                    Utils.DUBUQU_CATEGORY type = PHONE_CONTACT;
                    try {
                        for (String phoneContacts : socialGroupDetailsResponseModel.getMembers()) {
                            String userName = "", identifer = "", profilepic = "";
                            for (DubuquUserResponseModel userResponseModel : userResponseModels) {
                                if (userResponseModel.getMobileNumber().equalsIgnoreCase(phoneContacts)) {
                                    profilepic = userResponseModel.getProfileImage();
                                    identifer = userResponseModel.getUserIdentifier();
                                    userName = userResponseModel.getUserName();
                                    type = DUBUQU_CONTACT;
                                    break;
                                }
                            }
                            availableContactinGroup.add(new DubuqContactsShareModel(userName,
                                    phoneContacts, identifer, profilepic, type));
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }


            }

            @Override
            public void onFailure(Object o) {
            }

        }, dubuquUserRequestModel);
    }


    /**
     * Show list of available user in the group.
     *
     * @param participantList {@link List} of {@link DubuqContactsShareModel}
     * @throws Exception {Runtime Stub Exception}
     */
    private void openFullList(List<DubuqContactsShareModel> participantList) throws Exception {

        RecyclerView recyclerView;

        ImageView back;

        LayoutInflater inflater = (LayoutInflater)
                getSystemService(LAYOUT_INFLATER_SERVICE);

        View inflate = inflater.inflate(R.layout.group_list_memeber_full_list, null);

        final PopupWindow popupWindow = new PopupWindow(AlbumViewActivity.this);

        recyclerView = inflate.findViewById(R.id.group_list_memeber_rcv);
        recyclerView.setLayoutManager(new LinearLayoutManager(AlbumViewActivity.this));
        recyclerView.setAdapter(new GroupParticipantAdapter(splitView(participantList), AlbumViewActivity.this,
                GroupParticipantAdapter.ViewType.SEELIST));

        back = inflate.findViewById(R.id.popup_close);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                popupWindow.dismiss();
            }
        });

        inflate.setFocusableInTouchMode(true);
        inflate.requestFocus();
        inflate.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK) {
                    popupWindow.dismiss();
                    return true;
                }
                return false;
            }
        });


        popupWindow.setContentView(inflate);
        popupWindow.setWidth(LinearLayout.LayoutParams.MATCH_PARENT);
        popupWindow.setHeight(LinearLayout.LayoutParams.MATCH_PARENT);
        popupWindow.setFocusable(true);
        popupWindow.setBackgroundDrawable(null);
        popupWindow.showAtLocation(inflate, Gravity.TOP, 0, 0);
    }

    private List<DubuqContactsShareModel> splitView(List<DubuqContactsShareModel> participantList) throws Exception {

        List<DubuqContactsShareModel> dubuquContacts = new ArrayList<>();

        List<DubuqContactsShareModel> phoneContact = new ArrayList<>();

        for (DubuqContactsShareModel contacts : participantList) {

            if (contacts.getCategory() == Utils.DUBUQU_CATEGORY.DUBUQU_CONTACT)
                dubuquContacts.add(contacts);
            else if (contacts.getCategory() == Utils.DUBUQU_CATEGORY.PHONE_CONTACT)
                phoneContact.add(contacts);
        }

        if (dubuquContacts.size() > 0)
            dubuquContacts.add(0, new DubuqContactsShareModel("Dubuqu Contacts", "", "", "", Utils.DUBUQU_CATEGORY.HEADER));

        if (phoneContact.size() > 0) {
            dubuquContacts.add(new DubuqContactsShareModel(phoneContact.size() + "\t Unregistered Contacts", "", "", "", Utils.DUBUQU_CATEGORY.HEADER));
        }
        return dubuquContacts;
    }

}
