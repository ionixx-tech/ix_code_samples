package com.dubuqu.dnModels.commonModel;

/**
 * Created by Yogaraj subramanian on 25/10/17
 */

public class GalleryMediaListModel {


    private int mediaId;

    private String mimeType;

    private String mediaPath;

    private boolean isSelected;

    private String videoDuration;

    public String getVideoDuration() {
        return videoDuration;
    }

    public void setVideoDuration(String videoDuration) {
        this.videoDuration = videoDuration;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }

    public String getMediaPath() {
        return mediaPath;
    }

    public void setMediaPath(String mediaPath) {
        this.mediaPath = mediaPath;
    }

    public void setMediaId(int mediaId) {
        this.mediaId = mediaId;
    }

    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }


    public int getMediaId() {
        return mediaId;
    }

    public String getMimeType() {
        return mimeType;
    }




}
