package com.dubuqu.dnFragments.home;

import android.animation.Animator;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.dubuqu.R;
import com.dubuqu.dnActivity.LandingActivity;
import com.dubuqu.dnAdapter.home.HomeAdapter;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnModels.commonModel.ErrorBodyModel;
import com.dubuqu.dnModels.responseModel.GetAllMediaTimeLine;
import com.dubuqu.dnModels.responseModel.SharedMedias;
import com.dubuqu.dnRestServices.RestServiceController;
import com.dubuqu.dnRestServices.RestServiceProvider;
import com.dubuqu.dnUtils.RestServiceUtils;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;
import retrofit2.Response;
import retrofit2.Retrofit;

/**
 * Created by Yogaraj subramanian on 30/10/17
 */

public class HomeFragment extends Fragment implements HomeAdapter.HomeAdapterCallback {

    private final String TAG = HomeFragment.class.getName();

    Activity activity;

    View parentView, noFeedAvailable, newFeedavailable;

    RecyclerView homeRcv;

    List<GetAllMediaTimeLine> getAllMediaTimeLines = new ArrayList<>();

    HomeAdapter homeAdapter;

    SwipeRefreshLayout swipeRefreshLayout;

    int resourceCount = 0;

    ProgressBar progressBar;

    boolean isMediaFromLocal = false, isPaginating = false;

    @Override
    public void onResume() {
        super.onResume();

        homeAdapter.notifyDataSetChanged();

        if (activity instanceof LandingActivity) {
            try {
                activity.registerReceiver(onNewMediaReceived, new IntentFilter(Constants.NEWMEDIARECEIVED));

                activity.registerReceiver(receive, new IntentFilter(Constants.REFRESHHOMEDATA));

                activity.registerReceiver(refreshHomeContent, new IntentFilter(Constants.REFRESHHOME));

                ((LandingActivity) activity).toggleBottomSheet(false);

            } catch (Exception e) {
                if (activity instanceof LandingActivity) {
                    ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                }
            }
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (parentView == null)
            return inflater.inflate(R.layout.fragment_home, container, false);
        else
            return parentView;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        activity = getActivity();

        if (parentView == null) {
            this.parentView = view;
            try {
                initializeViews();
            } catch (Exception e) {
                writeCarshReport(e.getMessage());
            }
        }

        setupWindowAnimations();

    }

    @Override
    public void onPause() {
        super.onPause();
        try {
            activity.unregisterReceiver(onNewMediaReceived);
        } catch (Exception e) {
            writeCarshReport(e.getMessage());
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        try {
            activity.unregisterReceiver(receive);
            activity.unregisterReceiver(refreshHomeContent);
        } catch (Exception e) {
            writeCarshReport(e.getMessage());
        }

    }

    @Override
    public void startPaginating() {

    }

    @Override
    public void refreshHomeContent() {
        try {
            swipeRefreshLayout.setRefreshing(true);
            makeHttpRequest();
        } catch (Exception e) {
            writeCarshReport(e.getMessage());
        }
    }

    @Override
    public void removeTimelineMedia(int postion) {
        getAllMediaTimeLines.remove(postion);
        homeAdapter.notifyItemRemoved(postion);
    }

    private void setupWindowAnimations() {
       /* Transition fade = TransitionInflater.from(activity).inflateTransition(R.transition.fade);
        activity.getWindow().setEnterTransition(fade);*/
    }

    private void paginateResource() throws Exception {

        if (resourceCount != getAllMediaTimeLines.size()) {
            String data = "{}";
            OkHttpClient okHttpClient;
            try {
                progressBar.setVisibility(View.VISIBLE);

                okHttpClient = RestServiceUtils.getHeader(data, activity);
                Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
                RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
                RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
                mRetrofitCallBacks.paginateTimelineList(new RestServiceController.ResponseCallBacks() {
                    @Override
                    public void onResponse(Object o) {
                        if (o != null) {
                            if (getAllMediaTimeLines != null && getAllMediaTimeLines.size() > 0) {
                                int previousPostion = getAllMediaTimeLines.size();
                                getAllMediaTimeLines.addAll((List<GetAllMediaTimeLine>) o);
                                homeAdapter.notifyItemRangeChanged(previousPostion, 10);
                            } else {
                                getAllMediaTimeLines = new ArrayList<>();
                                getAllMediaTimeLines.addAll((List<GetAllMediaTimeLine>) o);
                            }

                            isPaginating = false;

                            progressBar.setVisibility(View.GONE);
                        }
                    }

                    @Override
                    public void onFailure(Object o) {
                        showApiErrorMessage(o);
                        progressBar.setVisibility(View.GONE);
                        isPaginating = false;
                    }
                }, getAllMediaTimeLines.size());

            } catch (Exception e) {
                writeCarshReport(e.getMessage());
                progressBar.setVisibility(View.GONE);
                isPaginating = false;
            }
        }

    }

    private void initializeViews() throws Exception {

        noFeedAvailable = parentView.findViewById(R.id.fragment_home_no_feed_available);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());

        homeAdapter = new HomeAdapter(activity, this);

        homeRcv = parentView.findViewById(R.id.fragment_home_rcv);
        homeRcv.setLayoutManager(linearLayoutManager);

        homeRcv.setAdapter(homeAdapter);

        swipeRefreshLayout = parentView.findViewById(R.id.swipe_refresh_layout);

        progressBar = parentView.findViewById(R.id.pagantion_indicator);
        progressBar.setProgress(0);
        progressBar.setVisibility(View.GONE);

        isMediaFromLocal = readDetails();

        newFeedavailable = parentView.findViewById(R.id.fragmet_home_newfeedavailable_txt);

        newFeedavailable.setVisibility(View.GONE);

        if (isMediaFromLocal) {
            homeAdapter.setGetAllMediaTimeLineList(getAllMediaTimeLines);
            homeAdapter.notifyDataSetChanged();
        }
        makeHttpRequest();

        initializeListeners();
    }

    private void initializeListeners() throws Exception {
        toogleView();

        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                try {
                    makeHttpRequest();
                } catch (Exception e) {
                    writeCarshReport(e.getMessage());
                }
            }
        });

        parentView.findViewById(R.id.add_medias_from_gallery_txt).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (activity instanceof LandingActivity) {
                    ((LandingActivity) activity).toogleToGallery();
                }
            }
        });

        homeRcv.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
                if (newState == RecyclerView.SCROLL_STATE_IDLE && !isPaginating) {
                    try {
                        RecyclerView.LayoutManager layoutManager = recyclerView.getLayoutManager();
                        if (layoutManager instanceof LinearLayoutManager) {
                            if (((LinearLayoutManager) layoutManager).findLastVisibleItemPosition()
                                    == getAllMediaTimeLines.size() - 1 &&
                                    resourceCount > getAllMediaTimeLines.size()) {
                                isPaginating = true;
                                paginateResource();
                            }
                        }
                    } catch (Exception e) {
                        writeCarshReport(e.getMessage());
                    }
                }
            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);


            }
        });

        newFeedavailable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    swipeRefreshLayout.setRefreshing(true);
                    makeHttpRequest();
                    YoYo.with(Techniques.SlideOutUp).withListener(new Animator.AnimatorListener() {
                        @Override
                        public void onAnimationStart(Animator animation) {

                        }

                        @Override
                        public void onAnimationEnd(Animator animation) {
                            newFeedavailable.setVisibility(View.GONE);
                        }

                        @Override
                        public void onAnimationCancel(Animator animation) {

                        }

                        @Override
                        public void onAnimationRepeat(Animator animation) {

                        }
                    }).playOn(newFeedavailable);
                } catch (Exception e) {
                    writeCarshReport(e.getMessage());
                }
            }
        });
    }

    private void makeHttpRequest() throws Exception {

        String data = "{}";
        OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, activity);
        Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
        RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
        RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);

        mRetrofitCallBacks.fetchAllMediasSharedToUserTimeLine(new RestServiceController.ResponseCallBacks() {
            @Override
            public void onResponse(Object o) {
                if (o != null) {
                    if (!isMediaFromLocal && getAllMediaTimeLines != null && getAllMediaTimeLines.size() > 0) {
                        getAllMediaTimeLines.clear();
                        getAllMediaTimeLines.addAll((List<GetAllMediaTimeLine>) o);
                    } else {
                        getAllMediaTimeLines = new ArrayList<>();
                        getAllMediaTimeLines.addAll((List<GetAllMediaTimeLine>) o);
                        //initial data loaded
                        writeInLocalCache(new Gson().toJson(getAllMediaTimeLines));
                    }
                    progressBar.setVisibility(View.GONE);

                    toogleView();

                    homeAdapter.setGetAllMediaTimeLineList(getAllMediaTimeLines);
                    homeAdapter.notifyItemRangeChanged(0, 10);
                    swipeRefreshLayout.setRefreshing(false);
                }
            }

            @Override
            public void onFailure(Object o) {
                swipeRefreshLayout.setRefreshing(false);
                progressBar.setVisibility(View.GONE);
            }
        }, new RestServiceController.ResourceCountCallBack() {
            @Override
            public void mediaResponse(String count) {
                resourceCount = Integer.parseInt(count);
            }
        });
    }

    /**
     * Write log report to StackTrace
     *
     * @param message "The Message that need to be printed."
     */
    private void writeCarshReport(String message) {
        if (activity instanceof LandingActivity) {
            ((LandingActivity) activity).writeCrashReport(TAG, message);
        }
    }

    private void showApiErrorMessage(Object o) {
        if (o != null) {
            if (activity instanceof LandingActivity) {
                try {

                    if (o instanceof retrofit2.Response) {
                        ResponseBody responseBody = ((Response) o).errorBody();
                        if (responseBody != null) {
                            String value = responseBody.string();
                            ErrorBodyModel errorBodyModel = new Gson().fromJson(value, ErrorBodyModel.class);
                            if (errorBodyModel != null)
                                ((LandingActivity) activity).showToastMessage(errorBodyModel.getMessage(), false);
                        }
                    } else if (o instanceof Throwable) {
                        ((LandingActivity) activity).showToastMessage(((Throwable) o).getMessage(), false);
                    }

                } catch (Exception e) {
                    if (activity instanceof LandingActivity) {
                        ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                    }
                }
            }

        }
    }


    private void toogleView() {
        if (getAllMediaTimeLines == null || getAllMediaTimeLines.size() == 0) {
            homeRcv.setVisibility(View.GONE);
            noFeedAvailable.setVisibility(View.VISIBLE);
        } else {
            noFeedAvailable.setVisibility(View.GONE);
            homeRcv.setVisibility(View.VISIBLE);
            homeRcv.setAdapter(homeAdapter);
            homeRcv.setLayoutManager(new LinearLayoutManager(activity));
        }

    }

    public void refreshFragment() throws Exception {
        swipeRefreshLayout.setRefreshing(true);
        makeHttpRequest();
    }


    BroadcastReceiver onNewMediaReceived = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            showNeedFeedAvailable();
        }
    };

    BroadcastReceiver refreshHomeContent = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            try {
                refreshFragment();
            } catch (Exception e) {
                writeCarshReport(e.getMessage());
            }
        }
    };


    BroadcastReceiver receive = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String timelineIdentifier = intent.getStringExtra(Constants.TIMELINE_IDENTIFIER);
            int positon = intent.getIntExtra(Constants.SHAREMEDA_POSITON, 0);
            String sharedMediasString = intent.getStringExtra(Constants.SELECTEDIMAGES);
            int po = 0;
            if (intent.getBooleanExtra(Constants.ISREPORTEDDATA, false)) {
                for (GetAllMediaTimeLine getallmediatimeline : getAllMediaTimeLines) {
                    if (getallmediatimeline.getTimelineIdentifier().equalsIgnoreCase(timelineIdentifier)) {
                        List<SharedMedias> sharedMedias = new Gson().fromJson(sharedMediasString,
                                new TypeToken<List<SharedMedias>>() {
                                }.getType());
                        getAllMediaTimeLines.get(po).setSharedMedias(sharedMedias);
                        getAllMediaTimeLines.get(po).setSharedMediaCount(intent.getIntExtra(Constants.SHAREDMEDIA_COUNT, 4));
                        if (sharedMedias.size() == 0) {
                            getAllMediaTimeLines.remove(po);
                        }
                        homeAdapter.setGetAllMediaTimeLineList(getAllMediaTimeLines);
                        homeAdapter.notifyDataSetChanged();
                        break;
                    }
                    po++;
                }
            } else {
                for (GetAllMediaTimeLine getallmediatimeline : getAllMediaTimeLines) {
                    if (getallmediatimeline.getTimelineIdentifier().equalsIgnoreCase(timelineIdentifier)) {
                        SharedMedias sharedMedias = new Gson().fromJson(sharedMediasString, SharedMedias.class);
                        if (positon <= 3) {
                            getAllMediaTimeLines.get(po).getSharedMedias().set(positon, sharedMedias);
                            break;
                        }
                        if (positon >= 4) {
                            break;
                        }
                    }
                    po++;
                }
            }
        }
    };


    private void writeInLocalCache(String data) {

        File file = new File(activity.getCacheDir(), Constants.HOMEDETAIL);

        try {
            FileOutputStream fos = new FileOutputStream(file.getAbsolutePath());
            fos.write(data.getBytes());
            fos.flush();
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * Read Group Details that are stored in local file path Name JSONGROUPFILENAME
     *
     * @throws Exception {Runtime Stub Exception}
     */
    private boolean readDetails() throws Exception {

        File file = new File(getContext().getCacheDir(), Constants.HOMEDETAIL);

        if (file.exists()) {
            FileInputStream fis = new FileInputStream(file);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader bufferedReader = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                sb.append(line);
            }
            Gson gson = new Gson();
            getAllMediaTimeLines = gson.fromJson(sb.toString(),
                    new TypeToken<List<GetAllMediaTimeLine>>() {
                    }.getType());
            return getAllMediaTimeLines.size() > 0;

        }

        return false;
    }

    public void showNeedFeedAvailable() {

        newFeedavailable.setVisibility(View.VISIBLE);

        YoYo.with(Techniques.SlideInDown).duration(Constants.ANIMATIONTIME).playOn(newFeedavailable);
    }
}
