package com.dubuqu.dnModels.responseModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * Created by ionixx on 14/6/17.
 */

public class DubuquGetGroupResponse implements Serializable {
    @SerializedName("group_name")
    @Expose
    private String groupName;
    /*group_identifier*/
    @SerializedName("group_identifier")
    @Expose
    private String groupIdentifier;
    @SerializedName("group_type")
    @Expose
    private String groupType;
    @SerializedName("member_count")
    @Expose
    private String memberCount;
    @SerializedName("profile_image")
    @Expose
    private String profileImage;
    @SerializedName("own_group")
    @Expose
    private String ownGroup;

    @SerializedName("allow_repost")
    @Expose
    private String allow_repost;


    private String memoryRetain;

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getGroupIdentifier() {
        return groupIdentifier;
    }

    public void setGroupIdentifier(String groupIdentifier) {
        this.groupIdentifier = groupIdentifier;
    }

    public String getGroupType() {
        return groupType;
    }

    public void setGroupType(String groupType) {
        this.groupType = groupType;
    }

    public String getMemberCount() {
        return memberCount;
    }

    public void setMemberCount(String memberCount) {
        this.memberCount = memberCount;
    }

    public String getProfileImage() {
        return profileImage;
    }

    public void setProfileImage(String profileImage) {
        this.profileImage = profileImage;
    }

    public String getMemoryRetain() {
        return memoryRetain;
    }

    public void setMemoryRetain(String memoryRetain) {
        this.memoryRetain = memoryRetain;
    }

    public String getOwnGroup() {
        return ownGroup;
    }

    public void setOwnGroup(String ownGroup) {
        this.ownGroup = ownGroup;
    }

    public String getAllow_repost() {
        return allow_repost;
    }

    public void setAllow_repost(String allow_repost) {
        this.allow_repost = allow_repost;
    }
}
