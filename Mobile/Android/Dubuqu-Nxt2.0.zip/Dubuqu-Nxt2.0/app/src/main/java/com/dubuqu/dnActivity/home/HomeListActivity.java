package com.dubuqu.dnActivity.home;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v4.util.Pair;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.format.DateUtils;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.dubuqu.R;
import com.dubuqu.dnActivity.BaseActivity;
import com.dubuqu.dnAdapter.home.HomeListMediaAdapter;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnModels.responseModel.GetAllMediaTimeLine;
import com.dubuqu.dnModels.responseModel.GetTimeLineStory;
import com.dubuqu.dnModels.responseModel.SharedMedias;
import com.dubuqu.dnRestServices.RestServiceController;
import com.dubuqu.dnRestServices.RestServiceProvider;
import com.dubuqu.dnStorage.SessionManager;
import com.dubuqu.dnUtils.RestServiceUtils;
import com.dubuqu.dnViews.DubuquLinearLayoutManager;
import com.google.gson.Gson;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;

/**
 * Created by Yogaraj subramanian on 5/12/17
 */

public class HomeListActivity extends BaseActivity implements HomeListMediaAdapter.HomeListMediaAdapterCallback {

    final String TAG = HomeListActivity.class.getName();

    HomeListMediaAdapter homeListMediaAdapter;

    RecyclerView recyclerView;

    TextView userName;

    View listView, gridView;

    GetAllMediaTimeLine getAllMediaTimeLine;

    GetTimeLineStory storyTimeLine;

    LinearLayout listMode;

    boolean currentLayoutManagerIsLinear = true, isStoryTimeLine = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_list);

        isStoryTimeLine = getIntent().getBooleanExtra(Constants.ISSTORYTIMELINE, false);

        Bundle bundle = getIntent().getExtras();

        if (bundle != null) {
            String data = bundle.getString(Constants.EXTRASTRINGS);
            if (!isStoryTimeLine)
                getAllMediaTimeLine = new Gson().fromJson(data, GetAllMediaTimeLine.class);
            else
                storyTimeLine = new Gson().fromJson(data, GetTimeLineStory.class);
            try {
                intializeView();
            } catch (Exception e) {
                writeCrachReport(e.getMessage());
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Constants.RESTRICT_SREENSHOT)
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
    }

    @Override
    public void sendBroadCast(int postion, SharedMedias sharedMedias) {

        Intent intent = new Intent(Constants.REFRESHHOMEDATA);
        intent.putExtra(Constants.SELECTEDIMAGES, new Gson().toJson(sharedMedias));
        intent.putExtra(Constants.SHAREMEDA_POSITON, postion);

        if (!isStoryTimeLine)
            intent.putExtra(Constants.TIMELINE_IDENTIFIER, getAllMediaTimeLine.getTimelineIdentifier());

        sendBroadcast(intent);

    }

    @Override
    public void mediaReported(int postion) {

        if (!isStoryTimeLine) {
            List<SharedMedias> sharedMedias = new ArrayList<>();
            if (getAllMediaTimeLine.getSharedMedias().size() > 4) {
                for (int i = 0; i <= 3; i++) {
                    sharedMedias.add(getAllMediaTimeLine.getSharedMedias().get(i));
                }
            } else {
                sharedMedias.addAll(getAllMediaTimeLine.getSharedMedias());
            }

            Intent intent = new Intent(Constants.REFRESHHOMEDATA);
            intent.putExtra(Constants.SELECTEDIMAGES, new Gson().toJson(sharedMedias));
            intent.putExtra(Constants.SHAREMEDA_POSITON, postion);
            intent.putExtra(Constants.ISREPORTEDDATA, true);
            intent.putExtra(Constants.SHAREDMEDIA_COUNT, getAllMediaTimeLine.getSharedMediaCount() - 1);
            intent.putExtra(Constants.TIMELINE_IDENTIFIER, getAllMediaTimeLine.getTimelineIdentifier());
            sendBroadcast(intent);
        }else {
            List<SharedMedias> sharedMedias = new ArrayList<>();
            if (storyTimeLine.getSharedMedias().size() > 4) {
                for (int i = 0; i <= 3; i++) {
                    sharedMedias.add(storyTimeLine.getSharedMedias().get(i));
                }
            } else {
                sharedMedias.addAll(storyTimeLine.getSharedMedias());
            }

            Intent intent = new Intent(Constants.REFRESHHOMEDATA);
            intent.putExtra(Constants.SELECTEDIMAGES, new Gson().toJson(sharedMedias));
            intent.putExtra(Constants.SHAREMEDA_POSITON, postion);
            intent.putExtra(Constants.ISREPORTEDDATA, true);
            intent.putExtra(Constants.SHAREDMEDIA_COUNT, storyTimeLine.getSharedMediasCount() - 1);
            intent.putExtra(Constants.TIMELINE_IDENTIFIER, storyTimeLine.getTimelineIdentifier());
            sendBroadcast(intent);
        }
    }

    private void intializeView() throws Exception {

        recyclerView = findViewById(R.id.feed_list_rcv);
        recyclerView.setLayoutManager(new LinearLayoutManager(HomeListActivity.this));

        boolean isRepostAllowed = true;

        if (!isStoryTimeLine) {
            if (getAllMediaTimeLine.getAllowRepost() == null ||
                    getAllMediaTimeLine.getAllowRepost().equalsIgnoreCase("false")) {
                isRepostAllowed = false;
            }
        }

        homeListMediaAdapter = new HomeListMediaAdapter(HomeListActivity.this,
                isStoryTimeLine ? storyTimeLine.getSharedMedias() :
                        getAllMediaTimeLine.getSharedMedias(),
                this, isRepostAllowed,
                recyclerView,
                isStoryTimeLine ? new SessionManager(HomeListActivity.this).getUserIdentifier() :
                        getAllMediaTimeLine.getUserIdentifier()
        );

        recyclerView.setAdapter(homeListMediaAdapter);

        userName = findViewById(R.id.feed_header_user_name);

        listMode = findViewById(R.id.list_mode_ll);

        listView = findViewById(R.id.mode_list);

        gridView = findViewById(R.id.mode_grid);

        setUserDetails();

        intilaizeListners();
    }

    private void intilaizeListners() throws Exception {

        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                HomeListActivity.super.onBackPressed();
            }
        });

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {

            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

               /* if (recyclerView.getLayoutManager() instanceof LinearLayoutManager) {
                    if (((LinearLayoutManager) recyclerView.getLayoutManager())
                            .findFirstCompletelyVisibleItemPosition() == 0 &&
                            listMode.getVisibility() == View.GONE) {
                        listMode.setVisibility(View.VISIBLE);
                    } else {
                        if (listMode.getVisibility() != View.GONE)
                            listMode.setVisibility(View.GONE);
                    }
                } else if (recyclerView.getLayoutManager() instanceof GridLayoutManager) {
                    if (((GridLayoutManager) recyclerView.getLayoutManager())
                            .findFirstCompletelyVisibleItemPosition() == 0) {
                        listMode.setVisibility(View.VISIBLE);
                    } else {
                        listMode.setVisibility(View.GONE);
                    }
                }*/
            }

        });

        listView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!currentLayoutManagerIsLinear) {
                    gridView.setAlpha(0.5f);
                    listView.setAlpha(1f);
                    currentLayoutManagerIsLinear = !currentLayoutManagerIsLinear;

                    DisplayMetrics displayMetrics = new DisplayMetrics();
                    getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);

                    DubuquLinearLayoutManager layout = new DubuquLinearLayoutManager(HomeListActivity.this);
                    layout.setExtraLayoutSpace(displayMetrics.heightPixels);
                    recyclerView.setLayoutManager(layout);

                    recyclerView.setAdapter(null);
                    recyclerView.setAdapter(homeListMediaAdapter);
                    homeListMediaAdapter.notifyDataSetChanged();
                    listMode.setVisibility(View.VISIBLE);
                }
            }
        });

        gridView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (currentLayoutManagerIsLinear) {
                    gridView.setAlpha(1f);
                    listView.setAlpha(0.5f);
                    currentLayoutManagerIsLinear = !currentLayoutManagerIsLinear;
                    recyclerView.setLayoutManager(new GridLayoutManager(
                            HomeListActivity.this, 2
                    ));
                    recyclerView.setAdapter(null);
                    recyclerView.setAdapter(homeListMediaAdapter);
                    homeListMediaAdapter.notifyDataSetChanged();
                    listMode.setVisibility(View.VISIBLE);
                }
            }
        });

    }

    private void writeCrachReport(String message) {
        super.writeCrashReport(TAG, message);
    }

    private void setUserDetails() throws Exception {
        if (!isStoryTimeLine) {
            if (getAllMediaTimeLine.getType().contains("social-group")) {
                String nameData = getAllMediaTimeLine.getName();
                String userNames = nameData.substring(0, nameData.indexOf("@") - 1);
                String groupNames = nameData.substring(nameData.indexOf("@"));
                userName.setText(userNames);
            } else {
                userName.setText(getAllMediaTimeLine.getName());
            }
        } else {
            userName.setText("Medias");
        }
    }

    private String formatDate(String timeStamp) throws Exception {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));

        Date date = sdf.parse(timeStamp);

        long millis = date.getTime();
        long timeInMillis = System.currentTimeMillis();

        CharSequence text = DateUtils.getRelativeTimeSpanString(millis, timeInMillis, 0, DateUtils.FORMAT_ABBREV_ALL);
        if (text.toString().equalsIgnoreCase("0 sec.ago")) {
            return "just now";
        } else {
            return "Posted\t" + text.toString();
        }

    }


    @Override
    public void onItemClicked(int position, boolean toMediaChat) {
        openMediaInFullView(position, toMediaChat);
    }

    @Override
    public void paginateValue() {
        try {
            String data = "{}";
            OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, HomeListActivity.this);
            Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
            RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
            RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);

            int offset = 0;
            if (!isStoryTimeLine) {
                if (getAllMediaTimeLine.getSharedMedias() != null &&
                        getAllMediaTimeLine.getSharedMediaCount() > getAllMediaTimeLine.getSharedMedias().size()) {
                    offset = getAllMediaTimeLine.getSharedMedias().size();

                    mRetrofitCallBacks.paginatetTimeLineResouces(
                            getAllMediaTimeLine.getTimelineIdentifier(),
                            new RestServiceController.ResponseCallBacks() {
                                @Override
                                public void onResponse(Object o) {
                                    if (o != null) {
                                        List<SharedMedias> sharedMedias = (List<SharedMedias>) o;
                                        if (sharedMedias.size() > 0) {
                                            List<SharedMedias> orginalData = getAllMediaTimeLine.getSharedMedias();
                                            if (orginalData != null) {
                                                orginalData.addAll(sharedMedias);
                                                getAllMediaTimeLine.setSharedMedias(orginalData);
                                                homeListMediaAdapter.notifyDataSetChanged();
                                            } else {
                                                orginalData = sharedMedias;
                                                getAllMediaTimeLine.setSharedMedias(orginalData);
                                                homeListMediaAdapter.notifyDataSetChanged();
                                            }
                                        }
                                    }
                                }

                                @Override
                                public void onFailure(Object o) {

                                }
                            },null, offset);
                }

            } else {
                if (storyTimeLine.getSharedMedias() != null &&
                        storyTimeLine.getSharedMediasCount() > storyTimeLine.getSharedMedias().size()) {
                    offset = storyTimeLine.getSharedMedias().size();

                    mRetrofitCallBacks.getStoryMedias(
                            storyTimeLine.getTimelineIdentifier(),
                            new RestServiceController.ResponseCallBacks() {
                                @Override
                                public void onResponse(Object o) {
                                    if (o != null) {
                                        List<SharedMedias> sharedMedias = (List<SharedMedias>) o;
                                        if (sharedMedias.size() > 0) {
                                            List<SharedMedias> orginalData = storyTimeLine.getSharedMedias();
                                            if (orginalData != null) {
                                                orginalData.addAll(sharedMedias);
                                                storyTimeLine.setSharedMedias(orginalData);
                                                homeListMediaAdapter.notifyDataSetChanged();
                                            } else {
                                                orginalData = sharedMedias;
                                                storyTimeLine.setSharedMedias(orginalData);
                                                homeListMediaAdapter.notifyDataSetChanged();
                                            }
                                        }
                                    }
                                }

                                @Override
                                public void onFailure(Object o) {

                                }
                            }, offset);
                }

            }


        } catch (Exception e) {
            writeCrachReport(e.getMessage());
        }
    }

    private void openMediaInFullView(int currentPostion, boolean shoulShowCommentView) {

        Intent startDetailImageView = new Intent(HomeListActivity.this, HomeDetailImageViewer.class);
        startDetailImageView.putExtra(Constants.ISSTORYTIMELINE, true);

        Bundle bundle = new Bundle();
        bundle.putString(Constants.EXTRASTRINGS, new Gson().toJson(isStoryTimeLine ? storyTimeLine : getAllMediaTimeLine));
        bundle.putInt(Constants.CURRENTIMAGE, currentPostion);
        bundle.putBoolean(Constants.SHOULDSHOWCHAT, shoulShowCommentView);
        startDetailImageView.putExtras(bundle);

//            Pair<View, String> p1 = Pair.create((View) profileImage, "profileimage");
        Pair<View, String> p2 = Pair.create(recyclerView.getLayoutManager().findViewByPosition(currentPostion)
                , "viewpager");

        Pair[] views = new Pair[]{p2};

        ActivityOptionsCompat options = ActivityOptionsCompat.
                makeSceneTransitionAnimation(HomeListActivity.this, views);

        ActivityCompat.startActivity(HomeListActivity.this, startDetailImageView, options.toBundle());
    }

}
