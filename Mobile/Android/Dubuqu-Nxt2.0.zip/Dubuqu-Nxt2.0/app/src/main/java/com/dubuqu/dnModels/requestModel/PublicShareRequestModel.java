package com.dubuqu.dnModels.requestModel;

/**
 * Created by ionixx on 10/7/17.
 */

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PublicShareRequestModel {

    @SerializedName("media_identifier")
    @Expose
    private String mediaIdentifier;

    public String getMediaIdentifier() {
        return mediaIdentifier;
    }

    public void setMediaIdentifier(String mediaIdentifier) {
        this.mediaIdentifier = mediaIdentifier;
    }

}