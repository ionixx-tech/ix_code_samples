package com.dubuqu.dnFragments.socialcircle;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.SearchView;
import android.transition.Explode;
import android.transition.Fade;
import android.transition.Visibility;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.dubuqu.R;
import com.dubuqu.dnActivity.LandingActivity;

/**
 * Created by Yogaraj subramanian on 30/10/17
 */

public class SocialCircleFragment extends Fragment {

    final String TAG = SocialCircleFragment.class.getName();

    ImageView backImv, addCiricleImv;

    TextView currentActionTxtView, doneTxv;

    SearchView searchImv;

    public CurrentSocialCircleAction currentSocialCircleAction =
            CurrentSocialCircleAction.LISTCIRCLE;

    View parentView, frameLayout;

    private Context context;

    private Activity activity;

    boolean isFiltered = false;

    public void handleSarchView() {
        if (searchImv.findViewById(R.id.search_close_btn).getVisibility() == View.VISIBLE) {
            searchImv.findViewById(R.id.search_close_btn).callOnClick();
        }
    }

    public enum CurrentSocialCircleAction {

        EDITCIRCLE,

        EDITCIRCLEADDPARTICIPANT,

        CREATECIRCLEUSERSELCTION,

        CREATECIRCLE,

        LISTCIRCLE
    }

    @Override
    public void onResume() {
        super.onResume();
        try {
            ((LandingActivity) activity).hidetoolbar();
            activity.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        } catch (Exception e) {
            ((LandingActivity) activity).writeCrashReport(TAG,
                    e.getMessage());
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        return inflater.inflate(R.layout.frgament_social_circle, container, false);

    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        try {
            context = getContext();

            activity = getActivity();

            this.parentView = view;

            initalizeViews();
        } catch (Exception e) {
            if (activity instanceof LandingActivity) {
                ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
            }
        }
    }

    private void initalizeViews() throws Exception {


        backImv = parentView.findViewById(R.id.socialcircleback);

        doneTxv = parentView.findViewById(R.id.socialcircleactiondone);

        addCiricleImv = parentView.findViewById(R.id.socailcircle_add_circle);

        currentActionTxtView = parentView.findViewById(R.id.socailcircle_toolbar_text);

        frameLayout = parentView.findViewById(R.id.social_circle_frame_layout);

        searchImv = parentView.findViewById(R.id.socialcircleactionsearch);

        initalizeLizteners();

        replaceFragments(new SocialCircleDashboard());


    }

    private void initalizeLizteners() throws Exception {

        doneTxv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                try {
                    actionDone();
                } catch (Exception e) {
                    if (activity instanceof LandingActivity) {
                        ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                    }
                }
            }
        });

        addCiricleImv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    replaceFragments(new CreateCircleParticipantSelection());
                } catch (Exception e) {
                    if (activity instanceof LandingActivity) {
                        ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                    }
                }
            }
        });

        backImv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    actionBack();
                } catch (Exception e) {
                    if (activity instanceof LandingActivity) {
                        ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                    }
                }
            }
        });

        searchImv.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                try {
                    actionSearch(newText);
                } catch (Exception e) {
                    if (activity instanceof LandingActivity) {
                        ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                    }
                }
                return true;
            }
        });

        searchImv.setOnSearchClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isFiltered = true;
                Fragment fragment = getChildFragmentManager().findFragmentById(frameLayout.getId());
                if (fragment instanceof SocialCircleDashboard) {
                    addCiricleImv.setVisibility(View.GONE);
                }

                if (fragment instanceof CreateCircleParticipantSelection) {
                    doneTxv.setVisibility(View.GONE);
                    backImv.setVisibility(View.GONE);
                }

            }
        });

        searchImv.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                isFiltered = false;
                Fragment fragment = getChildFragmentManager().findFragmentById(frameLayout.getId());
                if (fragment instanceof SocialCircleDashboard) {
                    addCiricleImv.setVisibility(View.VISIBLE);
                }
                if (fragment instanceof CreateCircleParticipantSelection) {
                    doneTxv.setVisibility(View.VISIBLE);
                    backImv.setVisibility(View.VISIBLE);
                }
                return false;
            }
        });


    }


    private void actionSearch(CharSequence text) throws Exception {

        Fragment fragment = getChildFragmentManager().findFragmentById(frameLayout.getId());

        if (fragment instanceof SocialCircleDashboard) {
            ((SocialCircleDashboard) fragment).searchGroup(text);
        }

        if (fragment instanceof CreateCircleParticipantSelection) {
            ((CreateCircleParticipantSelection) fragment).searchUser(text);
        }

    }

    private void actionBack() throws Exception {
        Fragment fragment = getChildFragmentManager().findFragmentById(frameLayout.getId());

        if (fragment instanceof CreateGroup) {
            ((CreateGroup) fragment).handleBackpress();
        }

        if (fragment instanceof CreateCircleParticipantSelection) {
            ((CreateCircleParticipantSelection) fragment).handleBackpress();
        }
    }

    private void actionDone() throws Exception {
        Fragment fragment = getChildFragmentManager().findFragmentById(frameLayout.getId());

        if (fragment instanceof CreateCircleParticipantSelection) {
            ((CreateCircleParticipantSelection) fragment).saveDetails();
        }

        if (fragment instanceof CreateGroup) {
            ((CreateGroup) fragment).saveAndExit();
        }
    }

    public void setCurrentSocialCircleAction(CurrentSocialCircleAction currentSocialCircleAction)
            throws Exception {
        this.currentSocialCircleAction = currentSocialCircleAction;
    }

    void replaceFragments(Fragment fragment) throws Exception {

        FragmentTransaction fragmentTransaction = getChildFragmentManager().beginTransaction();

        fragmentTransaction.replace(frameLayout.getId(), fragment);

        if (fragment instanceof CreateCircleParticipantSelection) {
            Fade fade = new Fade();
            fade.setDuration(500);
            fragment.setEnterTransition(fade);
            Fade fadeOut = new Fade(Visibility.MODE_OUT);
            fragment.setExitTransition(fadeOut);
        }

        if (fragment instanceof CreateGroup) {
            Explode explode = new Explode();
            explode.setDuration(700);
            fragment.setEnterTransition(explode);
        }

        fragment.setAllowEnterTransitionOverlap(true);

        fragmentTransaction.commit();
    }

    public void toggleToobarbasedOnOptions() throws Exception {

        switch (currentSocialCircleAction) {
            case EDITCIRCLE:
                doneTxv.setVisibility(View.VISIBLE);
                doneTxv.setText(getString(R.string.update));
                backImv.setVisibility(View.VISIBLE);
                backImv.setImageResource(R.drawable.ic_left_arrow);
                addCiricleImv.setVisibility(View.GONE);
                searchImv.setVisibility(View.GONE);
                currentActionTxtView.setText(getString(R.string.edit_circle));
                break;

            case CREATECIRCLE:
                doneTxv.setVisibility(View.VISIBLE);
                doneTxv.setText(getString(R.string.create));
                backImv.setVisibility(View.VISIBLE);
                backImv.setImageResource(R.drawable.ic_left_arrow);
                addCiricleImv.setVisibility(View.GONE);
                searchImv.setVisibility(View.GONE);
                currentActionTxtView.setText(getString(R.string.create_circle));

                break;

            case LISTCIRCLE:
                doneTxv.setVisibility(View.GONE);
                backImv.setVisibility(View.GONE);
                searchImv.setVisibility(View.VISIBLE);
                addCiricleImv.setVisibility(View.VISIBLE);
                currentActionTxtView.setText(getString(R.string.groups));

                break;

            case CREATECIRCLEUSERSELCTION:
                doneTxv.setVisibility(View.VISIBLE);
                doneTxv.setText(getString(R.string.next));
                backImv.setVisibility(View.VISIBLE);
                backImv.setImageResource(R.drawable.ic_close);
                addCiricleImv.setVisibility(View.GONE);
                searchImv.setVisibility(View.VISIBLE);
                currentActionTxtView.setText(getString(R.string.add_participants));

                break;

            case EDITCIRCLEADDPARTICIPANT:
                doneTxv.setVisibility(View.VISIBLE);
                doneTxv.setText(getString(R.string.next));
                backImv.setVisibility(View.VISIBLE);
                backImv.setImageResource(R.drawable.ic_close);
                addCiricleImv.setVisibility(View.GONE);
                searchImv.setVisibility(View.GONE);
                currentActionTxtView.setText(getString(R.string.add_participants));

                break;
        }

    }

}
