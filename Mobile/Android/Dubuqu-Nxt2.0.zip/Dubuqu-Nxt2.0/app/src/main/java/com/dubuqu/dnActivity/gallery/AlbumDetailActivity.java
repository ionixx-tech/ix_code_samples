package com.dubuqu.dnActivity.gallery;

import android.animation.Animator;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.dubuqu.R;
import com.dubuqu.dnActivity.BaseActivity;
import com.dubuqu.dnActivity.MultipleShareActivity;
import com.dubuqu.dnActivity.mediapreview.DubuquMediaViewerActivity;
import com.dubuqu.dnAdapter.gallery.CollageAdapter;
import com.dubuqu.dnAdapter.gallery.GalleryListAdapter;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnModels.commonModel.ActionConformationDialog;
import com.dubuqu.dnModels.commonModel.GalleryAlbumList;
import com.dubuqu.dnModels.commonModel.GalleryMediaListModel;
import com.dubuqu.dnReceiver.ImageListLoaderReceiver;
import com.dubuqu.dnServices.MediaDeleteService;
import com.dubuqu.dnServices.MediaLoadAlbumDetailService;
import com.dubuqu.dnStorage.DbHelper;
import com.dubuqu.dnStorage.RecentShareDbModel;
import com.dubuqu.dnUtils.RestServiceUtils;
import com.dubuqu.dnUtils.Utils;
import com.dubuqu.dnViews.DragSelectTouchListener;
import com.dubuqu.dnViews.DubuquCollageView;
import com.dubuqu.dnViews.StickyHeaderGridLayoutManager;
import com.google.gson.Gson;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

/**
 * Created by Yogaraj subramanian on 2/11/17
 */

public class AlbumDetailActivity extends BaseActivity implements ImageListLoaderReceiver.Receiver,
        GalleryListAdapter.GalleryAdapterCallBack {

    private final String TAG = AlbumDetailActivity.class.getName();

    private String currentFolderName = "";

    private HashMap<Date, List<GalleryMediaListModel>> galleryHashMap = new HashMap<>();

    private List<String> selectedImage = new ArrayList<>();

    private GalleryListAdapter galleryListAdapter;

    private RelativeLayout toolBarRL;

    private View quickShareView;

    private RecyclerView mediaRecyclerView;

    private TextView noOfImagesSelectedTV, quickShareUserOneTv, quickShareUserTwoTv, quickShareUserThreeTv;

    private DragSelectTouchListener touchListener;

    private LinearLayout frequentUserLL, showMoreContacts;

    private ImageView closeQuickSharePopup, collagePictures, deleteMedias, shareMedia, backImageView,
            quickShareuserOneImv, quickShareuserTwoImv, quickShareuserThreeImv;

    private PopupWindow popupWindow = null;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            Bundle intentBundle = getIntent().getExtras();
            currentFolderName = intentBundle.getString(Constants.FOLDERNAME);
            startService();
            setContentView(R.layout.activity_album_detail);
            initalizeViews();

        } catch (Exception e) {
            super.writeCrashReport(TAG, e.getMessage());
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(onMediaItemsChanged, new IntentFilter(Constants.MEDIAALBUMLISTCHANGED));
        registerReceiver(onAllMediaDeleted, new IntentFilter(Constants.ALLMEDIADELETED));

        registerReceiver(updateRecentShare, new IntentFilter(Constants.UPDATERECENTSHARE));

        if (Constants.RESTRICT_SREENSHOT)
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        unregisterReceiver(onMediaItemsChanged);
        unregisterReceiver(onAllMediaDeleted);

        unregisterReceiver(updateRecentShare);
    }

    BroadcastReceiver updateRecentShare = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            try {
                updateUserForQuickShare();
            } catch (Exception e) {
                Log.e(TAG, e.getMessage());
            }
        }
    };

    private void initalizeViews() throws Exception {

        galleryListAdapter = new GalleryListAdapter(AlbumDetailActivity.this, galleryHashMap);
        galleryListAdapter.setGalleryAdapterCallBack(this);

        mediaRecyclerView = findViewById(R.id.album_detail_activity_rcv);

        quickShareView = findViewById(R.id.album_detail_activity_quickshareview);

        quickShareView.setVisibility(View.GONE);

        touchListener = new DragSelectTouchListener();

        closeQuickSharePopup = findViewById(R.id.quick_share_cancel);

        noOfImagesSelectedTV = findViewById(R.id.quick_share_number_of_media_selected);

        collagePictures = findViewById(R.id.quick_share_collage_images);

        shareMedia = findViewById(R.id.quick_share_external_share);

        frequentUserLL = findViewById(R.id.quick_share_frequent_users_ll);

        deleteMedias = findViewById(R.id.quick_share_delete_medias);

        TextView albumNameTextView = findViewById(R.id.album_activity_toolbar_textview);

        albumNameTextView.setText(currentFolderName.equals("") ? getString(R.string.app_name) :
                currentFolderName);

        backImageView = findViewById(R.id.album_activity_back);

        quickShareuserOneImv = findViewById(R.id.rcntprofileone);

        quickShareUserOneTv = findViewById(R.id.rcntusernameone);

        quickShareuserTwoImv = findViewById(R.id.rcntuserprofiletwo);

        quickShareUserTwoTv = findViewById(R.id.rcntusernametwo);

        quickShareuserThreeImv = findViewById(R.id.rcntuserProfilethree);

        quickShareUserThreeTv = findViewById(R.id.rcntusernamethree);

        toolBarRL = findViewById(R.id.album_detail_activity_toolbar_ll);

        showMoreContacts = findViewById(R.id.showMoreContacts);

        initalizeListeners();

        updateUserForQuickShare();
    }

    /**
     * initlaize event or click lisenters used here
     *
     * @throws Exception {Run time Stub Exception.}
     */
    private void initalizeListeners() throws Exception {

        galleryListAdapter.setLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                try {
                    int position = mediaRecyclerView.getChildAdapterPosition(view);
                    if (galleryListAdapter.isInMultipselectMode()) {
                        touchListener.setStartSelectPosition(position);
                    }
                    galleryListAdapter.onItemMove(position);
                } catch (Exception e) {
                    AlbumDetailActivity.super.writeCrashReport(TAG, e.getMessage());
                }

                return false;
            }
        });

        touchListener.setSelectListener(new DragSelectTouchListener.onSelectListener() {
            @Override
            public void onSelectChange(int start, int end, boolean isSelected) {
                try {
                    galleryListAdapter.onItemMove(end);
                } catch (Exception e) {
                    AlbumDetailActivity.super.writeCrashReport(TAG, e.getMessage());
                }
            }
        });

        closeQuickSharePopup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    deSelectMedias();
                    toggleCollageIcon(false);
                    toogleQuickSahre(false);
                } catch (Exception e) {
                    AlbumDetailActivity.super.writeCrashReport(TAG, e.getMessage());
                }
            }
        });

        shareMedia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    shareMediaToExternalApps();
                } catch (Exception e) {
                    AlbumDetailActivity.super.writeCrashReport(TAG, e.getMessage());
                }
            }
        });

        collagePictures.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (frequentUserLL.getVisibility() == View.VISIBLE)
                        showCollageOptions();
                } catch (Exception e) {
                    AlbumDetailActivity.super.writeCrashReport(TAG, e.getMessage());
                }
            }
        });

        deleteMedias.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    showDeleteMediaConformation();
                } catch (Exception e) {
                    AlbumDetailActivity.super.writeCrashReport(TAG, e.getMessage());
                }
            }
        });

        backImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        quickShareuserOneImv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    shareMediaToFregquentUsers(0);
                } catch (Exception e) {
                    AlbumDetailActivity.super.writeCrashReport(TAG, e.getMessage());
                }
            }
        });

        quickShareuserTwoImv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    shareMediaToFregquentUsers(1);
                } catch (Exception e) {
                    AlbumDetailActivity.super.writeCrashReport(TAG, e.getMessage());
                }
            }
        });

        quickShareuserThreeImv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    shareMediaToFregquentUsers(2);
                } catch (Exception e) {
                    AlbumDetailActivity.super.writeCrashReport(TAG, e.getMessage());
                }
            }
        });

        showMoreContacts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (selectedImage.size() > 0) {

                    Intent intent = new Intent(AlbumDetailActivity.this, MultipleShareActivity.class);
                    String imageData = new Gson().toJson(selectedImage);
                    Bundle bundle = new Bundle();
                    bundle.putString(Constants.EXTRASTRINGS, imageData);
                    intent.putExtras(bundle);
                    startActivity(intent);
                    try {
                        toggleCollageIcon(false);
                        toogleQuickSahre(false);
                        deSelectMedias();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        });

    }

    private void shareMediaToFregquentUsers(int position) throws Exception {

        toggleCollageIcon(false);
        toogleQuickSahre(false);

        DbHelper dbHelper = new DbHelper(AlbumDetailActivity.this);
        List<RecentShareDbModel> recentShareDbModels = dbHelper.getAllRecentusers();
        if (recentShareDbModels != null) {

            RecentShareDbModel recentShareDbModel = recentShareDbModels.get(position);

            List<String> selectedUsers = new ArrayList<>();
            selectedUsers.add(recentShareDbModel.getIdentifier());

            Gson g = new Gson();

            String SselectedUsers = g.toJson(selectedUsers);
            Random random = new Random();
            String fileList = g.toJson(selectedImage);
            RestServiceUtils.scheduleUploadMediaFile(AlbumDetailActivity.this,
                    fileList, SselectedUsers, false);

        }

        deSelectMedias();
    }

    /**
     * Show Delete media conformation popup.
     *
     * @throws Exception {Runtime Stub Exception}
     */
    private void showDeleteMediaConformation() throws Exception {

        new ActionConformationDialog(
                getString(R.string.delete_media),
                getString(R.string.confirm_delete), AlbumDetailActivity.this,
                new ActionConformationDialog.OnActionCOnformationListner() {

                    @Override
                    public void onConformed() {
                        if (selectedImage.size() > 0) {

                            Bundle bundle = new Bundle();

                            String formattedDate = new Gson().toJson(selectedImage);

                            bundle.putString(Constants.EXTRASTRINGS, formattedDate);

                            Intent intent = new Intent(AlbumDetailActivity.this, MediaDeleteService.class);

                            intent.putExtras(bundle);

                            startService(intent);

                            try {
                                AlbumDetailActivity.super.showLoaders(AlbumDetailActivity.this);
                            } catch (Exception e) {
                                AlbumDetailActivity.super.writeCrashReport(TAG, e.getMessage());
                            }
                        }
                    }

                    @Override
                    public void onRejected() {
                        try {
                            deSelectMedias();
                        } catch (Exception e) {
                            AlbumDetailActivity.super.writeCrashReport(TAG, e.getMessage());
                        }
                    }
                });
    }


    /**
     * if fragment is replaced the data must be deselected
     *
     * @throws Exception {Runtime Stub Exception}
     */
    private void deSelectMedias() throws Exception {

        List<Date> values = new ArrayList<>(galleryHashMap.keySet());

        for (Date date : values) {

            List<GalleryMediaListModel> galleryMediaListModels = galleryHashMap.get(date);

            for (GalleryMediaListModel galleryMediaListModel : galleryMediaListModels) {

                if (galleryMediaListModel.isSelected()) {
                    galleryMediaListModel.setSelected(false);
                }
            }
        }

        if (selectedImage.size() > 0) {
            selectedImage.clear();
        }

        galleryListAdapter.setInMultipselectMode(false);

        galleryListAdapter.notifyAllSectionsDataSetChanged();
    }

    /**
     * Show or Hide Collage icon
     * <p>
     * false => show collage option
     * true =>  hides i.e video or images more than 9 is selected.
     * </p>
     *
     * @param shouldHideCOllageIcon Boolean Value
     */
    private void toggleCollageIcon(boolean shouldHideCOllageIcon) throws Exception {
        if (shouldHideCOllageIcon)
            collagePictures.setVisibility(View.GONE);
        else
            collagePictures.setVisibility(View.VISIBLE);
    }

    /**
     * toogle quickshare Navigation bar
     * <p>
     * true=> show ;  false= >hide;
     *
     * @param toogleOption whether to hide or show
     * @throws Exception {Runtime Stub Exception}
     */
    private void toogleQuickSahre(boolean toogleOption) throws Exception {
        if (toogleOption) {
            if (quickShareView.getVisibility() == View.GONE) {
                toolBarRL.setVisibility(View.GONE);
                quickShareView.setVisibility(View.VISIBLE);
                YoYo.with(Techniques.SlideInDown)
                        .duration(Constants.ANIMATIONTIME)
                        .onEnd(new YoYo.AnimatorCallback() {
                            @Override
                            public void call(Animator animator) {

                            }
                        }).playOn(quickShareView);
            }
        } else {
            quickShareView.setVisibility(View.GONE);
            toolBarRL.setVisibility(View.VISIBLE);

        }
    }

    /**
     * Hide frequent User Layout and show Collage layout
     *
     * @throws Exception {Runtime Stub Exception}
     */
    private void showCollageOptions() throws Exception {

        TypedArray collageTemplates = getResources().obtainTypedArray(R.array.collage_templates);

        RecyclerView collageRcv = findViewById(R.id.quick_share_collage_rcv);


        CollageAdapter collageAdapter = new CollageAdapter(collageTemplates, AlbumDetailActivity.this, new CollageAdapter.OnItemClick() {
            @Override
            public void getPostion(int postion) {
                DubuquCollageView.CollageOption collageOption = null;
                switch (postion) {
                    case 0:
                        collageOption = DubuquCollageView.CollageOption.COLLAGE_2_2;
                        break;
                    case 1:
                        collageOption = DubuquCollageView.CollageOption.COLLAGE_2_1;
                        break;
                    case 2:
                        collageOption = DubuquCollageView.CollageOption.COLLAGE_3_2;
                        break;
                    case 3:
                        collageOption = DubuquCollageView.CollageOption.COLLAGE_3_1;
                        break;
                    case 4:
                        collageOption = DubuquCollageView.CollageOption.COLLAGE_4_1;
                        break;
                    case 5:
                        collageOption = DubuquCollageView.CollageOption.COLLAGE_4_2;
                        break;
                    case 6:
                        collageOption = DubuquCollageView.CollageOption.COLLAGE_5_1;
                        break;
                    case 7:
                        collageOption = DubuquCollageView.CollageOption.COLLAGE_5_2;
                        break;
                    case 8:
                        collageOption = DubuquCollageView.CollageOption.COLLAGE_6_1;
                        break;
                    case 9:
                        collageOption = DubuquCollageView.CollageOption.COLLAGE_7_1;
                        break;
                    case 10:
                        collageOption = DubuquCollageView.CollageOption.COLLAGE_8_1;
                        break;
                    case 11:
                        collageOption = DubuquCollageView.CollageOption.COLLAGE_9_1;
                        break;
                }
                try {
                    hideCollageOptions();
                    toggleCollageIcon(false);
                    toogleQuickSahre(false);
                    showCollageView(collageOption);
                } catch (Exception e) {
                    AlbumDetailActivity.super.writeCrashReport(TAG,
                            e.getMessage());
                }
            }
        });

        collageRcv.setLayoutManager(new LinearLayoutManager(AlbumDetailActivity.this,
                LinearLayoutManager.HORIZONTAL, false));
        collageRcv.setAdapter(collageAdapter);

        frequentUserLL.setVisibility(View.GONE);

        collageRcv.setVisibility(View.VISIBLE);

        YoYo.with(Techniques.SlideInRight)
                .duration(Constants.ANIMATIONTIME)
                .playOn(collageRcv);

    }

    /**
     * Hide collage layout and show frequent user layout
     *
     * @throws Exception {Runtime Stub Exception}
     */
    private void hideCollageOptions() throws Exception {

        frequentUserLL.setVisibility(View.VISIBLE);

        YoYo.with(Techniques.SlideInLeft)
                .duration(Constants.ANIMATIONTIME)
                .playOn(frequentUserLL);

        RecyclerView collageRcv = findViewById(R.id.quick_share_collage_rcv);

        collageRcv.setVisibility(View.GONE);

    }


    /**
     * Show Collage View PopUp
     *
     * @param collageOption {@link DubuquCollageView} refer for details
     * @throws Exception {@link Exception}
     */
    private void showCollageView(DubuquCollageView.CollageOption collageOption) throws Exception {

        LayoutInflater inflater = (LayoutInflater)
                getSystemService(LAYOUT_INFLATER_SERVICE);

        View reportDreamView = inflater.inflate(R.layout.dubuqucollagelayout, null);


        final LinearLayout collageLayoutLL = reportDreamView.findViewById(R.id.collageview);
        collageLayoutLL.setDrawingCacheEnabled(true);
        collageLayoutLL.setDrawingCacheBackgroundColor(Color.WHITE);


        DubuquCollageView dubuquCollageView = new DubuquCollageView(AlbumDetailActivity.this
                , selectedImage);
        dubuquCollageView.setCollageOption(collageOption);
        collageLayoutLL.addView(dubuquCollageView);

        TextView createCollageTV = reportDreamView.findViewById(R.id.collage_done);

        TextView cloaseCollageView = reportDreamView.findViewById(R.id.collage_close);

        cloaseCollageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                popupWindow.dismiss();
                popupWindow = null;
            }
        });
        createCollageTV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {

                    AlbumDetailActivity.super.showLoaders(AlbumDetailActivity.this);
                    popupWindow.dismiss();

                    saveCollageImage(collageLayoutLL);
                } catch (Exception e) {
                    AlbumDetailActivity.super.writeCrashReport(TAG,
                            e.getMessage());
                }
            }
        });

        popupWindow = new PopupWindow(reportDreamView);
        popupWindow.setWidth(ViewGroup.LayoutParams.MATCH_PARENT);
        popupWindow.setHeight(ViewGroup.LayoutParams.MATCH_PARENT);
        popupWindow.setOutsideTouchable(true);
        popupWindow.setFocusable(true);
        popupWindow.setBackgroundDrawable(new ColorDrawable(Color.WHITE));

        if (!popupWindow.isShowing()) {
            popupWindow.showAtLocation(reportDreamView, 0, 0, Gravity.NO_GRAVITY);
        }
    }

    /**
     * Save CollagedImages
     *
     * @param collageLayoutLL the View that contains the images
     * @throws Exception {@link Exception}
     */
    private void saveCollageImage(LinearLayout collageLayoutLL) throws Exception {
        Date now = new Date();
        android.text.format.DateFormat.format("yyyy-MM-dd_hh:mm:ss", now);

        // image naming and path  to include sd card  appending name you choose for file
        String mPath = Environment.getExternalStorageDirectory().toString() + "/" + now + ".jpg";

        // create bitmap screen capture
        Bitmap bitmap = Bitmap.createBitmap(collageLayoutLL.getDrawingCache());
        collageLayoutLL.setDrawingCacheEnabled(false);

        File imageFile = new File(mPath);

        FileOutputStream outputStream = new FileOutputStream(imageFile);
        int quality = 100;
        bitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream);
        outputStream.flush();
        outputStream.close();
        Uri imagePath = Uri.fromFile(imageFile);

        ContentValues values = new ContentValues();

        values.put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis());
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpg");
        values.put(MediaStore.MediaColumns.DATA, imagePath.getPath());

        getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        popupWindow.dismiss();
        Utils.showToast(AlbumDetailActivity.this,
                "Collage Created Sucessfully.");

        deSelectMedias();
        startService();

        AlbumDetailActivity.super.cancelPopUp();

        Intent sendBroadCastIntent = new Intent(Constants.MEDIAITEMCHANGED);
        sendBroadcast(sendBroadCastIntent);

    }

    /**
     * Share media to external applications
     *
     * @throws Exception {Runtime Stub Exception}
     */
    private void shareMediaToExternalApps() throws Exception {

        if (selectedImage.size() > 0) {

            ArrayList<Uri> imageUris = new ArrayList<>();

            for (String s : selectedImage)
                imageUris.add(Uri.parse(s));

            Intent shareIntent = new Intent();
            shareIntent.setAction(Intent.ACTION_SEND_MULTIPLE);
            shareIntent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, imageUris);
            shareIntent.setType("image/*");
            startActivity(Intent.createChooser(shareIntent, "Share images to.."));

            deSelectMedias();
            toggleCollageIcon(false);
            toogleQuickSahre(false);
        }
    }

    private void deleteMediaFromSdCard() throws Exception {
        List<Date> values = new ArrayList<>(galleryHashMap.keySet());

        List<Date> tempKey = new ArrayList<>();

        for (Date date : values) {

            List<GalleryMediaListModel> galleryMediaListModels = galleryHashMap.get(date);

            List<GalleryMediaListModel> tempIndex = new ArrayList<GalleryMediaListModel>();

            for (GalleryMediaListModel galleryMediaListModel : galleryMediaListModels) {

                if (galleryMediaListModel.isSelected()) {
                    tempIndex.add(galleryMediaListModel);
                }
            }

            galleryMediaListModels.removeAll(tempIndex);
            galleryHashMap.put(date, galleryMediaListModels);

            if (galleryMediaListModels.size() <= 0) {
                tempKey.add(date);
            }
        }

        for (int i = 0; i < tempKey.size(); i++) {
            galleryHashMap.remove(tempKey.get(i));
            galleryListAdapter.removeDate(tempKey.get(i));
        }


        if (galleryHashMap.size() == 0) {

            mediaRecyclerView.setVisibility(View.GONE);
            mediaRecyclerView.setAdapter(null);

            findViewById(R.id.no_media_available).setVisibility(View.VISIBLE);
        }

        Utils.showToast(AlbumDetailActivity.this, "Media Deleted Sucessfully.");

        toogleQuickSahre(false);

        selectedImage.clear();

        deSelectMedias();

    }

    private void getSelectedMedias() throws Exception {
        if (selectedImage.size() > 0)
            selectedImage.clear();

        if (galleryHashMap.size() == 0)
            return;

        List<Date> values = new ArrayList<>(galleryHashMap.keySet());

        for (Date date : values) {

            List<GalleryMediaListModel> galleryMediaListModels = galleryHashMap.get(date);

            for (GalleryMediaListModel galleryMediaListModel : galleryMediaListModels) {

                if (galleryMediaListModel.isSelected()) {
                    selectedImage.add(galleryMediaListModel.getMediaPath());
                }

            }
        }
        if (checkIfVideoSelected() || selectedImage.size() <= 1)
            toggleCollageIcon(true);
        else
            toggleCollageIcon(false);
        if (selectedImage.size() > 0) {
            toogleQuickSahre(true);
            noOfImagesSelectedTV.setText(String.valueOf(selectedImage.size()).concat(getString(R.string.media_selected)));
        } else {
            toogleQuickSahre(false);
        }
    }

    /**
     * checks if any video or images is selcted more than 9
     * if yes need to hide the collage icon
     */
    private boolean checkIfVideoSelected() throws Exception {

        if (selectedImage.size() > 9) {
            return true;
        }

        for (String selectedMedia : selectedImage) {

            if (Utils.getMimeType(selectedMedia).contains("video")
                    || Utils.getMimeType(selectedMedia).contains("mp4")
                    || Utils.getMimeType(selectedMedia).contains("3gp"))
                return true;
        }

        return false;
    }


    /**
     * change adater gallery list view
     *
     * @throws Exception{Runtime stub exception}
     */
    private void loadGalerryListData() throws Exception {

        mediaRecyclerView.setAdapter(null);

        StickyHeaderGridLayoutManager gridLayoutManager = new StickyHeaderGridLayoutManager(3);
        gridLayoutManager.setHeaderBottomOverlapMargin(20);
        if (galleryListAdapter.getDateValues().size() == 0 && galleryHashMap.size() > 0) {
            galleryListAdapter.setDateValues(new ArrayList<>(galleryHashMap.keySet()));
        }
        mediaRecyclerView.setAdapter(galleryListAdapter);
        mediaRecyclerView.setLayoutManager(gridLayoutManager);

        if (galleryHashMap.size() > 0)
            mediaRecyclerView.addOnItemTouchListener(touchListener);

        galleryListAdapter.notifyAllSectionsDataSetChanged();

    }

    @Override
    public void onReceiveResult(HashMap<Date, List<GalleryMediaListModel>> galleryListModel) {
        if (galleryHashMap.size() > 0)
            galleryHashMap.clear();
        galleryHashMap.putAll(galleryListModel);
        galleryListAdapter.setDateValues(new ArrayList<>(galleryHashMap.keySet()));
        try {
            loadGalerryListData();
        } catch (Exception e) {
            super.writeCrashReport(TAG,
                    e.getMessage());
        }
    }

    @Override
    public void onReceiveAlbumList(HashMap<String, GalleryAlbumList> albumList) {

    }


    @Override
    public void onMediaClicked() {
        try {
            getSelectedMedias();
        } catch (Exception e) {
            super.writeCrashReport(TAG,
                    e.getMessage());
        }
    }


    @Override
    public void openMediaInFullView(String imageUrl) {
        try {
            Bundle bundle = new Bundle();

            List<String> listOfImages = new ArrayList<>();

            for (Object key : galleryListAdapter.getDateValues()) {
                List<GalleryMediaListModel> galleryMediaListModels =
                        galleryHashMap.get(key);

                if (galleryMediaListModels != null && galleryMediaListModels.size() > 0) {

                    for (GalleryMediaListModel galleryMediaListModel
                            : galleryMediaListModels) {

                        listOfImages.add(galleryMediaListModel.getMediaPath());

                        if (galleryMediaListModel.getMediaPath().equalsIgnoreCase(imageUrl))
                            bundle.putInt(Constants.CURRENTIMAGE, listOfImages.size());
                    }

                }
            }

            String formattedDate = new Gson().toJson(listOfImages);

            bundle.putString(Constants.EXTRASTRINGS, formattedDate);

            Intent intent = new Intent(AlbumDetailActivity.this,
                    DubuquMediaViewerActivity.class);

            intent.putExtras(bundle);

            startActivity(intent);

        } catch (Exception e) {
            super.writeCrashReport(TAG,
                    e.getMessage());
        }

    }

    private void startService() throws Exception {

        ImageListLoaderReceiver imageListLoaderReceiver = new ImageListLoaderReceiver(new Handler(),
                this);
        Intent galleyIntent = new Intent(this, MediaLoadAlbumDetailService.class);
        galleyIntent.putExtra(Constants.EXTRASTRINGS, imageListLoaderReceiver);
        galleyIntent.putExtra(Constants.FOLDERNAME, currentFolderName);
        startService(galleyIntent);
    }

    BroadcastReceiver onMediaItemsChanged = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            try {
                startService();
            } catch (Exception e) {
                AlbumDetailActivity.super.writeCrashReport(TAG, e.getMessage());
            }
        }
    };

    BroadcastReceiver onAllMediaDeleted = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            try {
                deleteMediaFromSdCard();
                AlbumDetailActivity.super.cancelPopUp();
                Intent sendBroadCastIntent = new Intent(Constants.MEDIAITEMCHANGED);
                sendBroadcast(sendBroadCastIntent);
            } catch (Exception e) {
                AlbumDetailActivity.super.writeCrashReport(TAG, e.getMessage());
            }
        }
    };

    /**
     * Update quick share options to views.
     *
     * @throws Exception{Runtime Stub Exception}
     */
    private void updateUserForQuickShare() throws Exception {

        DbHelper dbHelper = new DbHelper(AlbumDetailActivity.this);
        List<RecentShareDbModel> recentShareDbModels = dbHelper.getAllRecentusers();

        int iterator = 0;

        for (RecentShareDbModel shareDbModel : recentShareDbModels) {
            final Drawable drawable = new BitmapDrawable(
                    Utils.textAsBitmap(shareDbModel.getUserName(), AlbumDetailActivity.this));
            String userName = shareDbModel.getUserName();

            switch (iterator) {

                case 0:
                    if (shareDbModel.getProfilePic() != null &&
                            !shareDbModel.getProfilePic().equalsIgnoreCase("")) {
                        ImageLoader.getInstance().displayImage(
                                shareDbModel.getProfilePic(),
                                quickShareuserOneImv, new ImageLoadingListener() {
                                    @Override
                                    public void onLoadingStarted(String imageUri, View view) {
                                        quickShareuserOneImv.setImageDrawable(drawable);
                                    }

                                    @Override
                                    public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
                                        quickShareuserOneImv.setImageDrawable(drawable);
                                    }

                                    @Override
                                    public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                                        quickShareuserOneImv.setImageBitmap(loadedImage);
                                    }

                                    @Override
                                    public void onLoadingCancelled(String imageUri, View view) {
                                        quickShareuserOneImv.setImageDrawable(drawable);
                                    }
                                });
                    } else {
                        quickShareuserOneImv.setImageDrawable(drawable);
                    }
                    quickShareUserOneTv.setText(userName);
                    break;

                case 1:
                    if (shareDbModel.getProfilePic() != null &&
                            !shareDbModel.getProfilePic().equalsIgnoreCase("")) {
                        ImageLoader.getInstance().displayImage(
                                shareDbModel.getProfilePic(),
                                quickShareuserTwoImv, new ImageLoadingListener() {
                                    @Override
                                    public void onLoadingStarted(String imageUri, View view) {
                                        quickShareuserTwoImv.setImageDrawable(drawable);
                                    }

                                    @Override
                                    public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
                                        quickShareuserTwoImv.setImageDrawable(drawable);
                                    }

                                    @Override
                                    public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                                        quickShareuserTwoImv.setImageBitmap(loadedImage);
                                    }

                                    @Override
                                    public void onLoadingCancelled(String imageUri, View view) {
                                        quickShareuserTwoImv.setImageDrawable(drawable);
                                    }
                                });
                    } else {
                        quickShareuserTwoImv.setImageDrawable(drawable);
                    }
                    quickShareUserTwoTv.setText(userName);
                    break;

                case 2:
                    if (shareDbModel.getProfilePic() != null &&
                            !shareDbModel.getProfilePic().equalsIgnoreCase("")) {
                        ImageLoader.getInstance().displayImage(
                                shareDbModel.getProfilePic(),
                                quickShareuserThreeImv, new ImageLoadingListener() {
                                    @Override
                                    public void onLoadingStarted(String imageUri, View view) {
                                        quickShareuserThreeImv.setImageDrawable(drawable);
                                    }

                                    @Override
                                    public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
                                        quickShareuserThreeImv.setImageDrawable(drawable);
                                    }

                                    @Override
                                    public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                                        quickShareuserThreeImv.setImageBitmap(loadedImage);
                                    }

                                    @Override
                                    public void onLoadingCancelled(String imageUri, View view) {
                                        quickShareuserThreeImv.setImageDrawable(drawable);
                                    }
                                });
                    } else {
                        quickShareuserThreeImv.setImageDrawable(drawable);
                    }
                    quickShareUserThreeTv.setText(userName);
                    break;
            }

            iterator++;
        }
    }

}
