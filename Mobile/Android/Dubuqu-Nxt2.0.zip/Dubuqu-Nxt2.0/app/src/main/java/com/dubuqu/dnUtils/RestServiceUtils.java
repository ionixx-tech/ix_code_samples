package com.dubuqu.dnUtils;

import android.annotation.SuppressLint;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.PersistableBundle;
import android.util.Log;

import com.dubuqu.dnApplication.AppController;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnConstants.UploadConstants;
import com.dubuqu.dnServices.UploadMediaService;
import com.dubuqu.dnServices.UserProfileImageUpdateService;
import com.dubuqu.dnStorage.DbHelper;
import com.dubuqu.dnStorage.SessionManager;
import com.dubuqu.dnStorage.upload.UploadDbModel;
import com.dubuqu.dnStorage.upload.UploadMapModel;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static com.dubuqu.dnUtils.Utils.calculateRFC2104HMAC;

/**
 * Created by Yogaraj subramanian on 23/10/17
 */

public class RestServiceUtils {

    /*
   * Creates an Gson parser network call with base url.
   * here we  added header authorization using okhttp.
   * refer: Vogella/retrofit.com
   * */
    public static Retrofit makeHttpRequest(OkHttpClient okHttpClient) {
        if (okHttpClient == null) {
            return null;
        } else {
            Gson gson = new GsonBuilder()
                    .setDateFormat("yyyy-MM-dd'T'HH:mm:ssZ")
                    .setLenient()
                    .create();


            return new Retrofit.Builder()
                    .baseUrl(Constants.BASE_API_PATH)
                    .addConverterFactory(GsonConverterFactory.create(gson))
                    .client(okHttpClient)
                    .build();
        }
    }

    public static Retrofit makeHttpRequest() {

        Gson gson = new GsonBuilder()
                .setDateFormat("yyyy-MM-dd'T'HH:mm:ssZ")
                .setLenient()
                .create();

        return new Retrofit.Builder()
                .baseUrl(Constants.TENORBASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();

    }

    /**
     * Make HTTP request in Mcrypt Format
     *
     * @param okHttpClient {@link OkHttpClient} client which contains the headers {{@link #getHeader(String, Context)}}
     * @return {@link Retrofit} callable retrofit Object
     */

   /* public static Retrofit makeEnCryptedRequest(OkHttpClient okHttpClient) {

        Gson gson = new GsonBuilder()
                .setDateFormat("yyyy-MM-dd'T'HH:mm:ssZ")
                .create();

        return new Retrofit.Builder()
                .baseUrl(RestServiceProvider.BASEURL)
                .addConverterFactory(ScalarsConverterFactory.create())
                .client(okHttpClient)
                .build();
    }*/
    public static Retrofit makePostAndPutCall(OkHttpClient okHttpClient) {
        Gson gson = new GsonBuilder()
                .setDateFormat("yyyy-MM-dd'T'HH:mm:ssZ")
                .create();
        /*HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        okHttpClient.interceptors().add(interceptor);*/
        return new Retrofit.Builder()
                .baseUrl(Constants.BASE_API_PATH)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .client(okHttpClient)
                .build();
    }

    public static Retrofit uploadMediaToS3(String url) {

        OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .connectTimeout(0, TimeUnit.MINUTES)
                .writeTimeout(0, TimeUnit.MINUTES)

                .readTimeout(0, TimeUnit.MINUTES)
                .retryOnConnectionFailure(true)
                .build();

        return new Retrofit.Builder()
                .baseUrl(url)
                .addConverterFactory(GsonConverterFactory.create())
                .client(okHttpClient)
                .build();
    }

    /**
     * "X-User-ID": "Sy0Baa4woiWfdsA",
     * "X-Device-ID": "987897654654542312",
     * "X-Hmac": "642e8c05e694552ce8668015590a1a92e61b1361",
     * "Content-Type": "application/json"
     */
    public static OkHttpClient getHeader(final String data, final Context context) throws Exception {

        OkHttpClient okHttpClient = null;

        SessionManager sessionManager = new SessionManager(context);

        final HashMap<String, String> userCredentials = sessionManager.getSecrectAndUserIdentifier(context);

        okHttpClient = new OkHttpClient.Builder().addInterceptor(new Interceptor() {
            @Override
            public Response intercept(Chain chain) throws IOException {
                Request originalRequest = chain.request();

                Request.Builder builder = null;
                try {
                    builder = originalRequest.newBuilder()
                            .header(Constants.HEADER_USER_ID, userCredentials.get
                                    (Constants.DUBUQU_USER_IDENTIFIER))
                            .header(Constants.HEADER_DEVICE_ID, Utils.getDeviceIMEI(context))
                            .header(Constants.HEADER_HMAC,
                                    calculateRFC2104HMAC(data,
                                            userCredentials.get(Constants.SECRECT_KEY)
                                    ));
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Request newRequest = builder.build();
                return chain.proceed(newRequest);
            }
        }).readTimeout(60, TimeUnit.MINUTES)
                .retryOnConnectionFailure(true)
                .writeTimeout(60, TimeUnit.MINUTES)
                .connectTimeout(60, TimeUnit.MINUTES)
/*
                .addNetworkInterceptor(new StethoInterceptor())
*/
/*
                .addInterceptor(logging)
*/
                .build();

        return okHttpClient;
    }


    public static void uploadAudioComment(Context context, int jobid, String mediaIdentifier, String filePath)
            throws Exception {
//        ComponentName serviceComponent = new ComponentName(context, AudioCommentUploadService.class);
//        PersistableBundle bundle = new PersistableBundle();
//        bundle.putString(Constants.MEDIA_IDENTIFIER, mediaIdentifier);
//        bundle.putString(Constants.FILE_PATH, filePath);
//        JobInfo.Builder builder = new JobInfo.Builder(jobid, serviceComponent);
//        builder.setMinimumLatency(1 * 1000); // wait at least
//        builder.setOverrideDeadline(0);
//        builder.setPersisted(true);
//        builder.setExtras(bundle);
//        JobScheduler jobScheduler = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
//        jobScheduler.schedule(builder.build());
    }


    public static void fileUploadService(Context context, int jobid, String fileUrl, String filepath) throws Exception {
        ComponentName serviceComponent = new ComponentName(context, UploadMediaService.class);
        PersistableBundle bundle = new PersistableBundle();
        bundle.putString(Constants.UPLOADMEDIA, fileUrl);
        bundle.putString(Constants.FILE_PATH, filepath);
        JobInfo.Builder builder = new JobInfo.Builder(jobid, serviceComponent);
        builder.setOverrideDeadline(0);
        builder.setPersisted(true);
        builder.setExtras(bundle);
        JobScheduler jobScheduler = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        jobScheduler.schedule(builder.build());
    }

    @SuppressLint("StaticFieldLeak")
    public static void scheduleUploadMediaFile(final Context context,
                                               final String shareMediaList,
                                               final String selectedUsers,
                                               final boolean shouldDeleteOriginalMedia) throws Exception {
        try {
            new AsyncTask<Void, Void, Void>() {
                @Override
                protected Void doInBackground(Void... voids) {
                    try {
                        DbHelper dbHelper = new DbHelper(context);

                        int numberOfQuedprocess = dbHelper.getNumberOfQueuedProcess();
                        int jobid = numberOfQuedprocess == 0 ? 0 : numberOfQuedprocess + 1;

                        List<String> data = new Gson().fromJson(shareMediaList, new TypeToken<List<String>>() {
                        }.getType());

                        UploadMapModel uploadMapModel = new UploadMapModel();
                        uploadMapModel.setUploadId(String.valueOf(jobid));
                        uploadMapModel.setShouldDeleteMedia(shouldDeleteOriginalMedia);
                        uploadMapModel.setUploadStatus(String.valueOf(UploadConstants.UPLOADSTATUS.NOTYETSTARTED));
                        uploadMapModel.setUser(selectedUsers);

                        dbHelper.insertNewUpload(uploadMapModel);

                        for (String media : data) {
                            UploadDbModel uploadDbModel = new UploadDbModel();
                            uploadDbModel.setFilePath(media);
                            uploadDbModel.setUploadId(String.valueOf(jobid));
                            uploadDbModel.setProgressValue(0);
                            uploadDbModel.setUploadStatus(String.valueOf(UploadConstants.UPLOADSTATUS.NOTYETSTARTED));
                            dbHelper.insertNewUpload(uploadDbModel);
                        }

                    } catch (Exception e) {
                        Log.e(RestServiceUtils.class.getName(), e.getMessage());
                    }
                    return null;
                }

                @Override
                protected void onPostExecute(Void aVoid) {
                    super.onPostExecute(aVoid);
                    AppController.getInstance().sendBroadcast(new Intent("com.dubuqu.STARTFILESHARE"));
                }
            }.execute();

            Utils.showToast(context, "Added to Upload Queue");

        } catch (Exception e) {
            Log.e(RestServiceUtils.class.getName(), e.getMessage());
        }

    }

    public static void updateUserProfilePic(Context context,
                                            int jobid,
                                            String userIdentifier,
                                            String filePath) throws Exception {
        ComponentName serviceComponent = new ComponentName(context, UserProfileImageUpdateService.class);
        PersistableBundle bundle = new PersistableBundle();
        bundle.putString(Constants.USER_IDENTIFIER, userIdentifier);
        bundle.putString(Constants.FILE_PATH, filePath);
        JobInfo.Builder builder = new JobInfo.Builder(jobid, serviceComponent);
        builder.setOverrideDeadline(0);
        builder.setPersisted(true);
        builder.setExtras(bundle);
        JobScheduler jobScheduler = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        jobScheduler.schedule(builder.build());
    }
}
