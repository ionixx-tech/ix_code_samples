package com.dubuqu.dnModels.responseModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by Yogaraj subramanian on 26/6/17
 */

public class SocialGroupDetailsResponseModel {

    @SerializedName("group_name")
    @Expose
    private String groupName;

    @SerializedName("group_identifier")
    @Expose
    private String groupIdentifier;

    @SerializedName("group_type")
    @Expose
    private String groupType;

    @SerializedName("memory_retain")
    @Expose
    private String memoryRetain;

    @SerializedName("profile_image")
    @Expose
    private String profileImage;

    @SerializedName("members")
    @Expose
    private List<String> members = null;

    @SerializedName("allow_repost")
    @Expose
    private String allow_repost;

    @SerializedName("group_owner_identifier")
    private String groupOwnerIdnetifer;

    @SerializedName("media_count")
    private String mediaCount;

    public String getMediaCount() {
        return mediaCount;
    }

    public void setMediaCount(String mediaCount) {
        this.mediaCount = mediaCount;
    }

    public String getGroupOwnerIdnetifer() {
        return groupOwnerIdnetifer;
    }

    public void setGroupOwnerIdnetifer(String groupOwnerIdnetifer) {
        this.groupOwnerIdnetifer = groupOwnerIdnetifer;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getGroupIdentifier() {
        return groupIdentifier;
    }

    public void setGroupIdentifier(String groupIdentifier) {
        this.groupIdentifier = groupIdentifier;
    }

    public String getGroupType() {
        return groupType;
    }

    public void setGroupType(String groupType) {
        this.groupType = groupType;
    }

    public String getMemoryRetain() {
        return memoryRetain;
    }

    public void setMemoryRetain(String memoryRetain) {
        this.memoryRetain = memoryRetain;
    }

    public String getProfileImage() {
        return profileImage;
    }

    public void setProfileImage(String profileImage) {
        this.profileImage = profileImage;
    }

    public List<String> getMembers() {
        return members;
    }

    public void setMembers(List<String> members) {
        this.members = members;
    }

    public String getAllow_repost() {
        return allow_repost;
    }

    public void setAllow_repost(String allow_repost) {
        this.allow_repost = allow_repost;
    }
}
