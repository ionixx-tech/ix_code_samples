package com.dubuqu.dnAdapter.home;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.dubuqu.R;
import com.dubuqu.dnActivity.MultipleShareActivity;
import com.dubuqu.dnActivity.home.HomeListActivity;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnModels.commonModel.ActionConformationDialog;
import com.dubuqu.dnModels.requestModel.Captions;
import com.dubuqu.dnModels.responseModel.MediaLikeDetails;
import com.dubuqu.dnModels.responseModel.SharedMedias;
import com.dubuqu.dnRestServices.RestServiceController;
import com.dubuqu.dnRestServices.RestServiceProvider;
import com.dubuqu.dnStorage.SessionManager;
import com.dubuqu.dnUtils.RestServiceUtils;
import com.dubuqu.dnUtils.Utils;
import com.google.gson.Gson;

import java.util.List;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;

import static android.content.Context.LAYOUT_INFLATER_SERVICE;

/**
 * Created by Yogaraj subramanian on 5/12/17
 */

public class HomeListMediaAdapter extends RecyclerView.Adapter<HomeListMediaAdapter.HomeListMediaViewHolder> {

    private Context context;

    private List<SharedMedias> sharedMedias;

    private HomeListMediaAdapterCallback homeListMediaAdapterCallback;

    private boolean isRepostAllowed, isGridView = false, isOwnMedia = false;

    private RecyclerView recyclerView;

    private String userIdentifier;

    public HomeListMediaAdapter(Context context, List<SharedMedias> sharedMedias,
                                HomeListMediaAdapterCallback homeListMediaAdapterCallback,
                                boolean isRepostAllowed, RecyclerView recyclerView,
                                String userIdentifier
    ) {
        this.context = context;
        this.sharedMedias = sharedMedias;
        this.homeListMediaAdapterCallback = homeListMediaAdapterCallback;
        this.isRepostAllowed = isRepostAllowed;
        this.recyclerView = recyclerView;
        this.userIdentifier = userIdentifier;
    }

    @Override
    public HomeListMediaViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        RecyclerView.LayoutManager layoutManager = recyclerView.getLayoutManager();

        View view;

        if (layoutManager instanceof GridLayoutManager) {
            view = LayoutInflater.from(context).inflate(R.layout.home_grid, parent,
                    false);
            isGridView = true;
        } else {
            view = LayoutInflater.from(context).inflate(R.layout.home_list, parent,
                    false);
            isGridView = false;
        }
        return new HomeListMediaViewHolder(view);
    }

    @Override
    public void onBindViewHolder(HomeListMediaViewHolder holder, int position) {
        try {
            holder.onBind(position);
        } catch (Exception e) {
            if (context instanceof HomeListActivity) {
                ((HomeListActivity) context).writeCrashReport(
                        HomeListMediaAdapter.class.getName(),
                        e.getMessage()
                );
            }
        }
    }

    @Override
    public int getItemCount() {
        return sharedMedias.size();
    }

    @Override
    public int getItemViewType(int position) {
        return sharedMedias.get(position).hashCode();
    }

    @Override
    public long getItemId(int position) {
        return sharedMedias.get(position).hashCode();
    }

    class HomeListMediaViewHolder extends RecyclerView.ViewHolder {

        ImageView imageView, videoIndicator, likeMedia, commentMedia, repost, addCaption;

        TextView commentCount, likeCount, captionTv, likeTxt, commentTxt;

        boolean isMediaLiked = false;

        View moreOptions;

        HomeListMediaViewHolder(View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.feed_image_view);
            videoIndicator = itemView.findViewById(R.id.video_indicator);
            likeMedia = itemView.findViewById(R.id.feed_footer_like_media);
            commentMedia = itemView.findViewById(R.id.feed_footer_comment_imv);
            commentCount = itemView.findViewById(R.id.feed_footer_comment_count);
            likeCount = itemView.findViewById(R.id.feed_footer_like_count);
            repost = itemView.findViewById(R.id.feed_header_repost);
            if (!isGridView) {
                addCaption = itemView.findViewById(R.id.feed_add_caption);
                captionTv = itemView.findViewById(R.id.captions_tv);
                captionTv.setVisibility(View.GONE);

                SessionManager sessionManager = new SessionManager(context);
                String userIdentifiers = sessionManager.getUserIdentifier();

                if (!userIdentifiers.equalsIgnoreCase(userIdentifier)) {
                    addCaption.setVisibility(View.GONE);
                }

                moreOptions = itemView.findViewById(R.id.home_options_imv);

                likeTxt = itemView.findViewById(R.id.feed_footer_like_count_text);
                commentTxt = itemView.findViewById(R.id.feed_footer_comment_count_txt);

            }
        }

        void onBind(final int position) throws Exception {

            if (position % 4 == 0)
                homeListMediaAdapterCallback.paginateValue();

            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    homeListMediaAdapterCallback.onItemClicked(position, false);
                }
            });

            if (isRepostAllowed)
                repost.setVisibility(View.VISIBLE);
            else
                repost.setVisibility(View.GONE);

            final SharedMedias sharedMedia = sharedMedias.get(position);

            likeCount.setText(String.valueOf(sharedMedia.getLikeCount()));
            isMediaLiked = sharedMedia.getLiked();

            commentCount.setText(String.valueOf(sharedMedia.getCommentCount()));

            if (isMediaLiked) {
                likeMedia.setImageDrawable(context.getDrawable(R.drawable.ic_like));

            } else {
                likeMedia.setImageDrawable(context.getDrawable(R.drawable.ic_unlike));

            }

            if (recyclerView.getLayoutManager() instanceof GridLayoutManager) {

                itemView.setPadding(Utils.convertUnitToDp(context, 3)
                        , 0
                        , 0, 0);


                if (isMediaLiked) {
                    likeMedia.setColorFilter(ContextCompat.getColor(context,
                            R.color.red),
                            android.graphics.PorterDuff.Mode.SRC_IN);
                } else {
                    likeMedia.setColorFilter(ContextCompat.getColor(context,
                            R.color.white),
                            android.graphics.PorterDuff.Mode.SRC_IN);
                }
                commentMedia.setColorFilter(ContextCompat.getColor(context,
                        R.color.white),
                        android.graphics.PorterDuff.Mode.SRC_IN);
            }

            if (recyclerView.getLayoutManager() instanceof LinearLayoutManager) {
                itemView.setPadding(Utils.convertUnitToDp(context, 3)
                        , 0
                        , 0, 0);
            }


            loadImage(imageView, sharedMedia);

            likeMedia.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try {
                        YoYo.with(Techniques.Pulse).duration(500).playOn(view);
                        if (isMediaLiked) {
                            likeMedia.setImageDrawable(context.getDrawable(R.drawable.ic_unlike));
                            isMediaLiked = false;
                            postMediaLike("unlike", sharedMedia);
                            int likecount = Integer.parseInt(likeCount.getText().toString());
                            likeCount.setText(String.valueOf(likecount - 1));
                            sharedMedia.setLikeCount(likecount - 1);

                            if (recyclerView.getLayoutManager() instanceof GridLayoutManager) {
                                likeMedia.setColorFilter(ContextCompat.getColor(context,
                                        R.color.white),
                                        android.graphics.PorterDuff.Mode.SRC_IN);
                            }
                        } else {
                            isMediaLiked = true;
                            likeMedia.setImageDrawable(context.getDrawable(R.drawable.ic_like));
                            postMediaLike("like", sharedMedia);
                            int likecount = Integer.parseInt(likeCount.getText().toString());
                            likeCount.setText(String.valueOf(likecount + 1));
                            sharedMedia.setLikeCount(likecount + 1);

                            if (recyclerView.getLayoutManager() instanceof GridLayoutManager) {
                                likeMedia.setColorFilter(ContextCompat.getColor(context,
                                        R.color.red),
                                        android.graphics.PorterDuff.Mode.SRC_IN);
                            }
                        }
                        sharedMedia.setLiked(isMediaLiked);
                        homeListMediaAdapterCallback.sendBroadCast(position, sharedMedia);
                        sharedMedias.set(position, sharedMedia);

                        if (!isGridView) {
                            if (sharedMedia.getLikeCount() == 1) {
                                likeTxt.setText("Like");
                            } else {
                                likeTxt.setText("Likes");
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });

            repost.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (sharedMedia != null) {
                        repostMedia(sharedMedia);
                    }
                }
            });

            commentMedia.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    homeListMediaAdapterCallback.onItemClicked(position, true);
                }
            });

            if (sharedMedia.getContentType().contains("video")) {
                videoIndicator.setVisibility(View.VISIBLE);
            } else {
                videoIndicator.setVisibility(View.GONE);
            }

            if (!isGridView) {

                String captions = sharedMedia.getCaption();
                if (captions != null && !captions.equalsIgnoreCase("")) {
                    //show update text
                    captionTv.setVisibility(View.VISIBLE);
                    captionTv.setText(captions);
                } else {
                    //hide text
                    captionTv.setVisibility(View.GONE);
                }

                addCaption.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {
                            showAddCaptionPopup(sharedMedia, position);
                        } catch (Exception e) {
                            Log.e(HomeListMediaAdapter.class.getName(), e.getMessage());
                        }
                    }
                });

                moreOptions.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        openPopupOptionsMenu();
                    }
                });
            }

            if (isGridView) {
                commentCount.setShadowLayer(5, -1, -1, Color.BLACK);
                likeCount.setShadowLayer(5, -1, -1, Color.BLACK);
            }

            if (!isGridView) {
                likeTxt = itemView.findViewById(R.id.feed_footer_like_count_text);
                commentTxt = itemView.findViewById(R.id.feed_footer_comment_count_txt);
                if (sharedMedia.getLikeCount() == 1) {
                    likeTxt.setText("Like");
                } else {
                    likeTxt.setText("Likes");
                }
            }
        }

        private void openPopupOptionsMenu() {

            LayoutInflater inflater = (LayoutInflater)
                    context.getSystemService(LAYOUT_INFLATER_SERVICE);

            assert inflater != null;
            final View mediaOptionsMenu = inflater.inflate(R.layout.layout_media_options, null);

            final TextView cancel, reportSpam, block;

            cancel = mediaOptionsMenu.findViewById(R.id.options_cancel);

            reportSpam = mediaOptionsMenu.findViewById(R.id.reportmedia_txt);

            block = mediaOptionsMenu.findViewById(R.id.block_txt);

            View blurView = mediaOptionsMenu.findViewById(R.id.realtimeblurview);

            if (userIdentifier.equalsIgnoreCase(new SessionManager(context)
                    .getUserIdentifier())) {
                reportSpam.setText(context.getString(R.string.delete_media));
                isOwnMedia = true;
            }

            block.setVisibility(View.GONE);

            final PopupWindow popupWindow = new PopupWindow(context);
            popupWindow.setContentView(mediaOptionsMenu);
            popupWindow.setWidth(LinearLayout.LayoutParams.MATCH_PARENT);
            popupWindow.setHeight(LinearLayout.LayoutParams.MATCH_PARENT);
            popupWindow.setFocusable(true);
            popupWindow.setBackgroundDrawable(null);

            popupWindow.showAtLocation(mediaOptionsMenu, Gravity.TOP, 0, 0);

            cancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    popupWindow.dismiss();
                }
            });

            reportSpam.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    popupWindow.dismiss();
                    if (isOwnMedia)
                        deleteMedia();
                    else
                        reportSpam();
                }
            });

            blurView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    popupWindow.dismiss();
                }
            });

        }

        /**
         * make delete media request
         */
        private void deleteMedia() {
            try {
                new ActionConformationDialog(
                        context.getString(R.string.delete_media),
                        context.getString(R.string.confirm_delete), context,
                        new ActionConformationDialog.OnActionCOnformationListner() {
                            @Override
                            public void onConformed() {
                                try {
                                    SharedMedias sharedMedia = sharedMedias.get(getAdapterPosition());
                                    if (sharedMedia != null) {
                                        String data = "{}";
                                        OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, context);
                                        Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
                                        RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
                                        RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);

                                        mRetrofitCallBacks.deleteMedia(sharedMedia.getMediaIdentifier());

                                        sharedMedias.remove(getAdapterPosition());

                                        notifyItemRemoved(getAdapterPosition());

                                        homeListMediaAdapterCallback.mediaReported(getAdapterPosition());
                                    }
                                } catch (Exception e) {
                                    Log.e("HomeListAdapter", e.getMessage());
                                }

                            }

                            @Override
                            public void onRejected() {

                            }
                        });

            } catch (Exception e) {
                Log.e("HomeListAdapter", e.getMessage());
            }
        }

        /**
         * report spam api call
         */
        void reportSpam() {

            new ActionConformationDialog(
                    context.getString(R.string.report_spam), context.getString(R.string.report_media_confirm),
                    context, new ActionConformationDialog.OnActionCOnformationListner() {
                @Override
                public void onConformed() {
                    try {
                        SharedMedias sharedMedia = sharedMedias.get(getAdapterPosition());
                        if (sharedMedia != null) {
                            String data = "{}";
                            OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, context);
                            Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
                            RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
                            RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);

                            mRetrofitCallBacks.reportSpam(sharedMedia.getMediaIdentifier());

                            sharedMedias.remove(getAdapterPosition());

                            notifyItemRemoved(getAdapterPosition());

                            homeListMediaAdapterCallback.mediaReported(getAdapterPosition());
                        }
                    } catch (Exception e) {
                        Log.e("HomeListAdapter", e.getMessage());
                    }
                }

                @Override
                public void onRejected() {

                }
            });
        }


        private void showAddCaptionPopup(final SharedMedias sharedMedias, final int position) throws Exception {

            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            assert inflater != null;
            View view = inflater.inflate(R.layout.layout_addcaption, null);

            TextView captionHeader, cancelView, updateView;

            final EditText editText;

            String captions = "";

            captionHeader = view.findViewById(R.id.caption_head_text);

            cancelView = view.findViewById(R.id.caption_cancel);

            updateView = view.findViewById(R.id.caption_save);

            editText = view.findViewById(R.id.caption_edit_text);

            /*mediaType = view.findViewById(R.id.caption_media_type_txt);*/

            final PopupWindow pop = new PopupWindow(context);
            pop.setContentView(view);
            pop.setWidth(LinearLayout.LayoutParams.MATCH_PARENT);
            pop.setHeight(LinearLayout.LayoutParams.MATCH_PARENT);
            pop.setFocusable(true);
            pop.setBackgroundDrawable(null);
            pop.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
            pop.showAtLocation(view, Gravity.TOP, 0, 0);

            if (sharedMedias != null) {
                captions = sharedMedias.getCaption();
/*

                if (sharedMedias.getContentType().contains("video")) {
                    mediaType.setText("Add the caption for video");
                } else {
                    mediaType.setText("Add the caption for image");
                }
*/

                if (captions != null && !captions.equalsIgnoreCase("")) {
                    editText.setText(captions);
                    captionHeader.setText(context.getString(R.string.update_caption));
                    updateView.setText(context.getString(R.string.update));
                } else {
                    editText.setText("");
                    captionHeader.setText(context.getString(R.string.add_caption));
                    updateView.setText(context.getString(R.string.save));
                }
            }

            cancelView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    pop.dismiss();
                }
            });

            updateView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (sharedMedias != null) {
                        if (!editText.getText().toString()
                                .equalsIgnoreCase(sharedMedias.getCaption())) {
                            //make http request to save caption
                            String text = editText.getText().toString().trim()
                                   /* .replaceAll("\\s{2,}",
                                    "")*/
                                    .replaceAll("\\n{2,}", "\n\n");

                            makeHttpRequestToCaptions(text,

                                    sharedMedias.getMediaIdentifier());
                            sharedMedias.setCaption(text);

                            homeListMediaAdapterCallback.sendBroadCast(position, sharedMedias);

                            notifyItemRemoved(getAdapterPosition());

                            pop.dismiss();
                        } else {
                            pop.dismiss();
                        }
                    }
                }
            });
        }


        private void makeHttpRequestToCaptions(String s, String mediaIdentifier) {
            try {
                String data = new Gson().toJson(new Captions(s));
                OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, context);
                Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
                RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
                RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
                mRetrofitCallBacks.addCaptions(s, mediaIdentifier);
            } catch (Exception e) {
                Log.e(HomeListMediaAdapter.class.getName(), e.getMessage());
            }

        }

        private void loadImage(final ImageView dubuquImageView, SharedMedias sharedMedia) {

            Glide.with(context)
                    .load(sharedMedia.getSignedUrl())
                    .centerCrop()
                    .dontAnimate()
                    .dontTransform()
                    .into(dubuquImageView);
        }

        /**
         * action to like the media or unlike the media
         *
         * @param action the action user has done {LIKE,UNLIKE}
         */
        private void postMediaLike(final String action, SharedMedias sharedMedia) throws Exception {
            try {
                MediaLikeDetails mediaLikeDetails = new MediaLikeDetails();
                Gson gson = new Gson();
                String data = gson.toJson(mediaLikeDetails);
                OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, context);
                Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
                RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
                RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
                SharedMedias sharedMedias = sharedMedia;
                mRetrofitCallBacks.postMediaLikeAction(sharedMedias.getMediaIdentifier(),
                        action, mediaLikeDetails,
                        new RestServiceController.ResponseCallBacks() {
                            @Override
                            public void onResponse(Object o) {

                            }

                            @Override
                            public void onFailure(Object o) {
                                //Utils.showNegativeTost(getApplicationContext(), "Social Circle Creatation Failed.");
                            }
                        });
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        private void repostMedia(SharedMedias sharedMedia) {
            Intent intent = new Intent(context, MultipleShareActivity.class);
            Bundle bundle = new Bundle();
            bundle.putBoolean(Constants.RESHAREMEDIA, true);
            bundle.putString(Constants.MEDIA_IDENTIFIER, sharedMedia.getMediaIdentifier());
            intent.putExtras(bundle);
            context.startActivity(intent);
        }
    }


    public interface HomeListMediaAdapterCallback {
        void onItemClicked(int position, boolean toOpenMediaChat);

        void sendBroadCast(int postion, SharedMedias sharedMedias);

        void paginateValue();

        void mediaReported(int postion);

    }
}
