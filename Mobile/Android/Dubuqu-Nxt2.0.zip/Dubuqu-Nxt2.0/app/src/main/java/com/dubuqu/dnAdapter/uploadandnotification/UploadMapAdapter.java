package com.dubuqu.dnAdapter.uploadandnotification;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.os.PersistableBundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.dubuqu.R;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnConstants.UploadConstants;
import com.dubuqu.dnServices.FileShareService;
import com.dubuqu.dnStorage.DbHelper;
import com.dubuqu.dnStorage.upload.UploadDbModel;
import com.dubuqu.dnStorage.upload.UploadMapModel;
import com.dubuqu.dnUtils.Utils;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.File;
import java.sql.SQLException;
import java.util.List;

/**
 * Created by Yogaraj subramanian on 2/1/18
 */

public class UploadMapAdapter extends RecyclerView.Adapter<UploadMapAdapter.UploadMapViewHolder> {

    private List<UploadMapModel> uploadMapModels;

    private Context context;

    private UploadAdapterCallBack uploadAdapterCallBack;

    private DbHelper dbHelper;

    public UploadMapAdapter(List<UploadMapModel> uploadMapModels, Context context,
                            UploadAdapterCallBack uploadAdapterCallBack) {
        this.uploadMapModels = uploadMapModels;
        this.context = context;
        this.uploadAdapterCallBack = uploadAdapterCallBack;
        try {
            dbHelper = new DbHelper(context);
        } catch (Exception e) {
            Log.e(UploadMapAdapter.class.getName(), e.getMessage());
        }
    }

    @Override
    public UploadMapViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.upload_adapter_view_holder, parent, false);
        return new UploadMapViewHolder(view);
    }

    @Override
    public void onBindViewHolder(UploadMapViewHolder holder, int position) {
        try {
            holder.onBind(position);
        } catch (Exception e) {
            Log.e(UploadMapAdapter.class.getName(), e.getMessage());
        }
    }

    @Override
    public int getItemCount() {

        if (uploadMapModels == null)
            return 0;

        return uploadMapModels.size();
    }

    @Override
    public int getItemViewType(int position) {
        return uploadMapModels.get(position).hashCode();
    }

    @Override
    public long getItemId(int position) {
        return uploadMapModels.get(position).hashCode();
    }

    class UploadMapViewHolder extends RecyclerView.ViewHolder {

        ImageView uploadMedia;

        TextView currentActionTxt;

        CardView currnetActionCardView, removeCardView;

        UploadMapViewHolder(View itemView) {
            super(itemView);
            uploadMedia = itemView.findViewById(R.id.upload_media);

            currentActionTxt = itemView.findViewById(R.id.current_action_txt);

            currnetActionCardView = itemView.findViewById(R.id.current_action_cv);

            removeCardView = itemView.findViewById(R.id.current_remove_cv);
            removeCardView.setVisibility(View.GONE);
        }

        void onBind(final int postion) throws Exception {

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    uploadAdapterCallBack.onClick(postion);
                }
            });

            final UploadMapModel uploadMapModel = uploadMapModels.get(postion);

            final List<UploadDbModel> uploadDbModelList = dbHelper.fetchDataAgainstIdentifier(uploadMapModel.getUploadId());

            if (uploadDbModelList != null && Utils.isVaildString(uploadDbModelList.get(0).getFilePath())) {

                Glide.with(context).load(new File(uploadDbModelList.get(0).getFilePath())).into(uploadMedia);

                List<String> users = new Gson().fromJson(uploadMapModel.getUser(), new TypeToken<List<String>>() {
                }.getType());


                assert users != null;

                final UploadConstants.UPLOADSTATUS uploadstatus = UploadConstants.UPLOADSTATUS.valueOf(uploadMapModel.getUploadStatus());

                String statusText = "Showing\t";
                switch (uploadstatus) {
                    case FAILURE:
                        currnetActionCardView.setCardBackgroundColor(context.getResources().getColor(R.color.red_color_picker));
                        currentActionTxt.setText(context.getString(R.string.retry));
                        removeCardView.setVisibility(View.VISIBLE);
                        break;

                    case CANCELLED:
                        currnetActionCardView.setCardBackgroundColor(context.getResources().getColor(R.color.red_color_picker));
                        currentActionTxt.setText(context.getString(R.string.retry));
                        removeCardView.setVisibility(View.VISIBLE);
                        break;

                    case SUCCESS:
                        statusText = "Shown\t";
                        currentActionTxt.setText(context.getString(R.string.sucess));
                        currnetActionCardView.setCardBackgroundColor(context.getResources().getColor(R.color.green_color_picker));
                        break;

                    case PROGRESS:
                        currentActionTxt.setText(context.getString(R.string.cancel));
                        currnetActionCardView.setCardBackgroundColor(context.getResources().getColor(R.color.red_color_picker));
                        break;

                    case NOTYETSTARTED:
                        currentActionTxt.setText(context.getString(R.string.queued));
                        break;
                    case PAUSE:
                        currentActionTxt.setText(context.getString(R.string.paused));
                        break;
                }

                currentActionTxt.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {
                            switch (uploadstatus) {
                                case PROGRESS:
                                    showCancelConfirmation(uploadMapModel);
                                    break;

                                case FAILURE:
                                    startService(uploadMapModel);
                                    break;

                                case CANCELLED:
                                    startService(uploadMapModel);
                                    break;
                            }
                        } catch (Exception e) {
                            Log.e(UploadMapAdapter.class.getName(), e.getMessage());
                        }

                    }
                });

                removeCardView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {

                            uploadMapModels.remove(postion);
                            notifyItemRemoved(postion);

                            dbHelper.deleteUploadData(uploadMapModel.getUploadId());
                        } catch (SQLException e) {
                            Log.e(UploadMapAdapter.class.getName(), e.getMessage());
                        }
                    }
                });


            }

        }

        private void showCancelConfirmation(final UploadMapModel uploadMapModel) throws Exception {

            TextView delteMedia, dontdelteMedia;

            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View view = inflater.inflate(R.layout.delete_popup, null);

            delteMedia = view.findViewById(R.id.delete_popup_delete);

            dontdelteMedia = view.findViewById(R.id.delte_media_cancel);

            delteMedia.setText("I'm serious. Cancel it.");
            final PopupWindow pop = new PopupWindow(context);
            pop.setContentView(view);
            pop.setWidth(LinearLayout.LayoutParams.MATCH_PARENT);
            pop.setHeight(LinearLayout.LayoutParams.MATCH_PARENT);
            pop.setFocusable(true);
            pop.setBackgroundDrawable(null);
            pop.showAtLocation(view, Gravity.TOP, 0, 0);

            delteMedia.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    pop.dismiss();
                    JobScheduler jobScheduler = (JobScheduler)
                            context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
                    assert jobScheduler != null;
                    if (jobScheduler.getAllPendingJobs().size() > 0) {
                        jobScheduler.cancel(Integer.parseInt(uploadMapModel.getUploadId()));
                    }
                    currentActionTxt.setEnabled(true);
                    currentActionTxt.setText(context.getString(R.string.cancled));

                    notifyDataSetChanged();
                }
            });

            dontdelteMedia.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    pop.dismiss();

                }
            });
        }

        private void startService(UploadMapModel uploadMapModel) throws Exception {

            List<UploadDbModel> uploadDbModelList = dbHelper.fetchDataAgainstIdentifier(
                    uploadMapModel.getUploadId()
            );

            dbHelper.updateProgressStateOfUpload(uploadMapModel.getUploadId(),
                    UploadConstants.UPLOADSTATUS.PROGRESS);

            assert uploadDbModelList != null && uploadDbModelList.size() > 0;

            ComponentName serviceComponent = new ComponentName(context,
                    FileShareService.class);
            PersistableBundle bundle = new PersistableBundle();
            bundle.putString(Constants.SHAREMEDIA, new Gson().toJson(uploadDbModelList));

            bundle.putString(Constants.SELECTEDUSERS, uploadMapModel.getUser());

            bundle.putString(Constants.SHOULDDELETEMEDIA, String.valueOf(uploadMapModel.isShouldDeleteMedia()));

            JobInfo.Builder builder = new JobInfo.Builder(Integer.parseInt(uploadMapModel.getUploadId())
                    , serviceComponent);

            builder.setOverrideDeadline(0);
            builder.setPersisted(true);
            builder.setExtras(bundle);
            JobScheduler jobScheduler = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            assert jobScheduler != null;
            jobScheduler.schedule(builder.build());
        }
    }

    public interface UploadAdapterCallBack {
        void onClick(int postion);
    }
}
