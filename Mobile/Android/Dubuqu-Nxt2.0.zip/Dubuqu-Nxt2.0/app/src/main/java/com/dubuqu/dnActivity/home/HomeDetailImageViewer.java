package com.dubuqu.dnActivity.home;

import android.animation.Animator;
import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Matrix;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomSheetBehavior;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.dubuqu.R;
import com.dubuqu.dnActivity.BaseActivity;
import com.dubuqu.dnAdapter.home.CommentRecyclerViewAdapter;
import com.dubuqu.dnAdapter.home.HomeDetailViewPagerAdapter;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnModels.commonModel.ErrorBodyModel;
import com.dubuqu.dnModels.requestModel.PostMediaComment;
import com.dubuqu.dnModels.responseModel.GetAllMediaTimeLine;
import com.dubuqu.dnModels.responseModel.GetTimeLineStory;
import com.dubuqu.dnModels.responseModel.MediaComment;
import com.dubuqu.dnModels.responseModel.MediaLikeDetails;
import com.dubuqu.dnModels.responseModel.SharedMedias;
import com.dubuqu.dnRestServices.RestServiceController;
import com.dubuqu.dnRestServices.RestServiceProvider;
import com.dubuqu.dnStorage.SessionManager;
import com.dubuqu.dnUtils.RestServiceUtils;
import com.dubuqu.dnUtils.Utils;
import com.dubuqu.dnViews.DubuquEditText;
import com.dubuqu.dnViews.DubuquViewPager;
import com.github.chrisbanes.photoview.PhotoView;
import com.google.gson.Gson;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.TimeZone;

import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;
import retrofit2.Response;
import retrofit2.Retrofit;
import vc908.stickerfactory.StickersManager;
import vc908.stickerfactory.ui.OnStickerSelectedListener;
import vc908.stickerfactory.ui.fragment.StickersFragment;

/**
 * Created by Yogaraj subramanian on 29/11/17
 * <p>
 * {@link BaseActivity} is the super class of this activity.
 * <p>
 * Used to display the medias present in particular timeline in original media.
 * <p>
 * {@link GetTimeLineStory} && {@link GetAllMediaTimeLine} are the two models which are gonna received from the other classes.
 * <p>
 * A {@link BottomSheetBehavior}  is used to control the sliding of comment section {@link HomeDetailImageViewer#bottomSheetView}
 * <p>
 * {@link CommentRecyclerViewAdapter} is used to load the comment datas
 * <p>
 * {@link HomeDetailImageViewer#viewPager} is added with {@link ViewPager.OnPageChangeListener} to check if there is any change in Viewpager position.
 * <p>
 * {@link HomeDetailViewPagerAdapter} is used to populate the medias.
 * <p>
 * On each scroll the media is checked whether it is an video or image or gif.
 * </p>
 * <p>
 * {@link HomeDetailImageViewer#getCurrentObjectInstance()} returns the current object {@link SharedMedias} of the current viewpager
 * </p>
 */

@SuppressLint("ClickableViewAccessibility")
public class HomeDetailImageViewer extends BaseActivity implements
        HomeDetailViewPagerAdapter.HomeDetailCallBacks, OnStickerSelectedListener {

    BottomSheetBehavior<View> bottomSheetBehavior;

    View back, likeandcommentview;

    TextView commentCount, likeCount, parentCommentTxt, captionTxt, parentCommentUserNameTxt;

    ImageView addStickers, sendComment, likeMedia, commentMedia, parentCommentSticker;

    FrameLayout closeParnetComment;

    DubuquEditText edtxtComment;

    DubuquViewPager viewPager;

    GetAllMediaTimeLine getAllMediaTimeLine;

    GetTimeLineStory storyTimeLine;

    int currentMediaPositon = 0, minimumBottomSheetScroll = 90;

    HomeDetailViewPagerAdapter homeDetailViewPagerAdapter;

    RecyclerView commentRecyclerView;

    View bottomSheetView, parentCommentView;

    CommentRecyclerViewAdapter commentRecyclerViewAdapter;

    FrameLayout stickerLayout;

    List<MediaComment> mediaCommentList = new ArrayList<>();

    MediaComment.ParentComment parentCommetDetails = null;

    boolean isMediaLikedByUser = false, shouldOpenChat = false, isStoryTimeLine = false,
            isNewCommentReceived = false, isPromoVideo = false;

    @SuppressLint("UseSparseArrays")
    private HashMap<Integer, HomeDetailViewPagerAdapter.HomeDetailViewHolder> homeDetailViewHolderHashMap =
            new HashMap<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

            requestWindowFeature(Window.FEATURE_NO_TITLE);

            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    WindowManager.LayoutParams.FLAG_FULLSCREEN);

            setContentView(R.layout.activity_home_deatil_image_viewer);

            isStoryTimeLine = getIntent().getBooleanExtra(Constants.ISSTORYTIMELINE,
                    false);

            Bundle extras = getIntent().getExtras();

            if (extras != null) {

                String getallmedia = extras.getString(Constants.EXTRASTRINGS);

                if (!isStoryTimeLine)
                    getAllMediaTimeLine = new Gson().fromJson(getallmedia, GetAllMediaTimeLine.class);
                else
                    storyTimeLine = new Gson().fromJson(getallmedia, GetTimeLineStory.class);

                currentMediaPositon = extras.getInt(Constants.CURRENTIMAGE);

                shouldOpenChat = extras.getBoolean(Constants.SHOULDSHOWCHAT);

                initialize();
            }
        } catch (Exception e) {
            writeCrashReport(e.getMessage());
        }
    }

    @Override
    public void onItemViewAdded(Integer position, HomeDetailViewPagerAdapter.HomeDetailViewHolder
            homeDetailViewHolder) throws Exception {
        homeDetailViewHolderHashMap.put(position, homeDetailViewHolder);
    }

    @Override
    public void onItemViewremoved(int position) throws Exception {
        homeDetailViewHolderHashMap.remove(position);
    }

    @Override
    public void onItemViewClicked(int postion) throws Exception {
        toggleTopAndBottomView();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (shouldOpenChat) {

            if (bottomSheetBehavior.getState() == BottomSheetBehavior.STATE_EXPANDED) {
                View decorView = getWindow().getDecorView();
                if (decorView != null) {
                    decorView.post(new Runnable() {
                        @Override
                        public void run() {
                            resizeViewPager(0.8f);
                        }
                    });
                }
            }

        }

    }

    @Override
    public void onStickerSelected(String s) {
        try {

            SharedMedias sharedMedias = getCurrentObjectInstance();

            postMediaComments(sharedMedias.getMediaIdentifier(), "sticker", s, mediaCommentList.size());

            setCommentLocal("sticker", s, "");

        } catch (Exception e) {
            writeCrashReport(e.getMessage());
        }
    }

    @Override
    public void onEmojiSelected(String s) {
        if (edtxtComment.getText() != null && !edtxtComment.getText().toString().equalsIgnoreCase("")) {
            edtxtComment.setText(edtxtComment.getText().toString().concat(s));
        } else {
            edtxtComment.setText(s);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            unregisterReceiver(commentReceiver);
            homeDetailViewPagerAdapter.releasePlayer();
        } catch (Exception e) {
            writeCrashReport(e.getMessage());
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        homeDetailViewPagerAdapter.releasePlayer();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_MASK_ADJUST);

        if (Constants.RESTRICT_SREENSHOT)
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);

        SharedMedias sharedMedias = null;
        try {
            registerReceiver(commentReceiver, new IntentFilter("commentmedia"));
            sharedMedias = getCurrentObjectInstance();
            if (sharedMedias != null) {
                if (sharedMedias.getContentType().contains("video")) {
                    homeDetailViewPagerAdapter.resumePlayer();
                }
            }

        } catch (Exception e) {
            writeCrashReport(e.getMessage());
        }
    }


    @Override
    public void onBackPressed() {

        Utils.hideSoftKeyBoard(HomeDetailImageViewer.this);

        if (stickerLayout.getVisibility() == View.VISIBLE) {
            stickerLayout.setVisibility(View.GONE);
        } else if (bottomSheetBehavior.getState() == BottomSheetBehavior.STATE_EXPANDED) {
            bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
        } else {
            int orientation = this.getResources().getConfiguration().orientation;
            if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            } else {
                super.onBackPressed();
                /*super.overridePendingTransitionExit();*/
            }
        }
    }

    @Override
    public void onConfigurationChanged(final Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
            }
        });
    }

    @Override
    public void startPaginatingResource() {
        try {
            String data = "{}";
            OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, HomeDetailImageViewer.this);
            Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
            RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
            RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
            if (!isStoryTimeLine && getAllMediaTimeLine.getSharedMedias() != null &&
                    getAllMediaTimeLine.getSharedMediaCount() > getAllMediaTimeLine.getSharedMedias().size()) {

                mRetrofitCallBacks.paginatetTimeLineResouces(
                        getAllMediaTimeLine.getTimelineIdentifier(),
                        new RestServiceController.ResponseCallBacks() {
                            @Override
                            public void onResponse(Object o) {
                                if (o != null) {
                                    List<SharedMedias> sharedMedias = (List<SharedMedias>) o;
                                    if (sharedMedias.size() > 0) {
                                        List<SharedMedias> orginalData = getAllMediaTimeLine.getSharedMedias();
                                        orginalData.addAll(sharedMedias);
                                        getAllMediaTimeLine.setSharedMedias(orginalData);
                                        homeDetailViewPagerAdapter.notifyDataSetChanged();
                                    }
                                }
                            }

                            @Override
                            public void onFailure(Object o) {

                            }
                        }, null, getAllMediaTimeLine.getSharedMedias().size());

            } else {
                if (storyTimeLine.getSharedMedias() != null &&
                        storyTimeLine.getSharedMediasCount() > storyTimeLine.getSharedMedias().size()) {
                    mRetrofitCallBacks.getStoryMedias(
                            storyTimeLine.getTimelineIdentifier(),
                            new RestServiceController.ResponseCallBacks() {
                                @Override
                                public void onResponse(Object o) {
                                    if (o != null) {
                                        List<SharedMedias> sharedMedias = (List<SharedMedias>) o;
                                        if (sharedMedias.size() > 0) {
                                            List<SharedMedias> orginalData = storyTimeLine.getSharedMedias();
                                            if (orginalData != null) {
                                                orginalData.addAll(sharedMedias);
                                                storyTimeLine.setSharedMedias(orginalData);
                                                homeDetailViewPagerAdapter.notifyDataSetChanged();
                                            } else {
                                                orginalData = sharedMedias;
                                                storyTimeLine.setSharedMedias(orginalData);
                                                homeDetailViewPagerAdapter.notifyDataSetChanged();
                                            }
                                        }
                                    }
                                }

                                @Override
                                public void onFailure(Object o) {

                                }
                            }, storyTimeLine.getSharedMedias().size());
                }
            }

        } catch (Exception e) {
            writeCrashReport(e.getMessage());
        }
    }


    BroadcastReceiver commentReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            try {
                SharedMedias sharedMedias1 = getCurrentObjectInstance();
                if (sharedMedias1 != null) {
                    isNewCommentReceived = true;

                    mediaCommentList.clear();

                    commentRecyclerViewAdapter.notifyDataSetChanged();

                    getOrigianlMedia(sharedMedias1.getMediaIdentifier());
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    };

    private void initialize() throws Exception {

        bottomSheetView = findViewById(R.id.home_detail_bottom_sheet_rl);

        bottomSheetBehavior = BottomSheetBehavior.from(bottomSheetView);

        parentCommentView = findViewById(R.id.homedetailview_parnet_comment_rl);
        parentCommentView.setVisibility(View.GONE);

        parentCommentSticker = findViewById(R.id.homedetailview_parnet_comment_sticker);

        parentCommentTxt = findViewById(R.id.homedetailview_parnet_comment_txt);

        parentCommentUserNameTxt = findViewById(R.id.homedetailview_parnet_comment_username);

        closeParnetComment = findViewById(R.id.homedetailview_parnet_comment_close);

        back = findViewById(R.id.home_detail_image_back);

        likeCount = findViewById(R.id.txtLikeCount);

        commentCount = findViewById(R.id.txtCommentCount);

        commentMedia = findViewById(R.id.imgComment);

        addStickers = findViewById(R.id.add_stickers);

        sendComment = findViewById(R.id.send_comment);
        sendComment.setAlpha(0.5f);
        sendComment.setEnabled(false);

        edtxtComment = findViewById(R.id.edittext_comment);

        viewPager = findViewById(R.id.home_detail_view_pager);

        likeandcommentview = findViewById(R.id.layoutLikeCommentIcons);

        commentRecyclerView = findViewById(R.id.comment_recycler_view);

        stickerLayout = findViewById(R.id.home_detail_sticker_loader);

        likeMedia = findViewById(R.id.imglike);

        captionTxt = findViewById(R.id.captions_tv);

        homeDetailViewPagerAdapter = new HomeDetailViewPagerAdapter(
                HomeDetailImageViewer.this,
                isStoryTimeLine ? storyTimeLine.getSharedMedias() : getAllMediaTimeLine.getSharedMedias(),
                this
        );

        viewPager.setAdapter(homeDetailViewPagerAdapter);

        viewPager.setCurrentItem(currentMediaPositon);

        if (shouldOpenChat)
            bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);

        initializeListeners();


    }

    private void initializeListeners() throws Exception {
        if (!isPromoVideo) {
            final StickersFragment stickersFragment = new StickersFragment();
            stickersFragment.setOnStickerSelectedListener(this);

            getSupportFragmentManager().beginTransaction().replace(stickerLayout.getId(),
                    stickersFragment).commit();

            bottomSheetBehavior.setHideable(false);

            bottomSheetBehavior.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
                @Override
                public void onStateChanged(@NonNull View bottomSheet, int newState) {
                    switch (newState) {
                        case BottomSheetBehavior.STATE_COLLAPSED:
                            try {
                                setBottomSheetHeight(likeandcommentview.getBottom());
                            } catch (Exception e) {
                                writeCrashReport(e.getMessage());
                            }
                            break;
                        case BottomSheetBehavior.STATE_EXPANDED:

                            break;
                    }
                }

                @Override
                public void onSlide(@NonNull View bottomSheet, float slideOffset) {
                    resizeViewPager(slideOffset);
                }

            });

            edtxtComment.setKeyImeChangeListener(new DubuquEditText.KeyImeChange() {
                @Override
                public void onKeyIme(int keyCode, KeyEvent event) {
                    if (KeyEvent.KEYCODE_BACK == event.getKeyCode()) {
                        Utils.hideSoftKeyBoard(HomeDetailImageViewer.this);
                        if (stickerLayout.getVisibility() == View.VISIBLE) {
                            stickerLayout.setVisibility(View.GONE);
                        }
                    }
                }
            });

            edtxtComment.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    if (s.length() == 0) {
                        sendComment.setEnabled(false);
                        sendComment.setAlpha(0.5f);
                    } else if (s.length() > 0) {
                        sendComment.setEnabled(true);
                        sendComment.setAlpha(1f);
                    }
                }

                @Override
                public void afterTextChanged(Editable s) {

                }
            });

            back.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    onBackPressed();
                }
            });

            likeMedia.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try {
                        YoYo.with(Techniques.Pulse).duration(500).playOn(view);
                        if (isMediaLikedByUser) {
                            likeMedia.setBackground(getDrawable(R.drawable.ic_unlike_white));
                            isMediaLikedByUser = false;

                            int likecount = Integer.parseInt(likeCount.getText().toString());
                            int commentcount = Integer.parseInt(commentCount.getText().toString());

                            setLikeAndCommentCount(String.valueOf(likecount - 1),
                                    String.valueOf(commentcount), false);

                            sendBroadCastData();

                            postMediaLike("unlike");
                        } else {
                            isMediaLikedByUser = true;
                            likeMedia.setBackground(getDrawable(R.drawable.ic_like));

                            int likecount = Integer.parseInt(likeCount.getText().toString());
                            int commentcount = Integer.parseInt(commentCount.getText().toString());
                            SharedMedias sharedMedias = getCurrentObjectInstance();
                            if (sharedMedias != null) {
                                sharedMedias.setLiked(true);
                            }

                            setLikeAndCommentCount(String.valueOf(likecount + 1), String.valueOf(commentcount), true);

                            sendBroadCastData();

                            postMediaLike("like");
                        }
                    } catch (Exception e) {
                        writeCrashReport(e.getMessage());
                    }
                }
            });

            commentRecyclerViewAdapter = new CommentRecyclerViewAdapter(
                    HomeDetailImageViewer.this,
                    mediaCommentList,
                    isStoryTimeLine,
                    new CommentRecyclerViewAdapter.CommentCallback() {
                        @Override
                        public void onLongPressed(MediaComment mediaComment) {
                            parentCommentView.setVisibility(View.VISIBLE);

                            YoYo.with(Techniques.SlideInUp).duration(Constants.ANIMATIONTIME).playOn(parentCommentView);

                            parentCommetDetails = null;

                            String commentData = new Gson().toJson(mediaComment);
                            parentCommetDetails = new Gson().fromJson(commentData, MediaComment.ParentComment.class);

                            parentCommentUserNameTxt.setText(mediaComment.getUserName());

                            switch (mediaComment.getCommentType().toLowerCase()) {
                                case "text":
                                    parentCommentTxt.setVisibility(View.VISIBLE);
                                    parentCommentTxt.setText(mediaComment.getComment());
                                    parentCommentSticker.setVisibility(View.GONE);
                                    break;

                                case "sticker":
                                    parentCommentTxt.setVisibility(View.GONE);
                                    parentCommentSticker.setVisibility(View.VISIBLE);
                                    StickersManager.with(HomeDetailImageViewer.this)
                                            .loadSticker(mediaComment.getComment()).into(parentCommentSticker);
                                    break;
                            }
                        }
                    });

            commentRecyclerView.setAdapter(commentRecyclerViewAdapter);

            LinearLayoutManager layoutManager = new LinearLayoutManager(HomeDetailImageViewer.this);
            layoutManager.setStackFromEnd(true);

            commentRecyclerView.setLayoutManager(layoutManager);


            viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                @Override
                public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

                }

                @Override
                public void onPageSelected(int position) {
                    try {
                        currentMediaPositon = position;
                        resetView(position);
                        SharedMedias sharedMedias1 = getCurrentObjectInstance();
                        if (sharedMedias1 != null) {
                            getOrigianlMedia(sharedMedias1.getMediaIdentifier());

                            setCaption(sharedMedias1.getCaption());

                            if (!sharedMedias1.getContentType().contains("video")) {
                                homeDetailViewPagerAdapter.stopVideoPlayBack();
                            }
                            toogleLikeList();
                        }
                    } catch (Exception e) {
                        writeCrashReport(e.getMessage());
                    }
                }

                @Override
                public void onPageScrollStateChanged(int state) {

                }
            });

            commentRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
                @Override
                public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                    super.onScrollStateChanged(recyclerView, newState);
                }

                @Override
                public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                    super.onScrolled(recyclerView, dx, dy);

                    if (((LinearLayoutManager) commentRecyclerView.getLayoutManager())
                            .findFirstCompletelyVisibleItemPosition() == 0 && mediaCommentList.size() < Integer.parseInt(commentCount.getText().toString())) {
                        try {
                            SharedMedias sharedMedias1 = getCurrentObjectInstance();
                            if (sharedMedias1 != null) {
                                getMediaComments(sharedMedias1.getMediaIdentifier(), mediaCommentList.size());
                            }
                        } catch (Exception e) {
                            writeCrashReport(e.getMessage());
                        }
                    }

                }
            });

            closeParnetComment.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    YoYo.with(Techniques.SlideOutDown).duration(Constants.ANIMATIONTIME).withListener(new Animator.AnimatorListener() {
                        @Override
                        public void onAnimationStart(Animator animation) {

                        }

                        @Override
                        public void onAnimationEnd(Animator animation) {
                            parentCommentView.setVisibility(View.GONE);
                        }

                        @Override
                        public void onAnimationCancel(Animator animation) {

                        }

                        @Override
                        public void onAnimationRepeat(Animator animation) {

                        }
                    }).playOn(parentCommentView);
                    parentCommetDetails = null;
                }
            });

            edtxtComment.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    v.getParent().requestDisallowInterceptTouchEvent(true);
                    switch (event.getAction() & MotionEvent.ACTION_MASK) {
                        case MotionEvent.ACTION_UP:
                            stickerLayout.setVisibility(View.VISIBLE);
                            Utils.showSoftKeyBoard(HomeDetailImageViewer.this);
                            break;
                    }
                    return false;
                }
            });

            sendComment.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try {
                        if (!edtxtComment.getText().toString().equalsIgnoreCase("")) {

                            SharedMedias sharedMedias = getCurrentObjectInstance();

                            String comment = edtxtComment.getText().toString().trim();


                            postMediaComments(
                                    sharedMedias.getMediaIdentifier(), "text",
                                    comment,
                                    mediaCommentList.size()
                            );

                            setCommentLocal("text", comment,
                                    "");

                        }
                    } catch (Exception e) {
                        writeCrashReport(e.getMessage());
                    }
                }
            });

            addStickers.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (stickerLayout.getVisibility() == View.GONE) {
                        stickerLayout.setVisibility(View.VISIBLE);
                    }
                    Utils.hideSoftKeyBoard(HomeDetailImageViewer.this);
                }
            });

            findViewById(R.id.layoutLikeCommentIcons).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (bottomSheetBehavior.getState() != BottomSheetBehavior.STATE_EXPANDED) {
                        bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                        resizeViewPager(0.8f);
                    }
                }
            });

        }

        if (isPromoVideo) {
            bottomSheetBehavior.setPeekHeight(0);
            bottomSheetBehavior.setState(BottomSheetBehavior.STATE_HIDDEN);
            bottomSheetView.setVisibility(View.GONE);
        }

        SharedMedias sharedMedias1 = getCurrentObjectInstance();

        if (sharedMedias1 != null) {

            if (!isPromoVideo) {
                setCommentCount(String.valueOf(sharedMedias1.getCommentCount()));

                setCaption(sharedMedias1.getCaption());

                toogleLikeList();
            }

            getOrigianlMedia(sharedMedias1.getMediaIdentifier());
        }

    }


    private void setLikeAndCommentCount(String likeCount, String commentCount, boolean isMediaLikedByUser) throws Exception {
        this.likeCount.setText(likeCount);

        this.commentCount.setText(commentCount);

        SharedMedias sharedMedias = getCurrentObjectInstance();

        sharedMedias.setLiked(isMediaLikedByUser);
        sharedMedias.setLikeCount(Integer.parseInt(likeCount));
        sharedMedias.setCommentCount(Integer.parseInt(commentCount));
    }


    private void writeCrashReport(String mesage) {
        super.writeCrashReport(HomeDetailImageViewer.class.getName(), mesage);
    }


    /**
     * Set Like and comment count based on the media the user is currently available.
     *
     * @param likeCount    {@link String}
     * @param commentCount {@link String}
     * @throws Exception {Runtime Stub Exception}
     */
    private void setLikeAndCommentCount(String likeCount, String commentCount) throws Exception {

        this.likeCount.setText(likeCount);

        this.commentCount.setText(commentCount);

        SharedMedias sharedMedias = getCurrentObjectInstance();

        sharedMedias.setLikeCount(Integer.parseInt(likeCount));
        sharedMedias.setCommentCount(Integer.parseInt(commentCount));

        YoYo.with(Techniques.Pulse).duration(Constants.ANIMATIONTIME).playOn(this.likeCount);
        YoYo.with(Techniques.Pulse).duration(Constants.ANIMATIONTIME).playOn(this.commentCount);
    }

    private void setLikeCount(String likeCount) throws Exception {
        this.likeCount.setText(likeCount);
        SharedMedias sharedMedias = getCurrentObjectInstance();

        sharedMedias.setLikeCount(Integer.parseInt(likeCount));

        YoYo.with(Techniques.Pulse).duration(Constants.ANIMATIONTIME).playOn(this.likeCount);

    }

    private void setCommentCount(String commentCount) throws Exception {

        this.commentCount.setText(commentCount);
        SharedMedias sharedMedias = getCurrentObjectInstance();
        sharedMedias.setCommentCount(Integer.parseInt(commentCount));

        YoYo.with(Techniques.Pulse).duration(Constants.ANIMATIONTIME).playOn(this.commentCount);
    }

    /**
     * get Original media instead of showing the thumbnail
     *
     * @param mediaIdentifier the unique identifier of the media
     * @throws Exception {@link  NullPointerException}
     */
    public void getOrigianlMedia(final String mediaIdentifier) throws Exception {
        String data = "{}";
        OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, HomeDetailImageViewer.this);
        Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
        RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
        RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
        mRetrofitCallBacks.getMediaDetails(mediaIdentifier, new RestServiceController.ResponseCallBacks() {
            @Override
            public void onResponse(Object o) {
                if (o != null) {
                    try {
                        SharedMedias response = (SharedMedias) o;

                        setLikeAndCommentCount(String.valueOf(response.getLikeCount()),
                                String.valueOf(response.getCommentCount()));

                        int offset = 0;

                        if (mediaCommentList != null && mediaCommentList.size() < response.getCommentCount())
                            offset = mediaCommentList.size();

                        if (!isNewCommentReceived) {

                            int viewPagerCurrentPosition = viewPager.getCurrentItem();

                            HomeDetailViewPagerAdapter.HomeDetailViewHolder holder =
                                    homeDetailViewHolderHashMap.get(viewPagerCurrentPosition);

                            if (holder != null) {
                                if (response.getContentType().contains("video")) {
                                    holder.playVideo(response);
                                } else if (response.getContentType().contains("gif")) {
                                    holder.displayGifMedia(response);
                                } else {
                                    if (holder.photoView.getVisibility() == View.GONE) {
                                        holder.displayOriginalImage(response);
                                    }
                                }
                            }
                        } else {
                            sendBroadCastData();
                        }

                        if (offset == 0)
                            isNewCommentReceived = true;

                        getMediaComments(mediaIdentifier, offset);

                    } catch (Exception e) {
                        writeCrashReport(e.getMessage());
                    }
                }
            }

            @Override
            public void onFailure(Object o) {

            }
        });
    }

    /**
     * On Media Click top icons and like and comment icons need to be shown
     *
     * @throws Exception {@link RuntimeException} view may not be available
     */
    private void toggleTopAndBottomView() throws Exception {
        if (!isPromoVideo) {
            if (bottomSheetBehavior.getPeekHeight() == 0) {
                back.setVisibility(View.VISIBLE);
                setBottomSheetHeight(likeandcommentview.getBottom());
            } else {
                back.setVisibility(View.GONE);
                setBottomSheetHeight(0);
            }

            if (homeDetailViewPagerAdapter.player != null &&
                    homeDetailViewPagerAdapter.player.getPlayWhenReady()) {
                back.setVisibility(View.VISIBLE);
                setBottomSheetHeight(likeandcommentview.getBottom());
            }
        }

    }

    private void resetView(int position) throws Exception {
        if (position > 0) {
            View currentView = viewPager.getChildAt(position);
            View lastView = viewPager.getChildAt(position - 1);
            View previousView = viewPager.getChildAt(position + 1);

            if (currentView != null) {
                PhotoView img = currentView.findViewById(R.id.feed_viewpager_photo_view);
                img.setDisplayMatrix(new Matrix());
            }

            if (lastView != null) {
                PhotoView img = lastView.findViewById(R.id.feed_viewpager_photo_view);
                img.setDisplayMatrix(new Matrix());
            }

            if (previousView != null) {
                PhotoView img = previousView.findViewById(R.id.feed_viewpager_photo_view);
                img.setDisplayMatrix(new Matrix());
            }
        }
        edtxtComment.setText("");
        mediaCommentList.clear();
        commentRecyclerViewAdapter.notifyDataSetChanged();
    }


    private void setBottomSheetHeight(int peekheight) throws Exception {
        bottomSheetBehavior.setPeekHeight(peekheight);
    }

    /**
     * get media comments which are posted by many users
     *
     * @param mediaIdentifier the media identifier the comments need to be fetched
     * @param offSet          the current offest of the loaded comments
     */
    private void getMediaComments(final String mediaIdentifier, final int offSet) throws Exception {

        String data = "{}";
        OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, HomeDetailImageViewer.this);
        Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
        RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
        RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
        if (!isStoryTimeLine) {
            mRetrofitCallBacks.getMediaComments(mediaIdentifier, offSet, Constants.PAGE_SIZE,
                    new RestServiceController.ResponseCallBacks() {
                        @Override
                        public void onResponse(Object o) {
                            try {
                                final List<MediaComment> response = (List<MediaComment>) o;

                                Collections.reverse(response);

                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        try {
                                            commentRecyclerViewAdapter.add(response);

                                            if (isNewCommentReceived) {

                                                commentRecyclerView.scrollToPosition(
                                                        commentRecyclerViewAdapter.getItemCount() - 1);

                                                isNewCommentReceived = false;
                                            }
                                        } catch (Exception e) {
                                            writeCrashReport(e.getMessage());
                                        }

                                    }
                                });

                            } catch (Exception e) {
                                writeCrashReport(e.getMessage());
                            }
                        }

                        @Override
                        public void onFailure(Object o) {
                            handleApiError(o);
                        }
                    });
        } else {
            mRetrofitCallBacks.getMediaStoryComments(mediaIdentifier, offSet, Constants.PAGE_SIZE,
                    new RestServiceController.ResponseCallBacks() {
                        @Override
                        public void onResponse(Object o) {
                            try {

                                final List<MediaComment> response = (List<MediaComment>) o;

                                Collections.reverse(response);

                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        try {
                                            commentRecyclerViewAdapter.add(response);

                                            if (isNewCommentReceived) {
                                                commentRecyclerView.scrollToPosition(
                                                        commentRecyclerViewAdapter.getItemCount() - 1);

                                                isNewCommentReceived = false;

                                            }
                                        } catch (Exception e) {
                                            writeCrashReport(e.getMessage());
                                        }
                                    }
                                });
                            } catch (Exception e) {
                                writeCrashReport(e.getMessage());
                            }
                        }

                        @Override
                        public void onFailure(Object o) {
                            handleApiError(o);
                        }
                    });
        }

    }

    /**
     * if user enters any comment it may be audio or animation or emojji or text this function will be
     * called.
     *
     * @param mediaIdentifier the identifier against which the comment should be posted.
     * @param type            {emoji,text,animation,sticker}
     * @param content         content of the comment.
     */

    public void postMediaComments(final String mediaIdentifier, final String type,
                                  final String content, int postion) throws Exception {

        if (!isStoryTimeLine) {
            postTimelineComment(mediaIdentifier, type, content, postion);
        }

        if (isStoryTimeLine && parentCommetDetails == null) {
            postTimelineComment(mediaIdentifier, type, content, postion);
        } else if (parentCommetDetails != null && isStoryTimeLine) {
            postStoriesParentComment(type, content, postion);
        }

    }

    /**
     * post timeline comments on body if user is replying to a commnet{@link PostMediaComment#parentCommentId} is added
     *
     * @param mediaIdentifier the media against which the comment need to passed
     * @param type            {either text or sticker}
     * @param content         {text that need to be added}
     * @throws Exception {Runtime stub excetop}
     */
    private void postTimelineComment(final String mediaIdentifier, final String type,
                                     final String content, final int postion) throws Exception {

        PostMediaComment postMediaComment = new PostMediaComment(content, type);

        if (!isStoryTimeLine && parentCommetDetails != null) {
            postMediaComment.setParentCommentId(parentCommetDetails.getCommentIdentifier());
        }


        OkHttpClient okHttpClient = RestServiceUtils.getHeader(postMediaComment.toJSON(),
                HomeDetailImageViewer.this);
        Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
        RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
        RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);


        mRetrofitCallBacks.postMediaComments(mediaIdentifier, postMediaComment,
                new RestServiceController.ResponseCallBacks() {
                    @Override
                    public void onResponse(Object o) {
                        try {
                            CommentIdentifier commentIdentifier = (CommentIdentifier) o;

                            if (isStoryTimeLine) {

                                MediaComment mediaComment = mediaCommentList.get(postion);
                                mediaComment.setCommentIdentifier(commentIdentifier.getCommentIdentifier());

                            } else {
                                MediaComment mediaComment = mediaCommentList.get(postion);
                                mediaComment.setCommentIdentifier(
                                        commentIdentifier != null
                                                ? Utils.isVaildString(commentIdentifier.commentIdentifier)
                                                ? commentIdentifier.getCommentIdentifier() : ""
                                                : "");

                            }

                        } catch (Exception e) {
                            writeCrashReport(e.getMessage());
                        }
                    }

                    @Override
                    public void onFailure(Object o) {
                        handleApiError(o);
                    }
                });
    }

    /**
     * Post reply comment in storeis
     *
     * @param type    the type of comment either text or sticker
     * @param content the {@link String} content of the comment
     * @throws Exception {Runtime Exception}
     */
    private void postStoriesParentComment(final String type,
                                          final String content, final int postion) throws Exception {

        PostMediaComment postMediaComment = new PostMediaComment(content, type);

        Gson gson = new Gson();

        String data = gson.toJson(postMediaComment);
        OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, HomeDetailImageViewer.this);
        Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
        RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
        RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);

        mRetrofitCallBacks.postParnetMediaComment(parentCommetDetails.getCommentIdentifier(), postMediaComment,
                new RestServiceController.ResponseCallBacks() {
                    @Override
                    public void onResponse(Object o) {
                        try {
                            if (isStoryTimeLine) {

                                CommentIdentifier commentIdentifier = (CommentIdentifier) o;

                                MediaComment mediaComment = mediaCommentList.get(postion);

                                mediaComment.setCommentIdentifier(commentIdentifier.getCommentIdentifier());
                            }

                        } catch (Exception e) {
                            writeCrashReport(e.getMessage());
                        }
                    }

                    @Override
                    public void onFailure(Object o) {
                        handleApiError(o);
                    }
                });
    }

    /**
     * if user enters any comment it may be audio or animation or emojji or text this function will be
     * called.
     *
     * @param type    {emoji,text,animation,sticker}
     * @param content content of the comment.
     */
    private void setCommentLocal(String type, String content,
                                 String commentIdentifier) throws Exception {
        SessionManager sessionManager = new SessionManager(this);

        String userProfile = sessionManager.getUserProfileUri();

        String userIdentifier = sessionManager.getUserIdentifier();

        String userName = sessionManager.getUserName();

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));

        Date currentDay = new Date();
        String todayDate = sdf.format(currentDay);

        MediaComment mediaComment = new MediaComment(
                commentIdentifier,
                type,
                userIdentifier,
                userName,
                content,
                userProfile,
                todayDate,
                parentCommetDetails);


        edtxtComment.setText("");

        SharedMedias sharedMedias1 = getCurrentObjectInstance();
        if (sharedMedias1 != null) {
            setLikeAndCommentCount(
                    String.valueOf(sharedMedias1.getLikeCount()),
                    String.valueOf(sharedMedias1.getCommentCount() + 1));
        }

        commentRecyclerViewAdapter.add(mediaCommentList.size(), mediaComment);

        commentRecyclerViewAdapter.notifyItemInserted(mediaCommentList.size());

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                commentRecyclerView.scrollToPosition(mediaCommentList.size() - 1);
            }
        });

        if (parentCommetDetails != null) {

            parentCommentView.setVisibility(View.GONE);

            parentCommetDetails = null;
        }

        sendBroadCastData();
    }

    /**
     * get currnet {@link SharedMedias} object the user is viewing
     *
     * @return {@link SharedMedias} object
     * @throws Exception{Runtime Stub Excepion}
     */
    private SharedMedias getCurrentObjectInstance() throws Exception {
        List<SharedMedias> sharedMedias = isStoryTimeLine ? storyTimeLine.getSharedMedias()
                : getAllMediaTimeLine.getSharedMedias();
        return sharedMedias.get(viewPager.getCurrentItem());
    }

    /**
     * Toogle Like option either form like to unlike vice versa
     *
     * @throws Exception {Runtime Stub Exception}
     */
    private void toogleLikeList() throws Exception {
        SharedMedias sharedMedias = getCurrentObjectInstance();
        if (sharedMedias != null) {
            if (sharedMedias.getLiked()) {
                likeMedia.setBackground(getDrawable(R.drawable.ic_like));
                isMediaLikedByUser = true;
            } else {
                likeMedia.setBackground(getDrawable(R.drawable.ic_unlike_white));
                isMediaLikedByUser = false;
            }
            setLikeCount(String.valueOf(sharedMedias.getLikeCount()));
            setCommentCount(String.valueOf(sharedMedias.getCommentCount()));
        }
    }


    /**
     * action to like the media or unlike the media
     *
     * @param action the action user has done {LIKE,UNLIKE}
     */
    private void postMediaLike(final String action) throws Exception {
        try {
            MediaLikeDetails mediaLikeDetails = new MediaLikeDetails();
            Gson gson = new Gson();
            String data = gson.toJson(mediaLikeDetails);
            OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, HomeDetailImageViewer.this);
            Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
            RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
            RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
            SharedMedias sharedMedias = getCurrentObjectInstance();
            mRetrofitCallBacks.postMediaLikeAction(sharedMedias.getMediaIdentifier(),
                    action, mediaLikeDetails,
                    new RestServiceController.ResponseCallBacks() {
                        @Override
                        public void onResponse(Object o) {

                        }

                        @Override
                        public void onFailure(Object o) {
                            handleApiError(o);
                        }
                    });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * On Bottom Sheet scroll the viewpager must be resized.
     *
     * @param slideOffset {@link BottomSheetBehavior.BottomSheetCallback} the current slide value of the bottom sheet
     */
    private void resizeViewPager(float slideOffset) {

        int offset = (int) (slideOffset * 100);

        if (offset > 20 || offset < minimumBottomSheetScroll) {
            View rootView = getWindow().getDecorView();


            int totalHeight = rootView.getHeight();

            int bottomSheetTotalHeight = bottomSheetView.getHeight();

            int bottomSheetScrollHeight = (bottomSheetTotalHeight * offset) / 100;


            ViewGroup.LayoutParams layoutParams = viewPager.getLayoutParams();
            layoutParams.height = totalHeight - bottomSheetScrollHeight;

            viewPager.setLayoutParams(layoutParams);
            viewPager.requestLayout();
        }
    }

    /**
     * {@link BroadcastReceiver} send Local Broad cast data that user has liked the media or even commented on the media
     */
    private void sendBroadCastData() {
        try {
            Intent intent = new Intent(Constants.REFRESHHOMEDATA);
            intent.putExtra(Constants.SELECTEDIMAGES, new Gson().toJson(getCurrentObjectInstance()));
            intent.putExtra(Constants.SHAREMEDA_POSITON, viewPager.getCurrentItem());
            intent.putExtra(Constants.TIMELINE_IDENTIFIER, isStoryTimeLine ? storyTimeLine.getTimelineIdentifier()
                    : getAllMediaTimeLine.getTimelineIdentifier());
            sendBroadcast(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Handle API error messages
     *
     * @param o might be Instance of {@link Response} or {@link Throwable}
     */
    private void handleApiError(Object o) {
        if (o != null) {

            try {
                if (o instanceof retrofit2.Response) {
                    ResponseBody responseBody = ((Response) o).errorBody();
                    if (responseBody != null) {
                        String value = responseBody.string();
                        ErrorBodyModel errorBodyModel = new Gson().fromJson(value, ErrorBodyModel.class);
                        if (errorBodyModel != null) {
                            super.showToastMessage(
                                    errorBodyModel.getMessage(),
                                    false);
                        }

                    }
                } else if (o instanceof Throwable) {
                    writeCrashReport(((Throwable) o).getMessage());
                    super.showToastMessage(
                            getString(R.string.sp_no_internet_connection),
                            false);
                }

            } catch (Exception e) {
                writeCrashReport(e.getMessage());
            }
        }
    }

    /**
     * set caption if caption is added to the view.
     *
     * @param caption {@link String} value sent from server
     */
    public void setCaption(String caption) {
        if (Utils.isVaildString(caption)) {
            captionTxt.setText(caption);
            captionTxt.setVisibility(View.VISIBLE);
        } else {
            captionTxt.setVisibility(View.INVISIBLE);
        }
    }

    /**
     * Post Parent media comment to server MODEL class
     */
    public class CommentIdentifier {
        @SerializedName("comment_identifier")
        @Expose
        String commentIdentifier;

        String getCommentIdentifier() {
            return commentIdentifier;
        }

        public void setCommentIdentifier(String commentIdentifier) {
            this.commentIdentifier = commentIdentifier;
        }
    }

}
