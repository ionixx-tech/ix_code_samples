package com.dubuqu.dnServices;

import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.util.Log;

import com.bumptech.glide.Glide;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnConstants.UploadConstants;
import com.dubuqu.dnMediaCompression.ImageCompressor;
import com.dubuqu.dnMediaCompression.VideoCompressor;
import com.dubuqu.dnModels.requestModel.DubuquShareMediaRequest;
import com.dubuqu.dnRestServices.RestServiceController;
import com.dubuqu.dnRestServices.RestServiceProvider;
import com.dubuqu.dnServices.upload.UploadMediaToS3;
import com.dubuqu.dnStorage.DbHelper;
import com.dubuqu.dnStorage.upload.UploadDbModel;
import com.dubuqu.dnUtils.RestServiceUtils;
import com.dubuqu.dnUtils.Utils;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.List;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;

/**
 * Created by Yogaraj subramanian on 16/6/17
 * <p>
 * {@link FileShareService}is to compress and upload files to Amazon Web Service.
 * <p>
 * initlaily the media and user list are recieved from {@link JobParameters}
 * as json data because instead of using comma seperated values {@link org.json.JSONObject} is much more
 * convinient to work on.
 * <p>
 * based on the type of media {@link android.media.Image,android.provider.MediaStore.Video or Gif}
 * respective compressor is called {@link ImageCompressor,VideoCompressor}
 * <p>
 * for video compression {@link com.github.hiteshsondhi88.libffmpeg.FFmpeg}  is used.
 * <p>
 * for image compression {@link Glide} is used.
 * <p>
 * the progres of the media compression is updated to database for each 2 seconds because to avaoid
 * current modification exception.
 * </p>
 */
public class FileShareService extends JobService implements UploadMediaToS3.UploadMediaListner {

    List<String> selectedUsers = new ArrayList<>();

    List<String> mediaIdentifiers = new ArrayList<>();

    List<UploadDbModel> files = new ArrayList<>();

    boolean shouldDelteOriginalMedia = false, isCanceled = false;

    int totalNumberOfmedias = 0, numberOfMediasUploaded = 0;

    String uploadIdentifier;

    final String TAG = FileShareService.class.getName();

    long threadLastUpdateTime = 0;

    JobParameters jobParameters;

    UploadMediaToS3 uploadMediaToS3;

    @Override
    public boolean onStartJob(JobParameters jobParameters) {
        try {
            this.jobParameters = jobParameters;

            Log.e(TAG, jobParameters.getJobId() + "\t Job started");

            getApplicationContext().registerReceiver(cancelJob,
                    new IntentFilter(String.valueOf(jobParameters.getJobId())));

            threadLastUpdateTime = System.currentTimeMillis();

            String filePaths = jobParameters.getExtras().getString(Constants.SHAREMEDIA);

            String userPath = jobParameters.getExtras().getString(Constants.SELECTEDUSERS);

            Gson g = new Gson();

            uploadIdentifier = String.valueOf(jobParameters.getJobId());

            shouldDelteOriginalMedia = Boolean.parseBoolean(
                    jobParameters.getExtras().getString(Constants.SHOULDDELETEMEDIA));

            selectedUsers = g.fromJson(userPath,
                    new TypeToken<List<String>>() {
                    }.getType());

            files = g.fromJson(filePaths,
                    new TypeToken<List<UploadDbModel>>() {
                    }.getType());

            assert files != null;

            totalNumberOfmedias = files.size();

            Intent intent = new Intent(Constants.REFRESH_UPLOAD);
            intent.putExtra(Constants.ID, files.get(0).getUploadId());
            intent.putExtra(Constants.EXTRASTRINGS, String.valueOf(UploadConstants.UPLOADSTATUS.PROGRESS));

            getApplicationContext().sendBroadcast(intent);

            initateUpload();

        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
            jobFinished(jobParameters, false);
        }

        return true;
    }


    @Override
    public boolean onStopJob(JobParameters jobParameters) {
        try {

            getApplicationContext().unregisterReceiver(cancelJob);

            Log.e(TAG, "OnStopCalled");

            if (numberOfMediasUploaded < totalNumberOfmedias) {

                DbHelper dbHelper = new DbHelper(getApplicationContext());

                dbHelper.updateProgressStateOfUpload(String.valueOf(jobParameters.getJobId()),
                        UploadConstants.UPLOADSTATUS.FAILURE);

                sendBroadcast(new Intent(Constants.ONMEDIAUPLOADFAILED));
            }

            if (uploadMediaToS3 != null) {
                uploadMediaToS3.stopProcess();
                uploadMediaToS3 = null;
            }

            sendBroadcast(new Intent("com.dubuqu.STARTFILESHARE"));

        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        }

        return false;
    }


    private void initateUpload() throws Exception {

        if (numberOfMediasUploaded == totalNumberOfmedias) {
            makeShareRequest();
        } else {
            uploadMediaToS3 = new UploadMediaToS3(files.get(numberOfMediasUploaded),
                    shouldDelteOriginalMedia, this, getApplicationContext());
            uploadMediaToS3.startProcess();
        }
    }

    @Override
    public void onMediaUploadComplted(String mediaIdentifier) {
        mediaIdentifiers.add(mediaIdentifier);
        try {
            numberOfMediasUploaded++;
            initateUpload();

            sendBroadcast(new Intent(Constants.UPLOAD_RECEIVER));

        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        }
    }

    @Override
    public void onMediaUploadFailed(String exceptionMessage) {
        Log.e(TAG, exceptionMessage);
        try {
            DbHelper dbHelper = new DbHelper(getApplicationContext());

            dbHelper.updateProgressStateOfUpload(String.valueOf(jobParameters.getJobId()),
                    UploadConstants.UPLOADSTATUS.FAILURE);

            Intent intent = new Intent(Constants.REFRESH_UPLOAD);
            intent.putExtra(Constants.ID, files.get(0).getUploadId());
            intent.putExtra(Constants.EXTRASTRINGS, String.valueOf(UploadConstants.UPLOADSTATUS.FAILURE));
            getApplicationContext().sendBroadcast(intent);

            sendBroadcast(new Intent(Constants.UPLOAD_RECEIVER));

        } catch (Exception e) {
            Log.e(FileShareService.class.getName(), e.getMessage());
        }


        Utils.showNegativeTost(getApplicationContext(), "Media Upload Failed");
        jobFinished(jobParameters, false);
    }

    @Override
    public void updateProcesssState(UploadDbModel uploadDbModel, int progressValue,
                                    UploadConstants.UPLOADSTATUS uploadstatus) {
        updateProgress(uploadDbModel, progressValue, uploadstatus);

        sendBroadcast(new Intent(Constants.UPLOAD_RECEIVER));
    }

    @Override
    public void updateProgressForUpload(UploadDbModel uploadDbModel, String progressValue) {
        updateProgressForFileUpload(uploadDbModel, progressValue);
    }

    /**
     * Update Progess state of the upload object
     *
     * @param uploadDbModel {@link UploadDbModel} the object which contains the identifier
     * @param progress      {@link Integer} progress value range from 1 -100
     * @param uploadstatus  {@link UploadConstants.UPLOADSTATUS}
     */
    private void updateProgress(UploadDbModel uploadDbModel, int progress,
                                UploadConstants.UPLOADSTATUS uploadstatus) {
        if (progress != 0) {
            try {

                DbHelper dbHelper = new DbHelper(getApplicationContext());
                dbHelper.updateProgressValueForUpload(uploadDbModel, progress, String.valueOf(uploadstatus));

                if (uploadstatus == UploadConstants.UPLOADSTATUS.FAILURE) {
                    dbHelper.updateProgressStateOfUpload(uploadDbModel.getUploadId(),
                            UploadConstants.UPLOADSTATUS.FAILURE);
                    jobFinished(jobParameters, false);
                }

            } catch (Exception e) {
                Log.e(TAG, e.getMessage());
                jobFinished(jobParameters, false);
            }
        }

    }

    private void updateProgressForFileUpload(UploadDbModel uploadDbModel, String progresValue) {
        try {
            if (!isCanceled) {

                long currentTime = System.currentTimeMillis();

                if (threadLastUpdateTime == 0 || (currentTime - threadLastUpdateTime) > 300) {
                    //for every 3 milli second send broad cast
                    threadLastUpdateTime = currentTime;

                    DbHelper dbHelper = new DbHelper(getApplicationContext());

                    dbHelper.updateUploadProgressForFile(uploadDbModel, progresValue);

                    Intent intent = new Intent(Constants.UPLOAD_LIST_RECEIVER);
                    intent.putExtra(Constants.ID,uploadDbModel.getId());
                    intent.putExtra(Constants.EXTRASTRINGS,progresValue);
                    sendBroadcast(intent);

                }
            }
        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
            jobFinished(jobParameters, false);
        }

    }


    private void makeShareRequest() throws Exception {

        if (selectedUsers.size() > 0) {

            DubuquShareMediaRequest dubuquShareMediaRequest = new DubuquShareMediaRequest();
            dubuquShareMediaRequest.setMediaIdentifiers(mediaIdentifiers);
            dubuquShareMediaRequest.setRecipient(selectedUsers);
            Gson gson = new Gson();
            String shareData = gson.toJson(dubuquShareMediaRequest);
            OkHttpClient okHttpClient = RestServiceUtils.getHeader(shareData, getApplicationContext());

            Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
            RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
            RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
            mRetrofitCallBacks.shareMediaRequestToDubuqu(dubuquShareMediaRequest);

            DbHelper dbHelper = new DbHelper(getApplicationContext());

            dbHelper.updateProgressStateOfUpload(files.get(0).getUploadId(),
                    UploadConstants.UPLOADSTATUS.SUCCESS);

            Utils.showToast(getApplicationContext(), "Media Shown Sucessfully");

            Intent intent = new Intent(Constants.REFRESH_UPLOAD);
            intent.putExtra(Constants.ID, files.get(0).getUploadId());
            intent.putExtra(Constants.EXTRASTRINGS, String.valueOf(UploadConstants.UPLOADSTATUS.SUCCESS));
            sendBroadcast(intent);

            JobScheduler jobScheduler = (JobScheduler) getSystemService(Context.JOB_SCHEDULER_SERVICE);
            assert jobScheduler != null;
            jobScheduler.cancel(jobParameters.getJobId());

        }
    }


    BroadcastReceiver cancelJob = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            try {
                isCanceled = true;

                JobScheduler jobScheduler = (JobScheduler) getSystemService(Context.JOB_SCHEDULER_SERVICE);

                assert jobScheduler != null;

                jobScheduler.cancel(jobParameters.getJobId());
            } catch (Exception e) {
                Log.e(TAG, e.getMessage());
            }
        }
    };


    @Override
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        Log.e(TAG, "OnTask Removed");
    }
}
