package com.dubuqu.dnModels.responseModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Awesome Pojo Generator
 */
public class SharedMedias {

    @SerializedName("media_identifier")
    @Expose
    private String mediaIdentifier;

    @SerializedName("content_type")
    @Expose
    private String contentType;

    @SerializedName("comment_count")
    @Expose
    private Integer commentCount;

    @SerializedName("like_count")
    @Expose
    private Integer likeCount;

    @SerializedName("liked")
    @Expose
    private boolean liked;

    @SerializedName("created_time")
    @Expose
    private String createdTime;

    @SerializedName("thumbnail_signed_url")
    @Expose
    private  String thumbnailUrl;

    @SerializedName("signed_url")
    @Expose
    private String signedUrl;

    @SerializedName("caption")
    @Expose
    private String caption;

    @SerializedName("unread_comment_count")
    @Expose
    private Integer unreadCommentCount;


    public String getMediaIdentifier() {
        return mediaIdentifier;
    }

    public void setMediaIdentifier(String mediaIdentifier) {
        this.mediaIdentifier = mediaIdentifier;
    }

    public String getThumbnailUrl() {
        return thumbnailUrl;
    }

    public void setThumbnailUrl(String thumbnailUrl) {
        this.thumbnailUrl = thumbnailUrl;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public Integer getCommentCount() {
        return commentCount;
    }

    public void setCommentCount(Integer commentCount) {
        this.commentCount = commentCount;
    }

    public Integer getLikeCount() {
        return likeCount;
    }

    public void setLikeCount(Integer likeCount) {
        this.likeCount = likeCount;
    }

    public boolean getLiked() {
        return liked;
    }

    public void setLiked(boolean liked) {
        this.liked = liked;
    }

    public String getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(String createdTime) {
        this.createdTime = createdTime;
    }

    public String getSignedUrl() {
        return signedUrl;
    }

    public void setSignedUrl(String signedUrl) {
        this.signedUrl = signedUrl;
    }

    public boolean isLiked() {
        return liked;
    }

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }


    public Integer getUnreadCommentCount() {
        return unreadCommentCount;
    }

    public void setUnreadCommentCount(Integer unreadCommentCount) {
        this.unreadCommentCount = unreadCommentCount;
    }
}