package com.dubuqu.dnServices;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.util.Log;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.dubuqu.dnCallbacks.Callbacks;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnMediaCompression.ImageCompressor;
import com.dubuqu.dnModels.responseModel.FormAttributes;
import com.dubuqu.dnModels.responseModel.FormInputs;
import com.dubuqu.dnModels.responseModel.Media;
import com.dubuqu.dnModels.responseModel.SignedUrlResponseModel;
import com.dubuqu.dnModels.responseModel.Thumbnail;
import com.dubuqu.dnModels.responseModel.UpdateGroupProfileRequest;
import com.dubuqu.dnRestServices.RestServiceController;
import com.dubuqu.dnRestServices.RestServiceProvider;
import com.dubuqu.dnUtils.RestServiceUtils;
import com.dubuqu.dnUtils.Utils;
import com.google.gson.Gson;

import java.io.File;
import java.io.FileOutputStream;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Retrofit;

import static android.content.ContentValues.TAG;

/**
 * Created by Yogaraj subramanian on 28/6/17
 */

public class UserProfileImageUpdateService extends JobService {

    String userIdentifier, filepath;

    @Override
    public boolean onStartJob(JobParameters jobParameters) {
        userIdentifier = jobParameters.getExtras().getString(Constants.USER_IDENTIFIER);
        filepath = jobParameters.getExtras().getString(Constants.FILE_PATH);
        if (filepath != null && filepath.trim().length() != 0)
            getSignedUrlfromServer(filepath);
        else
            updateImageIdentifier("");
        return false;
    }

    @Override
    public boolean onStopJob(JobParameters jobParameters) {
        return false;
    }


    private void updateImageIdentifier(String profileImageIdentifier) {
        Gson gson = new Gson();
        try {
            UpdateGroupProfileRequest updateGroupProfileRequest = new UpdateGroupProfileRequest();
            updateGroupProfileRequest.setProfileImageIdentifier(profileImageIdentifier);
            String data = gson.toJson(updateGroupProfileRequest);
            OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, getApplicationContext());
            Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
            RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
            RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
            mRetrofitCallBacks.uploadUserProfileImageToDubuquServer(updateGroupProfileRequest, userIdentifier);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void getSignedUrlfromServer(final String filepath) {
        try {
            String[] resolution = Utils.getResolution(filepath);
            String width = "320";
            String height = "640";
            if (resolution.length == 2) {
                width = resolution[1];
                height = resolution[0];
            }
            String data = "{}";
            OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, getApplicationContext());
            Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
            RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
            RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
            mRetrofitCallBacks.getSignedUrl(

                    new RestServiceController.ResponseCallBacks() {
                        @Override
                        public void onResponse(Object o) {
                            SignedUrlResponseModel response = (SignedUrlResponseModel) o;
                            /*upload image to server*/
                            try {
                                uploadMediaToAmazonS3(response, filepath);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            /*make idientifier request to server*/
                            updateImageIdentifier(response.getMediaIdentifier());
                        }

                        @Override
                        public void onFailure(Object o) {

                        }
                    }
                    , "profile_image", Utils.getMimeType(filepath),
                    Utils.getFileExtension(filepath), width, height);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void uploadMediaToAmazonS3(final SignedUrlResponseModel response, final String filePath) throws Exception {

        new ImageCompressor(new Callbacks.CompressionCallback() {
            @Override
            public void getCompressedFilePath(String SfilePath) {
                uploadImageThumbnail(response, filePath);
            }

            @Override
            public void onFailed() {

            }

            @Override
            public void onUpdateProgress(int value) {

            }
        }, getApplicationContext()).execute(filePath);
    }



    private void uploadImageThumbnail(final SignedUrlResponseModel signedUrlResponseModel, final String filePath) {
        try {
            AsyncTask.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        Bitmap thumb = Glide.with(getApplicationContext()).load(filePath).asBitmap().diskCacheStrategy(DiskCacheStrategy.NONE).skipMemoryCache(true).into(240, 240).get();

                        File dir = getCacheDir();
                        if (!dir.exists())
                            dir.mkdirs();
                        final File file = new File(dir, "Thumbnails" + signedUrlResponseModel.getThumbnail() + ".jpg");
                        FileOutputStream fOut = new FileOutputStream(file);

                        thumb.compress(Bitmap.CompressFormat.JPEG, 85, fOut);
                        fOut.flush();
                        fOut.close();

                        Thumbnail thu = signedUrlResponseModel.getThumbnail();
                        FormAttributes formAttributes = thu.getFormAttributes();
                        FormInputs formInputs = thu.getFormInputs();

                        Retrofit retrofit = RestServiceUtils.uploadMediaToS3(formAttributes.getAction());
                        RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
                        RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);

                        RequestBody requestFile =
                                RequestBody.create(MediaType.parse(file.getAbsolutePath()), file);

                        mRetrofitCallBacks.uploadMediaToS3(convertresquestBofy(formInputs.getXAmzCredential()),
                                convertresquestBofy(formInputs.getXAmzAlgorithm()),
                                convertresquestBofy(formInputs.getXAmzDate()),
                                convertresquestBofy(formInputs.getAcl()),
                                convertresquestBofy(formInputs.getPolicy()),
                                convertresquestBofy(formInputs.getXAmzSignature()),
                                convertresquestBofy(formInputs.getKey()),
                                convertresquestBofy(formInputs.getContentType()),
                                requestFile, new RestServiceController.ResponseCallBacks() {
                                    @Override
                                    public void onResponse(Object o) {
                                        if (file.exists())
                                            file.delete();
                                    }

                                    @Override
                                    public void onFailure(Object o) {

                                    }
                                }, new RestServiceController.CallEvents() {
                                    @Override
                                    public void onCallCreated(Call<ResponseBody> responseBodyCall) {

                                    }
                                }
                        );

                        Media media = signedUrlResponseModel.getMedia();
                        FormAttributes formAttributesMedia = media.getFormAttributes();
                        FormInputs formInputsMedia = media.getFormInputs();

                        Retrofit retrofitMedia = RestServiceUtils.uploadMediaToS3(formAttributesMedia.getAction());
                        RestServiceProvider retrofitNetworkCallsMedia = retrofitMedia.create(RestServiceProvider.class);
                        RestServiceController mRetrofitCallBacksMedia = new RestServiceController(retrofitNetworkCallsMedia);

                        Log.d(TAG, "uploadMedia: uploading dash");
                        mRetrofitCallBacksMedia.uploadMediaToS3(convertresquestBofy(formInputsMedia.getXAmzCredential()),
                                convertresquestBofy(formInputsMedia.getXAmzAlgorithm()),
                                convertresquestBofy(formInputsMedia.getXAmzDate()),
                                convertresquestBofy(formInputsMedia.getAcl()),
                                convertresquestBofy(formInputsMedia.getPolicy()),
                                convertresquestBofy(formInputsMedia.getXAmzSignature()),
                                convertresquestBofy(formInputsMedia.getKey()),
                                convertresquestBofy(formInputsMedia.getContentType()),
                                requestFile, new RestServiceController.ResponseCallBacks() {
                                    @Override
                                    public void onResponse(Object o) {

                                    }

                                    @Override
                                    public void onFailure(Object o) {

                                    }
                                }, new RestServiceController.CallEvents() {
                                    @Override
                                    public void onCallCreated(Call<ResponseBody> responseBodyCall) {

                                    }
                                }
                        );
                    } catch (Exception e) {
                        e.getMessage();
                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }


    }



    private RequestBody convertresquestBofy(String text) {
        return RequestBody.create(MediaType.parse("text/plain"), text);
    }

}
