package com.dubuqu.dnViews;

import android.content.Context;
import android.graphics.Color;
import android.util.AttributeSet;
import android.util.Log;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.bumptech.glide.Glide;
import com.github.chrisbanes.photoview.PhotoView;

import java.io.File;
import java.util.List;

import static com.bumptech.glide.gifdecoder.GifHeaderParser.TAG;

/**
 * 7.5 Collage
 * User simply need to select multiple photos from DUBUQU gallery and we’ll automatically
 * create a stunning photo collage for them. Collage option will be provided under “Three Dots” option.
 * <p>
 * Clicking on the “Collage” button will display the DUBUQU gallery screen along with “Create Collage”
 * floating button at the footer, no matter from which screen user has clicked on collage button.
 * <p>
 * The images in the gallery will be displaying with a radio button or checkbox.
 * <p>
 * User will be allowed to select “2 to 9” photos from the gallery to create a collage.
 * <p>
 * Once the user selected the image, they can click on “Create Collage” button.
 * <p>
 * For few seconds, the app will be displaying loading icon.
 * <p>
 * Once the collage is created, the DUBUQU image viewer screen will be displaying with all option like share,
 * date and time stamp, edit and others. User can share the collage directly to any group or individual.
 * <p>
 * Once the collage image get shared, the same will be displaying in the Stories section of the VAULT.
 */
public class DubuquCollageView extends LinearLayout {

    private List<String> imageUrls;
    private Context context;
    private int collageOption;
    private LinearLayout mFirstLayoutLL, mSecondLayoutLL, mThridLayoutLL;
    private LayoutParams layoutParams, layoutRightParams,
            layoutBottomParams, layoutRightMarginParams;

    public enum CollageOption {
        /*verticall collage images size 2 */
        COLLAGE_2_1(1),
        /*horizontal collage image size 2*/
        COLLAGE_2_2(2),
        /*collage 4 images*/
        COLLAGE_4_1(3),
        /*collage three images with split at right*/
        COLLAGE_3_1(4),
        /*collage three images with split at left*/
        COLLAGE_3_2(5),

        COLLAGE_4_2(6),

        COLLAGE_5_1(7),

        COLLAGE_5_2(8),

        COLLAGE_6_1(9),

        COLLAGE_6_2(10),

        COLLAGE_7_1(11),

        COLLAGE_8_1(12),

        COLLAGE_9_1(13),

        COLLAGE_9_2(14);

        CollageOption(int anInt) {
            this.someThing = anInt;
        }

        final int someThing;
    }

    /*custom constructor
    * @params context the context of the fragment
    * @params imageUrls List <String> which contains the  urls of the image is to be loaded
     *
     * two linear lauouts are added to the main view to work on the main layout
     * then the two layouts orientation is  changed dynamically based on the type of the type of the
     * collage option selected.
     * */
    public DubuquCollageView(Context context, List<String> imageUrls) {
        super(context);
        this.imageUrls = imageUrls;
        this.context = context;
        this.setBackgroundColor(Color.WHITE);
        this.layoutParams = new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        this.layoutParams.setMargins(5, 5, 0, 5);

        this.layoutBottomParams = new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        this.layoutBottomParams.setMargins(0, 0, 5, 5);

        this.layoutRightParams = new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        this.layoutRightParams.setMargins(5, 5, 5, 5);

        this.layoutRightMarginParams = new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        this.layoutRightMarginParams.setMargins(5, 5, 5, 0);
    }

    public DubuquCollageView(Context context) {
        super(context);
    }

    public DubuquCollageView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public DubuquCollageView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public void setCollageOption(CollageOption collageOption) {
        try {

            if (collageOption == null) {
            /*values needed*/
                Log.d(TAG, "setCollageOption:Null PointerExpection occured because null value is passed");
                invalidate();
            } else {
                int index;
                switch (collageOption) {
                    case COLLAGE_2_1:
                        index = 0;
                        this.setOrientation(HORIZONTAL);
                        mFirstLayoutLL = new LinearLayout(context);
                        mSecondLayoutLL = new LinearLayout(context);
                        mFirstLayoutLL.setBackgroundColor(Color.WHITE);
                        mSecondLayoutLL.setBackgroundColor(Color.WHITE);
                        this.addView(mFirstLayoutLL, layoutParams);
                        this.addView(mSecondLayoutLL, layoutRightParams);
                        mFirstLayoutLL.setOrientation(HORIZONTAL);
                        mSecondLayoutLL.setOrientation(HORIZONTAL);
                        for (String url : imageUrls) {
                            PhotoView imageView = new PhotoView(context);
                            imageView.setScaleType(PhotoView.ScaleType.CENTER_CROP);
                            if (index < 1) {
                        /*first row*/
                                File f = new File(url);
                                Glide.with(context)
                                        .load(f)
                                        .into(imageView);
                                mFirstLayoutLL.addView(imageView, layoutParams);
                            } else {
                        /*second row*/
                                File f = new File(url);
                                Glide.with(context)
                                        .load(f)
                                        .into(imageView);
                                mSecondLayoutLL.addView(imageView, layoutRightParams);
                            }
                            index++;
                            if (index >= 2) {
                                break;
                            }
                        }
                        break;
                    case COLLAGE_2_2:
                        this.setOrientation(VERTICAL);
                        mFirstLayoutLL = new LinearLayout(context);
                        mSecondLayoutLL = new LinearLayout(context);
                        mFirstLayoutLL.setBackgroundColor(Color.WHITE);
                        mSecondLayoutLL.setBackgroundColor(Color.WHITE);
                        this.addView(mFirstLayoutLL, layoutRightMarginParams);
                        this.addView(mSecondLayoutLL, layoutRightMarginParams);
                        mFirstLayoutLL.setOrientation(VERTICAL);
                        mSecondLayoutLL.setOrientation(VERTICAL);
                        index = 0;
                        for (String url : imageUrls) {
                            PhotoView imageView = new PhotoView(context);
                            imageView.setScaleType(PhotoView.ScaleType.CENTER_CROP);
                            if (index < 1) {
                        /*first row*/
                                File f = new File(url);
                                Glide.with(context)
                                        .load(f)
                                        .into(imageView);
                                mFirstLayoutLL.addView(imageView, layoutBottomParams);
                            } else {
                        /*second row*/
                                File f = new File(url);
                                Glide.with(context)
                                        .load(f)
                                        .into(imageView);
                                mSecondLayoutLL.addView(imageView, layoutBottomParams);
                            }
                            index++;
                            if (index >= 2) {
                                break;
                            }
                        }
                        break;
                    case COLLAGE_3_2:
                        this.setOrientation(HORIZONTAL);
                        mFirstLayoutLL = new LinearLayout(context);
                        mSecondLayoutLL = new LinearLayout(context);
                        mFirstLayoutLL.setBackgroundColor(Color.WHITE);
                        mSecondLayoutLL.setBackgroundColor(Color.WHITE);

                        this.addView(mFirstLayoutLL, layoutParams);
                        this.addView(mSecondLayoutLL, layoutRightParams);
                        mFirstLayoutLL.setOrientation(VERTICAL);
                        mSecondLayoutLL.setOrientation(VERTICAL);
                        index = 0;
                        for (String url : imageUrls) {
                            PhotoView imageView = new PhotoView(context);
                            imageView.setScaleType(PhotoView.ScaleType.CENTER_CROP);
                            if (index < 2) {
                        /*first row*/
                                File f = new File(url);
                                Glide.with(context)
                                        .load(f)
                                        .into(imageView);
                                mFirstLayoutLL.addView(imageView, layoutParams);
                            } else {
                        /*second row*/
                                File f = new File(url);
                                Glide.with(context)
                                        .load(f)
                                        .into(imageView);
                                mSecondLayoutLL.addView(imageView, layoutRightParams);
                            }
                            index++;
                            if (index >= 3) {
                                break;
                            }
                        }
                        break;
                    case COLLAGE_3_1:
                        this.setOrientation(HORIZONTAL);
                        mFirstLayoutLL = new LinearLayout(context);
                        mSecondLayoutLL = new LinearLayout(context);
                        mFirstLayoutLL.setBackgroundColor(Color.WHITE);
                        mSecondLayoutLL.setBackgroundColor(Color.WHITE);
                        this.addView(mFirstLayoutLL, layoutParams);
                        this.addView(mSecondLayoutLL, layoutRightParams);
                        mFirstLayoutLL.setOrientation(VERTICAL);
                        mSecondLayoutLL.setOrientation(VERTICAL);
                        index = 0;
                        for (String url : imageUrls) {
                            PhotoView imageView = new PhotoView(context);
                            imageView.setScaleType(PhotoView.ScaleType.CENTER_CROP);
                            if (index < 1) {
                        /*first row*/
                                File f = new File(url);
                                Glide.with(context)
                                        .load(f)
                                        .into(imageView);
                                mFirstLayoutLL.addView(imageView, layoutParams);
                            } else {
                        /*second row*/
                                File f = new File(url);
                                Glide.with(context)
                                        .load(f)
                                        .into(imageView);
                                mSecondLayoutLL.addView(imageView, layoutRightParams);
                            }
                            index++;
                            if (index >= 3) {
                                break;
                            }
                        }
                        break;
                    case COLLAGE_4_1:
                        this.setOrientation(VERTICAL);
                        mFirstLayoutLL = new LinearLayout(context);
                        mSecondLayoutLL = new LinearLayout(context);
                        mThridLayoutLL = new LinearLayout(context);

                        mFirstLayoutLL.setBackgroundColor(Color.WHITE);
                        mSecondLayoutLL.setBackgroundColor(Color.WHITE);
                        mThridLayoutLL.setBackgroundColor(Color.WHITE);

                        this.addView(mFirstLayoutLL, layoutRightMarginParams);
                        this.addView(mSecondLayoutLL, layoutRightMarginParams);

                        mFirstLayoutLL.setOrientation(HORIZONTAL);
                        mSecondLayoutLL.setOrientation(HORIZONTAL);

                        index = 0;
                        for (String url : imageUrls) {
                            PhotoView imageView = new PhotoView(context);
                            imageView.setScaleType(PhotoView.ScaleType.CENTER_CROP);
                            if (index < 2) {
                        /*first row*/
                                File f = new File(url);
                                Glide.with(context)
                                        .load(f)
                                        .into(imageView);
                                mFirstLayoutLL.addView(imageView, layoutBottomParams);
                            } else {
                        /*second row*/
                                File f = new File(url);
                                Glide.with(context)
                                        .load(f)
                                        .into(imageView);
                                mSecondLayoutLL.addView(imageView, layoutBottomParams);
                            }
                            index++;
                            if (index >= 4) {
                                break;
                            }
                        }
                        break;

                    case COLLAGE_4_2:
                        this.setOrientation(HORIZONTAL);
                        mFirstLayoutLL = new LinearLayout(context);
                        mSecondLayoutLL = new LinearLayout(context);
                        mThridLayoutLL = new LinearLayout(context);

                        mFirstLayoutLL.setBackgroundColor(Color.WHITE);
                        mSecondLayoutLL.setBackgroundColor(Color.WHITE);
                        mThridLayoutLL.setBackgroundColor(Color.WHITE);

                        this.addView(mFirstLayoutLL, layoutParams);
                        this.addView(mSecondLayoutLL, layoutParams);
                        this.addView(mThridLayoutLL, layoutRightParams);

                        mFirstLayoutLL.setOrientation(VERTICAL);
                        mSecondLayoutLL.setOrientation(HORIZONTAL);
                        mThridLayoutLL.setOrientation(HORIZONTAL);
                        index = 0;
                        for (String url : imageUrls) {
                            PhotoView imageView = new PhotoView(context);
                            imageView.setScaleType(PhotoView.ScaleType.CENTER_CROP);
                            if (index < 2) {
                        /*first row*/
                                File f = new File(url);
                                Glide.with(context)
                                        .load(f)
                                        .into(imageView);
                                mFirstLayoutLL.addView(imageView, layoutParams);
                            } else if (index == 2) {
                        /*second row*/
                                File f = new File(url);
                                Glide.with(context)
                                        .load(f)
                                        .into(imageView);
                                mSecondLayoutLL.addView(imageView, layoutParams);
                            } else if (index == 3) {
                                File f = new File(url);
                                Glide.with(context)
                                        .load(f)
                                        .into(imageView);
                                mThridLayoutLL.addView(imageView, layoutRightParams);
                            }
                            index++;
                            if (index >= 4) {
                                break;
                            }
                        }
                        break;
                    case COLLAGE_5_1:
                        this.setOrientation(HORIZONTAL);
                        mFirstLayoutLL = new LinearLayout(context);
                        mSecondLayoutLL = new LinearLayout(context);
                        mThridLayoutLL = new LinearLayout(context);

                        mFirstLayoutLL.setBackgroundColor(Color.WHITE);
                        mSecondLayoutLL.setBackgroundColor(Color.WHITE);
                        mThridLayoutLL.setBackgroundColor(Color.WHITE);

                        this.addView(mFirstLayoutLL, layoutParams);
                        this.addView(mSecondLayoutLL, layoutRightParams);

                        mFirstLayoutLL.setOrientation(VERTICAL);
                        mSecondLayoutLL.setOrientation(VERTICAL);

                        index = 0;
                        for (String url : imageUrls) {
                            PhotoView imageView = new PhotoView(context);
                            imageView.setScaleType(PhotoView.ScaleType.CENTER_CROP);
                            if (index < 2) {
                        /*first row*/
                                File f = new File(url);
                                Glide.with(context)
                                        .load(f)
                                        .into(imageView);
                                mFirstLayoutLL.addView(imageView, layoutParams);
                            } else {
                        /*second row*/
                                File f = new File(url);
                                Glide.with(context)
                                        .load(f)
                                        .into(imageView);
                                mSecondLayoutLL.addView(imageView, layoutRightParams);
                            }
                            index++;
                            if (index >= 5) {
                                break;
                            }
                        }
                        break;
                    case COLLAGE_5_2:
                        this.setOrientation(HORIZONTAL);
                        mFirstLayoutLL = new LinearLayout(context);
                        mSecondLayoutLL = new LinearLayout(context);
                        mThridLayoutLL = new LinearLayout(context);

                        mFirstLayoutLL.setBackgroundColor(Color.WHITE);
                        mSecondLayoutLL.setBackgroundColor(Color.WHITE);
                        mThridLayoutLL.setBackgroundColor(Color.WHITE);

                        this.addView(mFirstLayoutLL, layoutParams);
                        this.addView(mSecondLayoutLL, layoutParams);
                        this.addView(mThridLayoutLL, layoutRightParams);

                        mFirstLayoutLL.setOrientation(VERTICAL);
                        mSecondLayoutLL.setOrientation(HORIZONTAL);
                        mThridLayoutLL.setOrientation(VERTICAL);
                        index = 0;
                        for (String url : imageUrls) {
                            PhotoView imageView = new PhotoView(context);
                            imageView.setScaleType(PhotoView.ScaleType.CENTER_CROP);
                            if (index < 2) {
                        /*first row*/
                                File f = new File(url);
                                Glide.with(context)
                                        .load(f)
                                        .into(imageView);
                                mFirstLayoutLL.addView(imageView, layoutParams);
                            } else if (index == 2) {
                        /*second row*/
                                File f = new File(url);
                                Glide.with(context)
                                        .load(f)
                                        .into(imageView);
                                mSecondLayoutLL.addView(imageView, layoutParams);
                            } else {
                                File f = new File(url);
                                Glide.with(context)
                                        .load(f)
                                        .into(imageView);
                                mThridLayoutLL.addView(imageView, layoutRightParams);
                            }
                            index++;
                            if (index >= 5) {
                                break;
                            }
                        }
                        break;
                    case COLLAGE_6_1:
                        this.setOrientation(VERTICAL);
                        mFirstLayoutLL = new LinearLayout(context);
                        mSecondLayoutLL = new LinearLayout(context);
                        mThridLayoutLL = new LinearLayout(context);

                        mFirstLayoutLL.setBackgroundColor(Color.WHITE);
                        mSecondLayoutLL.setBackgroundColor(Color.WHITE);
                        mThridLayoutLL.setBackgroundColor(Color.WHITE);

                        this.addView(mFirstLayoutLL, layoutRightMarginParams);
                        this.addView(mSecondLayoutLL, layoutRightMarginParams);
                        this.addView(mThridLayoutLL, layoutRightMarginParams);
                        mFirstLayoutLL.setOrientation(HORIZONTAL);
                        mSecondLayoutLL.setOrientation(HORIZONTAL);
                        mThridLayoutLL.setOrientation(HORIZONTAL);
                        index = 0;
                        for (String url : imageUrls) {
                            PhotoView imageView = new PhotoView(context);
                            imageView.setScaleType(PhotoView.ScaleType.CENTER_CROP);
                            if (index < 2) {
                        /*first row*/
                                File f = new File(url);
                                Glide.with(context)
                                        .load(f)
                                        .into(imageView);
                                mFirstLayoutLL.addView(imageView, layoutBottomParams);
                            } else if (index >= 2 && index < 4) {
                        /*second row*/
                                File f = new File(url);
                                Glide.with(context)
                                        .load(f)
                                        .into(imageView);
                                mSecondLayoutLL.addView(imageView, layoutBottomParams);
                            } else {
                                File f = new File(url);
                                Glide.with(context)
                                        .load(f)
                                        .into(imageView);
                                mThridLayoutLL.addView(imageView, layoutBottomParams);
                            }
                            index++;
                            if (index >= 6) {
                                break;
                            }
                        }
                        break;
                    case COLLAGE_6_2:
                        break;
                    case COLLAGE_7_1:

                        this.setOrientation(HORIZONTAL);
                        mFirstLayoutLL = new LinearLayout(context);
                        mSecondLayoutLL = new LinearLayout(context);
                        mThridLayoutLL = new LinearLayout(context);

                        mFirstLayoutLL.setBackgroundColor(Color.WHITE);
                        mSecondLayoutLL.setBackgroundColor(Color.WHITE);
                        mThridLayoutLL.setBackgroundColor(Color.WHITE);

                        this.addView(mFirstLayoutLL, layoutParams);
                        this.addView(mSecondLayoutLL, layoutParams);
                        this.addView(mThridLayoutLL, layoutRightParams);
                        mFirstLayoutLL.setOrientation(VERTICAL);
                        mSecondLayoutLL.setOrientation(HORIZONTAL);
                        mThridLayoutLL.setOrientation(VERTICAL);
                        index = 0;
                        for (String url : imageUrls) {
                            PhotoView imageView = new PhotoView(context);
                            imageView.setScaleType(PhotoView.ScaleType.CENTER_CROP);
                            if (index < 3) {
                        /*first row*/
                                File f = new File(url);
                                Glide.with(context)
                                        .load(f)
                                        .into(imageView);
                                mFirstLayoutLL.addView(imageView, layoutParams);
                            } else if (index == 3) {
                        /*second row*/
                                File f = new File(url);
                                Glide.with(context)
                                        .load(f)
                                        .into(imageView);
                                mSecondLayoutLL.addView(imageView, layoutParams);
                            } else {
                                File f = new File(url);
                                Glide.with(context)
                                        .load(f)
                                        .into(imageView);
                                mThridLayoutLL.addView(imageView, layoutRightParams);

                                LinearLayout.LayoutParams layoutParams =
                                        (LinearLayout.LayoutParams) mThridLayoutLL.getLayoutParams();
                                layoutParams.setMarginEnd(5);
                                mThridLayoutLL.setLayoutParams(layoutParams);
                            }
                            index++;
                            if (index >= 7) {
                                break;
                            }
                        }
                        break;
                    case COLLAGE_8_1:
                        this.setOrientation(HORIZONTAL);
                        mFirstLayoutLL = new LinearLayout(context);
                        mSecondLayoutLL = new LinearLayout(context);
                        mThridLayoutLL = new LinearLayout(context);

                        mFirstLayoutLL.setBackgroundColor(Color.WHITE);
                        mSecondLayoutLL.setBackgroundColor(Color.WHITE);
                        mThridLayoutLL.setBackgroundColor(Color.WHITE);

                        this.addView(mFirstLayoutLL, layoutParams);
                        this.addView(mSecondLayoutLL, layoutParams);
                        this.addView(mThridLayoutLL, layoutRightParams);

                        mFirstLayoutLL.setOrientation(VERTICAL);
                        mSecondLayoutLL.setOrientation(VERTICAL);
                        mThridLayoutLL.setOrientation(VERTICAL);
                        index = 0;
                        for (String url : imageUrls) {
                            PhotoView imageView = new PhotoView(context);
                            imageView.setScaleType(PhotoView.ScaleType.CENTER_CROP);
                            if (index < 3) {
                        /*first row*/
                                File f = new File(url);
                                Glide.with(context)
                                        .load(f)
                                        .into(imageView);
                                mFirstLayoutLL.addView(imageView, layoutParams);
                            } else if (index >= 3 && index < 5) {
                        /*second row*/
                                File f = new File(url);
                                Glide.with(context)
                                        .load(f)
                                        .into(imageView);
                                mSecondLayoutLL.addView(imageView, layoutParams);
                            } else {
                                File f = new File(url);
                                Glide.with(context)
                                        .load(f)
                                        .into(imageView);
                                mThridLayoutLL.addView(imageView, layoutRightParams);

                                LinearLayout.LayoutParams layoutParams =
                                        (LinearLayout.LayoutParams) mThridLayoutLL.getLayoutParams();
                                layoutParams.setMarginEnd(5);
                                mThridLayoutLL.setLayoutParams(layoutParams);
                            }
                            index++;
                            if (index >= 8) {
                                break;
                            }
                        }
                        break;
                    case COLLAGE_9_1:
                        this.setOrientation(VERTICAL);
                        mFirstLayoutLL = new LinearLayout(context);
                        mSecondLayoutLL = new LinearLayout(context);
                        mThridLayoutLL = new LinearLayout(context);

                        mFirstLayoutLL.setBackgroundColor(Color.WHITE);
                        mSecondLayoutLL.setBackgroundColor(Color.WHITE);
                        mThridLayoutLL.setBackgroundColor(Color.WHITE);

                        this.addView(mFirstLayoutLL, layoutRightMarginParams);

                        this.addView(mSecondLayoutLL, layoutRightMarginParams);
                        this.addView(mThridLayoutLL, layoutRightMarginParams);

                        mFirstLayoutLL.setOrientation(HORIZONTAL);
                        mSecondLayoutLL.setOrientation(HORIZONTAL);
                        mThridLayoutLL.setOrientation(HORIZONTAL);
                        index = 0;
                        for (String url : imageUrls) {
                            PhotoView imageView = new PhotoView(context);
                            imageView.setScaleType(PhotoView.ScaleType.CENTER_CROP);
                            if (index < 3) {
                        /*first row*/
                                File f = new File(url);
                                Glide.with(context)
                                        .load(f)
                                        .into(imageView);
                                mFirstLayoutLL.addView(imageView, layoutBottomParams);
                            } else if (index >= 3 && index <= 5) {
                        /*second row*/
                                File f = new File(url);
                                Glide.with(context)
                                        .load(f)
                                        .into(imageView);
                                mSecondLayoutLL.addView(imageView, layoutBottomParams);
                            } else {
                                File f = new File(url);
                                Glide.with(context)
                                        .load(f)
                                        .into(imageView);
                                mThridLayoutLL.addView(imageView, layoutBottomParams);

                            }
                            index++;
                            if (index >= 9) {
                                break;
                            }
                        }
                        break;
                    case COLLAGE_9_2:
                        break;
                    default:
                        Log.d(TAG, "setCollageOption: invalid values");
                        break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            Log.d(TAG, "setCollageOption: " + e.getMessage());
        }

    }


}
