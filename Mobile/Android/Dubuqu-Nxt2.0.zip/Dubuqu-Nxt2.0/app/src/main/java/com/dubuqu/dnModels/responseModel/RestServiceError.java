package com.dubuqu.dnModels.responseModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by Yogaraj subramanian on 24/10/17
 */

public class RestServiceError  {

    /*
    * "code": 1105,
		  "message": "Verfication code invalid",
    * */

    @SerializedName("message")
    @Expose
    String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
