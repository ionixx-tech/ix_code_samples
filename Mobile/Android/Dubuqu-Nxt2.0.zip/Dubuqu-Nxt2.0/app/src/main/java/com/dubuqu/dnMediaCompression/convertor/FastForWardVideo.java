package com.dubuqu.dnMediaCompression.convertor;

import android.content.Context;
import android.util.Log;

import com.dubuqu.dnApplication.AppController;
import com.github.hiteshsondhi88.libffmpeg.FFmpeg;
import com.github.hiteshsondhi88.libffmpeg.FFmpegExecuteResponseHandler;

import java.io.File;

/**
 * Created by Yogaraj subramanian on 17/11/17
 */

public class FastForWardVideo {

    private Context context;

    private OnFastForwardListenr onFastForwardListenr;

    private String originalFilePath;

    private FFmpeg ffmpeg;

    public FastForWardVideo(Context context, OnFastForwardListenr onFastForwardListenr, String originalFilePath) {
        this.context = context;
        this.onFastForwardListenr = onFastForwardListenr;
        this.originalFilePath = originalFilePath;

        try {
            initialzeFFmeg();
        } catch (Exception e) {
            Log.e(FastForWardVideo.class.getName(), e.getMessage());
        }
    }

    private void initialzeFFmeg() throws Exception {

        ffmpeg = AppController.getfFmpeg();

        try {
            convertVideo();
        } catch (Exception e) {
            onFastForwardListenr.onFastForwardFailed(e.getMessage());
        }

    }

    private void convertVideo() throws Exception {

        final String outputFile = context.getCacheDir() + "/" + String.valueOf(System.currentTimeMillis()) + ".mp4";

        /*-i input.mkv -filter:v "setpts=0.5*PTS"*/
        String[] complexCommand = {
                "-i", originalFilePath,
                "-vf", "fps=60,setpts=0.5*PTS",
                "-an",
                "-vcodec", "libx264",
                "-crf", "8",
                "-preset", "ultrafast",
                outputFile};

        ffmpeg.execute(complexCommand, new FFmpegExecuteResponseHandler() {
            @Override
            public void onSuccess(String message) {
                try {
                    onFastForwardListenr.onFastForwardCompleted(outputFile);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onProgress(String message) {
                Log.d(FastForWardVideo.class.getName(), message);
            }

            @Override
            public void onFailure(String message) {
                Log.d(FastForWardVideo.class.getName(), message);

            }

            @Override
            public void onStart() {
                Log.d(ReverseVideo.class.getName(), "Started.");
            }

            @Override
            public void onFinish() {
                Log.d(ReverseVideo.class.getName(), "Finished.");
            }
        });

    }

    private void deleteOriginalFile() {
        if (originalFilePath != null && !originalFilePath.equalsIgnoreCase(""))
            new File(originalFilePath).deleteOnExit();
    }

    public interface OnFastForwardListenr {
        void onFastForwardCompleted(String filePath);

        void onFastForwardFailed(String message);
    }
}
