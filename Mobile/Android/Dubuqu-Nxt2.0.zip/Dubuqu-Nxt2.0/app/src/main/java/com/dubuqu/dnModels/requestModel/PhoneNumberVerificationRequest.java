package com.dubuqu.dnModels.requestModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by Yogaraj subramanian on 24/10/17
 */

public class PhoneNumberVerificationRequest {

    /*"country_code":"91",
    "mobile_number":"9876543210",*/

    @SerializedName("country_code")
    @Expose
    String country_code;

    @SerializedName("mobile_number")
    @Expose
    String mobile_number;

    @SerializedName("verification_code")
    @Expose
    String verification_code;

    public String getCountry_code() {
        return country_code;
    }

    public void setCountry_code(String country_code) {
        this.country_code = country_code;
    }

    public String getMobile_number() {
        return mobile_number;
    }

    public void setMobile_number(String mobile_number) {
        this.mobile_number = mobile_number;
    }

    public String getVerification_code() {
        return verification_code;
    }

    public void setVerification_code(String verification_code) {
        this.verification_code = verification_code;
    }
}
