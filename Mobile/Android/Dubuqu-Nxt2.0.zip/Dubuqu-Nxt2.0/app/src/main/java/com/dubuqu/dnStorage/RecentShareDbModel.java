package com.dubuqu.dnStorage;

import com.dubuqu.dnConstants.Constants;
import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

/**
 * Created by Yogaraj subramanian on 19/6/17
 */

@DatabaseTable(tableName = Constants.RECENTSHARETABLE)
public class RecentShareDbModel {

    @DatabaseField(columnName = Constants.ID, generatedId = true)
    private int id;
    @DatabaseField(columnName = Constants.USER_IDENTIFIER)
    private
    String identifier;
    @DatabaseField(columnName = Constants.PROFILE_IMAGE)
    private
    String profilePic;
    @DatabaseField(columnName = Constants.DUBUQU_USER_NAME)
    private
    String userName;

    public RecentShareDbModel() {
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getIdentifier() {
        return identifier;
    }

    public void setIdentifier(String identifier) {
        this.identifier = identifier;
    }

    public String getProfilePic() {
        return profilePic;
    }

    public void setProfilePic(String profilePic) {
        this.profilePic = profilePic;
    }

}
