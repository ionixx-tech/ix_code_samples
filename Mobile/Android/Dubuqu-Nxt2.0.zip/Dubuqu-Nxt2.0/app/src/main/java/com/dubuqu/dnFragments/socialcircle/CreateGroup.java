package com.dubuqu.dnFragments.socialcircle;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.FileProvider;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.Switch;
import android.widget.TextView;

import com.airbnb.lottie.LottieAnimationView;
import com.bumptech.glide.Glide;
import com.dubuqu.R;
import com.dubuqu.dnActivity.LandingActivity;
import com.dubuqu.dnAdapter.group.UserSelectedAdapter;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnModels.commonModel.CreateGroupAddParticipantsModel;
import com.dubuqu.dnModels.commonModel.DubuqContactsShareModel;
import com.dubuqu.dnModels.commonModel.DubuqGroupDetails;
import com.dubuqu.dnModels.commonModel.ErrorBodyModel;
import com.dubuqu.dnModels.requestModel.CreateGroupRequest;
import com.dubuqu.dnModels.responseModel.CreateGroupResponse;
import com.dubuqu.dnModels.responseModel.SignedUrlResponseModel;
import com.dubuqu.dnModels.responseModel.UpdateGroupProfileRequest;
import com.dubuqu.dnReceiver.ContactLoadReceiver;
import com.dubuqu.dnRestServices.RestServiceController;
import com.dubuqu.dnRestServices.RestServiceProvider;
import com.dubuqu.dnServices.ContactService;
import com.dubuqu.dnUtils.RestServiceUtils;
import com.dubuqu.dnUtils.Utils;
import com.github.chrisbanes.photoview.PhotoView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;
import com.yalantis.ucrop.UCrop;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;
import retrofit2.Response;
import retrofit2.Retrofit;

import static android.app.Activity.RESULT_OK;
import static android.content.Context.LAYOUT_INFLATER_SERVICE;

/**
 * Created by Yogaraj subramanian on 7/11/17
 */

public class CreateGroup extends Fragment implements ContactLoadReceiver.addOnContactLoadListener {

    private final String TAG = CreateGroup.class.getName();

    CircleImageView userProfile;

    ImageView addUsers;

    TextView noOfUsersSelected;

    RecyclerView selectedUsers;

    EditText groupName;

    Switch privateGroupSwitch, saveAsAlbumSwich, allowReShareSwitch;

    private List<DubuqContactsShareModel> dubuqContactsSelected = new ArrayList<>();

    private Context context;

    private Activity activity;

    private Fragment parentFragment;

    private View parentView;

    private Uri profileUri = null, outputFileUri;

    private String deviceName, groupIdentifier = null;

    private ContactLoadReceiver contactLoadReceiver;

    private boolean isIneditMode = false, isProfileImageRemoved = false, isProfileImageChanged = false;



    //original data
    private CreateGroupAddParticipantsModel createGroupAddParticipantsModel;

    @Override
    public void onResume() {
        super.onResume();
        if (activity instanceof LandingActivity) {
            try {
                ((LandingActivity) activity).toggleBottomSheet(true);


                if (getView() != null) {
                    getView().setFocusableInTouchMode(true);
                    getView().requestFocus();
                    getView().setOnKeyListener(new View.OnKeyListener() {
                        @Override
                        public boolean onKey(View v, int keyCode, KeyEvent event) {
                            if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK) {
                                handleBackpress();
                                return true;
                            }
                            return false;
                        }
                    });
                }

            } catch (Exception e) {
                if (activity instanceof LandingActivity) {
                    ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                }
            }
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_creat_group, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        parentView = view;

        context = getContext();

        activity = getActivity();

        parentFragment = getParentFragment();
        try {
            initializeViews();
        } catch (Exception e) {
            if (activity instanceof LandingActivity) {
                ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
            }
        }

    }

    @Override
    public void
    onActivityResult(int requestCode, int resultCode, Intent result) {
        super.onActivityResult(requestCode, resultCode, result);
        if (resultCode == RESULT_OK) {
            try {
                switch (requestCode) {
                    case Constants.IMAGECPATURE_REQUEST:

                        final boolean isCamera;
                        if (result != null && result.hasExtra("remove_image")) {
                                /*remove image */
                            profileUri = null;
                            userProfile.setImageResource(R.drawable.ic_profile);
                            return;
                        } else if (result == null) {
                            isCamera = true;
                        } else {
                            final String action = result.getAction();
                            isCamera = action != null;
                        }

                        if (isCamera) {

                            if (result != null) {
                                profileUri = outputFileUri;
                            } else {
                                profileUri = outputFileUri;
                            }

                        } else {
                            profileUri = result.getData();
                        }

                        cropImage(profileUri);
                        profileUri = null;
                        break;

                    case UCrop.REQUEST_CROP:
                        if (UCrop.getOutput(result) != null)
                            profileUri = UCrop.getOutput(result);

                        Glide.with(context).load(profileUri).into(userProfile);

                        isProfileImageChanged = true;

                        break;

                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onContactsLoaded() {

        if (activity instanceof LandingActivity) {
            try {
                ((LandingActivity) activity).cancelPopUp();
                ((SocialCircleFragment) parentFragment).replaceFragments(new SocialCircleDashboard());

            } catch (Exception e) {
                ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
            }
        }

    }

    /**
     * Open Crop Activity which allows user to crop their images.
     *
     * @param cropImageUri {@link Uri} the pic user has picked
     * @throws Exception {Runtime Stub Exception}
     */
    private void cropImage(Uri cropImageUri) throws Exception {
        String destinationFileName = String.valueOf(System.currentTimeMillis());
        destinationFileName += ".png";

        UCrop uCrop = UCrop.of(cropImageUri
                , Uri.fromFile(new File(context.getCacheDir(), destinationFileName)));
        UCrop.Options options = new UCrop.Options();
        options.setCompressionFormat(Bitmap.CompressFormat.PNG);
        options.setCompressionQuality(100);
        options.setHideBottomControls(false);
        options.setFreeStyleCropEnabled(true);
        options.setStatusBarColor(getResources().getColor(R.color.colorPrimaryDark));
        options.setToolbarColor(getResources().getColor(R.color.colorPrimary));
        options.setActiveWidgetColor(getResources().getColor(R.color.colorPrimary));
        uCrop.withOptions(options);
        //uCrop = basisConfig(uCrop);
        //uCrop = advancedConfig(uCrop);
        uCrop.start(activity, this);

    }

    private void initializeViews() throws Exception {

        if (((SocialCircleFragment) parentFragment).currentSocialCircleAction != SocialCircleFragment.CurrentSocialCircleAction.EDITCIRCLE) {
            ((SocialCircleFragment) parentFragment).setCurrentSocialCircleAction(
                    SocialCircleFragment.CurrentSocialCircleAction.CREATECIRCLE);

            ((SocialCircleFragment) parentFragment).toggleToobarbasedOnOptions();
        } else {
            isIneditMode = true;
        }

        userProfile = parentView.findViewById(R.id.create_circle_profile_image);

        addUsers = parentView.findViewById(R.id.add_more_participants);

        selectedUsers = parentView.findViewById(R.id.user_selected_rcv);

        noOfUsersSelected = parentView.findViewById(R.id.header_view);

        privateGroupSwitch = parentView.findViewById(R.id.private_group_switch);

        saveAsAlbumSwich = parentView.findViewById(R.id.save_as_album_switch);

        allowReShareSwitch = parentView.findViewById(R.id.reshare_switch);

        groupName = parentView.findViewById(R.id.create_group_name_edt);

        String data = getArguments().getString(Constants.CREATECIRCLEMODELDATAS);

        if (data != null)
            updateValues(data);

        String userSelectedData = getArguments().getString(Constants.EXTRASTRINGS);

        dubuqContactsSelected = new Gson().fromJson(userSelectedData, new TypeToken<List<DubuqContactsShareModel>>() {
        }.getType());


        noOfUsersSelected.setText(String.valueOf(dubuqContactsSelected.size()).concat("\t" + getString(R.string.group_particitpants)));

        deviceName = android.os.Build.MANUFACTURER;

        contactLoadReceiver = new ContactLoadReceiver(new Handler(), this);

        inializeListeners();
    }

    private void inializeListeners() throws Exception {

        UserSelectedAdapter userSelectedAdapter = new UserSelectedAdapter(dubuqContactsSelected, context, new UserSelectedAdapter.UserSelectedListener() {
            @Override
            public void onUserSelected(DubuqContactsShareModel dubuqContactsShareModel) {
                if (dubuqContactsSelected.size() == 0) {
                    noOfUsersSelected.setText(R.string.add_participants_to_group);
                } else {
                    noOfUsersSelected.setText(String.valueOf(dubuqContactsSelected.size()).concat(getString(R.string.participants)));
                }
            }
        }, UserSelectedAdapter.ViewType.CREATECRIRCLE);

        selectedUsers.setLayoutManager(new GridLayoutManager(context, 4));
        selectedUsers.setAdapter(userSelectedAdapter);


        addUsers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                try {
                    addMoreParticiapants();
                } catch (Exception e) {
                    if (activity instanceof LandingActivity) {
                        ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                    }
                }
            }
        });

        userProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isIneditMode) {

                    if (isProfileImageChanged || !isProfileImageRemoved && profileUri != null) {
                        try {
                            openImageInFullView(getRealPathFromURI(profileUri));
                        } catch (Exception e) {
                            if (activity instanceof LandingActivity) {
                                ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                            }
                        }
                    } else {
                        if (createGroupAddParticipantsModel.getAmazonUrl() != null &&
                                !createGroupAddParticipantsModel.getAmazonUrl().equalsIgnoreCase("")) {
                            try {
                                openImageInFullView(createGroupAddParticipantsModel.getAmazonUrl());
                            } catch (Exception e) {
                                if (activity instanceof LandingActivity) {
                                    ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                                }
                            }
                        } else {
                            try {
                                openImageViewContent();
                            } catch (Exception e) {
                                if (activity instanceof LandingActivity) {
                                    ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                                }
                            }
                        }
                    }
                } else {
                    if (profileUri == null) {
                        try {
                            openImageViewContent();
                        } catch (Exception e) {
                            if (activity instanceof LandingActivity) {
                                ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                            }
                        }
                    } else {
                        try {
                            openImageInFullView(getRealPathFromURI(profileUri));
                        } catch (Exception e) {
                            if (activity instanceof LandingActivity) {
                                ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                            }
                        }
                    }
                }

            }
        });

        allowReShareSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (isChecked) {
                    if (privateGroupSwitch.isChecked()) {
                        allowReShareSwitch.setChecked(false);
                        Utils.showNegativeTost(context, getString(R.string.need_to_be_public_group));
                    } else {
                        Utils.showToast(context, getString(R.string.allow_reshare_enabled));
                    }
                }
            }
        });

        saveAsAlbumSwich.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (isChecked) {
                    if (privateGroupSwitch.isChecked()) {
                        saveAsAlbumSwich.setChecked(false);
                        Utils.showNegativeTost(context, getString(R.string.need_to_be_public_group));
                    } else {
                        Utils.showToast(context, getString(R.string.save_as_album_enabled));
                    }
                }
            }
        });

        privateGroupSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b) {
                    Utils.showToast(context, getString(R.string.enabled_private));
                    saveAsAlbumSwich.setChecked(false);
                    allowReShareSwitch.setChecked(false);
                }
            }
        });
    }

    /**
     * Allows user to add more participants to the group.
     *
     * @throws Exception {Runtime Stub Exception}
     */

    private void addMoreParticiapants() throws Exception {

        CreateGroupAddParticipantsModel model = new CreateGroupAddParticipantsModel();

        if (profileUri == null)
            model.setProfileUri(null);
        else
            model.setProfileUri(profileUri);

        model.setGroupName(groupName.getText().toString());

        model.setAllowRespost(allowReShareSwitch.isChecked());

        model.setPrivateGroup(privateGroupSwitch.isChecked());

        model.setSaveasAlbum(saveAsAlbumSwich.isChecked());

        if (groupIdentifier != null)
            model.setGroupIdentifier(groupIdentifier);

        String data = new Gson().toJson(model);

        Bundle bundle = new Bundle();
        bundle.putString(Constants.CREATECIRCLEMODELDATAS, data);
        bundle.putString(Constants.EXTRASTRINGS, new Gson().toJson(dubuqContactsSelected));

        CreateCircleParticipantSelection createCircleParticipantSelection = new CreateCircleParticipantSelection();
        createCircleParticipantSelection.setArguments(bundle);

        ((SocialCircleFragment) parentFragment).replaceFragments(createCircleParticipantSelection);

    }

    /**
     * On user pressed back button two actions need to be done
     * <p>
     * if user came navigated from {@link CreateCircleParticipantSelection} the fragment must be
     * pop backed to {@link CreateCircleParticipantSelection} with user selected in it.
     * </p>
     * <p>
     * if user naigated from {@link SocialCircleDashboard} i.e the user need to edit the group
     * on back press user need to be backstacked with no extras to   {@link SocialCircleDashboard}
     * </p>
     */
    protected void handleBackpress() {

        if (((SocialCircleFragment) parentFragment).currentSocialCircleAction ==
                SocialCircleFragment.CurrentSocialCircleAction.CREATECIRCLE) {

            try {
                addMoreParticiapants();
            } catch (Exception e) {
                if (activity instanceof LandingActivity) {
                    ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                }
            }
        }

        if (((SocialCircleFragment) parentFragment).currentSocialCircleAction ==
                SocialCircleFragment.CurrentSocialCircleAction.EDITCIRCLE) {
            try {
                ((SocialCircleFragment) parentFragment).replaceFragments(new SocialCircleDashboard());
            } catch (Exception e) {
                if (activity instanceof LandingActivity) {
                    ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                }
            }
        }
    }

    /**
     * if user added participants form create user the values that are saved need to be
     * populated.
     *
     * @throws Exception{runtime stub exception}
     */
    private void updateValues(String createGroupData) throws Exception {

        createGroupAddParticipantsModel =
                new Gson().fromJson(createGroupData, new TypeToken<CreateGroupAddParticipantsModel>() {
                }.getType());

        if (createGroupAddParticipantsModel.getProfileUri() != null) {
            Glide.with(context)
                    .load(createGroupAddParticipantsModel.getProfileUri())
                    .into(userProfile);
        }

        if (createGroupAddParticipantsModel.getAmazonUrl() != null &&
                !createGroupAddParticipantsModel.getAmazonUrl().equalsIgnoreCase("")) {

            Glide.with(context)
                    .load(createGroupAddParticipantsModel.getAmazonUrl())
                    .into(userProfile);
        }

        if (createGroupAddParticipantsModel.getGroupName() != null
                && !createGroupAddParticipantsModel.getGroupName().equalsIgnoreCase("")) {
            groupName.setText(createGroupAddParticipantsModel.getGroupName());
        }


        allowReShareSwitch.setChecked(createGroupAddParticipantsModel.isAllowRespost());

        privateGroupSwitch.setChecked(createGroupAddParticipantsModel.isPrivateGroup());

        saveAsAlbumSwich.setChecked(createGroupAddParticipantsModel.isSaveasAlbum());

        if (createGroupAddParticipantsModel.getGroupIdentifier() != null)
            groupIdentifier = createGroupAddParticipantsModel.getGroupIdentifier();

    }


    /**
     * Add Image Media Intents
     *
     * @throws Exception {Run time stub Exception.}
     */
    private void openImageViewContent() throws Exception {
        // Determine Uri of camera image to save.
        final File root = new File(Utils.getRootFolderForProfilePicture(context));
        root.mkdirs();
        final String fname = Utils.getAppName(context) + "_" + System.currentTimeMillis() + "."
                + Utils.getAppName(context);
        final File sdImageMainDirectory = new File(root.getPath(), fname);
        outputFileUri = Uri.fromFile(sdImageMainDirectory);

        Intent chooserIntent = null;

        List<Intent> intentList = new ArrayList<>();
        Intent pickIntent = new Intent(Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        pickIntent.setType("image/*");

        Intent takePhotoIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (!deviceName.contains("samsung")) {
            Uri photoURI = FileProvider.getUriForFile(context,
                    com.dubuqu.BuildConfig.APPLICATION_ID + ".provider",
                    sdImageMainDirectory);
            takePhotoIntent.putExtra("return-data", true);
            takePhotoIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
        }
        intentList = addIntentsToList(context, intentList, pickIntent);
        intentList = addIntentsToList(context, intentList, takePhotoIntent);

        if (intentList.size() > 0) {
            for (int i = 0; i < intentList.size(); i++) {
            }
            chooserIntent = Intent.createChooser(intentList.remove(intentList.size() - 1),
                    ("Pick image From"));
            chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, intentList.toArray(new Parcelable[]{}));
        }

        startActivityForResult(chooserIntent, Constants.IMAGECPATURE_REQUEST);

    }

    /**
     * add avialable camera nad gallery apps that can provide images
     *
     * @param context {Context of the Activity}
     * @param list    {package name list}
     * @param intent  {intnet to trigger}
     * @return {List}
     */
    private static List<Intent> addIntentsToList(Context context, List<Intent> list, Intent intent) {
        List<ResolveInfo> resInfo = context.getPackageManager().queryIntentActivities(intent, 0);
        for (ResolveInfo resolveInfo : resInfo) {
            String packageName = resolveInfo.activityInfo.packageName;
            Intent targetedIntent = new Intent(intent);
            targetedIntent.setPackage(packageName);
            list.add(targetedIntent);
        }
        return list;
    }


    protected void saveAndExit() throws Exception {

        Utils.hideSoftKeyBoard(activity);

        if (validateValues()) {
            //creat group api

            String groupname = groupName.getText().toString().trim();

            String groupType = privateGroupSwitch.isChecked() ? "closed" : "open";

            String memoryRetain = String.valueOf(saveAsAlbumSwich.isChecked());

            String allowReshare = String.valueOf(allowReShareSwitch.isChecked());

            final CreateGroupRequest createGroupRequest = new CreateGroupRequest(groupname,
                    groupType, memoryRetain, getMembers(), allowReshare);

            String data = new Gson().toJson(createGroupRequest);
            OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, getContext());
            Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
            RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
            RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);


            if (isIneditMode) {

                if (checkIfFeildIsUpdated()) {
                    ((LandingActivity) activity).showLoaders(activity);

                    mRetrofitCallBacks.updateGroup(groupIdentifier, createGroupRequest,
                            new RestServiceController.ResponseCallBacks() {
                                @Override
                                public void onResponse(Object o) {
                                    CreateGroupResponse createGroupResponse = new CreateGroupResponse();
                                    createGroupResponse.setGroupIdentifier(groupIdentifier);
                                    //profile image has been changed
                                    if (isProfileImageChanged && profileUri != null) {
                                        try {

                                            getSignedUrlfromServer(getRealPathFromURI(profileUri), createGroupResponse);
                                        } catch (Exception e) {
                                            ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                                        }
                                    } else {
                                        if (isProfileImageRemoved) {
                                            try {
                                                updateProfilePicture(null, "", createGroupResponse);
                                            } catch (Exception e) {
                                                if (activity instanceof LandingActivity) {
                                                    ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                                                }
                                            }
                                        }

                                        Intent startPhoneService = new Intent(getContext(), ContactService.class);
                                        startPhoneService.putExtra(Constants.EXTRASTRINGS, contactLoadReceiver);

                                        getContext().startService(startPhoneService);
                                    }

                                }

                                @Override
                                public void onFailure(Object o) {
                                    showCreateGroupFail(o);
                                }
                            });
                } else {
                    ((LandingActivity) activity).showToastMessage("Please Update any feilds to edit group", false);
                }


            } else {
                ((LandingActivity) activity).showLoaders(activity);
                mRetrofitCallBacks.createsocialGroup(createGroupRequest, new RestServiceController.ResponseCallBacks() {
                    @Override
                    public void onResponse(Object o) {

                        if (activity instanceof LandingActivity) {
                            try {
                                CreateGroupResponse createGroupResponse = (CreateGroupResponse) o;
                                if (profileUri != null && !profileUri.getPath().equalsIgnoreCase("")) {
                                    try {
                                        getSignedUrlfromServer(getRealPathFromURI(profileUri), createGroupResponse);
                                    } catch (Exception e) {
                                        ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                                    }
                                } else {
                                    Intent startPhoneService = new Intent(getContext(), ContactService.class);
                                    startPhoneService.putExtra(Constants.EXTRASTRINGS, contactLoadReceiver);

                                    getContext().startService(startPhoneService);
                                }

                            } catch (Exception e) {
                                ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                            }
                        }
                    }

                    @Override
                    public void onFailure(Object o) {
                        showCreateGroupFail(o);
                    }
                });
            }

        }
    }

    /**
     * get real path from URI
     *
     * @param uri {@link Uri}
     * @return String value of the uri
     */
    public String getRealPathFromURI(Uri uri) {
        if (uri == null) {
            return null;
        }
        String[] projection = {MediaStore.Images.Media.DATA};
        Cursor cursor = getActivity().getContentResolver().query(uri, projection, null, null, null);
        if (cursor != null) {
            int column_index = cursor
                    .getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            cursor.moveToFirst();
            return cursor.getString(column_index);
        }
        return uri.getPath();
    }


    /**
     * Validate whether the value entered are correct.
     *
     * @return {@link Boolean} true or false
     * @throws Exception {Runtime Stub Exception}
     */
    private boolean validateValues() throws Exception {

        if (groupName.getText().toString().length() == 0 ||
                groupName.getText().toString().equalsIgnoreCase("")
                || !Utils.isValidusername(groupName.getText().toString(), 50)) {

            Utils.showNegativeTost(context, "Invalide Group Name");
            return false;
        }

        if (dubuqContactsSelected != null && dubuqContactsSelected.size() == 0) {
            Utils.showNegativeTost(context, (getString(R.string.add_participants_to_group)));
            return false;
        }

        return true;
    }


    private boolean checkIfFeildIsUpdated() throws Exception {

        if (!groupName.getText().toString().trim().equalsIgnoreCase(
                createGroupAddParticipantsModel.getGroupName().trim())) {

            return true;
        }

        if (dubuqContactsSelected != null && checkisMemberUpdated()) {
            return true;
        }

        if (privateGroupSwitch.isChecked() != createGroupAddParticipantsModel.isPrivateGroup())
            return true;

        if (allowReShareSwitch.isChecked() != createGroupAddParticipantsModel.isAllowRespost())
            return true;

        if (saveAsAlbumSwich.isChecked() != createGroupAddParticipantsModel.isAllowRespost())
            return true;

        return isProfileImageRemoved || isProfileImageChanged;
    }

    private List<String> getMembers() {
        List<String> members = new ArrayList<>();

        for (DubuqContactsShareModel createModel : dubuqContactsSelected) {
            members.add(createModel.getModileNumber());
        }
        return members;
    }


    /**
     * get signedurl and other datas from dubuqu server to upload the profile image
     *
     * @param filepath            the file that need to be uploaded
     * @param createGroupResponse {@link CreateGroupResponse} contains the group identifier against which
     *                            the image need to be added.
     * @throws Exception {Runtime stub excepton}
     */
    private void getSignedUrlfromServer(final String filepath, final CreateGroupResponse createGroupResponse) throws Exception {

        String[] resolution = Utils.getResolution(filepath);
        String width = "320";
        String height = "640";
        if (resolution.length == 2) {
            width = resolution[1];
            height = resolution[0];
        }

        String data = "{}";
        OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, context);
        Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
        RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
        RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
        mRetrofitCallBacks.getSignedUrl(
                new RestServiceController.ResponseCallBacks() {
                    @Override
                    public void onResponse(Object o) {
                        SignedUrlResponseModel response = (SignedUrlResponseModel) o;

                        try {
                            updateProfilePicture(response, filepath, createGroupResponse);
                        } catch (Exception e) {
                            if (activity instanceof LandingActivity) {
                                ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                            }
                        }
                    }

                    @Override
                    public void onFailure(Object o) {
                    }
                }, "profile_image", Utils.getContentType(filepath),
                Utils.getFileExtension(filepath), width, height);


    }

    private void updateProfilePicture(SignedUrlResponseModel response, final String filepath,
                                      final CreateGroupResponse createGroupResponse) throws Exception {
        Gson gson = new Gson();

        UpdateGroupProfileRequest updateGroupProfileRequest = new UpdateGroupProfileRequest();

        if (!isProfileImageRemoved)
            updateGroupProfileRequest.setProfileImageIdentifier(response.getMediaIdentifier());
        else
            updateGroupProfileRequest.setProfileImageIdentifier("");

        String data = gson.toJson(updateGroupProfileRequest);
        OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, context);
        Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
        RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
        RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
        mRetrofitCallBacks.uploadProfileImageToDubuquServer(updateGroupProfileRequest,
                createGroupResponse.getGroupIdentifier());

        Intent startPhoneService = new Intent(getContext(), ContactService.class);
        startPhoneService.putExtra(Constants.EXTRASTRINGS, contactLoadReceiver);

        getContext().startService(startPhoneService);
        /*upload image to server*/
        if (!isProfileImageRemoved)
            uploadMediaToAmazonS3(response, filepath);
    }

    private void uploadMediaToAmazonS3(SignedUrlResponseModel response, String filePath) {
        Gson gson = new Gson();
        String json = gson.toJson(response);
        try {
            RestServiceUtils.fileUploadService(context, 130, json, filePath);
        } catch (Exception e) {
            if (activity instanceof LandingActivity) {
                ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
            }
        }
    }

    /**
     * Show group Image in full view.
     *
     * @throws Exception {Runtime Stub Exception}
     */
    private void openImageInFullView(final String amazonUrl) throws Exception {

        ImageView back, editImage, delteImage;

        final PhotoView photoView;

        final LottieAnimationView animationView;

        LayoutInflater inflater = (LayoutInflater)
                context.getSystemService(LAYOUT_INFLATER_SERVICE);

        View inflate = inflater.inflate(R.layout.layout_camera_show_media_in_full_view, null);

        final PopupWindow popupWindow = new PopupWindow(context);

        photoView = inflate.findViewById(R.id.profile_photoview);

        animationView = inflate.findViewById(R.id.lottie_view);


        editImage = inflate.findViewById(R.id.popup_edit_image);
        editImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    openImageViewContent();
                    popupWindow.dismiss();
                } catch (Exception e) {
                    if (activity instanceof LandingActivity) {
                        ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                    }
                }
            }
        });

        delteImage = inflate.findViewById(R.id.popup_delte_image);
        delteImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                isProfileImageRemoved = true;
                userProfile.setImageResource(R.drawable.ic_profile);
                profileUri = null;
                popupWindow.dismiss();
            }
        });


        if (amazonUrl.contains("storage") || amazonUrl.contains("0") || amazonUrl.contains("cache")) {
            animationView.cancelAnimation();
            animationView.setVisibility(View.GONE);
            Glide.with(activity).load(new File(amazonUrl)).into(photoView);
        } else {
            ImageLoader.getInstance().displayImage(amazonUrl, photoView, new ImageLoadingListener() {
                @Override
                public void onLoadingStarted(String imageUri, View view) {

                }

                @Override
                public void onLoadingFailed(String imageUri, View view, FailReason failReason) {

                }

                @Override
                public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                    animationView.cancelAnimation();
                    animationView.setVisibility(View.GONE);
                    photoView.setImageBitmap(loadedImage);
                }

                @Override
                public void onLoadingCancelled(String imageUri, View view) {

                }
            });
        }


        inflate.setFocusableInTouchMode(true);
        inflate.requestFocus();
        inflate.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK) {
                    popupWindow.dismiss();
                    return true;
                }
                return false;
            }
        });


        popupWindow.setContentView(inflate);
        popupWindow.setWidth(LinearLayout.LayoutParams.MATCH_PARENT);
        popupWindow.setHeight(LinearLayout.LayoutParams.MATCH_PARENT);
        popupWindow.setFocusable(true);
        popupWindow.setBackgroundDrawable(null);
        popupWindow.showAtLocation(inflate, Gravity.CENTER, 0, 0);
    }

    /**
     * Show Error message if create group failed.
     *
     * @param o {Generic Object}
     */

    private void showCreateGroupFail(Object o) {
        if (o != null) {
            if (activity instanceof LandingActivity) {
                try {
                    ((LandingActivity) activity).cancelPopUp();

                    if (o instanceof retrofit2.Response) {
                        ResponseBody responseBody = ((Response) o).errorBody();
                        if (responseBody != null) {
                            String value = responseBody.string();
                            ErrorBodyModel errorBodyModel = new Gson().fromJson(value, ErrorBodyModel.class);
                            if (errorBodyModel != null)
                                ((LandingActivity) activity).showToastMessage(errorBodyModel.getMessage(), false);
                        }
                    } else if (o instanceof Throwable) {
                        ((LandingActivity) activity).showToastMessage(context.getString(R.string.sp_no_internet_connection), false);
                    }

                } catch (Exception e) {
                    if (activity instanceof LandingActivity) {
                        ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                    }
                }
            }

        }
    }

    private boolean checkisMemberUpdated() throws Exception {
        File file = new File(getContext().getCacheDir(), Constants.JSONGROUPFILENAME);
        if (file.exists()) {
            FileInputStream fis = new FileInputStream(file);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader bufferedReader = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                sb.append(line);
            }
            Gson gson = new Gson();

            List<DubuqGroupDetails> dubuqGroupDetailses = gson.fromJson(sb.toString(),
                    new TypeToken<List<DubuqGroupDetails>>() {
                    }.getType());

            for (DubuqGroupDetails groupDetails : dubuqGroupDetailses) {
                if (groupDetails.getDubuquGetGroupResponse().getGroupIdentifier().equalsIgnoreCase(
                        groupIdentifier)) {
                    return dubuqContactsSelected.size() != groupDetails.getDubuquUserResponseModels().size();
                }
            }
        }

        return false;
    }

}

