package com.dubuqu.dnModels.responseModel;

/**
 * Created by Yogaraj subramanian on 11/1/18
 */


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;


public class GetTimeLineStory {

    @SerializedName("timeline_identifier")
    @Expose
    private String timelineIdentifier;

    @SerializedName("members_list")
    @Expose
    private List<MembersList> membersList = null;

    @SerializedName("like_count")
    @Expose
    private String likeCount;

    @SerializedName("comment_count")
    @Expose
    private String commentCount;

    @SerializedName("created_time")
    @Expose
    private String createdTime;

    @SerializedName("shared_medias_count")
    @Expose
    private Integer sharedMediasCount;

    @SerializedName("shared_medias")
    @Expose
    private List<SharedMedias> sharedMedias = null;

    public String getTimelineIdentifier() {
        return timelineIdentifier;
    }

    public void setTimelineIdentifier(String timelineIdentifier) {
        this.timelineIdentifier = timelineIdentifier;
    }

    public List<MembersList> getMembersList() {
        return membersList;
    }

    public void setMembersList(List<MembersList> membersList) {
        this.membersList = membersList;
    }

    public String getLikeCount() {
        return likeCount;
    }

    public void setLikeCount(String likeCount) {
        this.likeCount = likeCount;
    }

    public String getCommentCount() {
        return commentCount;
    }

    public void setCommentCount(String commentCount) {
        this.commentCount = commentCount;
    }

    public String getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(String createdTime) {
        this.createdTime = createdTime;
    }

    public Integer getSharedMediasCount() {
        return sharedMediasCount;
    }

    public void setSharedMediasCount(Integer sharedMediasCount) {
        this.sharedMediasCount = sharedMediasCount;
    }

    public List<SharedMedias> getSharedMedias() {
        return sharedMedias;
    }

    public void setSharedMedias(List<SharedMedias> sharedMedias) {
        this.sharedMedias = sharedMedias;
    }

    public class MembersList {

        @SerializedName("identifier")
        @Expose
        private String identifier;

        @SerializedName("name")
        @Expose
        private String name;

        @SerializedName("type")
        @Expose
        private String type;

        @SerializedName("profile_image")
        @Expose
        private String profileImage;

        public String getIdentifier() {
            return identifier;
        }

        public void setIdentifier(String identifier) {
            this.identifier = identifier;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getProfileImage() {
            return profileImage;
        }

        public void setProfileImage(String profileImage) {
            this.profileImage = profileImage;
        }

    }
}







