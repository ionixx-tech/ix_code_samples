package com.dubuqu.dnModels.requestModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by Yogaraj subramanian on 5/1/18
 */

public class Captions{

    @SerializedName("caption")
    @Expose
    String captions;

    public Captions(String captions) {
        this.captions = captions;
    }
}
