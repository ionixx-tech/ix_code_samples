package com.dubuqu.dnActivity.mediapreview;

import android.animation.Animator;
import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.dubuqu.R;
import com.dubuqu.dnActivity.BaseActivity;
import com.dubuqu.dnActivity.MultipleShareActivity;
import com.dubuqu.dnAdapter.common.ColorPickerAdapter;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnMediaCompression.convertor.AddOverLayToVideo;
import com.dubuqu.dnPhotoEditor.BrushDrawingView;
import com.dubuqu.dnPhotoEditor.OnPhotoEditorSDKListener;
import com.dubuqu.dnPhotoEditor.PhotoEditorSDK;
import com.dubuqu.dnPhotoEditor.ViewType;
import com.dubuqu.dnStorage.DbHelper;
import com.dubuqu.dnStorage.RecentShareDbModel;
import com.dubuqu.dnUtils.RestServiceUtils;
import com.dubuqu.dnUtils.Utils;
import com.google.android.exoplayer2.ExoPlaybackException;
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.PlaybackParameters;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.Timeline;
import com.google.android.exoplayer2.extractor.DefaultExtractorsFactory;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.TrackGroupArray;
import com.google.android.exoplayer2.trackselection.AdaptiveTrackSelection;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelection;
import com.google.android.exoplayer2.trackselection.TrackSelectionArray;
import com.google.android.exoplayer2.trackselection.TrackSelector;
import com.google.android.exoplayer2.ui.SimpleExoPlayerView;
import com.google.android.exoplayer2.upstream.BandwidthMeter;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DataSpec;
import com.google.android.exoplayer2.upstream.DefaultBandwidthMeter;
import com.google.android.exoplayer2.upstream.FileDataSource;
import com.google.gson.Gson;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import vc908.stickerfactory.ui.OnStickerSelectedListener;
import vc908.stickerfactory.ui.fragment.StickersFragment;

import static android.view.View.GONE;

/**
 * Created by Yogaraj subramanian on 20/11/17
 */
@SuppressLint("ClickableViewAccessibility")
public class MediaShareFromCameraActivity extends BaseActivity implements
        OnStickerSelectedListener, OnPhotoEditorSDKListener {

    private final String TAG = MediaShareFromCameraActivity.class.getName();

    private SimpleExoPlayerView exoPlayerView;

    private RelativeLayout overlayViewRL, deleteRL;

    private LinearLayout showMoreContacts;

    private ImageView quickShareuserOneImv, quickShareuserTwoImv, saveMedia,
            quickShareuserThreeImv, emojiImageView, drawOverImageView, addTextImageView;

    private ImageView photoView;

    private String filePath;

    private TextView quickShareUserOneTv, quickShareUserTwoTv, quickShareUserThreeTv, doneTv, cancelTv;

    public BrushDrawingView brushDrawingView;

    private PhotoEditorSDK photoEditorSDK;

    private View quickShareView, editView, rootView, drawView, collorPallete;

    private SimpleExoPlayer player;

    private FrameLayout frameLayout;

    private int colorCodeValue = -1;

    private boolean isVideo = false, isMediaEdited = false, isMediaSaving = false;

    private ArrayList<Integer> colorPickerColors = new ArrayList<>();

    PopupWindow pop;

    int filterCurrentPostion = 0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_media_share_from_camera);
        try {
            initializeViews();
            addColorValues();

        } catch (Exception e) {
            writeCreashRepost(e.getMessage());
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Constants.RESTRICT_SREENSHOT)
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        if (isVideo) {
            try {
                player.setPlayWhenReady(true);
            } catch (Exception e) {
                writeCreashRepost(e.getMessage());
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        releasePlayer();
    }

    @Override
    protected void onPause() {
        super.onPause();

        if (player != null)
            player.setPlayWhenReady(false);
    }

    @Override
    public void onBackPressed() {
        if (frameLayout.getVisibility() == View.VISIBLE) {
            try {
                closeEmojiList();
            } catch (Exception e) {
                MediaShareFromCameraActivity.super.writeCrashReport(TAG, e.getMessage());
            }
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public void onStickerSelected(String s) {
        photoEditorSDK.addImage(s);
        try {
            closeEmojiList();
        } catch (Exception e) {
            writeCreashRepost(e.getMessage());
        }
    }

    @Override
    public void onEmojiSelected(String s) {
        photoEditorSDK.addEmoji(s);
        try {
            closeEmojiList();
        } catch (Exception e) {
            writeCreashRepost(e.getMessage());
        }
    }

    @Override
    public void onEditTextChangeListener(String text, int colorCode) {
        colorCodeValue = colorCode;
        openAddTextPopupWindow(text);
    }

    @Override
    public void onAddViewListener(ViewType viewType, int numberOfAddedViews) {

    }

    @Override
    public void onRemoveViewListener(int numberOfAddedViews) {

    }

    @Override
    public void onStartViewChangeListener(ViewType viewType) {

    }

    @Override
    public void onStopViewChangeListener(ViewType viewType) {

    }

    private void addColorValues() throws Exception {
        colorPickerColors.add(getResources().getColor(R.color.black));
        colorPickerColors.add(getResources().getColor(R.color.blue_color_picker));
        colorPickerColors.add(getResources().getColor(R.color.brown_color_picker));
        colorPickerColors.add(getResources().getColor(R.color.green_color_picker));
        colorPickerColors.add(getResources().getColor(R.color.orange_color_picker));
        colorPickerColors.add(getResources().getColor(R.color.red_color_picker));
        colorPickerColors.add(getResources().getColor(R.color.red_orange_color_picker));
        colorPickerColors.add(getResources().getColor(R.color.sky_blue_color_picker));
        colorPickerColors.add(getResources().getColor(R.color.violet_color_picker));
        colorPickerColors.add(getResources().getColor(R.color.white));
        colorPickerColors.add(getResources().getColor(R.color.yellow_color_picker));
        colorPickerColors.add(getResources().getColor(R.color.yellow_green_color_picker));
    }

    private void releasePlayer() {
        if (player != null) {
            player.release();
            player = null;
        }
    }

    private void initializeViews() throws Exception {

        filePath = getIntent().getStringExtra(Constants.IMAGEURI);

        if (filePath != null && !filePath.equalsIgnoreCase("")) {

            overlayViewRL = findViewById(R.id.dubuqu_media_from_camera_parent_view);

            overlayViewRL.setDrawingCacheEnabled(true);

            photoView = findViewById(R.id.dubuqu_media_from_camera_editimageview);

            collorPallete = findViewById(R.id.color_pallete);
            collorPallete.setVisibility(GONE);

            brushDrawingView = findViewById(R.id.dubuqu_media_from_camera_drawing_view);

            deleteRL = findViewById(R.id.dubuqu_media_from_camera_delete_rl);

            quickShareuserOneImv = findViewById(R.id.rcntprofileone);

            quickShareUserOneTv = findViewById(R.id.rcntusernameone);

            quickShareuserTwoImv = findViewById(R.id.rcntuserprofiletwo);

            quickShareUserTwoTv = findViewById(R.id.rcntusernametwo);

            quickShareuserThreeImv = findViewById(R.id.rcntuserProfilethree);

            quickShareUserThreeTv = findViewById(R.id.rcntusernamethree);

            addTextImageView = findViewById(R.id.dubuqu_media_viewer_add_text);

            drawOverImageView = findViewById(R.id.dubuqu_media_viewer_draw);

            emojiImageView = findViewById(R.id.dubuqu_media_viewer_smiley);

            exoPlayerView = findViewById(R.id.dubuqu_media_from_camera_video_view);

            rootView = findViewById(R.id.root_view);

            BandwidthMeter bandwidthMeter = new DefaultBandwidthMeter();
            TrackSelection.Factory videoTrackSelectionFactory =
                    new AdaptiveTrackSelection.Factory(bandwidthMeter);
            TrackSelector trackSelector =
                    new DefaultTrackSelector(videoTrackSelectionFactory);

            player = ExoPlayerFactory.newSimpleInstance(this, trackSelector);

            saveMedia = findViewById(R.id.dubuqu_media_viewer_save_image);

            frameLayout = findViewById(R.id.stickers_frame);

            editView = findViewById(R.id.media_edit_options);

            quickShareView = findViewById(R.id.quick_share_frequent_users_ll);

            drawView = findViewById(R.id.draw_view_options);

            cancelTv = findViewById(R.id.dubuqu_media_viewer_cancel);

            doneTv = findViewById(R.id.dubuqu_media_viewer_done);

            showMoreContacts = findViewById(R.id.showMoreContacts);

            toogleDrawView(true);

            initailizeListenrs();

            updateUserForQuickShare();

            initalizeStickerPanel();

            intializeColorPallete();

        } else {
            throw new Exception("File Path must not be null OR empty");
        }
    }


    private void toogleDrawView(boolean toHideDrawView) {
        if (toHideDrawView) {
            editView.setVisibility(View.VISIBLE);
            drawView.setVisibility(View.GONE);
            quickShareView.setVisibility(View.VISIBLE);
            collorPallete.setVisibility(GONE);
        } else {
            editView.setVisibility(View.GONE);
            drawView.setVisibility(View.VISIBLE);
            quickShareView.setVisibility(View.GONE);
            collorPallete.setVisibility(View.VISIBLE);
        }
    }

    private void initailizeListenrs() throws Exception {

        photoEditorSDK = new PhotoEditorSDK.PhotoEditorSDKBuilder(MediaShareFromCameraActivity.this)
                .parentView(this.overlayViewRL)
                .deleteView(this.deleteRL)
                .brushDrawingView(brushDrawingView)
                .childView(photoView)
                .buildPhotoEditorSDK();

        if (Utils.getMimeType(filePath).contains("video") || Utils.getMimeType(filePath).contains("mp4")
                || Utils.getMimeType(filePath).contains("3gp")) {

            exoPlayerView.setVisibility(View.VISIBLE);
            saveMedia.setVisibility(View.VISIBLE);
            photoView.setVisibility(View.VISIBLE);
            photoView.setImageDrawable(getResources().getDrawable(R.drawable.tranperant_bitmap));
            isVideo = true;
            playVideo();
        } else {
            isVideo = false;
            Glide.with(MediaShareFromCameraActivity.this).load(filePath).into(photoView);
            saveMedia.setVisibility(View.VISIBLE);
            exoPlayerView.setVisibility(View.GONE);
            photoView.setVisibility(View.VISIBLE);
        }


        photoEditorSDK.setOnPhotoEditorSDKListener(this);

        quickShareuserOneImv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    shareMediaToFregquentUsers(0);
                } catch (Exception e) {
                    MediaShareFromCameraActivity.super.writeCrashReport(TAG, e.getMessage());
                }
            }
        });

        quickShareuserTwoImv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    shareMediaToFregquentUsers(1);
                } catch (Exception e) {
                    MediaShareFromCameraActivity.super.writeCrashReport(TAG, e.getMessage());
                }
            }
        });

        quickShareuserThreeImv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    shareMediaToFregquentUsers(2);
                } catch (Exception e) {
                    MediaShareFromCameraActivity.super.writeCrashReport(TAG, e.getMessage());
                }
            }
        });

        showMoreContacts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    toogleEditAndQucikShareView(true);
                    shareMediaWithOutSaving(new ArrayList<String>(), true);
                } catch (Exception e) {
                    writeCreashRepost(e.getMessage());
                }
            }
        });


        emojiImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    showEmojiList();
                    toogleDrawView(true);
                    photoEditorSDK.setBrushDrawingMode(false);
                } catch (Exception e) {
                    MediaShareFromCameraActivity.super.writeCrashReport(TAG, e.getMessage());
                }
            }
        });

        addTextImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openAddTextPopupWindow("");
                toogleDrawView(true);
                photoEditorSDK.setBrushDrawingMode(false);
            }
        });

        drawOverImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toogleDrawView(false);
                photoEditorSDK.setBrushDrawingMode(true);
                isMediaEdited = true;
            }
        });

        doneTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toogleDrawView(true);
                photoEditorSDK.setBrushDrawingMode(false);
                isMediaEdited = true;
            }
        });
        cancelTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toogleDrawView(true);
                photoEditorSDK.clearBrushAllViews();
                photoEditorSDK.setBrushDrawingMode(false);
                isMediaEdited = false;
            }
        });

        saveMedia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (!isMediaSaving) {

                        isMediaSaving = true;

                        Utils.addReppleEffectToview(
                                MediaShareFromCameraActivity.this,
                                view
                        );

                        saveMediaToLocalStorage();
                    }

//                    saveMedia.setClickable(false);
                } catch (Exception e) {
                    writeCreashRepost(e.getMessage());
                }
            }
        });

        photoView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (editView.getVisibility() == View.VISIBLE)
                        toogleEditAndQucikShareView(true);
                    else
                        toogleEditAndQucikShareView(false);
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });

        exoPlayerView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                try {
                    if (editView.getVisibility() == View.VISIBLE)
                        toogleEditAndQucikShareView(true);
                    else
                        toogleEditAndQucikShareView(false);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                return true;
            }
        });


    }

    private void openAddTextPopupWindow(final String text) {

        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View addTextPopupWindowRootView = inflater.inflate(R.layout.add_text_popup_window, null);

        final EditText addTextEditText = addTextPopupWindowRootView.findViewById(R.id.add_text_edit_text);

        ColorPickerAdapter colorPickerAdapter = new ColorPickerAdapter(MediaShareFromCameraActivity.this, colorPickerColors);
        colorPickerAdapter.setOnColorPickerClickListener(new ColorPickerAdapter.OnColorPickerClickListener() {
            @Override
            public void onColorPickerClickListener(int colorCode) {
                addTextEditText.setTextColor(colorCode);
                colorCodeValue = colorCode;
            }
        });

        RecyclerView addTextColorPickerRecyclerView = addTextPopupWindowRootView.findViewById(
                R.id.add_text_color_picker_recycler_view);
        LinearLayoutManager layoutManager = new LinearLayoutManager(MediaShareFromCameraActivity.this, LinearLayoutManager.HORIZONTAL, false);
        addTextColorPickerRecyclerView.setLayoutManager(layoutManager);
        addTextColorPickerRecyclerView.setHasFixedSize(true);
        addTextColorPickerRecyclerView.setAdapter(colorPickerAdapter);


        if (stringIsNotEmpty(text)) {
            addTextEditText.setText(text);
            addTextEditText.setTextColor(colorCodeValue == -1 ? Color.RED : colorCodeValue);
        }
        pop = new PopupWindow(MediaShareFromCameraActivity.this);
        pop.setContentView(addTextPopupWindowRootView);
        pop.setWidth(LinearLayout.LayoutParams.MATCH_PARENT);
        pop.setHeight(LinearLayout.LayoutParams.MATCH_PARENT);
        pop.setFocusable(true);
        pop.setBackgroundDrawable(null);
        pop.showAtLocation(addTextPopupWindowRootView, Gravity.TOP, 0, 0);
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);

        addTextEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {

            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {

                if ((actionId == EditorInfo.IME_ACTION_DONE)) {
                    photoEditorSDK.addText(addTextEditText.getText().toString(), colorCodeValue);
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(addTextEditText.getWindowToken(), 0);
                    pop.dismiss();
                    return true;
                }
                return false;

            }
        });
    }


    private void writeCreashRepost(String message) {
        super.writeCrashReport(TAG, message);
    }

    private void toogleEditAndQucikShareView(boolean toHideView) throws Exception {
        if (toHideView) {

            if (editView.getVisibility() == View.VISIBLE) {

                YoYo.with(Techniques.SlideOutUp)
                        .duration(Constants.ANIMATIONTIME)
                        .onEnd(new YoYo.AnimatorCallback() {
                            @Override
                            public void call(Animator animator) {
                                editView.setVisibility(View.GONE);
                            }
                        })
                        .playOn(editView);


            }
            if (quickShareView.getVisibility() == View.VISIBLE) {

                YoYo.with(Techniques.SlideOutDown)
                        .duration(Constants.ANIMATIONTIME)
                        .onEnd(new YoYo.AnimatorCallback() {
                            @Override
                            public void call(Animator animator) {
                                quickShareView.setVisibility(View.GONE);
                            }
                        })
                        .playOn(quickShareView);
            }
        } else {

            if (editView.getVisibility() == View.GONE) {
                editView.setVisibility(View.VISIBLE);
                YoYo.with(Techniques.SlideInDown)
                        .duration(Constants.ANIMATIONTIME)
                        .playOn(editView);
            }

            if (quickShareView.getVisibility() == View.GONE) {
                quickShareView.setVisibility(View.VISIBLE);

                YoYo.with(Techniques.SlideInUp)
                        .duration(Constants.ANIMATIONTIME)
                        .playOn(quickShareView);
            }
        }
    }

    private boolean stringIsNotEmpty(String string) {
        if (string != null && !string.equals("null")) {
            if (!string.trim().equals("")) {
                return true;
            }
        }
        return false;
    }

    /**
     * Update quick share options to views.
     *
     * @throws Exception{Runtime Stub Exception}
     */
    private void updateUserForQuickShare() throws Exception {

        DbHelper dbHelper = new DbHelper(MediaShareFromCameraActivity.this);
        List<RecentShareDbModel> recentShareDbModels = dbHelper.getAllRecentusers();

        int iterator = 0;

        for (RecentShareDbModel shareDbModel : recentShareDbModels) {
            final Drawable drawable = new BitmapDrawable(
                    Utils.textAsBitmap(shareDbModel.getUserName(), MediaShareFromCameraActivity.this));
            String userName = shareDbModel.getUserName();

            switch (iterator) {

                case 0:
                    if (shareDbModel.getProfilePic() != null &&
                            !shareDbModel.getProfilePic().equalsIgnoreCase("")) {
                        ImageLoader.getInstance().displayImage(
                                shareDbModel.getProfilePic(),
                                quickShareuserOneImv, new ImageLoadingListener() {
                                    @Override
                                    public void onLoadingStarted(String imageUri, View view) {
                                        quickShareuserOneImv.setImageDrawable(drawable);
                                    }

                                    @Override
                                    public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
                                        quickShareuserOneImv.setImageDrawable(drawable);
                                    }

                                    @Override
                                    public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                                        quickShareuserOneImv.setImageBitmap(loadedImage);
                                    }

                                    @Override
                                    public void onLoadingCancelled(String imageUri, View view) {
                                        quickShareuserOneImv.setImageDrawable(drawable);
                                    }
                                });
                    } else {
                        quickShareuserOneImv.setImageDrawable(drawable);
                    }
                    quickShareUserOneTv.setText(userName);
                    break;

                case 1:
                    if (shareDbModel.getProfilePic() != null &&
                            !shareDbModel.getProfilePic().equalsIgnoreCase("")) {
                        ImageLoader.getInstance().displayImage(
                                shareDbModel.getProfilePic(),
                                quickShareuserTwoImv, new ImageLoadingListener() {
                                    @Override
                                    public void onLoadingStarted(String imageUri, View view) {
                                        quickShareuserTwoImv.setImageDrawable(drawable);
                                    }

                                    @Override
                                    public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
                                        quickShareuserTwoImv.setImageDrawable(drawable);
                                    }

                                    @Override
                                    public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                                        quickShareuserTwoImv.setImageBitmap(loadedImage);
                                    }

                                    @Override
                                    public void onLoadingCancelled(String imageUri, View view) {
                                        quickShareuserTwoImv.setImageDrawable(drawable);
                                    }
                                });
                    } else {
                        quickShareuserTwoImv.setImageDrawable(drawable);
                    }
                    quickShareUserTwoTv.setText(userName);
                    break;

                case 2:
                    if (shareDbModel.getProfilePic() != null &&
                            !shareDbModel.getProfilePic().equalsIgnoreCase("")) {
                        ImageLoader.getInstance().displayImage(
                                shareDbModel.getProfilePic(),
                                quickShareuserThreeImv, new ImageLoadingListener() {
                                    @Override
                                    public void onLoadingStarted(String imageUri, View view) {
                                        quickShareuserThreeImv.setImageDrawable(drawable);
                                    }

                                    @Override
                                    public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
                                        quickShareuserThreeImv.setImageDrawable(drawable);
                                    }

                                    @Override
                                    public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                                        quickShareuserThreeImv.setImageBitmap(loadedImage);
                                    }

                                    @Override
                                    public void onLoadingCancelled(String imageUri, View view) {
                                        quickShareuserThreeImv.setImageDrawable(drawable);
                                    }
                                });
                    } else {
                        quickShareuserThreeImv.setImageDrawable(drawable);
                    }
                    quickShareUserThreeTv.setText(userName);
                    break;
            }

            iterator++;
        }
    }

    /**
     * Share Media from Qucik Sharw view
     *
     * @param position the postion of the user that has been selected.
     * @throws Exception {Runtime Stub Exception}
     */
    private void shareMediaToFregquentUsers(int position) throws Exception {

        toogleEditAndQucikShareView(true);

        DbHelper dbHelper = new DbHelper(MediaShareFromCameraActivity.this);
        List<RecentShareDbModel> recentShareDbModels = dbHelper.getAllRecentusers();
        if (recentShareDbModels != null) {
            RecentShareDbModel recentShareDbModel = recentShareDbModels.get(position);

            List<String> selectedUsers = new ArrayList<>();
            selectedUsers.add(recentShareDbModel.getIdentifier());

            shareMediaWithOutSaving(selectedUsers, false);

        }
    }

    private void playVideo() throws Exception {

        File file = new File(filePath);
        Uri uri = Uri.fromFile(file);
        DataSpec dataSpec = new DataSpec(uri);

        final FileDataSource fileDataSource = new FileDataSource();
        try {
            fileDataSource.open(dataSpec);
        } catch (FileDataSource.FileDataSourceException e) {
            e.printStackTrace();
        }

        DataSource.Factory factory = new DataSource.Factory() {
            @Override
            public DataSource createDataSource() {
                return fileDataSource;
            }
        };

        MediaSource videoSource = new ExtractorMediaSource(fileDataSource.getUri(),
                factory, new DefaultExtractorsFactory(), null, new ExtractorMediaSource.EventListener() {
            @Override
            public void onLoadError(IOException error) {
                writeCreashRepost(error.getMessage());
            }
        });

        // Prepare the player with the source.
        exoPlayerView.setPlayer(player);

        player.prepare(videoSource);
        player.setRepeatMode(Player.REPEAT_MODE_ALL);
        player.setVolume(0f);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                player.setPlayWhenReady(true);
            }
        }, 2000);


        player.addListener(new Player.EventListener() {
            @Override
            public void onTimelineChanged(Timeline timeline, Object manifest) {

            }

            @Override
            public void onTracksChanged(TrackGroupArray trackGroups, TrackSelectionArray trackSelections) {

            }

            @Override
            public void onLoadingChanged(boolean isLoading) {

            }

            @Override
            public void onPlayerStateChanged(boolean playWhenReady, int playbackState) {
                if (playWhenReady && playbackState == Player.STATE_READY) {
                    player.setVolume(1f);
                }
            }

            @Override
            public void onRepeatModeChanged(int repeatMode) {

            }

            @Override
            public void onPlayerError(ExoPlaybackException error) {

            }

            @Override
            public void onPositionDiscontinuity() {

            }

            @Override
            public void onPlaybackParametersChanged(PlaybackParameters playbackParameters) {

            }
        });
    }

    private void initalizeStickerPanel() throws Exception {
        StickersFragment stickersFragment = new StickersFragment();
        stickersFragment.setOnStickerSelectedListener(this);
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.add(frameLayout.getId(), stickersFragment);
        fragmentTransaction.commit();
    }

    private void showEmojiList() throws Exception {
        frameLayout.setVisibility(View.VISIBLE);
        YoYo.with(Techniques.SlideInUp)
                .duration(Constants.ANIMATIONTIME)
                .playOn(frameLayout);

        toogleEditAndQucikShareView(true);
    }

    private void closeEmojiList() throws Exception {

        YoYo.with(Techniques.SlideOutDown)
                .duration(Constants.ANIMATIONTIME)
                .onEnd(new YoYo.AnimatorCallback() {
                    @Override
                    public void call(Animator animator) {
                        frameLayout.setVisibility(View.GONE);
                    }
                })
                .playOn(frameLayout);
    }

    private void saveMediaToLocalStorage() throws Exception {

        Date now = new Date();
        android.text.format.DateFormat.format("yyyy-MM-dd_hh:mm:ss", now);
        String mPath = getCacheDir() + "/" + now + ".png";
        File imageFile = new File(mPath);
        FileOutputStream outputStream = new FileOutputStream(imageFile);
        int quality = 100;

        if (isVideo) {
            if (isMediaEdited || photoEditorSDK.getNumberOfViewsAdded() > 0) {

                MediaShareFromCameraActivity.super.showLoaders(MediaShareFromCameraActivity.this);

                Bitmap overlayBitmap = overlayViewRL.getDrawingCache();
                overlayBitmap.compress(Bitmap.CompressFormat.PNG, quality, outputStream);
                outputStream.flush();
                outputStream.close();

                new AddOverLayToVideo(MediaShareFromCameraActivity.this, filePath,
                        imageFile.getPath(), new AddOverLayToVideo.OnAddOverlayListener() {
                    @Override
                    public void onOverlayAdded(String imagePath) {
                        saveVideo(imagePath);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    MediaShareFromCameraActivity.super.cancelPopUp();
                                } catch (Exception e) {
                                    writeCreashRepost(e.getMessage());
                                }
                            }
                        });
                    }

                    @Override
                    public void onOverlayAddedFailed(String message) {
                        writeCreashRepost(message);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    MediaShareFromCameraActivity.super.cancelPopUp();
                                } catch (Exception e) {
                                    writeCreashRepost(e.getMessage());
                                }
                            }
                        });

                    }
                });
            } else {
                saveVideo(filePath);
            }

        } else {
            if (photoEditorSDK.getNumberOfViewsAdded() > 0 || isMediaEdited) {

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            MediaShareFromCameraActivity.super.showLoaders(MediaShareFromCameraActivity.this);
                        } catch (Exception e) {
                            writeCreashRepost(e.getMessage());
                        }
                    }
                });

                photoEditorSDK.saveImage(getString(R.string.app_name),
                        String.valueOf(System.currentTimeMillis()));

                super.cancelPopUp();
                sendBroadcast(new Intent("MediaItemChanged"));

                MediaShareFromCameraActivity.super.showToastMessage(
                        "Media Saved Sucessfully.",
                        true
                );
                isMediaSaving = false;
            } else {
                saveImage(filePath);
            }
        }

    }

    private void shareMediaWithOutSaving(
            final List<String> selecteduser,
            final boolean isShowMoreContacts) throws Exception {

        Date now = new Date();
        android.text.format.DateFormat.format("yyyy-MM-dd_hh:mm:ss", now);
        String mPath = getCacheDir() + "/" + now + ".png";
        File imageFile = new File(mPath);
        FileOutputStream outputStream = new FileOutputStream(imageFile);
        int quality = 100;

        if (isVideo) {
            if (isMediaEdited || photoEditorSDK.getNumberOfViewsAdded() > 0) {

                overlayViewRL.setDrawingCacheEnabled(true);

                MediaShareFromCameraActivity.super.showLoaders(MediaShareFromCameraActivity.this);

                Bitmap overlayBitmap = overlayViewRL.getDrawingCache();
                overlayBitmap.compress(Bitmap.CompressFormat.PNG, quality, outputStream);
                outputStream.flush();
                outputStream.close();

                overlayViewRL.setDrawingCacheEnabled(false);

                new AddOverLayToVideo(MediaShareFromCameraActivity.this, filePath,
                        imageFile.getPath(), new AddOverLayToVideo.OnAddOverlayListener() {
                    @Override
                    public void onOverlayAdded(String imagePath) {
                        try {
                            shareMediaToUsers(selecteduser, imagePath, isShowMoreContacts);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    try {
                                        MediaShareFromCameraActivity.super.cancelPopUp();
                                    } catch (Exception e) {
                                        writeCreashRepost(e.getMessage());
                                    }
                                }
                            });
                        } catch (Exception e) {
                            writeCreashRepost(e.getMessage());
                        }
                    }

                    @Override
                    public void onOverlayAddedFailed(String message) {
                        writeCreashRepost(message);

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    MediaShareFromCameraActivity.super.cancelPopUp();
                                } catch (Exception e) {
                                    writeCreashRepost(e.getMessage());
                                }
                            }
                        });
                    }
                });
            } else {
                shareMediaToUsers(selecteduser, filePath, isShowMoreContacts);
            }
        } else {
            if (isMediaEdited || photoEditorSDK.getNumberOfViewsAdded() > 0) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            MediaShareFromCameraActivity.super.showLoaders(MediaShareFromCameraActivity.this);
                        } catch (Exception e) {
                            writeCreashRepost(e.getMessage());
                        }
                    }
                });
                overlayViewRL.setDrawingCacheEnabled(true);
                Bitmap overlayBitmap = overlayViewRL.getDrawingCache();
                overlayBitmap.compress(Bitmap.CompressFormat.PNG, quality, outputStream);
                outputStream.flush();
                outputStream.close();
                overlayViewRL.setDrawingCacheEnabled(false);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            MediaShareFromCameraActivity.super.cancelPopUp();
                        } catch (Exception e) {
                            writeCreashRepost(e.getMessage());
                        }
                    }
                });
                shareMediaToUsers(selecteduser, mPath, isShowMoreContacts);
            } else {
                shareMediaToUsers(selecteduser, filePath, isShowMoreContacts);
            }
        }

    }

    private void shareMediaToUsers(List<String> selectedUsers,
                                   String filePath, boolean isShowMoreContact) throws Exception {
        if (isShowMoreContact) {
            List<String> selectedImage = new ArrayList<>();
            selectedImage.add(filePath);

            Intent intent = new Intent(MediaShareFromCameraActivity.this,
                    MultipleShareActivity.class);
            String imageData = new Gson().toJson(selectedImage);
            Bundle bundle = new Bundle();
            bundle.putString(Constants.EXTRASTRINGS, imageData);
            intent.putExtras(bundle);
            startActivity(intent);
        } else {
            List<String> selectedImage = new ArrayList<>();
            selectedImage.add(filePath);
            Gson g = new Gson();
            String json = g.toJson(selectedImage);
            String SselectedUsers = g.toJson(selectedUsers);
            Random random = new Random();
            RestServiceUtils.scheduleUploadMediaFile(MediaShareFromCameraActivity.this,
                    json, SselectedUsers, false);
        }
    }

    private void saveVideo(String filePath) {
        try {
            String mPath = Environment.getExternalStorageDirectory().toString() + "/" +
                    System.currentTimeMillis()
                    + ".mp4";

            try (InputStream in = new FileInputStream(filePath)) {
                try (OutputStream out = new FileOutputStream(mPath)) {
                    // Transfer bytes from in to out
                    byte[] buf = new byte[1024];
                    int len;
                    while ((len = in.read(buf)) > 0) {
                        out.write(buf, 0, len);
                    }
                }
            }

            ContentValues values = new ContentValues();
            values.put(MediaStore.Video.Media.DATE_TAKEN, System.currentTimeMillis());
            values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            values.put(MediaStore.MediaColumns.DATA, mPath);
            getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
            sendBroadcast(new Intent("MediaItemChanged"));

            MediaShareFromCameraActivity.super.showToastMessage(
                    "Media Saved Sucessfully.",
                    true
            );
            isMediaSaving = false;
        } catch (Exception e) {
            writeCreashRepost(e.getMessage());
        }
    }

    private void saveImage(String imagePath) {
        try {
            String selectedOutputPath = "";
            if (isSDCARDMounted()) {

                File mediaStorageDir = new File(
                        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                        getString(R.string.app_name));

                if (!mediaStorageDir.exists()) {
                    if (!mediaStorageDir.mkdirs()) {
                        Log.d("PhotoEditorSDK", "Failed to create directory");
                    }
                }


                selectedOutputPath = mediaStorageDir.getPath() + File.separator +
                        String.valueOf(System.currentTimeMillis()) + ".png";

                try (InputStream in = new FileInputStream(imagePath)) {
                    try (OutputStream out = new FileOutputStream(selectedOutputPath)) {
                        // Transfer bytes from in to out
                        byte[] buf = new byte[1024];
                        int len;
                        while ((len = in.read(buf)) > 0) {
                            out.write(buf, 0, len);
                        }
                    }
                }
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis());
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                values.put(MediaStore.MediaColumns.DATA, selectedOutputPath);
                getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);

                super.cancelPopUp();
                sendBroadcast(new Intent("MediaItemChanged"));

                MediaShareFromCameraActivity.super.showToastMessage(
                        "Media Saved Sucessfully.",
                        true
                );
                isMediaSaving = false;
            }

        } catch (Exception e) {
            writeCreashRepost(e.getMessage());
        }
    }

    private boolean isSDCARDMounted() {
        String status = Environment.getExternalStorageState();
        return status.equals(Environment.MEDIA_MOUNTED);
    }

    private void intializeColorPallete() throws Exception {

        ColorPickerAdapter colorPickerAdapter = new ColorPickerAdapter(this, colorPickerColors);
        colorPickerAdapter.setOnColorPickerClickListener(new ColorPickerAdapter.OnColorPickerClickListener() {
            @Override
            public void onColorPickerClickListener(int colorCode) {
                photoEditorSDK.setBrushColor(colorCode);
            }
        });

        RecyclerView addTextColorPickerRecyclerView = findViewById(
                R.id.add_text_color_picker_recycler_view);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        addTextColorPickerRecyclerView.setLayoutManager(layoutManager);
        addTextColorPickerRecyclerView.setHasFixedSize(true);
        addTextColorPickerRecyclerView.setAdapter(colorPickerAdapter);
    }
/*
    private Bitmap rescaleOverlay(Bitmap source, int videoWidth, int videoHeight) {
        // creating a dummy bitmap
        Bitmap background;
        Canvas canvas;

        if (source.getHeight() == source.getWidth()) // do nothing
            return source;

        background = Bitmap.createBitmap(source.getHeight(), source.getHeight(),
                Bitmap.Config.ARGB_8888);
        canvas = new Canvas(background);
        // draw the source image centered
        canvas.drawBitmap(source, videoWidth , 0, new Paint());

        // create a new Bitmap with the bigger side (to get a square)
       *//* if (source.getHeight() > source.getWidth()) {
            background = Bitmap.createBitmap(source.getHeight(), source.getHeight(),
                    Bitmap.Config.ARGB_8888);
            canvas = new Canvas(background);
            // draw the source image centered
            canvas.drawBitmap(source, videoHeight / 2, 0, new Paint());
        } else {
            background = Bitmap.createBitmap(source.getWidth(), source.getWidth(), Bitmap.Config.ARGB_8888);
            canvas = new Canvas(background);
            // draw the source image centered
            canvas.drawBitmap(source, 0, videoWidth / 2, new Paint());
        }*//*

        source.recycle();
        canvas.setBitmap(null);
        // update the source image
        return background;
    }*/
}
