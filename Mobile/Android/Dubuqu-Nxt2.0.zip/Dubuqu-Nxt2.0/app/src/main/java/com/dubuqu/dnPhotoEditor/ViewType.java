package com.dubuqu.dnPhotoEditor;

/**
 * Created by Yogaraj on 03/06/2017.
 */

public enum ViewType {

    BRUSH_DRAWING,
    TEXT,
    IMAGE,
    EMOJI

}
