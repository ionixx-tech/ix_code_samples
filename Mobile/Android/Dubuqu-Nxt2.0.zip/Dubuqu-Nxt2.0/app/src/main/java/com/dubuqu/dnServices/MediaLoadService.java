package com.dubuqu.dnServices;

import android.app.IntentService;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.ResultReceiver;
import android.provider.MediaStore;
import android.support.annotation.Nullable;

import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnModels.commonModel.GalleryMediaListModel;
import com.dubuqu.dnUtils.Utils;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Yogaraj subramanian on 25/10/17
 */

public class MediaLoadService extends IntentService {

    HashMap<Date, List<GalleryMediaListModel>> datesAdded = new HashMap<>();

    private ResultReceiver receiver;

    public MediaLoadService() {
        super(Constants.LOADIMAGESERVICE);
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {

        try {
            receiver = intent.getParcelableExtra(Constants.EXTRASTRINGS);
            loadImagesBasedOnDate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * <p>
     * Load Imagees form the external hard drive if neeeded internal values can be added.
     * to add internal storage look at line number {81} replace "external" by "internal"
     * this will fetch images from internal storage directory.
     * </p>
     * <p>
     * Query used in this service is
     * <p>
     * SELECT   MediaStore.Files.FileColumns._ID,
     * MediaStore.Files.FileColumns.DATE_ADDED,
     * MediaStore.Files.FileColumns.MIME_TYPE
     * FROM
     * <p>
     * MEDIASTOR.FILES
     * <p>
     * WHERE
     * <p>
     * MediaStore.Files.FileColumns.MEDIA_TYPE + "="
     * MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE
     * " OR "
     * MediaStore.Files.FileColumns.MEDIA_TYPE + "="
     * MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO
     * <p>
     * </p>
     * <p>
     * then medias are added with both HASHMAP {datesAdded} based on date.
     *
     * @throws Exception {Runtime Stub Exception}
     */

    private void loadImagesBasedOnDate() throws Exception {

        String[] mediaProjection = {
                MediaStore.Files.FileColumns._ID,
                MediaStore.Files.FileColumns.DATE_ADDED,
                MediaStore.Files.FileColumns.MIME_TYPE,
                MediaStore.Files.FileColumns.DATA
        };

        String selection = MediaStore.Files.FileColumns.MEDIA_TYPE + "="
                + MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE
                + " OR "
                + MediaStore.Files.FileColumns.MEDIA_TYPE + "="
                + MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO;

        Uri queryUri = MediaStore.Files.getContentUri("external");

        Cursor cursor = getContentResolver().query(
                queryUri,
                mediaProjection,
                selection,
                null,
                MediaStore.Files.FileColumns.DATE_ADDED + " DESC");

        if (cursor != null) {

            int totalSize = cursor.getCount();

            int iterator = 0;

            while (iterator < totalSize) {

                cursor.moveToPosition(iterator);

                int dateIndex = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_ADDED);

                int mediaIndex = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID);

                int mediaTypeIndex = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MIME_TYPE);

                int mediaDataIndex = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA);

                int mediaId = cursor.getInt(mediaIndex);
                String mimeType = cursor.getString(mediaTypeIndex);
                String data = cursor.getString(mediaDataIndex);

                GalleryMediaListModel galleryListModel = new GalleryMediaListModel();

                galleryListModel.setMediaId(mediaId);
                galleryListModel.setMimeType(mimeType);
                galleryListModel.setMediaPath(data);
                galleryListModel.setSelected(false);

                if (mimeType.contains("video")) {

                    try {
                        long videoDuration = Utils.getVideoDurationInMilliSec(data);

                        String videoDurationInMinutes = Utils.getVideoDurationString(videoDuration);

                        galleryListModel.setVideoDuration(videoDurationInMinutes);
                    } catch (Exception e) {
                        galleryListModel.setVideoDuration(String.valueOf("0.0"));
                    }

                }

                long date = cursor.getLong(dateIndex);

                List<GalleryMediaListModel> galleryList = datesAdded.get(Utils.formatDate(date));

                if (galleryList == null) {
                    galleryList = new ArrayList<>();
                }

                galleryList.add(galleryListModel);
                datesAdded.put(Utils.formatDate(date), galleryList);

                if (iterator == 200) {
                    AsyncTask.execute(new Runnable() {
                        @Override
                        public void run() {
                            Bundle bundle = new Bundle();
                            bundle.putSerializable(Constants.EXTRASTRINGS, datesAdded);

                            if (receiver != null) {
                                receiver.send(Constants.IMAGELISTRECEIVERREQUEST, bundle);
                            }

                        }
                    });

                }
                iterator++;
            }

            if (receiver != null) {
                Bundle bundle = new Bundle();
                bundle.putSerializable(Constants.EXTRASTRINGS, datesAdded);

                if (receiver != null)
                    receiver.send(Constants.IMAGELISTRECEIVERREQUEST, bundle);
            }

            cursor.close();

            this.stopSelf();
        }

    }
}
