package com.dubuqu.dnAdapter.gallery;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.dubuqu.R;
import com.dubuqu.dnActivity.LandingActivity;
import com.dubuqu.dnModels.commonModel.GalleryMediaListModel;
import com.dubuqu.dnUtils.Utils;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import static android.view.View.GONE;

/**
 * Created by Yogaraj subramanian on 26/10/17
 */

public class GalleryListAdapter extends StickyHeaderGridAdapter {


    private Context mContext;

    private HashMap<Date, List<GalleryMediaListModel>> galleryListModel;


    private GalleryAdapterCallBack galleryAdapterCallBack;

    private List<Date> dateValues;

    private boolean isInMultipselectMode = false;

    private View.OnLongClickListener longClickListener;


    public interface GalleryAdapterCallBack {
        //called if selection is not enabled and clicked to view media
        void onMediaClicked();

        void openMediaInFullView(String currentImageSelected);
    }

    public GalleryListAdapter(Context mContext, HashMap<Date,
            List<GalleryMediaListModel>> galleryListModel) {
        this.mContext = mContext;
        this.galleryListModel = galleryListModel;
        dateValues = new ArrayList<>();
    }


    public void setDateValues(List<Date> dateValues) {
        this.dateValues = dateValues;
        Collections.sort(this.dateValues);
        Collections.reverse(this.dateValues);
    }

    public void setLongClickListener(View.OnLongClickListener clickListener) {
        this.longClickListener = clickListener;
    }

    public List<Date> getDateValues() {
        return this.dateValues;
    }

    public void setGalleryAdapterCallBack(GalleryAdapterCallBack galleryAdapterCallBack) {
        this.galleryAdapterCallBack = galleryAdapterCallBack;
    }

    public void setInMultipselectMode(boolean inMultipselectMode) {
        this.isInMultipselectMode = inMultipselectMode;
    }

    public void removeDate(Date date) {
        int index = dateValues.indexOf(date);
        dateValues.remove(date);
        notifySectionRemoved(index);
    }

    public boolean isInMultipselectMode() {
        return isInMultipselectMode;
    }

    /*number of sections available*/
    @Override
    public int getSectionCount() {
        return dateValues.size();
    }

    /*number of offsets available in a single section*/
    @Override
    public int getSectionItemCount(int section) {
        try {
            List<GalleryMediaListModel> galleryImageModel = galleryListModel.get(dateValues.get(section));
            return galleryImageModel.size();
        } catch (Exception e) {
            if (mContext instanceof LandingActivity)
                ((LandingActivity) mContext).writeCrashReport(GalleryListAdapter.class.getName(),
                        e.getMessage());

        }
        return 0;
    }

    @Override
    public HeaderViewHolder onCreateHeaderViewHolder(ViewGroup parent, int headerType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.gallery_list_adapter_header_view, parent, false);
        return new GalleryListAdapterHeaderViewHolder(view);
    }

    @Override
    public ItemViewHolder onCreateItemViewHolder(ViewGroup parent, int itemType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.gallery_list_adapter_item_viewholder, parent, false);
        if (longClickListener != null)
            view.setOnLongClickListener(longClickListener);
        return new GalleryListAdapterItemViewHolder(view);
    }

    @Override
    public void onBindHeaderViewHolder(HeaderViewHolder viewHolder, int section) {
        try {

            ((GalleryListAdapterHeaderViewHolder) viewHolder).onBind(viewHolder, section);

        } catch (Exception e) {
            if (mContext instanceof LandingActivity)
                ((LandingActivity) mContext).writeCrashReport(GalleryListAdapter.class.getName(),
                        e.getMessage());
        }
    }

    @Override
    public void onBindItemViewHolder(ItemViewHolder viewHolder, int section, int offset) {
        try {

            ((GalleryListAdapterItemViewHolder) viewHolder).onBind(viewHolder, section, offset);
        } catch (Exception e) {
            if (mContext instanceof LandingActivity)
                ((LandingActivity) mContext).writeCrashReport(GalleryListAdapter.class.getName(),
                        e.getMessage());
        }
    }


    private class GalleryListAdapterHeaderViewHolder extends HeaderViewHolder {
        TextView dayIndicator;

        private GalleryListAdapterHeaderViewHolder(View itemView) {
            super(itemView);
            dayIndicator = itemView.findViewById(R.id.stickyheader);
        }

        private void onBind(HeaderViewHolder headerViewHolder, int position) throws Exception {

            List<GalleryMediaListModel> galleryImageModelList = galleryListModel.get(dateValues.get(position));

            if (galleryImageModelList != null && galleryImageModelList.size() <= 0) {
                itemView.setVisibility(GONE);
            } else {
                itemView.setVisibility(View.VISIBLE);

                dayIndicator.setText(foramtDate(position));
            }
        }


        /**
         * The time at which the file is created need to fomated as following senarios.
         * <p>
         * It need to get changed with "7 November"(No need to display year, if it is current year).
         * If the images are displaying for last year then it need to display "21 January,2016"
         * </p>
         *
         * @param position the current position of the view holder
         * @return formated date string
         * @throws Exception {Runtime Stub Exception}
         */
        private String foramtDate(int position) throws Exception {

            SimpleDateFormat fmtOut = new SimpleDateFormat("EEEE, MMM d,yyyy");

            String dateFileCreated = fmtOut.format(dateValues.get(position));

            Date currentDay = new Date();
            String todayDate = fmtOut.format(currentDay);

            if (todayDate.equalsIgnoreCase(dateFileCreated)) {
                return "Today";
            }

            Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            calendar.setTime(dateValues.get(position));
            if (calendar.get(Calendar.YEAR) < year) {
                SimpleDateFormat formatDate = new SimpleDateFormat("dd MMMM,yyyy");

                return formatDate.format(dateValues.get(position));
            } else {
                SimpleDateFormat formatDate = new SimpleDateFormat("dd MMMM");

                return formatDate.format(dateValues.get(position));
            }

        }

        public void makeInVisible() {
            itemView.setVisibility(GONE);
        }
    }

    private class GalleryListAdapterItemViewHolder extends ItemViewHolder {
        ImageView images;
        ImageView videoIndicator;
        RelativeLayout selectedIndicator, videoIndicatorRl;
        TextView duration;

        private GalleryListAdapterItemViewHolder(View itemView) {
            super(itemView);
            images = itemView.findViewById(R.id.gallery_image_view);
            selectedIndicator = itemView.findViewById(R.id.gallery_image_view_selected);
            selectedIndicator.setVisibility(GONE);
            videoIndicatorRl = itemView.findViewById(R.id.video_indicator_rl);
            duration = itemView.findViewById(R.id.video_duration);
            videoIndicator = itemView.findViewById(R.id.videoIndicator);
            videoIndicatorRl.setVisibility(GONE);
        }

        private void onBind(ItemViewHolder itemViewHolder, final int section, final int offset) throws Exception {

            if (offset == 0 || offset == 1 || offset == 2) {
                itemView.setPadding(Utils.convertUnitToDp(mContext, 1)
                        , Utils.convertUnitToDp(mContext, 8)
                        , 0, 0);
            } else {
                itemView.setPadding(Utils.convertUnitToDp(mContext, 1)
                        , Utils.convertUnitToDp(mContext, 1)
                        , 0, 0);
            }

            List<GalleryMediaListModel> galleryImageModelList = galleryListModel.get(dateValues.get(section));

            GalleryMediaListModel galleryImageModel = galleryImageModelList.get(offset);


            File f = new File(galleryImageModel.getMediaPath());
            if (galleryImageModel.isSelected()) {
                selectedIndicator.setVisibility(View.VISIBLE);
            } else {
                selectedIndicator.setVisibility(GONE);
            }
            if (galleryImageModel.getMimeType().contains("video")) {

                videoIndicatorRl.setVisibility(View.VISIBLE);

                Glide.with(mContext)
                        .load(f)
                        .placeholder(mContext.getResources().getDrawable(R.drawable.dn_preloader_gardient))
                        .into(images);

                duration.setText(galleryImageModel.getVideoDuration());
            } else if (galleryImageModel.getMimeType().contains("gif")) {
                videoIndicatorRl.setVisibility(GONE);
                Glide.with(mContext)
                        .load(f)
                        .asGif()
                        .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                        .placeholder(mContext.getResources().getDrawable(R.drawable.dn_preloader_gardient))
                        .into(images);
            } else {
                videoIndicatorRl.setVisibility(GONE);
                Glide.with(mContext)
                        .load(f)
                        .placeholder(mContext.getResources().getDrawable(R.drawable.dn_preloader_gardient))
                        .into(images);
            }

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    List<GalleryMediaListModel> galleryImageModelList = galleryListModel.get(dateValues.get(section));

                    GalleryMediaListModel galleryImageModel = galleryImageModelList.get(offset);

                    if (isInMultipselectMode) {

                        YoYo.with(Techniques.Pulse).duration(400).playOn(images);

                        if (galleryImageModel.isSelected()) {
                            galleryImageModel.setSelected(false);
                        } else {
                            galleryImageModel.setSelected(true);
                        }


                        galleryAdapterCallBack.onMediaClicked();

                    } else {
                        galleryAdapterCallBack.openMediaInFullView(galleryImageModel.getMediaPath());
                    }

                    galleryImageModelList.set(offset, galleryImageModel);

                    notifySectionItemChanged(section, offset);
                }
            });

        }
    }

    public void onItemMove(int adapterPosition) throws Exception {

        this.isInMultipselectMode = true;

        final int section = getAdapterPositionSection(adapterPosition);
        final int offset = getItemSectionOffset(section, adapterPosition);

        List<GalleryMediaListModel> galleryImageModelList = galleryListModel.get(dateValues.get(section));

        GalleryMediaListModel galleryImageModel = galleryImageModelList.get(offset);

        if (isInMultipselectMode) {
            if (galleryImageModel.isSelected()) {
                galleryImageModel.setSelected(false);
            } else {
                galleryImageModel.setSelected(true);

            }
        }
        galleryImageModelList.set(offset, galleryImageModel);

        notifyAllSectionsDataSetChanged();

        galleryAdapterCallBack.onMediaClicked();
    }
}
