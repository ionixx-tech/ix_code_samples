package com.dubuqu.dnAdapter.gallery;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.dubuqu.R;
import com.dubuqu.dnActivity.LandingActivity;
import com.dubuqu.dnActivity.gallery.AlbumDetailActivity;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnModels.commonModel.GalleryAlbumList;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Yogaraj subramanian on 26/10/17
 */

public class GalleryMediaAlbumAdapter extends RecyclerView.Adapter<GalleryMediaAlbumAdapter.GalleryMediaAlbumViewHolder> {

    private HashMap<String, GalleryAlbumList> albumListHashMap;
    private Context mContext;
    private List<String> albumList = new ArrayList<>();

    public GalleryMediaAlbumAdapter(HashMap<String, GalleryAlbumList> albumList,
                                    Context mContext) {
        this.albumListHashMap = albumList;
        this.mContext = mContext;
    }

    public void setAlbumList(List<String> albumList) {
        try {
            this.albumList = sortValues(albumList);
        } catch (Exception e) {
            ((LandingActivity) mContext).writeCrashReport(
                    GalleryMediaAlbumAdapter.class.getName(),
                    e.getMessage()
            );
        }

    }


    private List<String> sortValues(List<String> albumList) throws Exception {

        List<String> tempIndex = new ArrayList<>();

        ArrayList<String> tempKey = new ArrayList<>();

        for (String value : albumList) {
            String currentalue = value.toUpperCase();

            if (currentalue.contains("CAMERA")
                    || currentalue.contains("DUBUQU")) {
                tempIndex.add(value);
                tempKey.add(value);
            }
        }

        albumList.removeAll(tempIndex);

        Collections.sort(albumList);
        Collections.sort(tempKey);

        tempKey.addAll(albumList);

        return tempKey;

    }


    public List<String> getAlbumList() {
        return albumList;
    }

    @Override
    public GalleryMediaAlbumViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.albumadapterviewholder, parent, false);
        return new GalleryMediaAlbumViewHolder(view);
    }

    @Override
    public void onBindViewHolder(GalleryMediaAlbumViewHolder holder, int position) {

        try {
            holder.onBind(this.albumList.get(position));
        } catch (Exception e) {
            if (mContext instanceof LandingActivity)
                ((LandingActivity) mContext).writeCrashReport(
                        GalleryMediaAlbumAdapter.class.getName(),
                        e.getMessage()
                );
        }
    }

    @Override
    public int getItemCount() {
        return albumList.size();
    }

    class GalleryMediaAlbumViewHolder extends RecyclerView.ViewHolder {

        ImageView imageView;

        private TextView dirName, numberOfImages, numberOfVideos;

        GalleryMediaAlbumViewHolder(View itemView) {
            super(itemView);

            imageView = itemView.findViewById(R.id.albumcollageview);

            dirName = itemView.findViewById(R.id.albumName);

            numberOfImages = itemView.findViewById(R.id.numberOfalbumImageCount);

            numberOfVideos = itemView.findViewById(R.id.numberOfalbumVideoCount);
        }


        void onBind(final String albumName) throws Exception {

            dirName.setText(albumName);

            GalleryAlbumList albumIMageModels = albumListHashMap.get(albumName);
            if (albumIMageModels != null) {

                numberOfImages.setText(String.valueOf(albumIMageModels.getImageCount()));
                numberOfVideos.setText(String.valueOf(albumIMageModels.getVideoCount()));

                File file = new File(albumIMageModels.getFirstImagePath());

                Glide.with(mContext)
                        .load(file)
                        .asBitmap()
                        .placeholder(mContext.getResources().getDrawable(R.drawable.dn_preloader_gardient))
                        .into(imageView);

                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        try {
                            Bundle bundle = new Bundle();
                            bundle.putString(Constants.FOLDERNAME, albumName);
                            Intent startAlbum = new Intent(mContext, AlbumDetailActivity.class);
                            startAlbum.putExtras(bundle);
                            mContext.startActivity(startAlbum);
                        } catch (Exception e) {
                            if (mContext instanceof LandingActivity) {
                                ((LandingActivity) mContext).writeCrashReport(
                                        GalleryMediaAlbumAdapter.class.getName(),
                                        e.getMessage()
                                );
                            }
                        }

                    }
                });

            }
        }

    }


}
