package com.dubuqu.dnAdapter.common;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.dubuqu.R;
import com.dubuqu.dnModels.commonModel.ActionConformationDialog;
import com.dubuqu.dnModels.responseModel.BlockedUserModel;
import com.dubuqu.dnRestServices.RestServiceController;
import com.dubuqu.dnRestServices.RestServiceProvider;
import com.dubuqu.dnUtils.RestServiceUtils;
import com.dubuqu.dnUtils.Utils;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import okhttp3.OkHttpClient;
import retrofit2.Retrofit;

/**
 * Created by Yogaraj subramanian on 13/2/18
 */

public class BlockListAdapter extends RecyclerView.Adapter<BlockListAdapter.BlockListViewHolder> {

    private Context context;

    private List<BlockedUserModel> blockedUserModels;

    private OnItemRemovedListner onItemRemovedListner;

    public BlockListAdapter(Context context, List<BlockedUserModel> blockedUserModels, OnItemRemovedListner onItemRemovedListner) {
        this.context = context;
        this.blockedUserModels = blockedUserModels;
        this.onItemRemovedListner = onItemRemovedListner;
    }

    @Override
    public BlockListViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.layout_block_list_viewholder, parent, false);
        return new BlockListViewHolder(view);
    }

    @Override
    public void onBindViewHolder(BlockListViewHolder holder, int position) {
        try {
            holder.onBind(position);
        } catch (Exception e) {
            Log.e(BlockListViewHolder.class.getName(), e.getMessage());
        }
    }

    @Override
    public int getItemCount() {
        return blockedUserModels.size();
    }

    class BlockListViewHolder extends RecyclerView.ViewHolder {

        CircleImageView circleImageView;

        TextView unBlockUser, userName;

        BlockListViewHolder(View itemView) {
            super(itemView);

            circleImageView = itemView.findViewById(R.id.blocklist_userprofile_imv);

            unBlockUser = itemView.findViewById(R.id.blocklist_unblock_txt);

            userName = itemView.findViewById(R.id.blocklist_username_txt);
        }

        public void onBind(final int position) throws Exception {

            final BlockedUserModel blockedUserModel = blockedUserModels.get(position);

            if (blockedUserModel != null) {
                setProfileImage(blockedUserModel.getUser_name(), blockedUserModel.getProfile_image());

                unBlockUser.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        new ActionConformationDialog(
                                context.getString(R.string.unblockuser),
                                "Are you sure you want to unblock\t\n\"" + blockedUserModel.getUser_name() + "\"\t?",
                                context,
                                new ActionConformationDialog.OnActionCOnformationListner() {
                                    @Override
                                    public void onConformed() {
                                        try {
                                            unBlockUser(blockedUserModel.getUser_identifier());
                                            blockedUserModels.remove(position);
                                            notifyDataSetChanged();
                                            onItemRemovedListner.onUserRemoved();
                                        } catch (Exception e) {
                                            Log.e(BlockListAdapter.class.getName(), e.getMessage());
                                        }
                                    }

                                    @Override
                                    public void onRejected() {

                                    }
                                });
                    }
                });
            }
        }

        private void unBlockUser(String userIdentifier) {
            try {
                String data = "{}";
                OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, context);
                Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
                RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
                RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
                mRetrofitCallBacks.unblockUser(userIdentifier);
            } catch (Exception e) {
                Log.e(BlockedUserModel.class.getName(), e.getMessage());
            }

        }

        private void setProfileImage(String userNameTxt, String profileUrl) throws Exception {
            final Drawable drawable = new BitmapDrawable(Utils.textAsBitmap(userNameTxt,
                    context));

            userName.setText(userNameTxt);

            if (Utils.isVaildString(profileUrl)) {

                ImageLoader.getInstance().displayImage(profileUrl,
                        circleImageView,
                        new ImageLoadingListener() {
                            @Override
                            public void onLoadingStarted(String imageUri, View view) {
                                circleImageView.setImageDrawable(drawable);
                            }

                            @Override
                            public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
                                circleImageView.setImageDrawable(drawable);
                            }

                            @Override
                            public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                                circleImageView.setImageBitmap(loadedImage);
                            }

                            @Override
                            public void onLoadingCancelled(String imageUri, View view) {
                                circleImageView.setImageDrawable(drawable);
                            }
                        });
            } else {
                circleImageView.setImageDrawable(drawable);
            }
        }
    }

    public interface OnItemRemovedListner {
        void onUserRemoved();
    }
}
