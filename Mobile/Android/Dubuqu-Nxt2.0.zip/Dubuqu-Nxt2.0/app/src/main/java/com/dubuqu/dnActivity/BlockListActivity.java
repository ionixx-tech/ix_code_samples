package com.dubuqu.dnActivity;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.dubuqu.R;
import com.dubuqu.dnAdapter.common.BlockListAdapter;
import com.dubuqu.dnModels.responseModel.BlockedUserModel;
import com.dubuqu.dnRestServices.RestServiceController;
import com.dubuqu.dnRestServices.RestServiceProvider;
import com.dubuqu.dnUtils.RestServiceUtils;

import java.util.ArrayList;
import java.util.List;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;

/**
 * Created by Yogaraj subramanian on 13/2/18
 */

public class BlockListActivity extends BaseActivity {

    RecyclerView recyclerView;

    View noBlockListAvailableTxt;

    LinearLayoutManager linearLayoutManager;

    BlockListAdapter blockListAdapter;

    List<BlockedUserModel> blockedUserModels = new ArrayList<>();

    int totalResourceCount = 0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blocklist);

        try {
            initlaizeViews();
        } catch (Exception e) {
            writeCrashReport(e.getMessage());
        }
    }

    private Context getInstance() {
        return this;
    }

    private void initlaizeViews() throws Exception {

        noBlockListAvailableTxt = findViewById(R.id.blocklist_noblocks_txt);

        recyclerView = findViewById(R.id.blocklist_list_rcv);

        linearLayoutManager = new LinearLayoutManager(getInstance());

        blockListAdapter = new BlockListAdapter(getInstance(), blockedUserModels, new BlockListAdapter.OnItemRemovedListner() {
            @Override
            public void onUserRemoved() {
                toogleView();
            }
        });

        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(blockListAdapter);

        initlaizeListners();
    }

    private void toogleView() {
        if (blockedUserModels != null && blockedUserModels.size() > 0) {
            recyclerView.setVisibility(View.VISIBLE);
            noBlockListAvailableTxt.setVisibility(View.GONE);
        } else {
            recyclerView.setVisibility(View.GONE);
            noBlockListAvailableTxt.setVisibility(View.VISIBLE);
        }
    }

    private void initlaizeListners() throws Exception {

        makeHttpRequest(0);

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (linearLayoutManager.findLastCompletelyVisibleItemPosition() == blockedUserModels.size() - 2 &&
                        totalResourceCount > blockedUserModels.size()) {
                    try {
                        makeHttpRequest(blockedUserModels.size());
                    } catch (Exception e) {
                        writeCrashReport(e.getMessage());
                    }
                }
            }
        });

        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void makeHttpRequest(int offset) throws Exception {
        String data = "{}";
        OkHttpClient okHttpClient = null;
        okHttpClient = RestServiceUtils.getHeader(data, getInstance());
        Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
        RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
        RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
        mRetrofitCallBacks.getBlockedUserList(new RestServiceController.ResponseCallBacks() {
            @Override
            public void onResponse(Object o) {
                if (o != null) {
                    List<BlockedUserModel> blockedUserModelList = (List<BlockedUserModel>) o;
                    if (blockedUserModelList.size() > 0) {
                        blockedUserModels.addAll(blockedUserModelList);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                blockListAdapter.notifyDataSetChanged();
                                toogleView();
                            }
                        });
                    }
                }
            }

            @Override
            public void onFailure(Object o) {

            }
        }, new RestServiceController.ResourceCountCallBack() {
            @Override
            public void mediaResponse(String count) {
                totalResourceCount = count == null ? 0 : Integer.parseInt(count);
            }
        }, offset);
    }

    /**
     * write log data if any error occurs at runtime
     *
     * @param data {@link String} the error message that need to be printed
     */
    private void writeCrashReport(String data) {
        super.writeCrashReport(BlockListActivity.class.getName(), data);
    }
}
