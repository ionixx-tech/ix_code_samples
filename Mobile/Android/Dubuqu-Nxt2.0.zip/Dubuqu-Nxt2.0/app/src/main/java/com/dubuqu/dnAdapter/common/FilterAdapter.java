package com.dubuqu.dnAdapter.common;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.dubuqu.R;
import com.dubuqu.dnConstants.FilterConstants;



/**
 * Created by Yogaraj subramanian on 22/1/18
 */

public class FilterAdapter extends RecyclerView.Adapter<FilterAdapter.FilterAdapterViewHolder> {

    Context context;

    String[] filters;

    String imagePath;

    Bitmap bitmap;

    FilterAdapterEventListener filterAdapterEventListener;

    public FilterAdapter(final Context context, final String imagePath, FilterAdapterEventListener filterAdapterEventListener) {

        this.context = context;

        filters = FilterConstants.EFFECT_CONFIGS;

        this.imagePath = imagePath;
        this.filterAdapterEventListener = filterAdapterEventListener;

        BitmapFactory.Options bmOptions = new BitmapFactory.Options();

        bitmap = BitmapFactory.decodeFile(imagePath, bmOptions);

        bitmap = Bitmap.createScaledBitmap(bitmap, 72, 72, true);
    }

    public interface FilterAdapterEventListener {
        void onClicked(String filter);
    }

    @Override
    public FilterAdapterViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.layout_filter_viewholder, parent, false);
        FilterAdapter.FilterAdapterViewHolder filterAdapterViewHolder = new FilterAdapterViewHolder(view);
        filterAdapterViewHolder.setIsRecyclable(false);
        return filterAdapterViewHolder;
    }

    @Override
    public void onBindViewHolder(FilterAdapterViewHolder holder, int position) {
        try {

            holder.onBind(position);
        } catch (Exception e) {
            Log.e(FilterAdapter.class.getName(), e.getMessage());
        }
    }

    @Override
    public long getItemId(int position) {
        return filters[position].hashCode();
    }

    @Override
    public int getItemViewType(int position) {
        return filters[position].hashCode();
    }

    @Override
    public int getItemCount() {
        return filters.length;
    }

    class FilterAdapterViewHolder extends RecyclerView.ViewHolder {

        private ImageView mImageView;

        public FilterAdapterViewHolder(View itemView) {
            super(itemView);
            mImageView = itemView.findViewById(R.id.filter_imageview);
        }

        void onBind(final int postion) throws Exception {

//            Bitmap dstImage = CGENativeLibrary.filterImage_MultipleEffects(bitmap,
//                    filters[postion], 1.0f);
//
//            mImageView.setImageBitmap(dstImage);
//
//            itemView.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    filterAdapterEventListener.onClicked(filters[postion]);
//                }
//            });
        }
    }
}
