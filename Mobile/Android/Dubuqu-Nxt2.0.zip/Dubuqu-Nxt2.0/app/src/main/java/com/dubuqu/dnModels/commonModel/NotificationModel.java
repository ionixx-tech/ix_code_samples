
package com.dubuqu.dnModels.commonModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class NotificationModel {

    @SerializedName("notification_id")
    @Expose
    private String notificationId;
    @SerializedName("title")
    @Expose
    private String title;
    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("type")
    @Expose
    private String type;
    @SerializedName("user_identifier")
    @Expose
    private String userIdentifier;
    @SerializedName("media_identifier")
    @Expose
    private String mediaIdentifier;
    @SerializedName("group_identifier")
    @Expose
    private String groupIdentifier;
    @SerializedName("timeline_identifier")
    @Expose
    private String timelineIdentifier;
    @SerializedName("comment_identifier")
    @Expose
    private String commentIdentifier;
    @SerializedName("created_stamp")
    @Expose
    private String createdStamp;

    @SerializedName("thumbnail_signed_url")
    @Expose
    private String signedUrl;

    @SerializedName("read_notification")
    private String isNotificationRead;

    public String getIsNotificationRead() {
        return isNotificationRead;
    }

    public void setIsNotificationRead(String isNotificationRead) {
        this.isNotificationRead = isNotificationRead;
    }

    public String getSignedUrl() {
        return signedUrl;
    }

    public void setSignedUrl(String signedUrl) {
        this.signedUrl = signedUrl;
    }

    public String getNotificationId() {
        return notificationId;
    }

    public void setNotificationId(String notificationId) {
        this.notificationId = notificationId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUserIdentifier() {
        return userIdentifier;
    }

    public void setUserIdentifier(String userIdentifier) {
        this.userIdentifier = userIdentifier;
    }

    public String getMediaIdentifier() {
        return mediaIdentifier;
    }

    public void setMediaIdentifier(String mediaIdentifier) {
        this.mediaIdentifier = mediaIdentifier;
    }

    public String getGroupIdentifier() {
        return groupIdentifier;
    }

    public void setGroupIdentifier(String groupIdentifier) {
        this.groupIdentifier = groupIdentifier;
    }

    public String getTimelineIdentifier() {
        return timelineIdentifier;
    }

    public void setTimelineIdentifier(String timelineIdentifier) {
        this.timelineIdentifier = timelineIdentifier;
    }

    public String getCommentIdentifier() {
        return commentIdentifier;
    }

    public void setCommentIdentifier(String commentIdentifier) {
        this.commentIdentifier = commentIdentifier;
    }

    public String getCreatedStamp() {
        return createdStamp;
    }

    public void setCreatedStamp(String createdStamp) {
        this.createdStamp = createdStamp;
    }


}
