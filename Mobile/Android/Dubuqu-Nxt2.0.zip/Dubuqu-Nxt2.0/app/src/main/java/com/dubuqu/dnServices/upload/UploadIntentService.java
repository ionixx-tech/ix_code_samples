package com.dubuqu.dnServices.upload;

import android.app.IntentService;
import android.content.Intent;
import android.support.annotation.Nullable;

/**
 * Created by Yogaraj subramanian on 15/12/17
 */

public class UploadIntentService extends IntentService {

    public UploadIntentService() {
        super(UploadIntentService.class.getName());
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {

    }
}
