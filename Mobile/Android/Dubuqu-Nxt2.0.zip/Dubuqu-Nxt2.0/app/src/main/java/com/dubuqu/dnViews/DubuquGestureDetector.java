package com.dubuqu.dnViews;

import android.support.v4.view.GestureDetectorCompat;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View; /**
 * Created by Yogaraj subramanian on 7/9/17
 */

/**
 * Get Gestures that user has made for more details visit the quoted text.
 * <p>
 * https://developer.android.com/training/gestures/detector.html
 */

public class DubuquGestureDetector implements GestureDetector.OnGestureListener,
        GestureDetector.OnDoubleTapListener, View.OnTouchListener {


    private final float MIN_DISTANCE = 150;

    View view;

    GestureDetectorCompat gestureDetectorCompat;

    GesturesMade gesturesMade;

    private float downXValue, downYValue;

    float mDist = 0;

    public interface GesturesMade {
        void flignedRight();

        void flignedLeft();

        void flignedTop();

        void flignedBottom();

        void taped(MotionEvent motionEvent);

        void doubleTapped();

        void longPressed();

        void onPinchPanned(MotionEvent event);
    }

    /**
     * Set the view which gestures need to be detected.
     *
     * @param view {@link View} the view need to be linked
     * @throws Exception any exception may be thrown.
     */
    public void setGestures(View view, GesturesMade gesturesMade) throws Exception {

        gestureDetectorCompat = new GestureDetectorCompat(view.getContext(), this);
        // Set the gesture detector as the double tap
        // listener.
        gestureDetectorCompat.setOnDoubleTapListener(this);
        view.setOnTouchListener(this);

        this.gesturesMade = gesturesMade;
    }

    @Override
    public boolean onSingleTapConfirmed(MotionEvent e) {
        gesturesMade.taped(e);
        return false;
    }

    @Override
    public boolean onDoubleTap(MotionEvent e) {
        gesturesMade.doubleTapped();
        return false;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onDown(MotionEvent event) {
        downXValue = event.getX();
        downYValue = event.getY();
        return false;
    }

    @Override
    public void onShowPress(MotionEvent e) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent e) {

        return false;
    }

    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
        return false;
    }

    @Override
    public void onLongPress(MotionEvent e) {
        gesturesMade.longPressed();
    }

    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
        // Get the X value when the user released his/her finger
        float currentX = e2.getX();
        float currentY = e2.getY();
        // check if horizontal or vertical movement was bigger

        if (Math.abs(downXValue - currentX) > Math.abs(downYValue
                - currentY)) {
            // going backwards: pushing stuff to the right
            if (downXValue < currentX) {
                gesturesMade.flignedRight();
            }

            // going forwards: pushing stuff to the left
            if (downXValue > currentX) {
                gesturesMade.flignedLeft();
            }

        } else {
            if (downYValue < currentY) {
                gesturesMade.flignedBottom();
            }
            if (downYValue > currentY) {
                gesturesMade.flignedTop();
            }
        }

        return false;
    }


    @Override
    public boolean onTouch(View v, MotionEvent event) {
        int action = event.getAction();

        if (event.getPointerCount() > 1) {
            // handle multi-touch events
            if (action == MotionEvent.ACTION_POINTER_DOWN) {
                mDist = getFingerSpacing(event);
            } else if (action == MotionEvent.ACTION_MOVE) {
                gesturesMade.onPinchPanned(event);
            }
        }
        this.gestureDetectorCompat.onTouchEvent(event);
        return true;
    }

    /**
     * Determine the space between the first two fingers
     */
    private float getFingerSpacing(MotionEvent event) {
        // ...
        float x = event.getX(0) - event.getX(1);
        float y = event.getY(0) - event.getY(1);
        return (float) Math.sqrt(x * x + y * y);
    }
}
