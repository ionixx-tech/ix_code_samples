package com.dubuqu.dnActivity.mediapreview;

import android.animation.Animator;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.dubuqu.R;
import com.dubuqu.dnActivity.BaseActivity;
import com.dubuqu.dnAdapter.common.ColorPickerAdapter;
import com.dubuqu.dnAdapter.common.DubuquMediaAdapter;
import com.dubuqu.dnAdapter.common.FilterAdapter;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnModels.commonModel.ActionConformationDialog;
import com.dubuqu.dnServices.MediaDeleteService;
import com.dubuqu.dnStorage.DbHelper;
import com.dubuqu.dnStorage.RecentShareDbModel;
import com.dubuqu.dnUtils.Utils;
import com.dubuqu.dnViews.DubuquViewPager;
import com.github.chrisbanes.photoview.PhotoView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;
import com.yalantis.ucrop.UCrop;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import vc908.stickerfactory.ui.OnStickerSelectedListener;
import vc908.stickerfactory.ui.fragment.StickersFragment;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

/**
 * Created by Yogaraj subramanian on 31/10/17
 */

public class DubuquMediaViewerActivity extends BaseActivity implements OnStickerSelectedListener {

    private final String TAG = DubuquMediaViewerActivity.class.getName();

    private DubuquViewPager viewPager;

    private List<String> mediaList = new ArrayList<>();

    private HashMap<Integer, DubuquMediaAdapter.DubuquMediaAdapterViewHolder> viewDubuquMediaAdapterViewHolderHashMap
            = new HashMap<>();

    private int initalImageUrl = 0;

    private View toolBarView, bottomBarView, collorPallete;

    private ImageView emojiImageView, drawOverImageView, closeView, addTextImageView,
            cropImageView, deleteMediaView, quickShareuserOneImv, quickShareuserTwoImv,
            quickShareuserThreeImv, shareMediaToOtherApps, filterView;

    private TextView saveEditedMedia, eraseDrawwView, finishDrawView,
            quickShareUserOneTv, quickShareUserTwoTv, quickShareUserThreeTv;

    private FrameLayout emojiFrameLayout;

    private LinearLayout quickShareOptions, editImageOptions, showMoreContacts;

    private DubuquMediaAdapter dubuquMediaAdapter;

    private ArrayList<Integer> colorPickerColors = new ArrayList<>();

    int colorCodeValue = -1;

    RecyclerView addFilterRecyclerView;

    PopupWindow pop;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            hideNavigationAndToolBars();

            setContentView(R.layout.dubuqu_media_viewr_view);

            Bundle bundle = getIntent().getExtras();

            String mediaListString = bundle.getString(Constants.EXTRASTRINGS);

            initalImageUrl = bundle.getInt(Constants.CURRENTIMAGE) - 1;

            mediaList = new Gson().fromJson(mediaListString, new TypeToken<List<String>>() {
            }.getType());

            initializeViews();

        } catch (Exception e) {
            super.writeCrashReport(TAG, e.getMessage());
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        registerReceiver(onAllMediaDeleted, new IntentFilter(Constants.ALLMEDIADELETED));

        registerReceiver(updateRecentShare, new IntentFilter(Constants.UPDATERECENTSHARE));

        if (Constants.RESTRICT_SREENSHOT)
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);

        if (hasFocus) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(onAllMediaDeleted);
        unregisterReceiver(updateRecentShare);
    }

    BroadcastReceiver updateRecentShare = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            try {
                updateUserForQuickShare();
            } catch (Exception e) {
                Log.e(TAG, e.getMessage());
            }
        }
    };

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK && requestCode == UCrop.REQUEST_CROP) {

            final Uri resultUri = UCrop.getOutput(data);

            DubuquMediaAdapter.DubuquMediaAdapterViewHolder dubuquViewHolder =
                    viewDubuquMediaAdapterViewHolderHashMap.get(viewPager.getCurrentItem());

            if (dubuquViewHolder != null) {
                try {
                    dubuquViewHolder.cropImage(resultUri);
                } catch (Exception e) {
                    DubuquMediaViewerActivity.super.writeCrashReport(TAG, e.getMessage());
                }
            }

        } else if (resultCode == UCrop.RESULT_ERROR) {
            final Throwable cropError = UCrop.getError(data);
        }
    }


    /**
     * Hide System UI like Action Bar and Navigation Bars
     *
     * @throws Exception {@link Exception}
     */
    private void hideNavigationAndToolBars() throws Exception {
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
    }


    private void initializeViews() throws Exception {

        viewPager = findViewById(R.id.dubuqu_media_viewer_viewpager);

        collorPallete = findViewById(R.id.color_pallete);
        collorPallete.setVisibility(GONE);

        filterView = findViewById(R.id.dubuqu_media_viewer_filter);

        addFilterRecyclerView = findViewById(R.id.add_filters_recyclerView);
        addFilterRecyclerView.setVisibility(GONE);

        dubuquMediaAdapter = new DubuquMediaAdapter(mediaList, DubuquMediaViewerActivity.this,
                new DubuquMediaAdapter.OnItemClick() {
                    @Override
                    public void onItemClicked(int position) {

                        String currentPath = mediaList.get(position);

                        if (addFilterRecyclerView.getVisibility() != VISIBLE) {

                            if (Utils.getContentType(currentPath).contains("video")
                                    || Utils.getContentType(currentPath).contains("gif")) {
                                try {
                                    toogleTopAndBottomView(true);
                                } catch (Exception e) {
                                    DubuquMediaViewerActivity.super.writeCrashReport(TAG, e.getMessage());
                                }
                            } else {
                                try {
                                    toogleTopAndBottomView(false);
                                } catch (Exception e) {
                                    DubuquMediaViewerActivity.super.writeCrashReport(TAG, e.getMessage());
                                }
                            }
                        }
                    }

                    @Override
                    public void onEdittextChangeListener(String text, int colorCode) {
                        openAddTextPopupWindow(text, colorCode);
                    }

                    @Override
                    public void setOnEditMode(boolean isInEditMode) throws Exception {
                        if (!checkIfDrawViewEnabled())
                            setEditModeoptions(isInEditMode);
                    }

                    @Override
                    public void onNewViewAdded(Integer position,
                                               DubuquMediaAdapter.DubuquMediaAdapterViewHolder dubuquMediaAdapterViewHolder) throws Exception {
                        viewDubuquMediaAdapterViewHolderHashMap.put(position, dubuquMediaAdapterViewHolder);
                    }

                    @Override
                    public void onImageSaved() {
                        try {
                            toogleToolbars(false);
                            hideTopandBottomView();
                            sendBroadcast(new Intent(Constants.MEDIAITEMCHANGED));
                            sendBroadcast(new Intent(Constants.MEDIAALBUMLISTCHANGED));
                            setEditModeoptions(false);
                        } catch (Exception e) {
                            DubuquMediaViewerActivity.super.writeCrashReport(TAG, e.getMessage());
                        }
                    }

                    @Override
                    public void onItemMoved(boolean isItemMoved) {
                        if (isItemMoved) {
                            try {
                                hideTopandBottomView();
                            } catch (Exception e) {
                                DubuquMediaViewerActivity.super.writeCrashReport(TAG, e.getMessage());
                            }
                        } else {

                            try {
                                toogleTopAndBottomView(false);
                            } catch (Exception e) {
                                DubuquMediaViewerActivity.super.writeCrashReport(TAG, e.getMessage());
                            }
                        }

                    }

                    @Override
                    public void onViewRemoved(int position) {
                        viewDubuquMediaAdapterViewHolderHashMap.remove(position);
                    }
                });

        viewPager.setAdapter(dubuquMediaAdapter);

        viewPager.setCurrentItem(initalImageUrl);

        bottomBarView = findViewById(R.id.dubuqu_media_viewer_bottomview);
        bottomBarView.setVisibility(GONE);

        toolBarView = findViewById(R.id.dubuqu_media_viewer_toolbar);
        toolBarView.setVisibility(GONE);

        emojiImageView = findViewById(R.id.dubuqu_media_viewer_smiley);

        emojiFrameLayout = findViewById(R.id.dubuqu_media_viewer_load_stickers);
        emojiFrameLayout.setVisibility(GONE);

        drawOverImageView = findViewById(R.id.dubuqu_media_viewer_draw);

        quickShareOptions = findViewById(R.id.quick_share_options);

        editImageOptions = findViewById(R.id.edit_image_options);

        saveEditedMedia = findViewById(R.id.dubuqu_media_viewer_save);

        finishDrawView = findViewById(R.id.dubuqu_media_viewer_finish_draw);

        eraseDrawwView = findViewById(R.id.dubuqu_media_viewer_erase_drawing);
        eraseDrawwView.setVisibility(GONE);

        closeView = findViewById(R.id.dubuqu_media_viewer_toolbar_back);

        addTextImageView = findViewById(R.id.dubuqu_media_viewer_add_text);

        cropImageView = findViewById(R.id.dubuqu_media_viewer_crop);

        deleteMediaView = findViewById(R.id.dubuqu_media_viewer_delete_medias);

        quickShareuserOneImv = findViewById(R.id.rcntprofileone);

        quickShareUserOneTv = findViewById(R.id.rcntusernameone);

        quickShareuserTwoImv = findViewById(R.id.rcntuserprofiletwo);

        quickShareUserTwoTv = findViewById(R.id.rcntusernametwo);

        quickShareuserThreeImv = findViewById(R.id.rcntuserProfilethree);

        quickShareUserThreeTv = findViewById(R.id.rcntusernamethree);

        showMoreContacts = findViewById(R.id.showMoreContacts);

        shareMediaToOtherApps = findViewById(R.id.dubuqu_media_viewer_external_share);

        addColorValues();

        updateUserForQuickShare();

        initalizeStickerPanel();

        intializeListener();
    }

    private void intializeListener() throws Exception {

        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                try {
                    resetAdapterView(position);
                    hideTopandBottomView();
                } catch (Exception e) {
                    DubuquMediaViewerActivity.super.writeCrashReport(TAG, e.getMessage());
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        emojiImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    setEditModeoptions(true);
                    showEmojiList();
                    disableDrawView();
                    Utils.addReppleEffectToview(DubuquMediaViewerActivity.this, view);
                } catch (Exception e) {
                    DubuquMediaViewerActivity.super.writeCrashReport(TAG, e.getMessage());
                }
            }
        });

        drawOverImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    setEditModeoptions(true);
                    enableDrawView();
                    Utils.addReppleEffectToview(DubuquMediaViewerActivity.this, view);
                    collorPallete.setVisibility(View.VISIBLE);
                    initializeColorPalleteAndFilter(true);
                } catch (Exception e) {
                    DubuquMediaViewerActivity.super.writeCrashReport(TAG, e.getMessage());
                }
            }
        });

        eraseDrawwView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    Utils.addReppleEffectToview(DubuquMediaViewerActivity.this, view);
                    clearAllTobos();
                } catch (Exception e) {
                    DubuquMediaViewerActivity.super.writeCrashReport(TAG, e.getMessage());
                }

            }
        });

        filterView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    setEditModeoptions(true);
                    enableFilterMode();
                    collorPallete.setVisibility(View.VISIBLE);
                    initializeColorPalleteAndFilter(false);
                } catch (Exception e) {
                    writeCrashReport(TAG, e.getMessage());
                }
            }
        });

        shareMediaToOtherApps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    Utils.addReppleEffectToview(DubuquMediaViewerActivity.this, view);
                    int currentView = viewPager.getCurrentItem();
                    shareMediaToExternalApps(mediaList.get(currentView));

                } catch (Exception e) {
                    DubuquMediaViewerActivity.super.writeCrashReport(TAG, e.getMessage());
                }
            }
        });

        finishDrawView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (addFilterRecyclerView.getVisibility() == VISIBLE) {
                        disableFilterView();
                    } else {
                        disableDrawView();
                    }
                    Utils.addReppleEffectToview(DubuquMediaViewerActivity.this, view);
                } catch (Exception e) {
                    DubuquMediaViewerActivity.super.writeCrashReport(TAG, e.getMessage());
                }
            }
        });

        closeView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    onBackPressed();
                } catch (Exception e) {
                    DubuquMediaViewerActivity.super.writeCrashReport(TAG, e.getMessage());
                }
            }
        });

        addTextImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    setEditModeoptions(true);
                    disableFilterView();
                    openAddTextPopupWindow("", -1);
                    Utils.addReppleEffectToview(DubuquMediaViewerActivity.this, view);
                } catch (Exception e) {
                    DubuquMediaViewerActivity.super.writeCrashReport(TAG, e.getMessage());
                }

            }
        });


        saveEditedMedia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    saveEditedImage();
                    Utils.addReppleEffectToview(DubuquMediaViewerActivity.this, view);
                } catch (Exception e) {
                    DubuquMediaViewerActivity.super.writeCrashReport(TAG, e.getMessage());
                }
            }
        });

        cropImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    setEditModeoptions(true);
                    disableDrawView();
                    cropImage();
                    Utils.addReppleEffectToview(DubuquMediaViewerActivity.this, view);
                } catch (Exception e) {
                    DubuquMediaViewerActivity.super.writeCrashReport(TAG, e.getMessage());
                }
            }
        });


        deleteMediaView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    Utils.addReppleEffectToview(DubuquMediaViewerActivity.this, view);
                    showDeleteMediaConformation();
                } catch (Exception e) {
                    DubuquMediaViewerActivity.super.writeCrashReport(TAG, e.getMessage());
                }
            }
        });

        showMoreContacts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                DubuquMediaAdapter.DubuquMediaAdapterViewHolder dubuquViewHolder =
                        viewDubuquMediaAdapterViewHolderHashMap.get(viewPager.getCurrentItem());

                if (dubuquViewHolder != null) {
                    try {
                        dubuquViewHolder.openMultiShareActivity();
                    } catch (Exception e) {
                        DubuquMediaViewerActivity.super.writeCrashReport(TAG, e.getMessage());
                    }
                }

            }
        });

        quickShareuserOneImv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    Utils.addReppleEffectToview(DubuquMediaViewerActivity.this, view);
                    shareMediaToFregquentUsers(0);
                } catch (Exception e) {
                    DubuquMediaViewerActivity.super.writeCrashReport(TAG, e.getMessage());
                }
            }
        });

        quickShareuserTwoImv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    Utils.addReppleEffectToview(DubuquMediaViewerActivity.this, view);
                    shareMediaToFregquentUsers(1);
                } catch (Exception e) {
                    DubuquMediaViewerActivity.super.writeCrashReport(TAG, e.getMessage());
                }
            }
        });

        quickShareuserThreeImv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    Utils.addReppleEffectToview(DubuquMediaViewerActivity.this, view);
                    shareMediaToFregquentUsers(2);
                } catch (Exception e) {
                    DubuquMediaViewerActivity.super.writeCrashReport(TAG, e.getMessage());
                }
            }
        });


    }

    private void shareMediaToFregquentUsers(int position) throws Exception {
        DbHelper dbHelper = new DbHelper(DubuquMediaViewerActivity.this);
        List<RecentShareDbModel> recentShareDbModels = dbHelper.getAllRecentusers();
        if (recentShareDbModels != null) {

            RecentShareDbModel recentShareDbModel = recentShareDbModels.get(position);

            List<String> selectedUsers = new ArrayList<>();
            selectedUsers.add(recentShareDbModel.getIdentifier());

            DubuquMediaAdapter.DubuquMediaAdapterViewHolder dubuquViewHolder =
                    viewDubuquMediaAdapterViewHolderHashMap.get(viewPager.getCurrentItem());

            if (dubuquViewHolder != null) {
                dubuquViewHolder.shareMediaToFrequentUssers(selectedUsers);
            }

        }
    }

    private void cropImage() throws Exception {
        String destinationFileName = String.valueOf(System.currentTimeMillis());
        destinationFileName += ".png";

        UCrop uCrop = UCrop.of(Uri.fromFile(new File(mediaList.get(viewPager.getCurrentItem())))
                , Uri.fromFile(new File(getCacheDir(), destinationFileName)));
        UCrop.Options options = new UCrop.Options();
        options.setCompressionFormat(Bitmap.CompressFormat.PNG);
        options.setCompressionQuality(100);
        options.setHideBottomControls(false);
        options.setFreeStyleCropEnabled(true);
        options.setStatusBarColor(getResources().getColor(R.color.colorPrimaryDark));
        options.setToolbarColor(getResources().getColor(R.color.colorPrimary));
        options.setActiveWidgetColor(getResources().getColor(R.color.colorPrimary));
        uCrop.withOptions(options);
        //uCrop = basisConfig(uCrop);
        //uCrop = advancedConfig(uCrop);
        uCrop.start(DubuquMediaViewerActivity.this);


    }

    private void saveEditedImage() throws Exception {

        DubuquMediaAdapter.DubuquMediaAdapterViewHolder dubuquViewHolder =
                viewDubuquMediaAdapterViewHolderHashMap.get(viewPager.getCurrentItem());

        if (dubuquViewHolder != null) {
            dubuquViewHolder.saveImage();
        }
        addFilterRecyclerView.setVisibility(GONE);
    }


    /**
     * Show Toolbar view and bottom view  based on  mimetype of media
     *
     * @param isVideo if is video dont show bottom view
     * @throws Exception {@link Exception} Runtime Stub Excepion
     */
    private void toogleTopAndBottomView(boolean isVideo) throws Exception {
        if (isVideo) {
            bottomBarView.setVisibility(GONE);
            if (toolBarView.getVisibility() == View.VISIBLE) {

                YoYo.with(Techniques.SlideOutUp)
                        .duration(Constants.ANIMATIONTIME)
                        .onEnd(new YoYo.AnimatorCallback() {
                            @Override
                            public void call(Animator animator) {
                                toolBarView.setVisibility(GONE);
                            }
                        })
                        .playOn(toolBarView);
            } else {
                toolBarView.setVisibility(View.VISIBLE);
                YoYo.with(Techniques.SlideInDown)
                        .duration(Constants.ANIMATIONTIME)
                        .playOn(toolBarView);
            }

        } else {
            if (toolBarView.getVisibility() == View.VISIBLE) {

                YoYo.with(Techniques.SlideOutUp)
                        .duration(Constants.ANIMATIONTIME)
                        .onEnd(new YoYo.AnimatorCallback() {
                            @Override
                            public void call(Animator animator) {
                                toolBarView.setVisibility(GONE);
                            }
                        })
                        .playOn(toolBarView);
            } else {
                toolBarView.setVisibility(View.VISIBLE);
                YoYo.with(Techniques.SlideInDown)
                        .duration(Constants.ANIMATIONTIME)
                        .playOn(toolBarView);
            }

            if (bottomBarView.getVisibility() == View.VISIBLE) {

                YoYo.with(Techniques.SlideOutDown)
                        .duration(Constants.ANIMATIONTIME)
                        .onEnd(new YoYo.AnimatorCallback() {
                            @Override
                            public void call(Animator animator) {
                                bottomBarView.setVisibility(GONE);
                            }
                        })
                        .playOn(bottomBarView);
            } else {
                bottomBarView.setVisibility(View.VISIBLE);
                YoYo.with(Techniques.SlideInUp)
                        .duration(Constants.ANIMATIONTIME)
                        .playOn(bottomBarView);
            }
        }

    }

    /**
     * On page scroll the image must be un zoomed if the  view is previously zoomed or not.
     *
     * @param position the current position of the view.
     * @throws Exception {Runtime Stub Exception}
     */
    private void resetAdapterView(int position) throws Exception {

        if (position > 0) {
            View currentView = viewPager.getChildAt(position);
            View lastView = viewPager.getChildAt(position - 1);
            View previousView = viewPager.getChildAt(position + 1);

            /*if (currentView != null) {
                SubsamplingScaleImageView img = currentView.findViewById(R.id.dubuqu_media_adapter_imageview);
                img.resetScaleAndCenter();
            }*/

            if (lastView != null) {
                PhotoView img = lastView.findViewById(R.id.dubuqu_media_adapter_imageview);
                img.setDisplayMatrix(new Matrix());
            }

            if (previousView != null) {
                PhotoView img = previousView.findViewById(R.id.dubuqu_media_adapter_imageview);
                img.setDisplayMatrix(new Matrix());
            }
        }
    }

    /**
     * Hide ToolbarView and Bottom View on each page scroll
     *
     * @throws Exception {Runtime Sub Exception}
     */
    private void hideTopandBottomView() throws Exception {
        if (toolBarView.getVisibility() == View.VISIBLE) {

            YoYo.with(Techniques.SlideOutUp)
                    .duration(Constants.ANIMATIONTIME)
                    .onEnd(new YoYo.AnimatorCallback() {
                        @Override
                        public void call(Animator animator) {
                            toolBarView.setVisibility(GONE);
                        }
                    })
                    .playOn(toolBarView);
        }

        if (bottomBarView.getVisibility() == View.VISIBLE) {

            YoYo.with(Techniques.SlideOutDown)
                    .duration(Constants.ANIMATIONTIME)
                    .onEnd(new YoYo.AnimatorCallback() {
                        @Override
                        public void call(Animator animator) {
                            bottomBarView.setVisibility(GONE);
                        }
                    })
                    .playOn(bottomBarView);
        }
    }


    private void setEditModeoptions(boolean isInEditMode) throws Exception {
        toogleToolbars(isInEditMode);
        if (isInEditMode) {
            viewPager.setPagingEnabled(false);
        } else {
            viewPager.setPagingEnabled(true);
        }

    }

    private void showEmojiList() throws Exception {
        emojiFrameLayout.setVisibility(View.VISIBLE);
        YoYo.with(Techniques.SlideInUp)
                .duration(Constants.ANIMATIONTIME)
                .playOn(emojiFrameLayout);
    }

    private void closeEmojiList() throws Exception {

        YoYo.with(Techniques.SlideOutDown)
                .duration(Constants.ANIMATIONTIME)
                .onEnd(new YoYo.AnimatorCallback() {
                    @Override
                    public void call(Animator animator) {
                        emojiFrameLayout.setVisibility(GONE);
                    }
                })
                .playOn(emojiFrameLayout);
    }

    private void initalizeStickerPanel() throws Exception {
        StickersFragment stickersFragment = new StickersFragment();
        stickersFragment.setOnStickerSelectedListener(this);
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.add(emojiFrameLayout.getId(), stickersFragment);
        fragmentTransaction.commit();
    }

    private void enableFilterMode() throws Exception {
        DubuquMediaAdapter.DubuquMediaAdapterViewHolder dubuquViewHolder =
                viewDubuquMediaAdapterViewHolderHashMap.get(viewPager.getCurrentItem());

        saveEditedMedia.setVisibility(View.VISIBLE);
        eraseDrawwView.setVisibility(View.GONE);
        finishDrawView.setVisibility(View.GONE);
        bottomBarView.setVisibility(VISIBLE);
        toolBarView.setVisibility(VISIBLE);

        if (dubuquViewHolder != null) {
            try {
                dubuquViewHolder.setFilterMode();
            } catch (Exception e) {
                DubuquMediaViewerActivity.super.writeCrashReport(TAG, e.getMessage());
            }
        }
    }

    private void enableDrawView() throws Exception {

        DubuquMediaAdapter.DubuquMediaAdapterViewHolder dubuquViewHolder =
                viewDubuquMediaAdapterViewHolderHashMap.get(viewPager.getCurrentItem());

        saveEditedMedia.setVisibility(GONE);
        eraseDrawwView.setVisibility(View.VISIBLE);
        finishDrawView.setVisibility(View.VISIBLE);
        bottomBarView.setVisibility(GONE);
        addFilterRecyclerView.setVisibility(GONE);

        if (dubuquViewHolder != null) {
            try {
                dubuquViewHolder.updateBrushDrawingView(true);
            } catch (Exception e) {
                DubuquMediaViewerActivity.super.writeCrashReport(TAG, e.getMessage());
            }
        }

    }

    private void disableFilterView() throws Exception {
        saveEditedMedia.setVisibility(View.VISIBLE);
        eraseDrawwView.setVisibility(GONE);
        finishDrawView.setVisibility(GONE);
        collorPallete.setVisibility(GONE);
        addFilterRecyclerView.setVisibility(GONE);
    }

    private void disableDrawView() throws Exception {
        saveEditedMedia.setVisibility(View.VISIBLE);
        eraseDrawwView.setVisibility(GONE);
        finishDrawView.setVisibility(GONE);
        collorPallete.setVisibility(GONE);
        addFilterRecyclerView.setVisibility(GONE);
        bottomBarView.setVisibility(View.VISIBLE);
        DubuquMediaAdapter.DubuquMediaAdapterViewHolder dubuquViewHolder =
                viewDubuquMediaAdapterViewHolderHashMap.get(viewPager.getCurrentItem());

        if (dubuquViewHolder != null) {
            try {
                dubuquViewHolder.updateBrushDrawingView(false);
            } catch (Exception e) {
                DubuquMediaViewerActivity.super.writeCrashReport(TAG, e.getMessage());
            }
        }
    }

    private void clearAllTobos() throws Exception {

        saveEditedMedia.setVisibility(View.VISIBLE);
        eraseDrawwView.setVisibility(GONE);
        finishDrawView.setVisibility(GONE);
        collorPallete.setVisibility(GONE);
        bottomBarView.setVisibility(View.VISIBLE);
        addFilterRecyclerView.setVisibility(GONE);

        DubuquMediaAdapter.DubuquMediaAdapterViewHolder dubuquViewHolder =
                viewDubuquMediaAdapterViewHolderHashMap.get(viewPager.getCurrentItem());

        if (dubuquViewHolder != null) {
            try {
                dubuquViewHolder.updateBrushDrawingView(false);
                dubuquViewHolder.clearAllBrushView();
            } catch (Exception e) {
                DubuquMediaViewerActivity.super.writeCrashReport(TAG, e.getMessage());
            }
        }
    }

    /**
     * If all the stickers are removed and user has drawn any text the editImage Options need to
     * be displayed.
     *
     * @return true or false.
     * @throws Exception {RunTime Exception}
     */
    private boolean checkIfDrawViewEnabled() throws Exception {
        saveEditedMedia.setVisibility(View.VISIBLE);
        eraseDrawwView.setVisibility(GONE);
        finishDrawView.setVisibility(GONE);
        DubuquMediaAdapter.DubuquMediaAdapterViewHolder dubuquViewHolder =
                viewDubuquMediaAdapterViewHolderHashMap.get(viewPager.getCurrentItem());

        if (dubuquViewHolder != null) {
            return dubuquViewHolder.brushDrawingView.getVisibility() == View.VISIBLE;
        }

        return false;
    }

    private boolean checkifViewAdded() {
        DubuquMediaAdapter.DubuquMediaAdapterViewHolder dubuquViewHolder =
                viewDubuquMediaAdapterViewHolderHashMap.get(viewPager.getCurrentItem());

        if (dubuquViewHolder != null) {
            return dubuquViewHolder.checkIfAnyViewAvailable();
        }

        return false;
    }

    /**
     * toogle tool bar options base on user mode.
     *
     * @param isInEditMode indicated that user has edited the image
     * @throws Exception {Runtime Stub Exception}
     */
    private void toogleToolbars(boolean isInEditMode) throws Exception {

        if (isInEditMode) {
            editImageOptions.setVisibility(View.VISIBLE);
            quickShareOptions.setVisibility(GONE);
        } else {
            editImageOptions.setVisibility(GONE);
            quickShareOptions.setVisibility(View.VISIBLE);
        }
    }

    /**
     * clear all views that user has edited.
     *
     * @throws Exception {Runtime Stub Exception}
     */
    private void clearEditing() throws Exception {
        DubuquMediaAdapter.DubuquMediaAdapterViewHolder dubuquViewHolder =
                viewDubuquMediaAdapterViewHolderHashMap.get(viewPager.getCurrentItem());

        if (dubuquViewHolder != null) {
            dubuquViewHolder.clearView();
            toogleToolbars(false);
            hideTopandBottomView();
        }
    }


    private void showDeleteMediaConformation() throws Exception {

        new ActionConformationDialog(
                getString(R.string.delete_media),
                getString(R.string.confirm_delete),
                DubuquMediaViewerActivity.this,
                new ActionConformationDialog.OnActionCOnformationListner() {
                    @Override
                    public void onConformed() {
                        try {
                            deleteSeleteImage();
                        } catch (Exception e) {
                            DubuquMediaViewerActivity.super.writeCrashReport(TAG, e.getMessage());
                        }
                    }

                    @Override
                    public void onRejected() {

                    }
                });
    }

    /**
     * delete current media from the gallery
     *
     * @throws Exception {Runtime Stub Exception}
     */
    private void deleteSeleteImage() throws Exception {
        int viewPagerCurrentPostion = viewPager.getCurrentItem();

        List<String> selectedImage = new ArrayList<>();

        selectedImage.add(mediaList.get(viewPagerCurrentPostion));

        Bundle bundle = new Bundle();

        String formattedDate = new Gson().toJson(selectedImage);

        bundle.putString(Constants.EXTRASTRINGS, formattedDate);

        Intent intent = new Intent(DubuquMediaViewerActivity.this, MediaDeleteService.class);

        intent.putExtras(bundle);

        startService(intent);

        mediaList.remove(viewPagerCurrentPostion);

        dubuquMediaAdapter.notifyDataSetChanged();

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent sendBroadCastIntent = new Intent(Constants.MEDIAITEMCHANGED);
                sendBroadcast(sendBroadCastIntent);

            }
        }, 500);

        toogleTopAndBottomView(false);

        if (mediaList.size() == 0)
            finish();
    }

    private void addColorValues() throws Exception {
        colorPickerColors.add(getResources().getColor(R.color.black));
        colorPickerColors.add(getResources().getColor(R.color.blue_color_picker));
        colorPickerColors.add(getResources().getColor(R.color.brown_color_picker));
        colorPickerColors.add(getResources().getColor(R.color.green_color_picker));
        colorPickerColors.add(getResources().getColor(R.color.orange_color_picker));
        colorPickerColors.add(getResources().getColor(R.color.red_color_picker));
        colorPickerColors.add(getResources().getColor(R.color.red_orange_color_picker));
        colorPickerColors.add(getResources().getColor(R.color.sky_blue_color_picker));
        colorPickerColors.add(getResources().getColor(R.color.violet_color_picker));
        colorPickerColors.add(getResources().getColor(R.color.white));
        colorPickerColors.add(getResources().getColor(R.color.yellow_color_picker));
        colorPickerColors.add(getResources().getColor(R.color.yellow_green_color_picker));
    }


    private void openAddTextPopupWindow(String text, final int colorCode) {

        colorCodeValue = colorCode;
        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View addTextPopupWindowRootView = inflater.inflate(R.layout.add_text_popup_window, null);
        final EditText addTextEditText = addTextPopupWindowRootView.findViewById(R.id.add_text_edit_text);

        ColorPickerAdapter colorPickerAdapter = new ColorPickerAdapter(DubuquMediaViewerActivity.this, colorPickerColors);
        colorPickerAdapter.setOnColorPickerClickListener(new ColorPickerAdapter.OnColorPickerClickListener() {
            @Override
            public void onColorPickerClickListener(int colorCode) {
                addTextEditText.setTextColor(colorCode);
                colorCodeValue = colorCode;
            }
        });

        RecyclerView addTextColorPickerRecyclerView = addTextPopupWindowRootView.findViewById(
                R.id.add_text_color_picker_recycler_view);
        LinearLayoutManager layoutManager = new LinearLayoutManager(DubuquMediaViewerActivity.this, LinearLayoutManager.HORIZONTAL, false);
        addTextColorPickerRecyclerView.setLayoutManager(layoutManager);
        addTextColorPickerRecyclerView.setHasFixedSize(true);
        addTextColorPickerRecyclerView.setAdapter(colorPickerAdapter);
        if (stringIsNotEmpty(text)) {
            addTextEditText.setText(text);
            addTextEditText.setTextColor(colorCode == -1 ? getResources().getColor(R.color.colorWhite) : colorCode);
        }
        pop = new PopupWindow(DubuquMediaViewerActivity.this);
        pop.setContentView(addTextPopupWindowRootView);
        pop.setWidth(LinearLayout.LayoutParams.MATCH_PARENT);
        pop.setHeight(LinearLayout.LayoutParams.MATCH_PARENT);
        pop.setFocusable(true);
        pop.setBackgroundDrawable(null);
        pop.showAtLocation(addTextPopupWindowRootView, Gravity.TOP, 0, 0);
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);

        addTextEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {

            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {

                if ((actionId == EditorInfo.IME_ACTION_DONE)) {
                    addText(addTextEditText.getText().toString(), colorCodeValue);
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(addTextEditText.getWindowToken(), 0);
                    pop.dismiss();
                    return true;
                }
                return false;

            }
        });

    }

    private void addText(String s, int colorCodeValue) {
        DubuquMediaAdapter.DubuquMediaAdapterViewHolder dubuquViewHolder =
                viewDubuquMediaAdapterViewHolderHashMap.get(viewPager.getCurrentItem());

        if (dubuquViewHolder != null) {
            try {
                dubuquViewHolder.addText(s, colorCodeValue);
            } catch (Exception e) {
                DubuquMediaViewerActivity.super.writeCrashReport(TAG, e.getMessage());
            }
        }

    }


    private boolean stringIsNotEmpty(String string) {
        if (string != null && !string.equals("null")) {
            if (!string.trim().equals("")) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void onBackPressed() {

        if (emojiFrameLayout.getVisibility() == View.VISIBLE) {
            try {
                closeEmojiList();
            } catch (Exception e) {
                DubuquMediaViewerActivity.super.writeCrashReport(TAG, e.getMessage());
            }
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public void onStickerSelected(String s) {

        DubuquMediaAdapter.DubuquMediaAdapterViewHolder dubuquViewHolder =
                viewDubuquMediaAdapterViewHolderHashMap.get(viewPager.getCurrentItem());

        if (dubuquViewHolder != null) {
            try {
                dubuquViewHolder.addStrickers(s);
                closeEmojiList();
                hideTopandBottomView();
            } catch (Exception e) {
                DubuquMediaViewerActivity.super.writeCrashReport(TAG, e.getMessage());
            }
        }
    }

    @Override
    public void onEmojiSelected(String s) {
        DubuquMediaAdapter.DubuquMediaAdapterViewHolder dubuquViewHolder =
                viewDubuquMediaAdapterViewHolderHashMap.get(viewPager.getCurrentItem());

        if (dubuquViewHolder != null) {
            try {
                dubuquViewHolder.addEmoji(s);
                closeEmojiList();
                hideTopandBottomView();
            } catch (Exception e) {
                DubuquMediaViewerActivity.super.writeCrashReport(TAG, e.getMessage());
            }
        }
    }


    /**
     * Update quick share options to views.
     *
     * @throws Exception{Runtime Stub Exception}
     */
    private void updateUserForQuickShare() throws Exception {

        DbHelper dbHelper = new DbHelper(DubuquMediaViewerActivity.this);
        List<RecentShareDbModel> recentShareDbModels = dbHelper.getAllRecentusers();

        int iterator = 0;

        for (RecentShareDbModel shareDbModel : recentShareDbModels) {
            final Drawable drawable = new BitmapDrawable(
                    Utils.textAsBitmap(shareDbModel.getUserName(), DubuquMediaViewerActivity.this));
            String userName = shareDbModel.getUserName();

            switch (iterator) {

                case 0:
                    if (shareDbModel.getProfilePic() != null &&
                            !shareDbModel.getProfilePic().equalsIgnoreCase("")) {
                        ImageLoader.getInstance().displayImage(
                                shareDbModel.getProfilePic(),
                                quickShareuserOneImv, new ImageLoadingListener() {
                                    @Override
                                    public void onLoadingStarted(String imageUri, View view) {
                                        quickShareuserOneImv.setImageDrawable(drawable);
                                    }

                                    @Override
                                    public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
                                        quickShareuserOneImv.setImageDrawable(drawable);
                                    }

                                    @Override
                                    public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                                        quickShareuserOneImv.setImageBitmap(loadedImage);
                                    }

                                    @Override
                                    public void onLoadingCancelled(String imageUri, View view) {
                                        quickShareuserOneImv.setImageDrawable(drawable);
                                    }
                                });
                    } else {
                        quickShareuserOneImv.setImageDrawable(drawable);
                    }
                    quickShareUserOneTv.setText(userName);
                    break;

                case 1:
                    if (shareDbModel.getProfilePic() != null &&
                            !shareDbModel.getProfilePic().equalsIgnoreCase("")) {
                        ImageLoader.getInstance().displayImage(
                                shareDbModel.getProfilePic(),
                                quickShareuserTwoImv, new ImageLoadingListener() {
                                    @Override
                                    public void onLoadingStarted(String imageUri, View view) {
                                        quickShareuserTwoImv.setImageDrawable(drawable);
                                    }

                                    @Override
                                    public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
                                        quickShareuserTwoImv.setImageDrawable(drawable);
                                    }

                                    @Override
                                    public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                                        quickShareuserTwoImv.setImageBitmap(loadedImage);
                                    }

                                    @Override
                                    public void onLoadingCancelled(String imageUri, View view) {
                                        quickShareuserTwoImv.setImageDrawable(drawable);
                                    }
                                });
                    } else {
                        quickShareuserTwoImv.setImageDrawable(drawable);
                    }
                    quickShareUserTwoTv.setText(userName);
                    break;

                case 2:
                    if (shareDbModel.getProfilePic() != null &&
                            !shareDbModel.getProfilePic().equalsIgnoreCase("")) {
                        ImageLoader.getInstance().displayImage(
                                shareDbModel.getProfilePic(),
                                quickShareuserThreeImv, new ImageLoadingListener() {
                                    @Override
                                    public void onLoadingStarted(String imageUri, View view) {
                                        quickShareuserThreeImv.setImageDrawable(drawable);
                                    }

                                    @Override
                                    public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
                                        quickShareuserThreeImv.setImageDrawable(drawable);
                                    }

                                    @Override
                                    public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                                        quickShareuserThreeImv.setImageBitmap(loadedImage);
                                    }

                                    @Override
                                    public void onLoadingCancelled(String imageUri, View view) {
                                        quickShareuserThreeImv.setImageDrawable(drawable);
                                    }
                                });
                    } else {
                        quickShareuserThreeImv.setImageDrawable(drawable);
                    }
                    quickShareUserThreeTv.setText(userName);
                    break;
            }

            iterator++;
        }
    }

    /**
     * Share media to external applications
     *
     * @throws Exception {Runtime Stub Exception}
     */

    private void shareMediaToExternalApps(String images) throws Exception {

        ArrayList<Uri> imageUris = new ArrayList<>();

        imageUris.add(Uri.fromFile(new File(images)));

        Intent shareIntent = new Intent();
        shareIntent.setAction(Intent.ACTION_SEND_MULTIPLE);
        shareIntent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, imageUris);
        shareIntent.setType("image/*");
        startActivity(Intent.createChooser(shareIntent, "Share images to.."));

    }

    BroadcastReceiver onAllMediaDeleted = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            try {
                sendBroadcast(new Intent(Constants.MEDIAALBUMLISTCHANGED));
            } catch (Exception e) {
                DubuquMediaViewerActivity.super.writeCrashReport(TAG, e.getMessage());
            }
        }
    };

    private void initializeColorPalleteAndFilter(boolean isColorPicker) throws Exception {


        if (isColorPicker) {
            RecyclerView addTextColorPickerRecyclerView = findViewById(
                    R.id.add_text_color_picker_recycler_view);
            LinearLayoutManager layoutManager = new LinearLayoutManager(DubuquMediaViewerActivity.this, LinearLayoutManager.HORIZONTAL, false);
            addTextColorPickerRecyclerView.setLayoutManager(layoutManager);
            addTextColorPickerRecyclerView.setHasFixedSize(true);
            ColorPickerAdapter colorPickerAdapter = new ColorPickerAdapter(DubuquMediaViewerActivity.this,
                    colorPickerColors);
            colorPickerAdapter.setOnColorPickerClickListener(new ColorPickerAdapter.OnColorPickerClickListener() {
                @Override
                public void onColorPickerClickListener(int colorCode) {
                    DubuquMediaAdapter.DubuquMediaAdapterViewHolder dubuquViewHolder =
                            viewDubuquMediaAdapterViewHolderHashMap.get(viewPager.getCurrentItem());

                    if (dubuquViewHolder != null) {
                        try {
                            dubuquViewHolder.setBrushColor(colorCode);
                        } catch (Exception e) {
                            DubuquMediaViewerActivity.super.writeCrashReport(TAG, e.getMessage());
                        }
                    }
                }
            });

            addTextColorPickerRecyclerView.setAdapter(colorPickerAdapter);
        } else {
            if (addFilterRecyclerView.getVisibility() == GONE) {
                LinearLayoutManager layoutManager = new LinearLayoutManager(DubuquMediaViewerActivity.this, LinearLayoutManager.HORIZONTAL, false);
                addFilterRecyclerView.setLayoutManager(layoutManager);
                addFilterRecyclerView.setHasFixedSize(true);

                FilterAdapter filterAdapter = new FilterAdapter(
                        DubuquMediaViewerActivity.this,
                        mediaList.get(viewPager.getCurrentItem()),
                        new FilterAdapter.FilterAdapterEventListener() {
                            @Override
                            public void onClicked(String filter) {

                                DubuquMediaAdapter.DubuquMediaAdapterViewHolder dubuquViewHolder =
                                        viewDubuquMediaAdapterViewHolderHashMap.get(viewPager.getCurrentItem());

                                if (dubuquViewHolder != null) {
                                    try {
                                        dubuquViewHolder.addFilterToMedia(filter);
                                    } catch (Exception e) {
                                        DubuquMediaViewerActivity.super.writeCrashReport(TAG, e.getMessage());
                                    }
                                }
                            }
                        });
                addFilterRecyclerView.setAdapter(filterAdapter);
                addFilterRecyclerView.setVisibility(VISIBLE);
            }
        }
    }
}
