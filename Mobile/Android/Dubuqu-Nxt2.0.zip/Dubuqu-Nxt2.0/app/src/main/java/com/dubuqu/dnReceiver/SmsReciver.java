package com.dubuqu.dnReceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;

/**
 * Created by Yogaraj subramanian on 24/10/17
 */

public class SmsReciver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        Bundle bundle = intent.getExtras();
        try {

            if (bundle != null) {

                final Object[] pdusObj = (Object[]) bundle.get("pdus");

                for (int i = 0; i < pdusObj.length; i++) {

                    SmsMessage currentMessage = SmsMessage.createFromPdu((byte[]) pdusObj[i]);
                    String message = currentMessage.getDisplayMessageBody();
                    if (message.contains("Dubuqu verification code is")) {
                        String msg1 = message.replaceAll("[^0-9]", "");
                        String verifycode = msg1.substring(0, 4);
                        try {
                            Intent intentForVerifyCode = new Intent("verifycodefromsms");
                            intentForVerifyCode.putExtra("verify_code", verifycode);
                            context.sendBroadcast(intentForVerifyCode);
                        } catch (Exception BroadcastFailure) {
                            BroadcastFailure.printStackTrace();
                        }

                    }

                }
            }

        } catch (Exception exception) {
            exception.printStackTrace();

        }
    }
}
