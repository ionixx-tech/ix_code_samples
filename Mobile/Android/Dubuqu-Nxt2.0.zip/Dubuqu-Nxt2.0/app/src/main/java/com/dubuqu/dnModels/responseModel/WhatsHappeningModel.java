package com.dubuqu.dnModels.responseModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class WhatsHappeningModel {

    @SerializedName("signed_url")
    @Expose
    private String signedUrl;
    @SerializedName("media_identifier")
    @Expose
    private String mediaIdentifier;
    @SerializedName("content_type")
    @Expose
    private String contentType;
    @SerializedName("unread_comment")
    @Expose
    private String unreadComment;

    public String getSignedUrl() {
        return signedUrl;
    }

    public void setSignedUrl(String signedUrl) {
        this.signedUrl = signedUrl;
    }

    public String getMediaIdentifier() {
        return mediaIdentifier;
    }

    public void setMediaIdentifier(String mediaIdentifier) {
        this.mediaIdentifier = mediaIdentifier;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getUnreadComment() {
        return unreadComment;
    }

    public void setUnreadComment(String unreadComment) {
        this.unreadComment = unreadComment;
    }

}