package com.dubuqu.dnFragments.uploadandnotification;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import com.dubuqu.R;
import com.dubuqu.dnActivity.BaseActivity;
import com.dubuqu.dnActivity.home.HomeDetailImageViewer;
import com.dubuqu.dnActivity.uploadandnotification.UploadAndNotification;
import com.dubuqu.dnAdapter.uploadandnotification.NotificationAdapter;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnModels.commonModel.ErrorBodyModel;
import com.dubuqu.dnModels.commonModel.NotificationModel;
import com.dubuqu.dnModels.responseModel.GetAllMediaTimeLine;
import com.dubuqu.dnModels.responseModel.SharedMedias;
import com.dubuqu.dnRestServices.RestServiceController;
import com.dubuqu.dnRestServices.RestServiceProvider;
import com.dubuqu.dnUtils.RestServiceUtils;
import com.dubuqu.dnUtils.Utils;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;
import retrofit2.Response;
import retrofit2.Retrofit;

/**
 * Created by Yogaraj subramanian on 2/1/18
 */

public class Notificationfragmet extends Fragment {

    Context context;

    Activity activity;

    final String TAG = Notificationfragmet.class.getName();

    View parentView, noNotificationAvailable;

    List<NotificationModel> notificationModelList = new ArrayList<>();

    private int totalNotificaton = 0;

    private NotificationAdapter notificationAdapter;

    private RecyclerView recyclerView;

    ProgressBar progressBar;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return LayoutInflater.from(getContext()).inflate(R.layout.fragment_notification_and_upload, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        parentView = view;
        try {
            activity = getActivity();

            context = getContext();

            initalizeView();
        } catch (Exception e) {
            writreCrashReport(e.getMessage());
        }
    }


    @Override
    public void onResume() {
        super.onResume();
        try {
            activity.registerReceiver(OnNotificationReceive, new IntentFilter(Constants.ONNOTIFICATIONRECEIVE));

           /* if (notificationModelList != null && notificationModelList.size() > 0)
                notificationModelList.clear();

            assert notificationModelList != null;
            makeHttpCall(notificationModelList.size());*/
        } catch (Exception e) {
            writreCrashReport(e.getMessage());
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        activity.unregisterReceiver(OnNotificationReceive);
    }

    private void initalizeView() throws Exception {

        recyclerView = parentView.findViewById(R.id.fragment_notification_and_upload_rcv);

        final LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);

        progressBar = parentView.findViewById(R.id.fragment_notification_and_upload_progress);

        recyclerView.setLayoutManager(linearLayoutManager);

        notificationAdapter = new NotificationAdapter(context,
                notificationModelList,
                new NotificationAdapter.NotificationCallback() {
                    @Override
                    public void startPaginating() {

                    }

                    @Override
                    public void onClick(int positon, boolean isOpenChat) {
                        try {
                            NotificationModel notificationModel = notificationModelList.get(positon);

                            if (notificationModel != null) {
                                fetchMediaDetailAgainstTimeLine(notificationModel, isOpenChat);
                            }
                        } catch (Exception e) {
                            writreCrashReport(e.getMessage());
                        }
                    }
                });

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                try {

                    if (linearLayoutManager.findLastCompletelyVisibleItemPosition() == notificationModelList.size() - 2 &&
                            totalNotificaton > notificationModelList.size())
                        makeHttpCall(notificationModelList.size());
                } catch (Exception e) {
                    writreCrashReport(e.getMessage());
                }

            }
        });

        noNotificationAvailable = parentView.findViewById(R.id.no_notification_available);
        noNotificationAvailable.setVisibility(View.GONE);

        parentView.findViewById(R.id.clear_upload_list).setVisibility(View.GONE);

        initalizeListenrs();
    }

    private void initalizeListenrs() throws Exception {

        recyclerView.setAdapter(notificationAdapter);

        if (notificationModelList != null && notificationModelList.size() > 0)
            notificationModelList.clear();

        assert notificationModelList != null;
        makeHttpCall(notificationModelList.size());

    }

    /**
     * Make Http Request to fetch the notifications available to user.
     *
     * @param offset current offset of the {@link #notificationModelList}
     * @throws Exception Runtime stub Exception
     */
    private void makeHttpCall(int offset) throws Exception {

        String data = "{}";
        OkHttpClient okHttpClient = null;
        okHttpClient = RestServiceUtils.getHeader(data, context);
        Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
        RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
        RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);

        mRetrofitCallBacks.getNotification(new RestServiceController.ResponseCallBacks() {
            @Override
            public void onResponse(Object o) {
                if (o != null) {
                    activity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            progressBar.setVisibility(View.GONE);
                        }
                    });
                    List<NotificationModel> notificationModels = (List<NotificationModel>) o;
                    if (notificationModels.size() > 0) {
                        notificationModelList.addAll(notificationModels);
                        activity.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (recyclerView.getVisibility() == View.GONE)
                                    recyclerView.setVisibility(View.VISIBLE);

                                notificationAdapter.notifyDataSetChanged();
                                if (noNotificationAvailable.getVisibility() == View.VISIBLE)
                                    noNotificationAvailable.setVisibility(View.GONE);

                            }
                        });
                    } else {
                        activity.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (recyclerView.getVisibility() == View.VISIBLE)
                                    recyclerView.setVisibility(View.GONE);

                                if (noNotificationAvailable.getVisibility() == View.GONE)
                                    noNotificationAvailable.setVisibility(View.VISIBLE);

                            }
                        });
                    }
                } else {
                    activity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (recyclerView.getVisibility() == View.VISIBLE)
                                recyclerView.setVisibility(View.GONE);

                            if (noNotificationAvailable.getVisibility() == View.GONE)
                                noNotificationAvailable.setVisibility(View.VISIBLE);
                        }
                    });
                }
            }

            @Override
            public void onFailure(Object o) {
                showNetworkError(o);
            }
        }, new RestServiceController.ResourceCountCallBack() {
            @Override
            public void mediaResponse(String count) {
                totalNotificaton = count == null ? 0 : Integer.parseInt(count);
            }
        }, offset);
    }

    /**
     * Write Log Report to the console log
     *
     * @param message the log data that need to printed
     */
    private void writreCrashReport(String message) {
        if (context instanceof UploadAndNotification) {
            ((UploadAndNotification) context).writeCrashReport(TAG, message);
        }
    }

    /**
     * Handle error message and no internet message form api.
     *
     * @param o might be instance of {@link retrofit2.Response} or {@link Throwable}
     */
    private void showNetworkError(Object o) {
        if (o != null) {
            if (activity instanceof BaseActivity) {
                try {

                    if (o instanceof retrofit2.Response) {
                        ResponseBody responseBody = ((Response) o).errorBody();
                        if (responseBody != null) {
                            String value = responseBody.string();
                            ErrorBodyModel errorBodyModel = new Gson().fromJson(value, ErrorBodyModel.class);
                            if (errorBodyModel != null)
                                ((UploadAndNotification) activity)
                                        .showToastMessage(errorBodyModel.getMessage(), false);
                        }
                    } else if (o instanceof Throwable) {
                        ((BaseActivity) activity)
                                .showToastMessage(((Throwable) o).getMessage(), false);
                    }

                } catch (Exception e) {
                    if (activity instanceof BaseActivity) {
                        ((BaseActivity) activity)
                                .writeCrashReport(TAG, e.getMessage());
                    }
                }
            }

        }
    }

    /**
     * Refersh data if any notification received.
     */
    private BroadcastReceiver OnNotificationReceive = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (notificationModelList != null && notificationModelList.size() > 0)
                notificationModelList.clear();
            try {
                assert notificationModelList != null;
                makeHttpCall(notificationModelList.size());
            } catch (Exception e) {
                writreCrashReport(e.getMessage());
            }
        }
    };

    private void fetchMediaDetailAgainstTimeLine(final NotificationModel notificationModel, final boolean toOpenChat) throws Exception {

        String data = "{}";
        OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, context);
        Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
        RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
        RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
        final String mediaIdentifier = notificationModel.getMediaIdentifier();

        final GetAllMediaTimeLine getAllMediaTimeLine = new GetAllMediaTimeLine();
        getAllMediaTimeLine.setTimelineIdentifier(notificationModel.getTimelineIdentifier());
        final List<SharedMedias> sharedMediasList = new ArrayList<>();

        showProgress(true);

        if (Utils.isVaildString(mediaIdentifier)) {
            //single media;
            mRetrofitCallBacks.getMediaDetails(mediaIdentifier, new RestServiceController.ResponseCallBacks() {
                @Override
                public void onResponse(Object o) {
                    if (o != null) {
                        SharedMedias sharedMedias = (SharedMedias) o;
                        sharedMedias.setMediaIdentifier(mediaIdentifier);
                        sharedMediasList.add(sharedMedias);
                        getAllMediaTimeLine.setSharedMedias(sharedMediasList);
                        openDetailMediaViewer(getAllMediaTimeLine, toOpenChat);
                    }
                }

                @Override
                public void onFailure(Object o) {
                    showProgress(false);
                }
            });
        } else {
            //multiple media
            mRetrofitCallBacks.paginatetTimeLineResouces(
                    notificationModel.getTimelineIdentifier(),
                    new RestServiceController.ResponseCallBacks() {
                        @Override
                        public void onResponse(Object o) {
                            if (o != null) {
                                List<SharedMedias> sharedMedias = (List<SharedMedias>) o;
                                if (sharedMedias.size() > 0) {
                                    sharedMediasList.addAll(sharedMedias);
                                    getAllMediaTimeLine.setSharedMedias(sharedMediasList);
                                }
                            }
                        }

                        @Override
                        public void onFailure(Object o) {
                            showProgress(false);
                        }
                    }, new RestServiceController.ResourceCountCallBack() {
                        @Override
                        public void mediaResponse(String count) {
                            if (Utils.isVaildString(count)) {
                                getAllMediaTimeLine.setSharedMediaCount(Integer.parseInt(count));
                                openDetailMediaViewer(getAllMediaTimeLine, toOpenChat);
                            }
                        }
                    }, 0);
        }
    }

    private void openDetailMediaViewer(GetAllMediaTimeLine allMediaTimeLine, boolean toOpenChat) {

        Intent startDetailImageView = new Intent(context, HomeDetailImageViewer.class);
        Bundle bundle = new Bundle();
        bundle.putString(Constants.EXTRASTRINGS, new Gson().toJson(allMediaTimeLine));
        bundle.putInt(Constants.CURRENTIMAGE, 0);
        bundle.putBoolean(Constants.SHOULDSHOWCHAT, toOpenChat);
        startDetailImageView.putExtras(bundle);
        context.startActivity(startDetailImageView);

        showProgress(false);
    }

    private void showProgress(boolean toShowProgress) {
        try {
            if (activity instanceof UploadAndNotification) {
                if (toShowProgress) {
                    ((UploadAndNotification) activity).showLoaders(activity);
                } else {
                    ((UploadAndNotification) activity).cancelPopUp();
                }
            }
        } catch (Exception e) {
            writreCrashReport(e.getMessage());
        }

    }
}
