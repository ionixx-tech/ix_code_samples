package com.dubuqu.dnAdapter.uploadandnotification;

import android.content.Context;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.dubuqu.R;
import com.dubuqu.dnActivity.uploadandnotification.UploadActivity;
import com.dubuqu.dnStorage.DbHelper;
import com.dubuqu.dnStorage.upload.UploadDbModel;
import com.dubuqu.dnStorage.upload.UploadMapModel;
import com.dubuqu.dnViews.ExpandableItem;
import com.dubuqu.dnViews.linearStickView.exposed.StickyHeaderHandler;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.File;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * Created by Yogaraj subramanian on 15/12/17
 */

public class UploadAdapter extends RecyclerView.Adapter<UploadAdapter.UploadAdpaterViewHolder>
        implements StickyHeaderHandler {

    private Context context;

    private List<UploadMapModel> uploadDbModels;

    private UploadActivityInterface uploadActivityInterface;

    private DbHelper dbHelper;

    public UploadAdapter(LinearLayoutManager linearLayoutManager,
                         Context context, List<UploadMapModel> uploadDbModels,
                         UploadActivityInterface uploadActivityInterface) {

        this.context = context;
        this.uploadDbModels = uploadDbModels;
        this.uploadActivityInterface = uploadActivityInterface;
        try {
            dbHelper = new DbHelper(context);
        } catch (Exception e) {
            writeCrashReport(e.getMessage());
        }
    }


    private void writeCrashReport(String message) {
        if (context != null && context instanceof UploadActivity) {
            Log.e(UploadAdapter.class.getName(), message);
        }
    }

    @Override
    public UploadAdpaterViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.uploadexpandableitem, parent,
                false);
        return new UploadAdpaterViewHolder(view);
    }


    @Override
    public List<?> getAdapterData() {
        return null;
    }

    @Override
    public void onBindViewHolder(UploadAdpaterViewHolder holder, int position) {

        try {
            holder.onBind(position);
        } catch (Exception e) {
            writeCrashReport(e.getMessage());
        }
    }

    @Override
    public int getItemCount() {
        return uploadDbModels.size();
    }

    class UploadAdpaterViewHolder extends RecyclerView.ViewHolder {

        ExpandableItem expandableItem;

        /*header content*/
        CircleImageView firstImageView, secondImageView;

        TextView shareText;

        /*body contnet*/
        RecyclerView recyclerView;

        UploadAdpaterViewHolder(View itemView) {
            super(itemView);
            expandableItem = itemView.findViewById(R.id.upload_list_items);

            firstImageView = expandableItem.getHeaderLayout().findViewById(R.id.upload_image_first_thumbnail);
            secondImageView = expandableItem.getHeaderLayout().findViewById(R.id.upload_image_second_thumbnail);
            shareText = expandableItem.getHeaderLayout().findViewById(R.id.upload_show_text);

            recyclerView = expandableItem.getContentLayout().findViewById(R.id.upload_rcv);

        }

        public void onBind(int position) throws Exception {

            UploadMapModel uploadMapModel = uploadDbModels.get(position);

            List<UploadDbModel> uploadDbModelList = dbHelper.fetchDataAgainstIdentifier(uploadMapModel.getUploadId());
            if (uploadDbModelList != null ) {
                UploadListAdapter uploadListAdapter = new UploadListAdapter(context, uploadDbModelList);
                recyclerView.setAdapter(uploadListAdapter);
                recyclerView.setLayoutManager(new LinearLayoutManager(context));
                uploadListAdapter.notifyDataSetChanged();

                if (uploadDbModelList.size() > 1) {
                    Glide.with(context).load(new File(uploadDbModelList.get(0).getFilePath())).into(firstImageView);
                    Glide.with(context).load(new File(uploadDbModelList.get(1).getFilePath())).into(secondImageView);
                } else {
                    secondImageView.setVisibility(View.GONE);
                    Glide.with(context).load(new File(uploadDbModelList.get(0).getFilePath())).into(firstImageView);
                }

                List<String> users = new Gson().fromJson(uploadMapModel.getUser(), new TypeToken<List<String>>() {
                }.getType());


                assert users != null;

                shareText.setText("Showing\t"
                        .concat(String.valueOf(uploadDbModelList.size()))
                        .concat("\tto\t")
                        .concat(String.valueOf(users.size()))
                        .concat("\tdubuqies"));

            }


        }
    }

    public interface UploadActivityInterface {
        void cancelUpload();

        void retryUpload();
    }
}

