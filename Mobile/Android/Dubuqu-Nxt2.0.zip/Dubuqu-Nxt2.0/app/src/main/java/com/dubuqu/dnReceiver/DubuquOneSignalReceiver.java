package com.dubuqu.dnReceiver;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.dubuqu.MainActivity;
import com.dubuqu.R;
import com.dubuqu.dnActivity.uploadandnotification.UploadAndNotification;
import com.dubuqu.dnApplication.AppController;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnModels.commonModel.NotificationModel;
import com.dubuqu.dnModels.responseModel.SharedMedias;
import com.dubuqu.dnRestServices.RestServiceController;
import com.dubuqu.dnRestServices.RestServiceProvider;
import com.dubuqu.dnServices.ContactService;
import com.dubuqu.dnStorage.SessionManager;
import com.dubuqu.dnUtils.RestServiceUtils;
import com.dubuqu.dnUtils.Utils;
import com.google.gson.Gson;
import com.onesignal.OSNotification;
import com.onesignal.OneSignal;

import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;

/**
 * Created by Yogaraj subramanian on 24/10/17
 */

public class DubuquOneSignalReceiver implements OneSignal.NotificationReceivedHandler {

    private String TAG = DubuquOneSignalReceiver.class.getName();

    private Context context;

    public DubuquOneSignalReceiver(Context context) {
        this.context = context;
    }

    private int notificationId;

    private NotificationCompat.Builder builder;

    private Notification notification;

    enum Type {
        COMMENT,
        LIKE,
        SHARE,
        GROUP,
        MULTIPLE_MEDIA,
        EXIT_GROUP,
        SCREEN_SHOT,
        PROMOTION
    }

    @Override
    public void notificationReceived(OSNotification notification) {
        try {
            assert notification != null;

            NotificationManager notificationManager = (NotificationManager) context
                    .getSystemService(Context.NOTIFICATION_SERVICE);

            assert notificationManager != null;

            SessionManager sessionManager = new SessionManager(context);

            if (sessionManager.getNewMessageNotification()) {

                JSONObject dataNameValuePair = notification.payload.additionalData;

                notificationManager.cancel(notification.androidNotificationId);

                notificationId = notification.androidNotificationId;

                builder = new NotificationCompat.Builder(context);
                builder.setSmallIcon(R.drawable.ic_dubu);
                builder.setPriority(NotificationCompat.PRIORITY_HIGH);
                builder.setAutoCancel(true);


                if (sessionManager.getNotificationTone().equalsIgnoreCase("false"))
                    builder.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION));
                else
                    builder.setSound(Uri.parse(sessionManager.getNotificationTone()));

                if (sessionManager.getNotificationVibrate())
                    builder.setVibrate(new long[]{0, 400, 250, 400});

                String notificationType;

                String mediaIdentifiers = null;
                String groupIdentifier = null;
                String userIdentifier = null;

                Log.e(TAG, "Notification Recevied");

                if (dataNameValuePair.has("media_identifier"))
                    mediaIdentifiers = dataNameValuePair.getString("media_identifier");
                if (dataNameValuePair.has("group_identifier"))
                    groupIdentifier = dataNameValuePair.getString("group_identifier");
                if (dataNameValuePair.has("user_identifier"))
                    userIdentifier = dataNameValuePair.getString("user_identifier");

                notificationType = dataNameValuePair.getString("type");

                String notificationMessage = dataNameValuePair.getString("message");

                String title = dataNameValuePair.getString("title");

                Intent notificationIntent = new Intent(context.getApplicationContext(),
                        UploadAndNotification.class);

                TaskStackBuilder stackBuilder = TaskStackBuilder.create(context);
                stackBuilder.addNextIntentWithParentStack(notificationIntent);

                PendingIntent resultPendingIntent =
                        stackBuilder.getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT);

                builder.setContentIntent(resultPendingIntent);

                sendLocalBroadCast(false);

                /*OneSignal.cancelNotification(notificationId);*/

                /*notificationManager.cancel(notificationId);*/

                boolean isAppinForGround = checkIfAppIsOnLine();

                if (notificationType.equalsIgnoreCase("DEVICE_CHANGED")) {

                    sessionManager.registrationCompleted(false);

                    Intent i = new Intent(context, MainActivity.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

                    context.startActivity(i);

                } else if (notificationType.equalsIgnoreCase("SHARED_MEDIA")) {

                    Intent broadCast = new Intent(Constants.NEWMEDIARECEIVED);
                    context.sendBroadcast(broadCast);

                    if (mediaIdentifiers != null) {
                        if (isAppinForGround) {
                            showInappNotification(title, notificationMessage, null, Type.SHARE, mediaIdentifiers);
                        } else {
                            builder.setContentTitle(title);
                            builder.setContentText(notificationMessage);

                            setProfileImage(mediaIdentifiers);
                        }

                    } else if (groupIdentifier != null || userIdentifier != null) {
                        try {
                            if (isAppinForGround) {
                                showInappNotification(title, notificationMessage, null, Type.SHARE, null);

                            } else {
                                builder.setContentTitle(title);
                                builder.setContentText(notificationMessage);
                                builder.setSmallIcon(R.mipmap.ic_launcher);
                                notificationManager.notify(notificationId, builder.build());
                            }

                        } catch (Exception e) {
                            Log.e(TAG, e.getMessage());
                        }
                    }

                } else if (notificationType.equalsIgnoreCase("SOCIAL_CIRCLE")) {

                    Intent intent1 = new Intent(context, ContactService.class);

                    context.startService(intent1);

                    try {
                        title = "Group";
                        if (isAppinForGround) {
                            showInappNotification(title, notificationMessage, null, Type.GROUP,
                                    null);

                        } else {
                            builder.setContentTitle(title);
                            builder.setContentText(notificationMessage);
                            builder.setSmallIcon(R.mipmap.ic_launcher);
                            notificationManager.notify(notificationId, builder.build());
                        }
                    } catch (Exception e) {
                        Log.e(TAG, e.getMessage());
                    }

                } else if (notificationType.equalsIgnoreCase("COMMENT_MEDIA")
                        || notificationType.contains("LIKE_MEDIA")) {

                    Intent broadCast = new Intent("commentmedia");
                    context.sendBroadcast(broadCast);

                    if (notificationType.equalsIgnoreCase("COMMENT_MEDIA")) {
                        String commentData;
                        if (!notificationMessage.contains("sticker")) {
                            title = notificationMessage.substring(0, notificationMessage.lastIndexOf("~") - 1);
                            commentData = notificationMessage;
                            notificationMessage = commentData.substring(commentData.lastIndexOf("~") + 1, commentData.length());
                            if (isAppinForGround) {
                                showInappNotification(title, title, notificationMessage, notificationType.contains("LIKE_MEDIA") ?
                                        Type.SHARE : Type.COMMENT, mediaIdentifiers);

                            } else {
                                builder.setContentTitle(title);
                                builder.setContentText(notificationMessage);
                                builder.setSmallIcon(R.mipmap.ic_launcher);
                                setProfileImage(mediaIdentifiers);
                            }
                        } else {
                            builder.setContentTitle(title);
                            builder.setContentText(notificationMessage);
                            setProfileImage(mediaIdentifiers);
                        }
                    } else {
                        if (isAppinForGround) {
                            showInappNotification(title, notificationMessage, null, notificationType.contains("LIKE_MEDIA") ?
                                    Type.SHARE : Type.COMMENT, mediaIdentifiers);

                        } else {
                            builder.setContentTitle(title);
                            builder.setContentText(notificationMessage);
                            setProfileImage(mediaIdentifiers);
                        }
                    }


                } else if (notificationType.equalsIgnoreCase("SCREENSHOT_TAKEN")) {

                    if (isAppinForGround) {
                        showInappNotification(title, notificationMessage, null, Type.SHARE, null);

                    } else {

                        builder.setContentTitle(title);
                        builder.setContentText(notificationMessage);
                        setProfileImage(mediaIdentifiers);
                    }
                } else if (notificationType.equalsIgnoreCase("promotion")) {
                    builder.setContentTitle(title);
                    builder.setContentText(notificationMessage);
                    builder.setSmallIcon(R.mipmap.ic_launcher);
                    notificationManager.notify(notificationId, builder.build());
                }

                if (!isAppinForGround) {
                    int currentCount = sessionManager.getBadgeCount();
                    sessionManager.setBadgeCount(currentCount + 1);
                    Utils.setBadge(context);
                }

            } else {
                OneSignal.cancelNotification(notificationId);
            }

        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        }
    }


    private void setProfileImage(String mediaIdentifier) throws Exception {
        Log.e(TAG, mediaIdentifier);

        String data = "{}";

        OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, context);

        Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);

        RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);

        RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);

        mRetrofitCallBacks.getMediaDetails(mediaIdentifier, new RestServiceController.ResponseCallBacks() {
            @Override
            public void onResponse(Object o) {
                if (o != null) {
                    Log.e(TAG, ((SharedMedias) o).getThumbnailUrl());
                    new GeneratePictureFromUrl(
                            context, ((SharedMedias) o).getThumbnailUrl()
                    ).execute();
                }
            }

            @Override
            public void onFailure(Object o) {
                Log.e(TAG, "Error");
            }
        });
    }


    private boolean checkIfAppIsOnLine() {
        try {

            Log.e(TAG, "Checking if App is in background");

            if (context == null)
                return false;
            boolean isInBackground = false;
            ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
            assert am != null;
            List<ActivityManager.RunningAppProcessInfo> runningProcesses = am.getRunningAppProcesses();
            for (ActivityManager.RunningAppProcessInfo processInfo : runningProcesses) {
                if (processInfo.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
                    for (String activeProcess : processInfo.pkgList) {
                        if (activeProcess.equals(AppController.getInstance().getPackageName())) {
                            isInBackground = true;
                        }
                    }
                }
            }
            Log.e(TAG, isInBackground + "");
            return isInBackground;
        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
            return false;
        }
    }

    private void sendLocalBroadCast(boolean isSharedMedia) {
        Intent intent = new Intent(Constants.ONNOTIFICATIONRECEIVE);
        intent.putExtra(Constants.EXTRASTRINGS, isSharedMedia);
        context.sendBroadcast(intent);
    }

    private void showInappNotification(String title, String message, String comment, Type type, String mediaIdentifier) {
        NotificationModel notificationModel = new NotificationModel();
        notificationModel.setMediaIdentifier(mediaIdentifier);
        notificationModel.setMessage(message);
        notificationModel.setTitle(title);
        notificationModel.setCommentIdentifier(comment);
        notificationModel.setType(type == Type.COMMENT ? "comment" : "normal");

        String parseData = new Gson().toJson(notificationModel);

        Intent intent = new Intent(context.getString(R.string.SHOWINAPP));
        intent.putExtra(Constants.EXTRASTRINGS, parseData);
        context.sendBroadcast(intent);

    }

    @SuppressLint("StaticFieldLeak")
    private class GeneratePictureFromUrl extends AsyncTask<String, Void, Bitmap> {

        private Context mContext;
        private String imageUrl;

        private GeneratePictureFromUrl(Context context, String imageUrl) {
            super();
            this.mContext = context;
            this.imageUrl = imageUrl;
        }

        @Override
        protected Bitmap doInBackground(String... params) {

            InputStream in;
            try {
                URL url = new URL(this.imageUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setDoInput(true);
                connection.connect();
                in = connection.getInputStream();
                return BitmapFactory.decodeStream(in);
            } catch (IOException e) {
                Log.e(TAG, e.getMessage());
            }
            return null;
        }

        @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
        @Override
        protected void onPostExecute(Bitmap result) {
            super.onPostExecute(result);


            NotificationManager notificationManager = (NotificationManager)
                    mContext.getSystemService(Context.NOTIFICATION_SERVICE);

            builder.setLargeIcon(result);

            builder.setSmallIcon(R.mipmap.ic_launcher);

            notificationManager.notify(notificationId, builder.build());
        }
    }
}
