package com.dubuqu.dnMediaCompression;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.os.AsyncTask;
import android.support.media.ExifInterface;

import com.dubuqu.dnCallbacks.Callbacks;

import java.io.File;
import java.io.FileOutputStream;


/**
 * Created by Yogaraj subramanian on 26/4/17
 * <p>
 * Algorithm used initillay
 * Bitmap originalBitmap = Glide.with(context).load(params[0]).asBitmap().into(-1, -1).get();
 * <p>
 * Bitmap compressedBitmap = Glide.with(context).load(params[0]).asBitmap()
 * .into(originalBitmap.getWidth() / 3, originalBitmap.getHeight() / 3)
 * .get();
 * <p>
 * File compressdFile = new File(context.getCacheDir(),
 * "Dubuquee".concat(String.valueOf(System.currentTimeMillis())).concat(".jpeg"));
 * OutputStream os = new BufferedOutputStream(new FileOutputStream(compressdFile));
 * compressedBitmap.compress(Bitmap.CompressFormat.PNG,
 * 100, os);
 * os.flush();
 * os.close();
 * originalPath = compressdFile.getPath();
 */
public class ImageCompressor extends AsyncTask<String, Void, Void> {
    private Callbacks.CompressionCallback compressionCallback;
    @SuppressLint("StaticFieldLeak")
    private Context context;
    private String originalPath = "";

    public ImageCompressor(Callbacks.CompressionCallback compressionCallback, Context context) {
        this.compressionCallback = compressionCallback;
        this.context = context;
    }

    @Override
    protected Void doInBackground(String... params) {
        try {
            File file = new File(params[0]);

            if (file.length() / 1024 < 200) {
                originalPath = file.getPath();
            } else {
                File compressedFile = saveBitmapToFile(file);
                originalPath = compressedFile != null ? compressedFile.getPath() : file.getPath();
            }

        } catch (Exception e) {
            originalPath = params[0];
        }

        return null;
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        compressionCallback.getCompressedFilePath(originalPath);
    }

    private File saveBitmapToFile(File file) {
        try {

            // First decode with inJustDecodeBounds=true to check dimensions
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(file.getAbsolutePath(), options);

            // Calculate inSampleSize req.width and req.height determines the quality of the media and size
            /*
            * 72 x 72 output file size ~10kb
            * 120 x 120 output file size ~10kb
            * 240 x 240 output file size ~30kb
            * 700 x 700 output file size ~150kb
            * */
            options.inSampleSize = calculateInSampleSize(options);
            // Decode bitmap with inSampleSize set
            options.inJustDecodeBounds = false;

            Bitmap scaledBitmap = BitmapFactory.decodeFile(file.getAbsolutePath(), options);

            //check the rotation of the image and display it properly
            ExifInterface exif;
            exif = new ExifInterface(file.getAbsolutePath());
            int orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, 0);
            Matrix matrix = new Matrix();
            if (orientation == 6) {
                matrix.postRotate(90);
            } else if (orientation == 3) {
                matrix.postRotate(180);
            } else if (orientation == 8) {
                matrix.postRotate(270);
            }
            scaledBitmap = Bitmap.createBitmap(scaledBitmap,
                    0, 0, scaledBitmap.getWidth(),
                    scaledBitmap.getHeight(), matrix, true);

            File compressdFile = new File(context.getCacheDir(),
                    "Dubuquee".concat(String.valueOf(System.currentTimeMillis())).concat(".jpeg"));

            FileOutputStream outputStream = new FileOutputStream(compressdFile);

            scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 90, outputStream);

            return compressdFile;
        } catch (Exception e) {
            return null;
        }
    }

    private static int calculateInSampleSize(
            BitmapFactory.Options options) throws Exception {
        // Raw height and width of image
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > 750 || width > 750) {

            final int halfHeight = height / 2;
            final int halfWidth = width / 2;

            // Calculate the largest inSampleSize value that is a power of 2 and keeps both
            // height and width larger than the requested height and width.
            while ((halfHeight / inSampleSize) >= 750
                    && (halfWidth / inSampleSize) >= 750) {
                inSampleSize *= 2.5;
            }
        }

        return inSampleSize;
    }
}
