package com.dubuqu.dnServices;

import android.app.IntentService;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.ResultReceiver;
import android.provider.MediaStore;
import android.support.annotation.Nullable;

import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnModels.commonModel.GalleryMediaListModel;
import com.dubuqu.dnUtils.Utils;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Yogaraj subramanian on 2/11/17
 */

public class MediaLoadAlbumDetailService extends IntentService {

    HashMap<Date, List<GalleryMediaListModel>> datesAdded = new HashMap<>();

    private ResultReceiver receiver;

    private String folderName = "";

    public MediaLoadAlbumDetailService() {
        super(Constants.LOADIMAGESERVICE);
    }


    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        try {
            receiver = intent.getParcelableExtra(Constants.EXTRASTRINGS);
            folderName = intent.getStringExtra(Constants.FOLDERNAME);
            loadImagesBasedOnDate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadImagesBasedOnDate() throws Exception {

        String[] mediaProjection = {
                MediaStore.Files.FileColumns._ID,
                MediaStore.Files.FileColumns.DATE_ADDED,
                MediaStore.Files.FileColumns.MIME_TYPE,
                MediaStore.Files.FileColumns.DATA
        };

        String orderBy = MediaStore.Video.Media.DATE_ADDED + " DESC";

        String selection = MediaStore.Video.Media.BUCKET_DISPLAY_NAME + " =?"
                + " OR "
                + MediaStore.Images.ImageColumns.BUCKET_DISPLAY_NAME + " =?";

        Uri queryUri = MediaStore.Files.getContentUri("external");

        Cursor cursor = getContentResolver().query(queryUri, mediaProjection, selection,
                new String[]{folderName, folderName}, orderBy);

        if (cursor != null) {

            int totalSize = cursor.getCount();

            int iterator = 0;

            while (iterator < totalSize) {

                cursor.moveToPosition(iterator);

                int dateIndex = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_ADDED);

                int mediaIndex = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID);

                int mediaTypeIndex = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MIME_TYPE);

                int mediaDataIndex = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA);

                int mediaId = cursor.getInt(mediaIndex);
                String mimeType = cursor.getString(mediaTypeIndex);
                String data = cursor.getString(mediaDataIndex);

                GalleryMediaListModel galleryListModel = new GalleryMediaListModel();

                galleryListModel.setMediaId(mediaId);
                galleryListModel.setMimeType(mimeType == null ? "image" : mimeType);
                galleryListModel.setMediaPath(data);
                galleryListModel.setSelected(false);

                if (mimeType != null && mimeType.contains("video")) {

                    try {
                        long videoDuration = Utils.getVideoDurationInMilliSec(data);

                        String videoDurationInMinutes = Utils.getVideoDurationString(videoDuration);

                        galleryListModel.setVideoDuration(videoDurationInMinutes);
                    } catch (Exception e) {
                        galleryListModel.setVideoDuration(String.valueOf("0.0"));
                    }
                }


                long date = cursor.getLong(dateIndex);

                List<GalleryMediaListModel> galleryList = datesAdded.get(Utils.formatDate(date));

                if (galleryList == null) {
                    galleryList = new ArrayList<>();
                }

                galleryList.add(galleryListModel);
                datesAdded.put(Utils.formatDate(date), galleryList);

                if (iterator == 100) {
                    AsyncTask.execute(new Runnable() {
                        @Override
                        public void run() {
                            Bundle bundle = new Bundle();
                            bundle.putSerializable(Constants.EXTRASTRINGS, datesAdded);

                            if (receiver != null)
                                receiver.send(Constants.IMAGELISTRECEIVERREQUEST, bundle);
                        }
                    });

                }
                iterator++;
            }

            if (receiver != null) {
                Bundle bundle = new Bundle();
                bundle.putSerializable(Constants.EXTRASTRINGS, datesAdded);

                if (receiver != null)
                    receiver.send(Constants.IMAGELISTRECEIVERREQUEST, bundle);
            }

            cursor.close();

            this.stopSelf();

            cursor.close();
        }
    }
}
