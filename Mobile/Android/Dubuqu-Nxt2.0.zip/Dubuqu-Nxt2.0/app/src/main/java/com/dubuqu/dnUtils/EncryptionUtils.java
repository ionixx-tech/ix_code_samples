package com.dubuqu.dnUtils;

import android.util.Base64;

import com.dubuqu.dnConstants.Constants;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

/**
 * Created by Yogaraj subramanian on 23/6/17
 */

public class EncryptionUtils {

    /**
     * decyrpts the data which is send from the server make sure  AES/ECB/ZeroBytePadding algorithm
     * is used.
     *
     * @param encData the response which is send from the server
     * @return String data i.e original response
     * @throws NoSuchAlgorithmException
     * @throws NoSuchPaddingException
     * @throws InvalidKeyException
     * @throws IllegalBlockSizeException
     * @throws BadPaddingException
     */
    public static String decrypt_data(String encData)
            throws NoSuchAlgorithmException, NoSuchPaddingException,
            InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        String key = Constants.ENCRPYTION_SECRECT_KEY;
        SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes(), "AES");
        Cipher cipher = Cipher.getInstance("AES/ECB/ZeroBytePadding");

        cipher.init(Cipher.DECRYPT_MODE, skeySpec);

        System.out.println("Base64 decoded: "
                + Base64.decode(encData.getBytes(), Base64.DEFAULT).length);

        byte[] original = cipher.doFinal(Base64.decode(encData.getBytes(), Base64.DEFAULT));

        return new String(original).trim();
    }

    /**
     * while making any api the request body need to be encypted AES/ECB/ZeroBytePadding algorithm is
     * used for encrpting the data.
     *
     * @param data the request body which is needed to encrypt.
     * @return Stirng of encrpted data.
     * @throws Exception
     */
    public static String encrypt_data(String data) throws Exception {

        String key = Constants.ENCRPYTION_SECRECT_KEY;

        SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes(), "AES");

        Cipher cipher = Cipher.getInstance("AES/ECB/ZeroBytePadding");

        cipher.init(Cipher.ENCRYPT_MODE, skeySpec);

        System.out.println("Base64 encoded: "
                + Base64.encode(data.getBytes(), Base64.DEFAULT).length);

        byte[] original = Base64.encode(cipher.doFinal(data.getBytes()), Base64.DEFAULT);
        return new String(original);
    }
}
