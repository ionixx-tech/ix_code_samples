package com.dubuqu.dnModels.commonModel;

import android.net.Uri;

/**
 * Created by Yogaraj subramanian on 7/11/17
 */

public class CreateGroupAddParticipantsModel {

    private Uri profileUri;

    private String groupName, groupIdentifier,amazonUrl;

    private boolean privateGroup, saveasAlbum, allowRespost;

    public String getAmazonUrl() {
        return amazonUrl;
    }

    public void setAmazonUrl(String amazonUrl) {
        this.amazonUrl = amazonUrl;
    }

    public String getGroupIdentifier() {
        return groupIdentifier;
    }

    public void setGroupIdentifier(String groupIdentifier) {
        this.groupIdentifier = groupIdentifier;}

    public Uri getProfileUri() {
        return profileUri;
    }

    public void setProfileUri(Uri profileUri) {
        this.profileUri = profileUri;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public boolean isPrivateGroup() {
        return privateGroup;
    }

    public void setPrivateGroup(boolean privateGroup) {
        this.privateGroup = privateGroup;
    }

    public boolean isSaveasAlbum() {
        return saveasAlbum;
    }

    public void setSaveasAlbum(boolean saveasAlbum) {
        this.saveasAlbum = saveasAlbum;
    }

    public boolean isAllowRespost() {
        return allowRespost;
    }

    public void setAllowRespost(boolean allowRespost) {
        this.allowRespost = allowRespost;
    }
}
