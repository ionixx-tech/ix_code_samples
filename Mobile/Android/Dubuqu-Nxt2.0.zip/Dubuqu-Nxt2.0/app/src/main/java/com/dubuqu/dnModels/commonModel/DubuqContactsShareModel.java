package com.dubuqu.dnModels.commonModel;


import com.dubuqu.dnUtils.Utils;

import java.io.Serializable;

/**
 * Created by Yogaraj subramanian on 14/6/17
 */

public class DubuqContactsShareModel implements Serializable {

    private int id;

    private String userName;

    private String modileNumber;

    private String identifier;

    private String profilePicture;

    private Utils.DUBUQU_CATEGORY category;

    private boolean isSelected = false;

    public DubuqContactsShareModel(String userName, String modileNumber, String identifier,
                                   String profilePicture, Utils.DUBUQU_CATEGORY category) {
        this.userName = userName;
        this.modileNumber = modileNumber;
        this.category = category;
        this.identifier = identifier;
        this.profilePicture = profilePicture;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }


    public String getIdentifier() {
        return identifier;
    }

    public void setIdentifier(String identifier) {
        this.identifier = identifier;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getModileNumber() {
        return modileNumber;
    }

    public void setModileNumber(String modileNumber) {
        this.modileNumber = modileNumber;
    }

    public Utils.DUBUQU_CATEGORY getCategory() {
        return category;
    }

    public void setCategory(Utils.DUBUQU_CATEGORY category) {
        this.category = category;
    }

    public String getProfilePicture() {
        return profilePicture;
    }

    public void setProfilePicture(String profilePicture) {
        this.profilePicture = profilePicture;
    }
}
