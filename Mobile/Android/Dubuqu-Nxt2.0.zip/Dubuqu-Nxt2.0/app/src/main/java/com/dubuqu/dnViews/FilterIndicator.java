package com.dubuqu.dnViews;

import android.content.Context;
import android.content.res.TypedArray;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.dubuqu.R;


/**
 * A filter indicator is an view that indicates the pageindicator like viewpager inidicator
 * {@link android.support.v4.view.ViewPager} refer github for example.
 * FilterIndicator Extends {@link LinearLayout} since inidicators are arranged in both
 * vertical and horizontal serial sections.
 */
public class FilterIndicator extends LinearLayout {

    private LayoutParams unselectedParams, selectedParams;
    private int mIndicatorWidth = 0, mIndicatorHeight = 0, mIndicatorMargin = 0,
            mOrientation = 0, pageinidcatornotselected = 0, pageIndicatorSelected = 0,
            mPreviousPostion = 0, mIndicatorMediumWidth = 0, mIndicatorSmallwidth = 0;

    private int totalCount = 0;


    public FilterIndicator(Context context) {
        this(context, null, 0);

    }

    public FilterIndicator(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public FilterIndicator(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs, defStyleAttr);
    }

    private void init(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        TypedArray a = context.getTheme().obtainStyledAttributes(
                attrs, R.styleable.FilterIndicator, defStyleAttr, defStyleAttr);
        try {
            mIndicatorHeight = a.getDimensionPixelSize(R.styleable.FilterIndicator_indicatorSize, mIndicatorHeight);
            mIndicatorWidth = a.getDimensionPixelSize(R.styleable.FilterIndicator_indicatorSize, mIndicatorWidth);
            mIndicatorMargin = a.getDimensionPixelSize(R.styleable.FilterIndicator_indicatormargin, mIndicatorMargin);
            mOrientation = a.getInteger(R.styleable.FilterIndicator_orientation, mOrientation);
            pageIndicatorSelected = a.getResourceId(R.styleable.FilterIndicator_indicatorSelected, pageIndicatorSelected);
            pageinidcatornotselected = a.getResourceId(R.styleable.FilterIndicator_indicatorUnSelected, pageinidcatornotselected);
            setInidcatorOrientation(mOrientation);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * A Layout that arranges its children in a single column or a single row. The direction of
     * the row can be set by calling {@link #setInidcatorOrientation(int) setInidcatorOrientation()}.
     *
     * @param value 0 -> horizontal, 1-> vertical.
     */
    public void setInidcatorOrientation(int value) throws Exception {
        switch (value) {
            case 0:
                this.setOrientation(HORIZONTAL);
                this.setGravity(Gravity.CENTER);
                break;
            case 1:
                this.setOrientation(VERTICAL);
                this.setGravity(Gravity.CENTER);
                break;
        }
    }

    /**
     * set the number of indicators needed .
     * intial postion is of default height and other indicator will be of size half the size of it.
     *
     * @param inidicatorSize integer value inidicates the number of filters needed.
     */
    public void setSizeOfIndicator(int inidicatorSize) throws Exception {
        int index = 0;

        while (index < inidicatorSize) {

            View indicator = new View(getContext());
            indicator.setBackgroundResource(pageinidcatornotselected);
            if (index == 0)
                addView(indicator, mIndicatorWidth, mIndicatorHeight);
            else
                addView(indicator, mIndicatorWidth / 2, mIndicatorHeight / 2);
            LayoutParams lp = (LayoutParams) indicator.getLayoutParams();
            lp.setMargins(mIndicatorMargin, mIndicatorMargin, mIndicatorMargin, mIndicatorMargin);
            indicator.setLayoutParams(lp);
            index++;
        }
    }


    public void changeIndicatorPostion(int position) throws Exception {

        View previousPostion = getChildAt(mPreviousPostion);
        previousPostion.setBackgroundResource(pageinidcatornotselected);

        ViewGroup.LayoutParams layoutParams = previousPostion.getLayoutParams();
        layoutParams.width = mIndicatorWidth / 2;
        layoutParams.height = mIndicatorHeight / 2;
        previousPostion.setLayoutParams(layoutParams);

        View currentView = getChildAt(position);
        currentView.setBackgroundResource(pageIndicatorSelected);

        ViewGroup.LayoutParams currentViewLayoutParams = currentView.getLayoutParams();
        currentViewLayoutParams.width = mIndicatorWidth;
        currentViewLayoutParams.height = mIndicatorHeight;
        currentView.setLayoutParams(currentViewLayoutParams);

        YoYo.with(Techniques.Pulse).duration(1000).playOn(currentView);

        mPreviousPostion = position;
    }

}
