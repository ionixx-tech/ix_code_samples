package com.dubuqu.dnReceiver;

import android.os.Bundle;
import android.os.Handler;
import android.os.ResultReceiver;

import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnModels.commonModel.GalleryAlbumList;
import com.dubuqu.dnModels.commonModel.GalleryMediaListModel;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Yogaraj subramanian on 26/10/17
 */

public class ImageListLoaderReceiver extends ResultReceiver {

    private Receiver mReceiver;

    public ImageListLoaderReceiver(Handler handler) {
        super(handler);
    }

    public ImageListLoaderReceiver(Handler handler, Receiver mReceiver) {
        super(handler);
        this.mReceiver = mReceiver;
    }

    public interface Receiver {
        void onReceiveResult(HashMap<Date, List<GalleryMediaListModel>> galleryListModel);

        void onReceiveAlbumList(HashMap<String, GalleryAlbumList> albumList);
    }

    @Override
    protected void onReceiveResult(int resultCode, Bundle resultData) {
        super.onReceiveResult(resultCode, resultData);

        if (resultCode == Constants.IMAGELISTRECEIVERREQUEST) {
            HashMap<Date, List<GalleryMediaListModel>> galleryList = (HashMap<Date, List<GalleryMediaListModel>>)
                    resultData.getSerializable(Constants.EXTRASTRINGS);

            mReceiver.onReceiveResult(galleryList);
        }

        if (resultCode == Constants.ALBUMLOADRECEIVEREQUEST) {

            HashMap<String, GalleryAlbumList> galleryList = (HashMap<String, GalleryAlbumList>)
                    resultData.getSerializable(Constants.EXTRASTRINGS);

            mReceiver.onReceiveAlbumList(galleryList);
        }

    }
}
