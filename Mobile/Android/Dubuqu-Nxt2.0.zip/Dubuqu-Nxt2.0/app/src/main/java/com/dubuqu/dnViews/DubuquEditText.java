package com.dubuqu.dnViews;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Typeface;
import android.support.annotation.ColorInt;
import android.util.AttributeSet;
import android.view.KeyEvent;

import com.dubuqu.R;
import com.dubuqu.dnConstants.Constants;

/**
 * Created by Yogaraj subramanian on 24/10/17
 */

public class DubuquEditText extends android.support.v7.widget.AppCompatEditText {

    boolean isBold = false;

    public DubuquEditText(Context context) {
        super(context);
        Typeface typeface = Typeface.createFromAsset(context.getResources().getAssets(), Constants.FONT_LIGHT);
        this.setTypeface(typeface);
    }

    public DubuquEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.DubuquTextView);

        this.isBold = a.getBoolean(R.styleable.DubuquTextView_fontbold, isBold);

        if (isBold) {
            Typeface typeface = Typeface.createFromAsset(context.getResources().getAssets(), Constants.FONTBOLD);
            this.setTypeface(typeface);
        } else {
            Typeface typeface = Typeface.createFromAsset(context.getResources().getAssets(), Constants.FONT_LIGHT);
            this.setTypeface(typeface);
        }
        a.recycle();
    }

    public DubuquEditText(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.DubuquTextView);

        this.isBold = a.getBoolean(R.styleable.DubuquTextView_fontbold, isBold);

        if (isBold) {
            Typeface typeface = Typeface.createFromAsset(context.getResources().getAssets(), Constants.FONTBOLD);
            this.setTypeface(typeface);
        } else {
            Typeface typeface = Typeface.createFromAsset(context.getResources().getAssets(), Constants.FONT_LIGHT);
            this.setTypeface(typeface);
        }
        a.recycle();
    }

    private KeyImeChange keyImeChangeListener;

    public void setKeyImeChangeListener(KeyImeChange listener)
    {
        keyImeChangeListener = listener;
    }

    public interface KeyImeChange
    {
        void onKeyIme(int keyCode, KeyEvent event);
    }


    @Override
    public void setBackgroundColor(@ColorInt int color) {
        super.setBackgroundColor(Color.WHITE);
    }


    @Override
    public boolean onKeyPreIme(int keyCode, KeyEvent event)
    {
        if (keyImeChangeListener != null)
        {
            keyImeChangeListener.onKeyIme(keyCode, event);
        }
        return false;
    }
}
