package com.dubuqu.dnModels.requestModel;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Yogaraj subramanian on 25/10/17
 */

public class CreateUserRequest {


    @SerializedName("user_name")
    private String user_name;

    @SerializedName("country_code")
    private String country_code;

    @SerializedName("mobile_number")
    private String mobile_number;

    @SerializedName("email_id")
    private String email_id;

    @SerializedName("gender")
    private String gender;

    @SerializedName("device_notification_key")
    private String device_notification_key;

    @SerializedName("device_id")
    private String device_id;

    @SerializedName("device_type")
    private String device_type;

    @SerializedName("verification_code")
    private String verification_code;

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getCountry_code() {
        return country_code;
    }

    public void setCountry_code(String country_code) {
        this.country_code = country_code;
    }

    public String getMobile_number() {
        return mobile_number;
    }

    public void setMobile_number(String mobile_number) {
        this.mobile_number = mobile_number;
    }

    public String getEmail_id() {
        return email_id;
    }

    public void setEmail_id(String email_id) {
        this.email_id = email_id;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDevice_notification_key() {
        return device_notification_key;
    }

    public void setDevice_notification_key(String device_notification_key) {
        this.device_notification_key = device_notification_key;
    }

    public String getDevice_id() {
        return device_id;
    }

    public void setDevice_id(String device_id) {
        this.device_id = device_id;
    }

    public String getDevice_type() {
        return device_type;
    }

    public void setDevice_type(String device_type) {
        this.device_type = device_type;
    }

    public String getVerification_code() {
        return verification_code;
    }

    public void setVerification_code(String verification_code) {
        this.verification_code = verification_code;
    }
}
