package com.dubuqu.dnModels.commonModel;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by ionixx on 14/6/17.
 */

public class DubuqShareMediaModel implements Parcelable {
    DubuqContactsShareModel dubuqContactsShareModel;
    boolean isSelected, isHeader;

    public DubuqShareMediaModel(DubuqContactsShareModel dubuqContactsShareModel, boolean isSelected) {
        this.dubuqContactsShareModel = dubuqContactsShareModel;
        this.isSelected = isSelected;
    }


    public DubuqContactsShareModel getDubuqContactsShareModel() {
        return dubuqContactsShareModel;
    }

    public void setDubuqContactsShareModel(DubuqContactsShareModel dubuqContactsShareModel) {
        this.dubuqContactsShareModel = dubuqContactsShareModel;
    }

    public boolean isHeader() {
        return isHeader;
    }

    public void setHeader(boolean header) {
        isHeader = header;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeByte((byte) (isSelected ? 1 : 0));
    }

    protected DubuqShareMediaModel(Parcel in) {
        isSelected = in.readByte() != 0;
    }

    public static final Creator<DubuqShareMediaModel> CREATOR = new Creator<DubuqShareMediaModel>() {
        @Override
        public DubuqShareMediaModel createFromParcel(Parcel in) {
            return new DubuqShareMediaModel(in);
        }

        @Override
        public DubuqShareMediaModel[] newArray(int size) {
            return new DubuqShareMediaModel[size];
        }
    };

}
