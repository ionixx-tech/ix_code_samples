package com.dubuqu.dnModels.requestModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by ionixx on 19/6/17.
 */

public class DubuquShareMediaRequest {

    @SerializedName("media_identifiers")
    @Expose
    private List<String> mediaIdentifiers = null;
    @SerializedName("recipient")
    @Expose
    private List<String> recipient = null;

    public List<String> getMediaIdentifiers() {
        return mediaIdentifiers;
    }

    public void setMediaIdentifiers(List<String> mediaIdentifiers) {
        this.mediaIdentifiers = mediaIdentifiers;
    }

    public List<String> getRecipient() {
        return recipient;
    }

    public void setRecipient(List<String> recipient) {
        this.recipient = recipient;
    }

}
