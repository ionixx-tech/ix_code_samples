package com.dubuqu.dnServices;

import android.app.IntentService;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.ResultReceiver;
import android.support.annotation.Nullable;
import android.util.Log;

import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnModels.commonModel.DubuqContactsShareModel;
import com.dubuqu.dnModels.commonModel.DubuqGroupDetails;
import com.dubuqu.dnModels.commonModel.PhoneContacts;
import com.dubuqu.dnModels.requestModel.DubuquUserRequestModel;
import com.dubuqu.dnModels.responseModel.DubuquGetGroupResponse;
import com.dubuqu.dnModels.responseModel.DubuquUserResponseModel;
import com.dubuqu.dnModels.responseModel.SocialGroupDetailsResponseModel;
import com.dubuqu.dnRestServices.RestServiceController;
import com.dubuqu.dnRestServices.RestServiceProvider;
import com.dubuqu.dnStorage.DbHelper;
import com.dubuqu.dnStorage.RecentShareDbModel;
import com.dubuqu.dnStorage.SessionManager;
import com.dubuqu.dnUtils.RestServiceUtils;
import com.dubuqu.dnUtils.Utils;
import com.github.tamir7.contacts.Contact;
import com.github.tamir7.contacts.Contacts;
import com.github.tamir7.contacts.PhoneNumber;
import com.github.tamir7.contacts.Query;
import com.google.gson.Gson;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;

import static com.dubuqu.dnUtils.Utils.DUBUQU_CATEGORY.DUBUQU_CONTACT;
import static com.dubuqu.dnUtils.Utils.DUBUQU_CATEGORY.PHONE_CONTACT;
import static com.dubuqu.dnUtils.Utils.DUBUQU_CATEGORY.SOCIAL_GROUP;

/**
 * This service is to fetch the phone contacts available in users mobile phone
 * and seperate them as dubqu user and non dubuqu user
 * fetch avaialable  open and close social gorups and list of users available in each
 * social group this service will be stared whenever the app is launced for allowing free flow the
 * contact datas are stored in local directory as a json file in this case everytime the user will be shown
 * the last fetched data once new data arrived the old data  will be rewritten.
 */
public class ContactService extends IntentService {

    //list of phone contacts available in the user mobile
    private List<PhoneContacts> phoneContactsesList;
    //list of dubuqu users available in phoneContactsesList.
    private List<DubuquUserResponseModel> dubuqUserResponseList = new ArrayList<>();
    //list of groups available for the user.
    private List<DubuquGetGroupResponse> dubuquGroupResponseList = new ArrayList<>();
    //list of groups and their details i.e profile pic memory retain state etc..
    private List<DubuqGroupDetails> dubuqGroupDetailses = new ArrayList<>();
    private List<DubuquGetGroupResponse> getGroupResponseList = new ArrayList<>();
    private List<DubuqContactsShareModel> dubuqContacts = new ArrayList<>();
    //an receiver is set to initmate that the service has done its process
    private ResultReceiver receiver;
    //to nullify repeating contacts an hashmap is maintained with phone number as key.
    HashMap<String, String> stringHashMap = new HashMap<>();

    public ContactService() {
        super(ContactService.class.getName());
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        this.phoneContactsesList = new ArrayList<>();
        //reciever instance is received as extra.i.e the activity call the receiver.
        receiver = intent.getParcelableExtra(Constants.EXTRASTRINGS);

        try {
            readPhoneContacts();
        } catch (Exception e) {
            Log.e(ContactService.class.getName(),
                    e.getMessage());
        }
    }

    /**
     * Read phone contacts available in the phone number.
     * every time the hashmap is set and checked if the phone number is repeating of not.
     * since we faced +91 (country code issue) as disscussed with api team if the phone number is not
     * proper i.e country code is missing the country code is automatically assumed as the country code
     * the user has entered in the time of registration.
     */
    private void readPhoneContacts() throws Exception {
        if (phoneContactsesList.size() > 0) {
            phoneContactsesList.clear();
        }

        SessionManager s = new SessionManager(this);
        Gson gson = new Gson();

        Query q = Contacts.getQuery();
        q.hasPhoneNumber();
        List<Contact> contacts = q.find();

        for (Contact c : contacts) {

            List<PhoneNumber> phoneNumbers = c.getPhoneNumbers();
            String sProfilepic = c.getPhotoUri() == null ? "" : c.getPhotoUri();
            String sDisplayName = c.getDisplayName();
            int countryCode = 123;
            long nationalNumber = 1233;
            String phoneNumberS = "";

            if (phoneNumbers != null && phoneNumbers.size() > 0)
                for (PhoneNumber p : phoneNumbers) {

                    String sPhoneNumber = p.getNumber();

                    if (sPhoneNumber != null && sPhoneNumber.length() >= 8) {

                        try {
                            PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
                            Phonenumber.PhoneNumber numberProto = phoneUtil.parse(sPhoneNumber, "");
                            countryCode = numberProto.getCountryCode();
                            nationalNumber = numberProto.getNationalNumber();
                            phoneNumberS = String.valueOf(countryCode).concat(String.valueOf(nationalNumber));

                        } catch (Exception e) {
                            try {
                                String subString = sPhoneNumber.substring(0, 2);
                                if (!String.valueOf(s.getCountryCode()).contains(subString)) {
                                    countryCode = Integer.parseInt(s.getCountryCode());
                                    phoneNumberS = String.valueOf(countryCode).concat(sPhoneNumber);
                                } else {
                                    phoneNumberS = sPhoneNumber;
                                }
                            } catch (Exception e1) {
                                continue;
                            }
                        }

                        sPhoneNumber = phoneNumberS.replaceAll("[^\\d.]", "");

                        if (!stringHashMap.containsKey(sPhoneNumber)) {

                            stringHashMap.put(sPhoneNumber, sPhoneNumber);

                            Log.d("Phone Numbers:", sPhoneNumber);

                            phoneContactsesList.add(new PhoneContacts(phoneNumberS.replaceAll("[^\\d.]", ""),
                                    sDisplayName, String.valueOf(c.getId()), sProfilepic));

                            dubuqContacts.add(new DubuqContactsShareModel(sDisplayName, phoneNumberS.replaceAll("[^\\d.]", ""),
                                    "", sProfilepic, PHONE_CONTACT));
                        }
                    }

                }

        }


        String data = gson.toJson(dubuqContacts);
            /*intial write all the phone contacts to the local data*/
        writeContactToLocal(data);
        fetchDubuqUsers();

    }


    /**
     * for quick share functicionality if the user launches the app for first time top 3 contacts
     * need to be shown so the datas are written to the local db.
     *
     * @param dubuqContactsShareModel details of the contact refer @link(ORM db manangement)
     */

    private void updateTodatabase(DubuqContactsShareModel dubuqContactsShareModel) {
        if (this.getApplicationContext() != null) {
            try {
                DbHelper helper = new DbHelper(ContactService.this);

                RecentShareDbModel recentShare = new RecentShareDbModel();
                recentShare.setUserName(dubuqContactsShareModel.getUserName());
                recentShare.setProfilePic(dubuqContactsShareModel.getProfilePicture());
                switch (dubuqContactsShareModel.getCategory()) {
                    case DUBUQU_CONTACT:
                        recentShare.setIdentifier(dubuqContactsShareModel.getModileNumber());
                        break;
                    case PHONE_CONTACT:
                        recentShare.setIdentifier(dubuqContactsShareModel.getModileNumber());
                        break;
                    case SOCIAL_GROUP:
                        recentShare.setIdentifier(dubuqContactsShareModel.getIdentifier());
                        break;
                    case SOCIAL_OPEN_GROUP:
                        recentShare.setIdentifier(dubuqContactsShareModel.getIdentifier());
                        break;
                }
                helper.insertUser(recentShare);
            } catch (java.sql.SQLException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    /**
     * fetch list of avvailble dubuqu users in the users phone contact.
     */
    private void fetchDubuqUsers() throws Exception {
        try {
            List<String> numbers = new ArrayList<>();
            for (PhoneContacts phoneContacts : phoneContactsesList) {
                numbers.add(phoneContacts.getPhoneNumber());
            }
            DubuquUserRequestModel dubuquUserRequestModel = new DubuquUserRequestModel();
            dubuquUserRequestModel.setMobileNumbers(numbers);

            Gson gson = new Gson();

            String data = gson.toJson(dubuquUserRequestModel);
            OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, getApplicationContext());
            Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
            RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
            RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);

            mRetrofitCallBacks.getDubuqUserList(new RestServiceController.ResponseCallBacks() {
                @Override
                public void onResponse(Object o) {
                    dubuqUserResponseList = (List<DubuquUserResponseModel>) o;
                    try {
                        SessionManager sessionManager = new SessionManager(getApplicationContext());
                        if (!sessionManager.getIsInviteUserNotified()){
                            Intent intent = new Intent(Constants.NODUBQUCONTACTAVAILABLEEVENT);

                            intent.putExtra(Constants.EXTRASTRINGS, dubuqUserResponseList != null ?
                                    dubuqUserResponseList.size() : 0);

                            sendBroadcast(intent);

                            sessionManager.setIsInviteUserNotified();
                        }


                        fetchDubuqGroups();
                    } catch (Exception e) {
                        Log.e(ContactService.class.getName(),
                                e.getMessage());
                    }
                }

                @Override
                public void onFailure(Object o) {

                }

            }, dubuquUserRequestModel);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * fetch list of available groups for the user i.e the groups which are created by the user.
     */
    private void fetchDubuqGroups() throws Exception {
        String data = "{}";
        OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, getApplicationContext());
        Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
        RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
        RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);

        mRetrofitCallBacks.getDubuqGroupList(new RestServiceController.ResponseCallBacks() {
            @Override
            public void onResponse(Object o) {
                try {
                    if (dubuquGroupResponseList.size() > 0)
                        dubuquGroupResponseList.clear();
                    dubuquGroupResponseList.addAll((List<DubuquGetGroupResponse>) o);
                    fetchOpenSocialGroups();
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Object o) {

            }
        });
    }


    /*Fetch list of open groups available to the user i.e the groups which are created as public by
    * other userss*/
    private void fetchOpenSocialGroups() throws Exception {
        String data = "{}";
        OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, getApplicationContext());
        Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
        RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
        RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);

        mRetrofitCallBacks.getAllOpenGroupList(new RestServiceController.ResponseCallBacks() {
            @Override
            public void onResponse(Object o) {
                try {
                    if (o != null) {
                        if (getGroupResponseList.size() > 0)
                            getGroupResponseList.clear();
                        getGroupResponseList.addAll((List<DubuquGetGroupResponse>) o);
                        saveContactsInAppController();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Object o) {

            }
        });
    }

    private void saveContactsInAppController() {
        try {
            DbHelper dbHelper = new DbHelper(this);
            List<DubuqContactsShareModel> dubuqContacts = new ArrayList<>();
            if (getGroupResponseList.size() > 0) {
                for (DubuquGetGroupResponse dubuquGetGroupResponse : getGroupResponseList) {
                    if (dubuquGetGroupResponse.getOwnGroup().equalsIgnoreCase("false")) {
                        dubuqContacts.add(new DubuqContactsShareModel(dubuquGetGroupResponse.getGroupName(),
                                "", dubuquGetGroupResponse.getGroupIdentifier(),
                                dubuquGetGroupResponse.getProfileImage(),
                                SOCIAL_GROUP));
                    }
                }
            }
            if (dubuquGroupResponseList.size() > 0) {
                for (DubuquGetGroupResponse dubuquGetGroupResponse : dubuquGroupResponseList) {

                    dubuqContacts.add(new DubuqContactsShareModel(dubuquGetGroupResponse.getGroupName(),
                            "", dubuquGetGroupResponse.getGroupIdentifier(),
                            dubuquGetGroupResponse.getProfileImage(),
                            SOCIAL_GROUP));

                    new GetGroupDetails().execute(dubuquGetGroupResponse);
                }
            } else {
                if (receiver != null) {
                    receiver.send(Constants.CONTACTSERVICE_REQUESTCODE, new Bundle());
                }
            }

            int index = 0;
            for (PhoneContacts phoneContacts : phoneContactsesList) {
                Utils.DUBUQU_CATEGORY type = PHONE_CONTACT;
                String userName = "", phoneNumber = "", identifer = "", profilepic = "";
                phoneNumber = phoneContacts.getPhoneNumber();
                userName = phoneContacts.getUserName();
                profilepic = phoneContacts.getProfileUrl();
                for (DubuquUserResponseModel dubuquUserResponse : dubuqUserResponseList) {
                    if (phoneNumber.equalsIgnoreCase(dubuquUserResponse.getMobileNumber())) {
                        userName = dubuquUserResponse.getUserName();
                        identifer = dubuquUserResponse.getUserIdentifier();
                        type = DUBUQU_CONTACT;
                        profilepic = dubuquUserResponse.getProfileImage();
                    }
                }
                dubuqContacts.add(new DubuqContactsShareModel(userName, phoneNumber, identifer, profilepic,
                        type));
                List<RecentShareDbModel> recentShareDbModels = dbHelper.getAllRecentusers();
                if (recentShareDbModels.size() == 0 || recentShareDbModels.size() == 1 || recentShareDbModels.size() == 2) {
                    updateTodatabase(new DubuqContactsShareModel(userName, phoneNumber.replaceAll("[^\\d.]", ""),
                            "", profilepic,
                            PHONE_CONTACT));
                }
                index++;
            }

            Gson d = new Gson();
            writeContactToLocal(d.toJson(dubuqContacts));

        } catch (Exception e) {
            e.printStackTrace();
            if (receiver != null) {
                Log.d("COntact service", "onHandleIntent: stopping");
                receiver.send(Constants.CONTACTSERVICE_REQUESTCODE, new Bundle());

            }
        }

    }

    /**
     * fetch dubuqu groups avilable and also the details of the users avilable in the group
     * the datas fetched are stored inside the appcontroller.
     */

    private class GetGroupDetails extends AsyncTask<DubuquGetGroupResponse, Void, Void> {
        DubuquGetGroupResponse dubuquGetGroupResponse;

        @Override
        protected Void doInBackground(DubuquGetGroupResponse... voids) {
            dubuquGetGroupResponse = voids[0];
            String data = "{}";
            OkHttpClient okHttpClient = null;
            try {
                okHttpClient = RestServiceUtils.getHeader(data, getApplicationContext());
                Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
                RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
                RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
                mRetrofitCallBacks.getGroupDetails(dubuquGetGroupResponse.getGroupIdentifier(),
                        new RestServiceController.ResponseCallBacks() {
                            @Override
                            public void onResponse(Object o) {
                                SocialGroupDetailsResponseModel socialGroupDetailsResponseModel =
                                        (SocialGroupDetailsResponseModel) o;
                                dubuquGetGroupResponse.setMemoryRetain(socialGroupDetailsResponseModel.getMemoryRetain());
                                dubuquGetGroupResponse.setAllow_repost(socialGroupDetailsResponseModel.getAllow_repost());

                                fetchavilableDubuquUsersInthegroup(socialGroupDetailsResponseModel,
                                        dubuquGetGroupResponse);
                            }


                            @Override
                            public void onFailure(Object o) {

                            }
                        });

            } catch (Exception e) {
                Log.e(ContactService.class.getName(),
                        e.getMessage());
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
        }
    }

    /**
     * Fetch available user avilable in the group and seperate whether it is dubuqu user or non bubuqu user
     *
     * @param socialGroupDetailsResponseModel List of mobile numbers which are available in the social groups.
     */
    private void fetchavilableDubuquUsersInthegroup(final SocialGroupDetailsResponseModel socialGroupDetailsResponseModel,
                                                    final DubuquGetGroupResponse dubuquGetGroupResponse) {
        try {
            if (socialGroupDetailsResponseModel.getMembers() != null &&
                    socialGroupDetailsResponseModel.getMembers().size() > 0) {

                final DubuquUserRequestModel dubuquUserRequestModel = new DubuquUserRequestModel();
                dubuquUserRequestModel.setMobileNumbers(socialGroupDetailsResponseModel.getMembers());

                Gson gson = new Gson();

                String data = gson.toJson(dubuquUserRequestModel);
                OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, getApplicationContext());
                Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
                RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
                RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);

                mRetrofitCallBacks.getDubuqUserList(new RestServiceController.ResponseCallBacks() {
                    @Override
                    public void onResponse(Object o) {
                        if (o != null) {
                            List<DubuquUserResponseModel> userResponseModels = new ArrayList<>();
                            userResponseModels.addAll((List<DubuquUserResponseModel>) o);

                            List<DubuqContactsShareModel> availableContactinGroup = new ArrayList<>();


                            Utils.DUBUQU_CATEGORY type = PHONE_CONTACT;
                            SessionManager sessionManager = new SessionManager(getApplicationContext());
                            try {
                                for (String phoneContacts : socialGroupDetailsResponseModel.getMembers()) {

                                    String userName = "", identifer = "", profilepic = "";

                                    if (!phoneContacts.contains(sessionManager.getPhoneNumber())) {

                                        for (DubuqContactsShareModel dubuqContactsShareModel : dubuqContacts) {

                                            if (dubuqContactsShareModel.getModileNumber().contains(phoneContacts)) {

                                                for (DubuquUserResponseModel dubuquUserResponse : userResponseModels) {

                                                    if (phoneContacts.contains(dubuquUserResponse.getMobileNumber())) {

                                                        type = DUBUQU_CONTACT;
                                                        identifer = dubuquUserResponse.getUserIdentifier();
                                                        profilepic = dubuquUserResponse.getProfileImage();

                                                        break;
                                                    } else {
                                                        profilepic = dubuqContactsShareModel.getProfilePicture();
                                                    }
                                                }

                                                userName = dubuqContactsShareModel.getUserName();
                                                break;
                                            }
                                        }

                                        availableContactinGroup.add(new DubuqContactsShareModel(userName, phoneContacts, identifer, profilepic, type));
                                    } else {
                                        availableContactinGroup.add(
                                                new DubuqContactsShareModel("You",
                                                        phoneContacts,
                                                        sessionManager.getUserIdentifier(),
                                                        sessionManager.getUserProfileUri(),
                                                        DUBUQU_CONTACT));
                                    }
                                }

                                dubuqGroupDetailses.add(new DubuqGroupDetails(
                                        dubuquGetGroupResponse,
                                        availableContactinGroup));

                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }

                        Gson s = new Gson();
                        writeGroupDetailsToLocal(s.toJson(dubuqGroupDetailses));

                        if (dubuqGroupDetailses.size() == dubuquGroupResponseList.size()) {
                            if (receiver != null) {
                                receiver.send(Constants.CONTACTSERVICE_REQUESTCODE, new Bundle());
                            }
                        }
                    }

                    @Override
                    public void onFailure(Object o) {

                        receiver.send(Constants.CONTACTSERVICE_REQUESTCODE, new Bundle());
                    }

                }, dubuquUserRequestModel);

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void writeContactToLocal(String data) {


        File file = new File(getCacheDir(), Constants.JSONFILENAME);

        try {
            FileOutputStream fos = new FileOutputStream(file.getAbsolutePath());
            fos.write(data.getBytes());
            fos.flush();
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void writeGroupDetailsToLocal(String data) {

        File file = new File(getCacheDir(), Constants.JSONGROUPFILENAME);

        try {
            FileOutputStream fos = new FileOutputStream(file.getAbsolutePath());
            fos.write(data.getBytes());
            fos.flush();
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
