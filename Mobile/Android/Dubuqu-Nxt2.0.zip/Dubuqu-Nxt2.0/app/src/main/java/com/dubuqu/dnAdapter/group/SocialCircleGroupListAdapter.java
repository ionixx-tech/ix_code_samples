package com.dubuqu.dnAdapter.group;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.Switch;
import android.widget.TextView;

import com.dubuqu.R;
import com.dubuqu.dnActivity.LandingActivity;
import com.dubuqu.dnModels.commonModel.ActionConformationDialog;
import com.dubuqu.dnModels.commonModel.DubuqContactsShareModel;
import com.dubuqu.dnModels.commonModel.DubuqGroupDetails;
import com.dubuqu.dnModels.requestModel.CreateGroupRequest;
import com.dubuqu.dnModels.responseModel.DubuquGetGroupResponse;
import com.dubuqu.dnRestServices.RestServiceController;
import com.dubuqu.dnRestServices.RestServiceProvider;
import com.dubuqu.dnUtils.RestServiceUtils;
import com.dubuqu.dnUtils.Utils;
import com.dubuqu.dnViews.ExpandableItem;
import com.dubuqu.dnViews.ExpandableRecyclerView;
import com.google.gson.Gson;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import okhttp3.OkHttpClient;
import retrofit2.Retrofit;

import static android.content.Context.LAYOUT_INFLATER_SERVICE;

/**
 * Created by Yogaraj subramanian on 28/6/17
 */

public class SocialCircleGroupListAdapter extends ExpandableRecyclerView.Adapter<
        SocialCircleGroupListAdapter.AvailableSocialGroupAdapterViewholder> implements Filterable {

    private final String TAG = SocialCircleGroupListAdapter.class.getName();

    private Context context;
    private List<DubuqGroupDetails> dubuqGroupDetailses;
    private List<DubuqGroupDetails> dubuqGroupDetailsesFilter;
    private SocialCircleListCallBacks socialCircleListCallBacks;

    public enum OptionsSelected {
        DELTE_GROUP,
        EDIT_GROUP
    }

    public interface SocialCircleListCallBacks {
        void writeDataToLocal();

        void onItemClicked(int position, OptionsSelected optionsSelected);
    }

    public SocialCircleGroupListAdapter(@NonNull LinearLayoutManager lm,
                                        Context context,
                                        List<DubuqGroupDetails> dubuqGroupDetailses,
                                        List<DubuqGroupDetails> dubuqGroupDetailses1,
                                        SocialCircleListCallBacks socialCircleListCallBacks) {
        super(lm);
        this.context = context;
        this.dubuqGroupDetailses = dubuqGroupDetailses;
        this.dubuqGroupDetailsesFilter = dubuqGroupDetailses1;
        this.socialCircleListCallBacks = socialCircleListCallBacks;
    }

    @Override
    public AvailableSocialGroupAdapterViewholder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.grouplistviewholder, parent, false);
        return new AvailableSocialGroupAdapterViewholder(view);
    }

    @Override
    public void onBindViewHolder(AvailableSocialGroupAdapterViewholder holder, int position, List<Object> payloads) {
        super.onBindViewHolder(holder, position, payloads);
        try {
            holder.onBind(position);
        } catch (Exception e) {
            if (context instanceof LandingActivity) {
                ((LandingActivity) context).writeCrashReport(TAG, e.getMessage());
            }
        }
    }


    @Override
    public int getItemViewType(int position) {
        return dubuqGroupDetailsesFilter.get(position).hashCode();
    }

    @Override
    public long getItemId(int position) {
        return dubuqGroupDetailsesFilter.get(position).hashCode();
    }

    @Override
    public int getItemCount() {
        return dubuqGroupDetailsesFilter.size();
    }

    class AvailableSocialGroupAdapterViewholder extends RecyclerView.ViewHolder {


        ExpandableItem expandableItem;
        /*header items*/
        ImageView privateGroupIndicator, deleteGroup, editGroup;

        CircleImageView groupProfilePic, borderIndicator;

        TextView gropName, memberCount, seeMore;

        LinearLayout groupCountLL, groupEditOptionLL, seeMoreLL;

        /*content items*/
        TextView participantCount;

        Switch saveAsAlbum, allowRepost;

        RecyclerView participantlistRCV;


        AvailableSocialGroupAdapterViewholder(View itemView) {
            super(itemView);

            expandableItem = itemView.findViewById(R.id.socailcircle_row_items);

            privateGroupIndicator = expandableItem.getHeaderLayout().findViewById(R.id.social_circle_list_header_private_indicator);

            groupProfilePic = expandableItem.getHeaderLayout().findViewById(R.id.social_circle_list_header_profile_imv);

            gropName = expandableItem.getHeaderLayout().findViewById(R.id.social_circle_list_header_group_name);

            groupCountLL = expandableItem.getHeaderLayout().findViewById(R.id.group_member_count_ll);

            groupEditOptionLL = expandableItem.getHeaderLayout().findViewById(R.id.group_options_ll);

            memberCount = expandableItem.getHeaderLayout().findViewById(R.id.social_circle_list_header_member_count);

            editGroup = expandableItem.getHeaderLayout().findViewById(R.id.social_circle_list_header_edit_group);

            deleteGroup = expandableItem.getHeaderLayout().findViewById(R.id.social_circle_list_header_delete_group);

            participantCount = expandableItem.getContentLayout().findViewById(R.id.social_circle_list_contnet_participant_count);

            saveAsAlbum = expandableItem.getContentLayout().findViewById(R.id.save_as_album_switch);

            allowRepost = expandableItem.getContentLayout().findViewById(R.id.reshare_switch);

            participantlistRCV = expandableItem.getContentLayout().findViewById(R.id.social_circle_list_contnet_participant_rcv);

            participantlistRCV.setLayoutManager(new GridLayoutManager(context, 3));

            borderIndicator = expandableItem.getHeaderLayout().findViewById(R.id.border_indicator);

            seeMore = expandableItem.getContentLayout().findViewById(R.id.social_circle_list_contnet_see_more);

            seeMoreLL = expandableItem.getContentLayout().findViewById(R.id.social_circle_list_contnet_see_more_ll);

            seeMoreLL.setVisibility(View.GONE);
        }

        void onBind(final int position) throws Exception {

            final DubuqGroupDetails dubuqGroupDetails = dubuqGroupDetailsesFilter.get(position);

            final DubuquGetGroupResponse dubuquGetGroupResponse = dubuqGroupDetails.getDubuquGetGroupResponse();

            final List<DubuqContactsShareModel> participantList = dubuqGroupDetails.getDubuquUserResponseModels();

            final boolean isGroupPrivate = dubuquGetGroupResponse.getGroupType().equalsIgnoreCase("closed");

            boolean isReShareAllowed = dubuquGetGroupResponse.getAllow_repost().equalsIgnoreCase("true");

            boolean isSaveAsAlbumEnabled = dubuquGetGroupResponse.getMemoryRetain().equalsIgnoreCase("true");

            saveAsAlbum.setChecked(isSaveAsAlbumEnabled);

            allowRepost.setChecked(isReShareAllowed);

            if (isGroupPrivate) {
                privateGroupIndicator.setVisibility(View.VISIBLE);
                borderIndicator.setVisibility(View.VISIBLE);
            } else {
                privateGroupIndicator.setVisibility(View.GONE);
                borderIndicator.setVisibility(View.GONE);
            }

            participantCount.setText(dubuquGetGroupResponse.getMemberCount().concat(context.getString(R.string.participants)));

            saveAsAlbum.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                    if (isChecked) {

                        if (isGroupPrivate) {
                            saveAsAlbum.setChecked(false);
                            Utils.showNegativeTost(context, context.getString(R.string.need_to_be_public_group));
                        } else {
                            dubuquGetGroupResponse.setMemoryRetain(String.valueOf(true));
                            updateGroupDetails(dubuquGetGroupResponse, dubuqGroupDetails);
                        }
                    } else {
                        dubuquGetGroupResponse.setMemoryRetain(String.valueOf(false));
                        updateGroupDetails(dubuquGetGroupResponse, dubuqGroupDetails);
                    }
                }
            });

            allowRepost.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                    if (isChecked) {

                        if (isGroupPrivate) {
                            allowRepost.setChecked(false);
                            Utils.showNegativeTost(context, context.getString(R.string.need_to_be_public_group));
                        } else {
                            dubuquGetGroupResponse.setAllow_repost(String.valueOf(true));
                            updateGroupDetails(dubuquGetGroupResponse, dubuqGroupDetails);
                        }
                    } else {
                        dubuquGetGroupResponse.setAllow_repost(String.valueOf(false));
                        updateGroupDetails(dubuquGetGroupResponse, dubuqGroupDetails);
                    }
                }
            });

            final Drawable drawable = new BitmapDrawable(Utils.textAsBitmap(dubuquGetGroupResponse.getGroupName(), context));

            if (!dubuquGetGroupResponse.getProfileImage().equalsIgnoreCase("")) {

                ImageLoader.getInstance().displayImage(dubuquGetGroupResponse.getProfileImage(),
                        groupProfilePic, new ImageLoadingListener() {
                            @Override
                            public void onLoadingStarted(String imageUri, View view) {
                                groupProfilePic.setImageDrawable(drawable);
                            }

                            @Override
                            public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
                                groupProfilePic.setImageDrawable(drawable);
                            }

                            @Override
                            public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                                groupProfilePic.setImageBitmap(loadedImage);
                            }

                            @Override
                            public void onLoadingCancelled(String imageUri, View view) {
                                groupProfilePic.setImageDrawable(drawable);
                            }
                        });

            } else {
                groupProfilePic.setImageDrawable(drawable);
            }

            gropName.setText(dubuquGetGroupResponse.getGroupName());

            memberCount.setText(dubuquGetGroupResponse.getMemberCount());

            GroupParticipantAdapter groupParticipantAdapter = new GroupParticipantAdapter(participantList, context,
                    GroupParticipantAdapter.ViewType.NORAML);

            participantlistRCV.setAdapter(groupParticipantAdapter);

            expandableItem.setExpandPanelStateListener(new ExpandableItem.OnExpandPanelStateListener() {
                @Override
                public void onOpened() {
                    groupCountLL.setVisibility(View.GONE);
                    groupEditOptionLL.setVisibility(View.VISIBLE);
                }

                @Override
                public void onClosed() {
                    groupCountLL.setVisibility(View.VISIBLE);
                    groupEditOptionLL.setVisibility(View.GONE);
                }
            });

            if (participantList.size() > 3) {
                seeMoreLL.setVisibility(View.VISIBLE);
                int memberCount = Integer.parseInt(dubuquGetGroupResponse.getMemberCount());
                seeMore.setText("+".concat(String.valueOf(memberCount - 3)));

                seeMore.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        try {
                            openFullList(participantList);
                        } catch (Exception e) {
                            if (context instanceof LandingActivity) {
                                ((LandingActivity) context).writeCrashReport(TAG, e.getMessage());
                            }
                        }
                    }
                });
            }


            deleteGroup.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try {
                        Utils.addReppleEffectToview(context, view);
                        android.os.Handler handler = new android.os.Handler();
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    showDeleteMediaConformation(dubuquGetGroupResponse.getGroupIdentifier(),
                                            position);
                                } catch (Exception e) {
                                    if (context instanceof LandingActivity) {
                                        ((LandingActivity) context).writeCrashReport(TAG, e.getMessage());
                                    }
                                }
                                expandableItem.hide();
                            }
                        }, 500);

                    } catch (Exception e) {
                        if (context instanceof LandingActivity) {
                            ((LandingActivity) context).writeCrashReport(TAG, e.getMessage());
                        }
                    }
                }
            });

            editGroup.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try {
                        Utils.addReppleEffectToview(context, editGroup);
                        Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                expandableItem.hide();

                                socialCircleListCallBacks.onItemClicked(position, OptionsSelected.EDIT_GROUP);
                            }
                        }, 500);


                    } catch (Exception e) {
                        if (context instanceof LandingActivity) {
                            ((LandingActivity) context).writeCrashReport(TAG, e.getMessage());
                        }
                    }
                }
            });


        }

        /**
         * Show list of available user in the group.
         *
         * @param participantList {@link List} of {@link DubuqContactsShareModel}
         * @throws Exception {Runtime Stub Exception}
         */
        private void openFullList(List<DubuqContactsShareModel> participantList) throws Exception {

            RecyclerView recyclerView;

            ImageView back;

            LayoutInflater inflater = (LayoutInflater)
                    context.getSystemService(LAYOUT_INFLATER_SERVICE);

            View inflate = inflater.inflate(R.layout.group_list_memeber_full_list, null);

            final PopupWindow popupWindow = new PopupWindow(context);

            recyclerView = inflate.findViewById(R.id.group_list_memeber_rcv);
            recyclerView.setLayoutManager(new LinearLayoutManager(context));
            recyclerView.setAdapter(new GroupParticipantAdapter(splitView(participantList), context, GroupParticipantAdapter.ViewType.SEELIST));

            back = inflate.findViewById(R.id.popup_close);

            back.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    popupWindow.dismiss();
                }
            });

            inflate.setFocusableInTouchMode(true);
            inflate.requestFocus();
            inflate.setOnKeyListener(new View.OnKeyListener() {
                @Override
                public boolean onKey(View v, int keyCode, KeyEvent event) {
                    if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK) {
                        popupWindow.dismiss();
                        return true;
                    }
                    return false;
                }
            });


            popupWindow.setContentView(inflate);
            popupWindow.setWidth(LinearLayout.LayoutParams.MATCH_PARENT);
            popupWindow.setHeight(LinearLayout.LayoutParams.MATCH_PARENT);
            popupWindow.setFocusable(true);
            popupWindow.setBackgroundDrawable(null);
            popupWindow.showAtLocation(inflate, Gravity.TOP, 0, 0);
        }


        private List<DubuqContactsShareModel> splitView(List<DubuqContactsShareModel> participantList) throws Exception {

            List<DubuqContactsShareModel> dubuquContacts = new ArrayList<>();

            List<DubuqContactsShareModel> phoneCOntacts = new ArrayList<>();

            for (DubuqContactsShareModel contacts : participantList) {

                if (contacts.getCategory() == Utils.DUBUQU_CATEGORY.DUBUQU_CONTACT)
                    dubuquContacts.add(contacts);
                else if (contacts.getCategory() == Utils.DUBUQU_CATEGORY.PHONE_CONTACT)
                    phoneCOntacts.add(contacts);
            }

            if (dubuquContacts.size() > 0)
                dubuquContacts.add(0, new DubuqContactsShareModel("Dubuqu Contacts", "", "", "", Utils.DUBUQU_CATEGORY.HEADER));

            if (phoneCOntacts.size() > 0)
                phoneCOntacts.add(0, new DubuqContactsShareModel("Phone Contacts", "", "", "", Utils.DUBUQU_CATEGORY.HEADER));

            dubuquContacts.addAll(phoneCOntacts);

            return dubuquContacts;
        }
    }


    @Override
    public Filter getFilter() {

        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {

                List<DubuqGroupDetails> dubuqGroupDetailsesFilter = new ArrayList<>();
                if (constraint.length() == 0) {
                    dubuqGroupDetailsesFilter = dubuqGroupDetailses;
                } else {
                    dubuqGroupDetailsesFilter = getFilteredResults(constraint.toString().toLowerCase());
                }
                FilterResults results = new FilterResults();

                results.values = dubuqGroupDetailsesFilter;
                return results;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                dubuqGroupDetailsesFilter = (List<DubuqGroupDetails>) results.values;
                SocialCircleGroupListAdapter.this.notifyDataSetChanged();
            }
        };
    }


    List<DubuqGroupDetails> getFilteredResults(String constraint) {
        List<DubuqGroupDetails> results = new ArrayList<>();

        for (DubuqGroupDetails item : dubuqGroupDetailses) {
            final DubuquGetGroupResponse dubuquGetGroupResponse = item.getDubuquGetGroupResponse();
            if (dubuquGetGroupResponse.getGroupName().toLowerCase().contains(constraint)) {
                results.add(item);
            }
        }
        return results;
    }

    private void updateGroupDetails(DubuquGetGroupResponse dubuquGetGroupResponse, DubuqGroupDetails dubuqGroupDetails) {

        final CreateGroupRequest createGroupRequest = new CreateGroupRequest(dubuquGetGroupResponse.getGroupName(),
                dubuquGetGroupResponse.getGroupType(), dubuquGetGroupResponse.getMemoryRetain(), getMembers(dubuqGroupDetails), dubuquGetGroupResponse.getAllow_repost());
        Gson gson = new Gson();
        try {
            String data = gson.toJson(createGroupRequest);
            OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, context);
            Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
            RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
            RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
            mRetrofitCallBacks.updateGroup(dubuquGetGroupResponse.getGroupIdentifier(), createGroupRequest, new RestServiceController.ResponseCallBacks() {
                @Override
                public void onResponse(Object o) {
                    socialCircleListCallBacks.writeDataToLocal();
                    Utils.showToast(context, "Group Updated.");
                }

                @Override
                public void onFailure(Object o) {
                    if (o != null) {

                        if (context instanceof LandingActivity) {
                            try {
                                if (o instanceof retrofit2.Response) {
                                    ((LandingActivity) context).showToastMessage(((retrofit2.Response) o).message(), false);
                                } else if (o instanceof Throwable) {
                                    ((LandingActivity) context).showToastMessage(((Throwable) o).getMessage(), false);
                                }

                            } catch (Exception e) {
                                if (context instanceof LandingActivity) {
                                    ((LandingActivity) context).writeCrashReport(TAG, e.getMessage());
                                }
                            }
                        }

                    }
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * Show delete media popup UI for conformation
     *
     * @param groupIdentifier identifier of the group that need to be deleted.
     * @param postion         position of the group that need to be delted.
     * @throws Exception{Runtime Stub Exception.}
     */
    private void showDeleteMediaConformation(final String groupIdentifier, final int postion) throws Exception {

        new ActionConformationDialog(
                context.getString(R.string.delete_group),
                context.getString(R.string.confirm_delete_group),
                context,
                new ActionConformationDialog.OnActionCOnformationListner() {

                    @Override
                    public void onConformed() {
                        try {
                            deleteGroupAPICALL(groupIdentifier, postion);
                        } catch (Exception e) {
                            if (context instanceof LandingActivity) {
                                ((LandingActivity) context).writeCrashReport(TAG, e.getMessage());
                            }
                        }
                    }

                    @Override
                    public void onRejected() {

                    }
                });
    }


    private void deleteGroupAPICALL(String groupIdentifier, final int postion) throws Exception {
        String data = "{}";
        OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, context);
        Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
        RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
        RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
        mRetrofitCallBacks.deleteGroup(groupIdentifier, new RestServiceController.ResponseCallBacks() {
            @Override
            public void onResponse(Object o) {

                socialCircleListCallBacks.onItemClicked(postion, OptionsSelected.DELTE_GROUP);

                notifyDataSetChanged();
            }

            @Override
            public void onFailure(Object o) {
                if (o != null) {

                    if (context instanceof LandingActivity) {
                        try {
                            if (o instanceof retrofit2.Response) {
                                ((LandingActivity) context).showToastMessage(((retrofit2.Response) o).message(), false);
                            } else if (o instanceof Throwable) {
                                ((LandingActivity) context).showToastMessage(((Throwable) o).getMessage(), false);
                            }

                        } catch (Exception e) {
                            if (context instanceof LandingActivity) {
                                ((LandingActivity) context).writeCrashReport(TAG, e.getMessage());
                            }
                        }
                    }

                }
            }
        });
    }

    @Nullable
    private List<String> getMembers(DubuqGroupDetails dubuqGroupDetails) {
        List<DubuqContactsShareModel> dubuqContactsShareModels = dubuqGroupDetails.getDubuquUserResponseModels();

        List<String> members = new ArrayList<>();
        for (DubuqContactsShareModel dubuqContactsShareModel : dubuqContactsShareModels) {
            members.add(dubuqContactsShareModel.getModileNumber());
        }
        return null;
    }


}
