package com.dubuqu.dnRestServices;


import com.dubuqu.dnActivity.home.HomeDetailImageViewer;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnModels.commonModel.NotificationModel;
import com.dubuqu.dnModels.requestModel.Captions;
import com.dubuqu.dnModels.requestModel.CreateGroupRequest;
import com.dubuqu.dnModels.requestModel.CreateUserRequest;
import com.dubuqu.dnModels.requestModel.DubuquShareMediaRequest;
import com.dubuqu.dnModels.requestModel.DubuquUserRequestModel;
import com.dubuqu.dnModels.requestModel.GifResponse;
import com.dubuqu.dnModels.requestModel.PhoneNumberVerificationRequest;
import com.dubuqu.dnModels.requestModel.PostMediaComment;
import com.dubuqu.dnModels.requestModel.PublicShareRequestModel;
import com.dubuqu.dnModels.responseModel.BlockedUserModel;
import com.dubuqu.dnModels.responseModel.CreateGroupResponse;
import com.dubuqu.dnModels.responseModel.CreateUserResponse;
import com.dubuqu.dnModels.responseModel.DubuquGetGroupResponse;
import com.dubuqu.dnModels.responseModel.DubuquUserModel;
import com.dubuqu.dnModels.responseModel.DubuquUserResponseModel;
import com.dubuqu.dnModels.responseModel.FetchAllUserEvent;
import com.dubuqu.dnModels.responseModel.FollwoingUserResponse;
import com.dubuqu.dnModels.responseModel.GetAllMediaTimeLine;
import com.dubuqu.dnModels.responseModel.GetAllSharedMediaModel;
import com.dubuqu.dnModels.responseModel.GetTimeLineStory;
import com.dubuqu.dnModels.responseModel.MediaComment;
import com.dubuqu.dnModels.responseModel.MediaLikeDetails;
import com.dubuqu.dnModels.responseModel.PublicMediaResponseModel;
import com.dubuqu.dnModels.responseModel.SearchUserModel;
import com.dubuqu.dnModels.responseModel.SharedMedia;
import com.dubuqu.dnModels.responseModel.SharedMedias;
import com.dubuqu.dnModels.responseModel.SignedUrlResponseModel;
import com.dubuqu.dnModels.responseModel.SocialGroupDetailsResponseModel;
import com.dubuqu.dnModels.responseModel.UpdateGroupProfileRequest;
import com.dubuqu.dnModels.responseModel.UserDetails;
import com.dubuqu.dnModels.responseModel.WhatsHappeningModel;

import java.util.List;

import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Part;
import retrofit2.http.Path;
import retrofit2.http.Query;


/**
 * Created by Yogaraj subramanian on 19/4/17
 */

public interface RestServiceProvider<E> {

    String BASEURL = Constants.BASE_API_PATH;

    /*----------------------------------Registration ---------------------------------------*/

    @POST("generate-verification-code/")
    Call<ResponseBody> generateVerificationCode(
            @Body PhoneNumberVerificationRequest phoneNumberVerificationRequest);

    @POST("check-verification-code/")
    Call<ResponseBody> checkIsVerificationCodeIsvalid(@Body PhoneNumberVerificationRequest phoneNumberVerificationRequest);

    @POST("user/")
    Call<CreateUserResponse> createUser(@Body CreateUserRequest createUserRequest);

    /*---------------------------------------------DubquUser-----------------------------------------*/

    /**
     * This API is used to fetch dubuqu user information using mobile number
     * Pagination will be not supported for this API.
     * http://52.76.204.166/dubuqu-nxt/api/user/dubuqu-user
     * <p>
     * Parameter
     * mobile_numbers	JSON_Array	Embedded array of Mobile number which will requested.
     * Dubuqu user alone will be retrieved in response.
     */
    @POST("user/dubuqu-user")
    Call<List<DubuquUserResponseModel>> getDubuqUsersList(
            @Body DubuquUserRequestModel dubuquUserRequestModels);

    /*update user details*/
    @PUT("user/{user_identifier}")
    Call<ResponseBody> updateUserDetails(@Path(Constants.USER_IDENTIFIER) String userIdentifier,
                                         @Body UserDetails userDetails);

    /**
     * encryption test call
     */
    @POST("user/dubuqu-user")
    Call<String> getDubuqUsersList(@Body String encrpytedString);

    /*update user Profile image*/
    @PUT("user/{user_identifier}/profile-image")
    Call<ResponseBody> updateUserProfileImage(@Path(Constants.USER_IDENTIFIER) String userIdentifier,
                                              @Body UpdateGroupProfileRequest updateGroupProfileRequest);

    /**
     * This API is used to fetch user details. If requested user and logged in are matched
     * then all information will be retrieved. Otherwise user_name and profile picture only will be retrieved.
     * <p>
     * GET
     * http://52.76.204.166/dubuqu-nxt/api/user/:user_identifier
     */
    @GET("user/{user_identifier}")
    Call<DubuquUserModel> getUserDetails(@Path("user_identifier") String userIdentifier);

    /**
     * This API is used to fetch actual user profile image (Full size image).
     * <p>
     * GET
     * http://52.76.204.166/dubuqu-nxt/api/user/profile-image
     *
     * @param userIdentifier the identifier of the user whose profile image need to be fetched.
     * @return
     */
    @GET("user/{user_identifier}/profile-image")
    Call<ResponseBody> getUserProfileImage(@Path("user_identifier") String userIdentifier);


    /*----------------------------------------Social Gorups---------------------------------------*/

    /**
     * This API is used to fetch social group details
     * <p>
     * GET
     * http://52.76.204.166/dubuqu-nxt/api/social-group/:group_identifier
     * Parameter          FieldType	Description
     * group_identifier	String      Unique group identifier for getting details.
     */
    @GET("social-group/{group_identifier}")
    Call<SocialGroupDetailsResponseModel> getGroupDetails(@Path(Constants.GROUP_IDENTIFIER) String group_identifier);

    /**
     * This API is used to create a social group
     * <p>
     * POST
     * http://52.76.204.166/dubuqu-nxt/api/social-group/
     */
    @POST("social-group/")
    Call<CreateGroupResponse> createGroup(@Body CreateGroupRequest createGroupRequest);

    /**
     * This API is used to update the social group profile image.
     * This API has to called after upload image to S3 using generate-signed-url and provide
     * the media identifier for profile_image_identifier
     * PUT
     * http://52.76.204.166/dubuqu-nxt/api/social-group/:group_identifier/profile-image
     */
    @PUT("social-group/{group_identifier}/profile-image")
    Call<ResponseBody> updategroupProfileImage(@Path(Constants.GROUP_IDENTIFIER) String grroupIdentifier,
                                               @Body UpdateGroupProfileRequest updateGroupProfileRequest);

    /**
     * This API is used to delete the social group
     * <p>
     * DELETE
     * http://52.76.204.166/dubuqu-nxt/api/social-group/:group_identifier
     */

    @DELETE("social-group/{group_identifier}")
    Call<ResponseBody> deleteGroup(@Path(Constants.GROUP_IDENTIFIER) String grroupIdentifier);

    /**
     * This API is used to update the social group information
     * <p>
     * PUT
     * http://52.76.204.166/dubuqu-nxt/api/social-group/:group_identifier
     */
    @PUT("social-group/{group_identifier}")
    Call<CreateGroupResponse> updateGroup(@Path(Constants.GROUP_IDENTIFIER) String grroupIdentifier,
                                          @Body CreateGroupRequest createGroupRequest);

    /*This API is used to fetch all group details
  * http://52.76.204.166/dubuqu-nxt/api/social-group/
  * */
    @GET("social-group/")
    Call<List<DubuquGetGroupResponse>> getDubuqGroupResponse();


    @GET("social-group/share-social-circle/")
    Call<List<DubuquGetGroupResponse>> getOpenGroupResponse();


    /*------------------------------------------------------Vault------------------------------*/

    /*get all public shared medias that is my top 10 medias*/
    @GET("public-media/")
    Call<List<PublicMediaResponseModel>> getAllPublicMedia();

    /**
     * This API is used to fetch specific user's public shared medias.
     * <p>
     * GET
     * http://52.76.204.166/dubuqu-nxt/api/public-media/user/:user_identifier
     */
    @GET("public-media/user/{user_identifier}")
    Call<List<SharedMedia>> fetchMediaSharedByUser(@Path("user_identifier") String user_identifier);


    /**
     * This API is used to fetch all media which is shared by requested user. Each contact has 5 media details by default.
     * GET
     * http://52.76.204.166/dubuqu-nxt/api/media/stories
     */

    @GET("media/stories")
    Call<List<FetchAllUserEvent>> fetchAlluserEvents();

    /**
     * This API is used for delete the shared media.
     * <p>
     * DELETE
     * http://52.76.204.166/dubuqu-nxt/api/media/:media_identifier
     */

    @DELETE("media/{media_identifier}")
    Call<ResponseBody> deleteMedia(@Path("media_identifier") String media_identifier);

    /**
     * This API is used to mark the comments for the media is read by media share owner.
     * <p>
     * PUT
     * http://52.76.204.166/dubuqu-nxt/api/media/:media_identifier/read-comment
     */
    @PUT("media/{media_identifier}/read-comment")
    Call<ResponseBody> readCommets(@Path("media_identifier") String media_identifier);

    /**
     * This API is used to fetch user's public information.
     * <p>
     * GET
     * http://52.76.204.166/dubuqu-nxt/api/user/
     * Parameter
     * <p>
     * Field	Type	Description
     * search_keyword	String
     * The collection response will be filtered based on this String value.
     */
    @GET("user/")
    Call<List<SearchUserModel>> searchUser(@Query("search_keyword") String searchKey);

    /*----------------------------------followers--------------------------------------------------*/

    /**
     * This API is used to get following details by user identifier
     * <p>
     * GET
     * http://52.76.204.166/dubuqu-nxt/api/user/:user_identifier/following-user
     * Response
     * HTTP/1.1 200 OK
     * [
     * {
     * "user_identifier": "Sy0Baa4woiWfdsA",
     * "user_name": "John kanady",
     * "profile_image": ""
     * },
     * {
     * "user_identifier": "Sy0Baa4woiWfdsB",
     * "user_name": "Abraham",
     * "profile_image": ""
     * }
     * ]
     */
    @GET("user/{user_identifier}/following-user")
    Call<List<FollwoingUserResponse>> fetchFollowingList(@Path("user_identifier") String user_identifier);

    /**
     * This API is used to following the user
     * <p>
     * POST
     * http://52.76.204.166/dubuqu-nxt/api/user/:user_identifier/follow
     * Parameter
     * <p>
     * Field	Type	Description
     * user_identifier	String
     * Users unique identifier for user who is being followed.
     * <p>
     * Request-Response
     * Request:
     * <p>
     * {
     * }
     * <p>
     * Response:
     * <p>
     * HTTP/1.1 200 OK
     * {
     * }
     */
    @POST("user/{user_identifier}/follow")
    Call<ResponseBody> followUser(@Path("user_identifier") String user_identifier);

    /**
     * This API is used to unfollowing the user
     * <p>
     * POST
     * http://52.76.204.166/dubuqu-nxt/api/user/:user_identifier/unfollow
     * Parameter
     * <p>
     * Field	Type	Description
     * user_identifier	String
     * Users unique identifier for user who follows.
     * <p>
     * Request-Response
     * Request:
     * <p>
     * {
     * }
     * <p>
     * Response:
     * <p>
     * HTTP/1.1 200 OK
     * {
     * }
     */
    @POST("user/{user_identifier}/unfollow")
    Call<ResponseBody> unFollowUser(@Path("user_identifier") String user_identifier);


    @GET("user/{user_identifier}/follower-user")
    Call<List<FollwoingUserResponse>> getFollowersList(@Path("user_identifier") String user_identifier);
    /*-------------------------------------------------------------------------------------------*/

    /**
     * This API is used to get all media which is in unread shared by requested user.
     * GET
     * http://52.76.204.166/dubuqu-nxt/api/media/stories/unread-media
     */
    @GET("media/stories/unread-media")
    Call<List<WhatsHappeningModel>> getWhatsHappening();

    /**
     * This API is used to fetch all media which is shared to requested user.
     * Each contact has 10 media details by default.
     * <p>
     * GET
     * GetAllSharedMediaModel/
     */

    @GET("media/")
    Call<List<GetAllSharedMediaModel>> getAllSharedMedia();

    @GET("media/user/{user_identifier}")
    Call<List<SharedMedia>> getMediaSharedByUser(@Path("user_identifier") String user_identifier);

    /**
     * This API is used to fetch all media which is shared to requested user.
     * <p>
     * GET
     * http://52.76.204.166/dubuqu-nxt/api/media/social-group/:group_identifier
     */
    @GET("media/social-group/{group_identifier}")
    Call<List<SharedMedia>> getMediaSharedByGroup(@Path("group_identifier") String user_identifier);


    /**
     * This API is used to fetch all media which is shared by requested user to dubuqu contact.
     * <p>
     * GET
     * http://52.76.204.166/dubuqu-nxt/api/media/stories/user/:user_identifier
     */
    @GET("media/stories/user/{user_identifier}")
    Call<List<SharedMedia>> getUserMEdiaEvents(@Path("user_identifier") String user_identifier);

    /**
     * This API is used to fetch all media which is shared by requested user to social group.
     * <p>
     * GET
     * http://52.76.204.166/dubuqu-nxt/api/media/stories/social-group/:group_identifier
     */
    @GET("media/stories/social-group/{group_identifier}")
    Call<List<SharedMedia>> getGroupMEdiaEvents(@Path("group_identifier") String group_identifier);



    /*-------------------------------------------Media Upload and Share Media-------------------------------*/

    /*This API is used to get the pre-signed parameter for uploading media to Amazon S3.
    Actually it contains form input parameter and actual uploaded file need to be included as part of form input.
    Add a field called "file" and submit the form as multi-part. This request will be valid within 30 minutes.
    All kind of media like profile-image, comment audio and shared media should use this API to S3

    http://52.76.204.166/dubuqu-nxt/api/media/signed-url
    media_type	String	Type of the media to upload. Allowed values: "media", "profile_image", "audio"
    content_type	String	File content-type to be uploaded. It should be urlencoded value.
    file_extension	String	File extension to be uploaded.
    */

    @GET("media/signed-url")
    Call<SignedUrlResponseModel> getSignedUrl(@Query(value = Constants.MEDIATYPE, encoded = true) String mediaType,
                                              @Query(value = Constants.CONTENT_TYPE_SIGNED, encoded = true) String contnetType,
                                              @Query(value = Constants.FILE_EXTENSION, encoded = true) String fileExtension,
                                              @Query(value = Constants.WIDTH, encoded = true) String width,
                                              @Query(value = Constants.HEIGHT, encoded = true) String height);

    @GET("media/{media_identifier}")
    Call<SharedMedias> getMediaDetails(@Path(Constants.MEDIA_IDENTIFIER) String mediaIdentifier);

    @GET("media/{media_identifier}/like")
    Call<List<MediaLikeDetails>> getMediaLikeDetails(@Path(Constants.MEDIA_IDENTIFIER) String mediaIdentifier);

    @Multipart
    @POST("./")
    Call<ResponseBody> uploadImgaeToS3(
            @Part("X-Amz-Credential") RequestBody X_AMZ_CREDEN,
            @Part("X-Amz-Algorithm") RequestBody X_Amz_Algorithm,
            @Part("X-Amz-Date") RequestBody X_Amz_Date,
            @Part("acl") RequestBody acl,
            @Part("Policy") RequestBody Policy,
            @Part("X-Amz-Signature") RequestBody X_Amz_Signature,
            @Part("key") RequestBody key,
            @Part("content-type") RequestBody content_type,
            /*"file\"; filename=\"pp.png\" "*/
            @Part("file\"; filename=\"pp.png ") RequestBody file);

    /*This API is used for sharing media to people. After uploading media to S3, then it needs to be called.
  POST
  http://52.76.204.166/dubuqu-nxt/api/media/share
  media_identifiers	JSON_Array	Array of unique identifiers of the media. The media identifier will be
   retrieved when hitting signed-url API.recipient	JSON_Array	Actual audience to show the shared media.
    It might be mobile number and social group identifiers.
*/
    @POST("media/share")
    Call<ResponseBody> shareMediaRequest(@Body DubuquShareMediaRequest dubuquShareMediaRequest);

    @POST("media/reshare")
    Call<ResponseBody> reshareMediaRequest(@Body DubuquShareMediaRequest dubuquShareMediaRequest);


    @POST("public-media/{media_identifier}/share")
    Call<ResponseBody> shareMediaPublicrequest(@Path("media_identifier") String mediaIdentifier,
                                               @Body PublicShareRequestModel publicShareRequestModel);


    /*http://52.76.204.166/dubuqu-nxt/api/public-media/:media_identifier/reshare*/
    @POST("public-media/{media_identifier}/reshare")
    Call<ResponseBody> reshareMediaPublicrequest(@Path("media_identifier") String mediaIdentifier);

    /*--------------------------------------------Paginations-------------------------------------*/

    /**
     * This option will be available only for API calls (GET ALL) that return collection of records.
     * For get /user/dubuqu-user/ API, pagination will be supported.
     * <p>
     * GET
     * http://52.76.204.166/dubuqu-nxt/api/<screen-name>/
     * Parameter
     * <p>
     * Field	Type	Description
     * offset	Number
     * Integer value denotes the internal division of page number.
     * <p>
     * limit	Number
     * Integer value denotes the no of records the server should return and it should be
     * less than Max-page-size supported for this resource type.
     */

    @GET("social-group/")
    Call<List<DubuquGetGroupResponse>> getPaginatedGroupResponse(@Query(Constants.OFFSET) int offset,
                                                                 @Query(Constants.LIMIT) int limt);


    @GET("social-group/share-social-circle/")
    Call<List<DubuquGetGroupResponse>> getPaginateOpenGroupRespone(@Query(Constants.OFFSET) int offset,
                                                                   @Query(Constants.LIMIT) int limt);


    @GET("media/")
    Call<List<GetAllSharedMediaModel>> getPaginatedVaultHomeResponse(@Query(Constants.OFFSET) int offset,
                                                                     @Query(Constants.LIMIT) int limt);

    @GET("media/user/{user_identifier}")
    Call<List<SharedMedia>> paginateMediaAvailable(@Path("user_identifier") String userIdentifier,
                                                   @Query(Constants.OFFSET) int offset,
                                                   @Query(Constants.LIMIT) int limt);

    @GET("media/social-group/{group_identifier}")
    Call<List<SharedMedia>> paginateGroupMediaAvailable(@Path("group_identifier") String userIdentifier,
                                                        @Query(Constants.OFFSET) int offset,
                                                        @Query(Constants.LIMIT) int limt);

    @GET("media/stories/user/{user_identifier}")
    Call<List<SharedMedia>> paginateEventFullView(@Path("user_identifier") String userIdentifier,
                                                  @Query(Constants.OFFSET) int offset,
                                                  @Query(Constants.LIMIT) int limt);

    @GET("media/stories/social-group/{group_identifier}")
    Call<List<SharedMedia>> paginateEventGroupFullView(@Path("group_identifier") String userIdentifier,
                                                       @Query(Constants.OFFSET) int offset,
                                                       @Query(Constants.LIMIT) int limt);

    @GET("public-media/user/{user_identifier}")
    Call<List<SharedMedia>> paginatePublicUserMedia(@Path("user_identifier") String userIdentifier,
                                                    @Query(Constants.OFFSET) int offset,
                                                    @Query(Constants.LIMIT) int limt);


    @GET("media/{media_identifier}/comment")
    Call<List<MediaComment>> getMediaComments(@Path(Constants.MEDIA_IDENTIFIER) String mediaIdentifier,
                                              @Query(Constants.OFFSET) int offset,
                                              @Query(Constants.LIMIT) int limt);

    @POST("media/{media_identifier}/comment")
    Call<HomeDetailImageViewer.CommentIdentifier> postMediaComments(@Path(Constants.MEDIA_IDENTIFIER) String mediaIdentifier,
                                                                    @Body PostMediaComment postMediaComment);

    @POST("media/{media_identifier}/{action}")
    Call<ResponseBody> postMediaLike(@Path(Constants.MEDIA_IDENTIFIER) String mediaIdentifier,
                                     @Path(Constants.LIKE_ACTION) String action, @Body MediaLikeDetails data);


    /*---------------------------------------TIMELINE-----------------------------------------------*/

    @GET("timeline-media")
    Call<List<GetAllMediaTimeLine>> getMediasSharedToUserTimeline();


    @GET("timeline-media/")
    Call<List<GetAllMediaTimeLine>> getMediasSharedToUserTimeline(@Query(Constants.GROUP_IDENTIFIER)
                                                                          String groupIdentifier);


    @GET("timeline-media/{timeline}")
    Call<List<SharedMedias>> paginateTimeLineReource(
            @Path("timeline") String timeLineIdentifier,
            @Query(Constants.OFFSET) int offset);

    @GET("timeline-media/")
    Call<List<GetAllMediaTimeLine>> paginateTimeLineList(@Query(Constants.OFFSET) int offset);

    @GET("timeline-media/")
    Call<List<GetAllMediaTimeLine>> paginateTimeLineList(@Query(Constants.OFFSET) int offset,
                                                         @Query(Constants.GROUP_IDENTIFIER)
                                                                 String groupIdentifier
    );

    @PUT("media/{media_identifier}")
    Call<ResponseBody> updateCaptions(@Body Captions captions, @Path("media_identifier") String mediaIdentifier);


    @GET("timeline-media/stories")
    Call<List<GetTimeLineStory>> getTimelineStory(@Query(Constants.OFFSET) int offset,
                                                  @Query(Constants.LIMIT) int limit);

    @GET("timeline-media/stories/{timeline}")
    Call<List<SharedMedias>> getStoryMedias(@Path("timeline") String timeLineIdentifier,
                                            @Query(Constants.OFFSET) int offset,
                                            @Query(Constants.LIMIT) int limit);

    @GET("media/{media_identifier}/stories-comment")
    Call<List<MediaComment>> getMediaStoryComments(@Path("media_identifier") String mediaIdentifier,
                                                   @Query(Constants.OFFSET) int offset,
                                                   @Query(Constants.LIMIT) int limit);

    @POST("media/{comment_identifier}/stories-comment")
    Call<HomeDetailImageViewer.CommentIdentifier> postParnetComment(@Path("comment_identifier") String commentIdentifier,
                                                                    @Body PostMediaComment postMediaComment);
    /*--------------------------Notification-------------------------------------------------------*/

    @GET("notification")/*@Query(Constants.OFFSET) int offset,
                                                      @Query(Constants.LIMIT) int limit*/
    Call<List<NotificationModel>> getAllNotifications(@Query(Constants.OFFSET) int offset,
                                                      @Query(Constants.LIMIT) int limit);

    /**
     * ---------------------------------Block and Spam -------------------------------------------
     */

    @PUT("user/{user_identifier}/block-user")
    Call<ResponseBody> blockUser(@Path("user_identifier") String userIdentifier);


    @PUT("user/{user_identifier}/unblock-user")
    Call<ResponseBody> unblockUser(@Path("user_identifier") String userIdentifier);


    @PUT("social-group/{group_identifier}/exit-group")
    Call<ResponseBody> exitGroup(@Path("group_identifier") String groupIdentifier);

    @PUT("media/{media_identifier}/report-spam")
    Call<ResponseBody> reportSpam(@Path("media_identifier") String mediaIdentifier);

    @GET("user/block-user")
    Call<List<BlockedUserModel>> getBlockedUserlist(@Query(Constants.OFFSET) int offset,
                                                    @Query(Constants.LIMIT) int limi);

    @GET("random")
    Call<GifResponse> getRandomGif(@Query("pos") int offset,
                                   @Query("limit") int limit,
                                   @Query("key") String key);

    @GET("search")
    Call<GifResponse> searchGif(@Query("pos") int offset,
                                @Query("limit") int limit,
                                @Query("key") String key,
                                @Query("q") String text);

    @PUT("notification/{notification_identifier}/read-notification")
    Call<ResponseBody> markNotificationRead(@Path("notification_identifier") String notificationIdentifier);
}
