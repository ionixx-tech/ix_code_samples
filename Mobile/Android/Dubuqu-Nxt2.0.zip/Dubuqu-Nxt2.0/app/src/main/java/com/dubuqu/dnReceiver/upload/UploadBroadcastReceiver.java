package com.dubuqu.dnReceiver.upload;

import android.annotation.SuppressLint;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.PersistableBundle;
import android.util.Log;

import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnConstants.UploadConstants;
import com.dubuqu.dnServices.FileShareService;
import com.dubuqu.dnStorage.DbHelper;
import com.dubuqu.dnStorage.upload.UploadDbModel;
import com.dubuqu.dnStorage.upload.UploadMapModel;
import com.google.gson.Gson;

import java.util.List;

/**
 * Created by Yogaraj subramanian on 14/12/17
 * {@link UploadBroadcastReceiver} which helps to start the service {@link FileShareService}
 * for uploading medias.
 * <p>
 * here check if the service is runing if not running start it or else do nothing.</p>
 * <p>
 * need to check of internet conectivity to too.
 */

public class UploadBroadcastReceiver extends BroadcastReceiver {

    final String TAG = UploadBroadcastReceiver.class.getName();

    @SuppressLint("Assert")
    @Override
    public void onReceive(Context context, Intent intent) {
        try {
            DbHelper dbHelper = new DbHelper(context);

            UploadMapModel uploadMapModel = dbHelper.fetchDataAgainstIdentifier();

            if (uploadMapModel != null) {

                if (UploadConstants.UPLOADSTATUS.valueOf(uploadMapModel.getUploadStatus())
                        != UploadConstants.UPLOADSTATUS.PROGRESS
                        && UploadConstants.UPLOADSTATUS.valueOf(uploadMapModel.getUploadStatus())
                        != UploadConstants.UPLOADSTATUS.SUCCESS) {

                    JobScheduler jobScheduler = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);

                    assert jobScheduler != null;
                    if (jobScheduler.getAllPendingJobs().size() == 0) {

                        if (UploadConstants.UPLOADSTATUS.valueOf(uploadMapModel.getUploadStatus())
                                == UploadConstants.UPLOADSTATUS.NOTYETSTARTED) {

                            List<UploadDbModel> uploadDbModelList = dbHelper.fetchDataAgainstIdentifier(
                                    uploadMapModel.getUploadId()
                            );

                            dbHelper.updateProgressStateOfUpload(uploadMapModel.getUploadId(),
                                    UploadConstants.UPLOADSTATUS.PROGRESS);

                            assert uploadDbModelList != null && uploadDbModelList.size() > 0;

                            ComponentName serviceComponent = new ComponentName(context,
                                    FileShareService.class);
                            PersistableBundle bundle = new PersistableBundle();
                            bundle.putString(Constants.SHAREMEDIA, new Gson().toJson(uploadDbModelList));

                            bundle.putString(Constants.SELECTEDUSERS, uploadMapModel.getUser());

                            bundle.putString(Constants.SHOULDDELETEMEDIA, String.valueOf(uploadMapModel.isShouldDeleteMedia()));

                            JobInfo.Builder builder = new JobInfo.Builder(Integer.parseInt(uploadMapModel.getUploadId())
                                    , serviceComponent);

                            builder.setOverrideDeadline(0);
                            builder.setPersisted(true);
                            builder.setExtras(bundle);

                            jobScheduler.schedule(builder.build());
                        }
                    }
                }
            }

        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        }
    }
}
