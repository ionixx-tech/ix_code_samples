package com.dubuqu.dnConstants;

/**
 * Created by Yogaraj subramanian on 6/6/17
 */

public class Constants {

    public static final boolean RESTRICT_SREENSHOT = false;

    public static final String ENCRPYTION_SECRECT_KEY = "ad2cf9d6736d1dcf7379ee95deeea443";

    public static final String BASE_API_PATH = "http://api.dubuqu.com/dubuqu-nxt-test/api/";

    private static final String URI_HOST = "http://52.76.204.166/dubuqu_site/";

    public static final String URI_ABOUT = URI_HOST + "index.php#about";

    public static final String TENOR_APIL_KEY = "0H0I12BAMJZ2";

    public static final String TENORBASE_URL = "https://api.tenor.com/v1/";

    public static final String DUBUQUCAMERA = "Dubucam";

    public static final String SHORUTCUTINENT = "com.android.launcher.action.INSTALL_SHORTCUT";

    public static final String SHORTCUTCREATED = "Shortcut Created";

    public static final String API_StickerPipe = "c257bc17f8b72de70305a02b6a5cfe84";

    public static final String JSONFILENAME = "dubuqucontacts.json";

    public static final String JSONGROUPFILENAME = "dubuqugroups.json";

    public static final String HOMEDETAIL = "home_details.json";

    public static final String IMAGEURI = "imageuri";

    public static final int IMAGECPATURE_REQUEST = 1234;

    public static final String DEVICE_TYPE = "android";

    public static final String PROFILE_IMAGE = "profile_image";

    public static final String LOADIMAGESERVICE = "LoadImageService";

    public static final String UPDATERECENTSHARE = "update_recent_share";

    public static final int IMAGELISTRECEIVERREQUEST = 1234;

    public static final int ALBUMLOADRECEIVEREQUEST = 567;

    public static final int ANIMATIONTIME = 500;

    public static final java.lang.String CURRENTIMAGE = "currnetimageurl";

    public static final String MEDIAITEMCHANGED = "MediaItemChanged";

    public static final String FOLDERNAME = "foldername";

    public static final String DB_NAME = "dubuqu";

    public static final int DBVERSION = 6;

    public static final String RECENTSHARETABLE = "recentshare";

    public static final String ID = "id";

    public static final int CONTACTSERVICE_REQUESTCODE = 1;

    public static final String CONTACTS = "Invite";

    public static final String DUBUQUCONTACTS = "Dubuqu Users";

    public static final String OWNGROUPS = "Groups";

    public static final String CREATECIRCLEMODELDATAS = "create_circle_datas";

    public static final String ALLMEDIADELETED = "media_delted";

    public static final String MEDIAALBUMLISTCHANGED = "media_album_value_deleted";

    public static final int PAGE_SIZE = 10;

    public static final String RESHAREMEDIA = "to_reshare";

    public static final String SHOULDSHOWCHAT = "shouldshow_chat";

    public static final String NEWMEDIARECEIVED = "new_media_received";

    public static final String UPLOAD_RECEIVER = "upload_prgress";

    public static final String TIMELINE_IDENTIFIER = "timeline_identiifer";

    public static final String SHAREMEDA_POSITON = "sharemedia_position";

    public static final String REFRESHHOMEDATA = "refreshdata";

    public static final String UPLOADTABLEMAPER = "upload_table_map";

    public static final String ONNOTIFICATIONRECEIVE = "onnotificationreceive";

    public static final java.lang.String JOBID = "job_id";

    public static final String CAPTUREPROFILEIMAGE = "capture_profile_image";

    public static final String ISSTORYTIMELINE = "is_story_timeline";

    public static final String ONPROFILEPICCHANGED = "onprofilepicchanged";

    public static final String SHORTCUTREMOVED = "Shortcut removed";

    public static final String ISOPENEDFROMSHORTCUT = "isAppLauncedFromShortCut";

    public static final String ISREPORTEDDATA = "isReportedMedia";

    public static final String SHAREDMEDIA_COUNT = "sharedmediacount";

    public static final String REFRESHHOME = "refreshhome";

    public static final String UPLOAD_PROGRESS_FILE = "upload_progress_file";

    public static final String REFRESH_UPLOAD = "refresh_upload_screen";

    public static final String ONMEDIAUPLOADFAILED = "onMediaUploadFailed";

    public static final String UPLOAD_LIST_RECEIVER = "UPLOAD_LIST_UPDATE_EVENT";

    public static final String NODUBQUCONTACTAVAILABLEEVENT = "nodubuqucontactavailable";

    public static String FONT_LIGHT = "font.ttf";

    public static String FONTBOLD = "font_bold.ttf";

    public static String FONT_HOME = "dubuqu_home_font.ttf";

    public static final String DUBUQU_LOGIN_DATA_SHARED_PREFERANCE = "dubuquLoginInfo";

    public static final String DUBUQU_LOGIN_STATUS = "isLoggedIn";

    public static final String DUBUQU_USER_NAME = "username";

    public static final String DUBUQU_USER_PHONE = "userPhone";

    public static final String DUBUQU_USER_EMAIL = "userEmail";

    public static final String DUBUQU_USER_IDENTIFIER = "user_identifier";

    public static final String DUBUQU_USER_GENDER = "user_gender";

    public static final String ISFIRSTLOGIN = "isFirstlogin";

    public static final String SECRECT_KEY = "secret_key";

    public static final String SELECTEDIMAGES = "selectedimages";

    public static final String SHAREMEDIA = "sharemediabundle";

    public static final String UPLOADMEDIA = "uploadmedia";

    public static final String FILE_PATH = "filepath";

    public static final String SELECTEDUSERS = "selectedusers";

    public static final String SHOULDDELETEMEDIA = "should_delete_media";

    public static final String GROUP_IDENTIFIER = "group_identifier";

    public static final String USER_IDENTIFIER = "user_identifier";

    public static final String MEDIA_IDENTIFIER = "media_identifier";
    /*headers*/
    public static final String HEADER_USER_ID = "X-User-ID";

    public static final String HEADER_DEVICE_ID = "X-Device-ID";

    public static final String HEADER_HMAC = "X-Hmac";


    public static final String X_RESOURCE_COUNT = "X-Resource-Count";

    public static final String X_Media_Count = "X-Media-Count";

    public static final String X_PAGE_INFO = "X-Page-Info";

    public static final String OFFSET = "offset";

    public static final String LIMIT = "limit";

    public static final String MEDIATYPE = "media_type";

    public static final String CONTENT_TYPE_SIGNED = "content_type";

    public static final String FILE_EXTENSION = "file_extension";

    public static final String LIKE_ACTION = "action";

    public static final String WIDTH = "width";

    public static final String HEIGHT = "height";

    public static final String EXTRASTRINGS = "extras";

    public static final String UPLOADTABLE = "table_upload";

    public static final String UPLOAD_PROGRESS = "upload_progress";

    public static final String UPLOADIDENTIFIER = "upload_identfier";

    public static final String UPLOAD_STATUS = "upload_status";

    public static final String BITMAP = "bitmap_extras";

}
