package com.dubuqu.dnFragments.settings;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v4.app.Fragment;
import android.support.v4.util.Pair;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.Switch;
import android.widget.TextView;

import com.dubuqu.MainActivity;
import com.dubuqu.R;
import com.dubuqu.dnActivity.BlockListActivity;
import com.dubuqu.dnActivity.LandingActivity;
import com.dubuqu.dnActivity.profile.EditProfileActivity;
import com.dubuqu.dnActivity.profile.ProfileActivity;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnModels.commonModel.ErrorBodyModel;
import com.dubuqu.dnModels.responseModel.DubuquUserModel;
import com.dubuqu.dnRestServices.RestServiceController;
import com.dubuqu.dnRestServices.RestServiceProvider;
import com.dubuqu.dnStorage.SessionManager;
import com.dubuqu.dnUtils.RestServiceUtils;
import com.dubuqu.dnUtils.Utils;
import com.google.gson.Gson;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;

import de.hdodenhof.circleimageview.CircleImageView;
import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;
import retrofit2.Response;
import retrofit2.Retrofit;

/**
 * Created by Yogaraj subramanian on 30/10/17
 */

public class SettingsFragment extends Fragment {

    private final String TAG = SettingsFragment.class.getName();

    Activity activity;

    CircleImageView userProfile;

    TextView userName, mediaCount, groupCount;

    Switch notificationSwitch, vibrateSwitch, shortCutSwitch;

    View parentView, notificationTonePicker, editProfileImageView, aboutUsView, inviteFriendsView,
            howToUseView, termsandConditions, blockedUsers;

    SessionManager sessionManager;

    @Override
    public void onResume() {
        super.onResume();

        if (activity instanceof LandingActivity) {
            try {
                ((LandingActivity) activity).toggleBottomSheet(false);
                getUserDetails();
            } catch (Exception e) {
                writeCrashReport(e.getMessage());
            }
        }
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK && requestCode == 5) {
            Uri uri = data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
            if (uri != null) {
                sessionManager.setNotificationTone(uri.toString());
            }
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_settings, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        activity = getActivity();
        sessionManager = new SessionManager(activity);
        parentView = view;
        try {
            initialize();
        } catch (Exception e) {
            writeCrashReport(e.getMessage());
        }
    }

    private void initialize() throws Exception {

        userProfile = parentView.findViewById(R.id.settings_user_profile_imv);

        mediaCount = parentView.findViewById(R.id.settings_media_count);

        groupCount = parentView.findViewById(R.id.settings_group_count);

        userName = parentView.findViewById(R.id.settings_user_name);

        notificationSwitch = parentView.findViewById(R.id.mute_notification_switch);

        vibrateSwitch = parentView.findViewById(R.id.vibration_switch);

        notificationTonePicker = parentView.findViewById(R.id.notification_tone_picker_ll);

        editProfileImageView = parentView.findViewById(R.id.settings_edit_profile);

        aboutUsView = parentView.findViewById(R.id.settings_about_us);

        inviteFriendsView = parentView.findViewById(R.id.settings_invitefriends);

        howToUseView = parentView.findViewById(R.id.settings_howtouse);

        termsandConditions = parentView.findViewById(R.id.settings_terms_and_condition);

        shortCutSwitch = parentView.findViewById(R.id.shortcut_switch);
        shortCutSwitch.setChecked(sessionManager.isCameraShortCutCreated());

        blockedUsers = parentView.findViewById(R.id.settings_blockedusers);


        initalizeLisenter();

    }

    private void initalizeLisenter() throws Exception {

        notificationTonePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNotificationSoundPicker();
            }
        });

        notificationSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                sessionManager.setNewMessageNotification(isChecked);
                if (!isChecked)
                    vibrateSwitch.setChecked(false);
            }
        });

        vibrateSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                sessionManager.setNotificationVibrate(isChecked);

            }
        });

        editProfileImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openEditProfileActvity();
            }
        });

        shortCutSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                sessionManager.setIscamerashortcutcreted(isChecked);
                checkIfShortCutCreated(isChecked);
            }
        });

        parentView.findViewById(R.id.settings_card_cv).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openUserProfile();
            }
        });

        aboutUsView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openURI(Constants.URI_ABOUT);
            }
        });

        userProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openUserProfile();
            }
        });
        howToUseView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    setHowToUseView();
                } catch (Exception e) {
                    writeCrashReport(e.getMessage());
                }
            }
        });

        inviteFriendsView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                inviteFriends();
            }
        });

        termsandConditions.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openURI("http://52.76.204.166/dubuqu_site/termsandconditions.php");
            }
        });

        blockedUsers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openBlockList();
            }
        });
    }

    private void openUserProfile() {
        Pair<View, String> p2 = Pair.create((View) userProfile, "user_profile_pic");

        Pair[] views = new Pair[]{p2};

        ActivityOptionsCompat options = ActivityOptionsCompat.
                makeSceneTransitionAnimation(activity, views);

        ActivityCompat.startActivity(
                activity,
                new Intent(activity, ProfileActivity.class),
                options.toBundle());
    }

    /**
     * Open Notification Sound picker intent.
     */
    private void openNotificationSoundPicker() {
        Intent intent = new Intent(RingtoneManager.ACTION_RINGTONE_PICKER);
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION);
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Select Tone");
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(sessionManager.getNotificationTone()));
        this.startActivityForResult(intent, 5);
    }

    /**
     * Open Profile Edit Activity
     */
    private void openEditProfileActvity() {

        Pair<View, String> p2 = Pair.create((View) userProfile, "user_profile");

        Pair<View, String> p1 = Pair.create(editProfileImageView, "edit_profile");

        Pair<View, String> p3 = Pair.create((View) userName, "user_name");

        Pair[] views = new Pair[]{p2, p1};

        ActivityOptionsCompat options = ActivityOptionsCompat.
                makeSceneTransitionAnimation(activity, views);

        ActivityCompat.startActivity(activity, new Intent(activity, EditProfileActivity.class), options.toBundle());
    }

    /**
     * get user details from API.
     *
     * @throws Exception
     */
    private void getUserDetails() throws Exception {

        String userNameS = sessionManager.getUserName();

        userName.setText(userNameS);

        Bitmap bitmap = Utils.textAsBitmap(userNameS, activity);

        userProfile.setImageBitmap(bitmap);

        notificationSwitch.setChecked(sessionManager.getNewMessageNotification());

        vibrateSwitch.setChecked(sessionManager.getNotificationVibrate());

        String data = "{}";
        OkHttpClient okHttpClient = null;

        okHttpClient = RestServiceUtils.getHeader(data, activity);
        Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
        RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
        RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);

        mRetrofitCallBacks.fetchDubuquUserDetails(new RestServiceController.ResponseCallBacks() {
            @Override
            public void onResponse(Object o) {
                if (o != null) {
                    final DubuquUserModel userModel = (DubuquUserModel) o;
                    activity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            mediaCount.setText(String.valueOf(userModel.getMediaCount()));
                            groupCount.setText(String.valueOf(userModel.getGroupCount()));

                            String profileImageS = userModel.getProfileImage();

                            if (profileImageS != null && !profileImageS.equalsIgnoreCase("")) {
                                ImageLoader.getInstance().displayImage(profileImageS, userProfile, new ImageLoadingListener() {
                                    @Override
                                    public void onLoadingStarted(String imageUri, View view) {

                                    }

                                    @Override
                                    public void onLoadingFailed(String imageUri, View view, FailReason failReason) {

                                    }

                                    @Override
                                    public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                                        userProfile.setImageBitmap(loadedImage);
                                    }

                                    @Override
                                    public void onLoadingCancelled(String imageUri, View view) {

                                    }
                                });
                            }
                        }
                    });
                }
            }

            @Override
            public void onFailure(Object o) {
                showHttpErrorMessage(o);
            }
        }, sessionManager.getUserIdentifier());
    }

    /**
     * Write Log Report to Console
     *
     * @param message
     */
    private void writeCrashReport(String message) {
        if (activity instanceof LandingActivity) {
            ((LandingActivity) activity).writeCrashReport(TAG, message);
        }
    }

    /**
     * Handle API error log.
     *
     * @param o
     */
    private void showHttpErrorMessage(Object o) {
        if (o != null) {
            if (activity instanceof LandingActivity) {
                try {
                    ((LandingActivity) activity).cancelPopUp();

                    if (o instanceof retrofit2.Response) {
                        ResponseBody responseBody = ((Response) o).errorBody();
                        if (responseBody != null) {
                            String value = responseBody.string();
                            ErrorBodyModel errorBodyModel = new Gson().fromJson(value, ErrorBodyModel.class);
                            if (errorBodyModel != null)
                                ((LandingActivity) activity).showToastMessage(errorBodyModel.getMessage(), false);
                        }
                    } else if (o instanceof Throwable) {
                        ((LandingActivity) activity).showToastMessage(activity.getString(R.string.sp_no_internet_connection), false);
                    }

                } catch (Exception e) {
                    if (activity instanceof LandingActivity) {
                        ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                    }
                }
            }

        }
    }

    /**
     * Open About US uri in browser.
     *
     * @param uri
     */
    private void openURI(String uri) {
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
        startActivity(browserIntent);
    }


    /**
     * show to use popup window
     *
     * @throws Exception
     */
    private void setHowToUseView() throws Exception {

        LayoutInflater inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        final PopupWindow pop = new PopupWindow(activity);

        assert inflater != null;
        View view = inflater.inflate(R.layout.layout_how_to_use, null);

        view.findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pop.dismiss();
            }
        });
        view.findViewById(R.id.layoutInstantshare).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openURI(getString(R.string.instantsharurl));
            }
        });
        view.findViewById(R.id.layoutsocialcircle).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openURI(getString(R.string.socialcircleurl));
            }
        });
        view.findViewById(R.id.layoutvaultevents).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openURI(getString(R.string.vaulteventurl));
            }
        });
        view.findViewById(R.id.layouthome).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openURI(getString(R.string.vaulthomeurl));
            }
        });
        view.findViewById(R.id.layoutCollage).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openURI(getString(R.string.collageurl));
            }
        });

        pop.setContentView(view);
        pop.setWidth(LinearLayout.LayoutParams.MATCH_PARENT);
        pop.setHeight(LinearLayout.LayoutParams.MATCH_PARENT);
        pop.setFocusable(true);
        pop.setBackgroundDrawable(null);
        pop.showAtLocation(view, Gravity.CENTER, 0, 0);
    }

    /**
     * open invite friends intent.
     */
    private void inviteFriends() {
        Utils.inviteFriends(activity);
    }

    /**
     * Allow User to create shortcut to homeScreen
     */
    private void checkIfShortCutCreated(boolean isChecked) {
        if (isChecked) {

            LayoutInflater inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

            final PopupWindow pop = new PopupWindow(activity);

            assert inflater != null;
            View view = inflater.inflate(R.layout.layout_add_short_cut_request, null);

            view.findViewById(R.id.create_short_cut).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    createShortCutInHomeScreen();
                    pop.dismiss();
                }
            });

            /*view.findViewById(R.id.cancel_popup).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    sessionManager.setIscamerashortcutcreted(false);
                    shortCutSwitch.setChecked(false);
                    pop.dismiss();
                }
            });*/
            pop.setContentView(view);
            pop.setWidth(LinearLayout.LayoutParams.MATCH_PARENT);
            pop.setHeight(LinearLayout.LayoutParams.MATCH_PARENT);
            pop.setFocusable(true);
            pop.setBackgroundDrawable(null);
            pop.showAtLocation(view, Gravity.CENTER, 0, 0);
        } /*else {
            removeCameraShortCut();
        }*/
    }

    /**
     * create camera Short cut
     */
    private void createShortCutInHomeScreen() {

        Intent shortcutIntent = new Intent(activity, MainActivity.class);
        shortcutIntent.putExtra(Constants.ISOPENEDFROMSHORTCUT, true);
        shortcutIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        shortcutIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

        Intent addIntent = new Intent();

        addIntent.putExtra(Intent.EXTRA_SHORTCUT_INTENT, shortcutIntent);
        addIntent.putExtra(Intent.EXTRA_SHORTCUT_NAME, Constants.DUBUQUCAMERA);
        addIntent.putExtra(Intent.EXTRA_SHORTCUT_ICON_RESOURCE,
                Intent.ShortcutIconResource.fromContext(activity,
                        R.mipmap.ic_cam_icon));

        addIntent.putExtra("duplicate", false);

        addIntent.setAction(Constants.SHORUTCUTINENT);
        activity.sendBroadcast(addIntent);

        Utils.showToast(activity,
                Constants.SHORTCUTCREATED);
    }

    private void openBlockList() {
        Intent intent = new Intent(activity, BlockListActivity.class);
        startActivity(intent);
    }

}
