package com.dubuqu.dnAdapter.group;

import android.content.Context;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.dubuqu.R;
import com.dubuqu.dnActivity.LandingActivity;
import com.dubuqu.dnModels.commonModel.DubuqContactsShareModel;
import com.dubuqu.dnUtils.Utils;
import com.dubuqu.dnViews.linearStickView.exposed.StickyHeaderHandler;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * Created by Yogaraj subramanian on 7/11/17
 */

public class CreateCircleUserSelectadapter extends RecyclerView.Adapter<CreateCircleUserSelectadapter.CreateCircleUserSelectionViewHolder>
        implements StickyHeaderHandler, Filterable {

    private List<DubuqContactsShareModel> dubuqContactsShareModels, dubuquContactSearchList;

    private Context context;

    private OnuserSelectedListener onuserSelectedListener;


    public CreateCircleUserSelectadapter(List<DubuqContactsShareModel> dubuqContactsShareModels,
                                         List<DubuqContactsShareModel> dubuquContactSearchList,
                                         Context context,
                                         OnuserSelectedListener onuserSelectedListener) {
        this.dubuqContactsShareModels = dubuqContactsShareModels;
        this.dubuquContactSearchList = dubuquContactSearchList;
        this.context = context;
        this.onuserSelectedListener = onuserSelectedListener;
    }

    @Override
    public List<?> getAdapterData() {
        return dubuquContactSearchList;
    }

    @Override
    public CreateCircleUserSelectionViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.create_circle_user_selection_view_holder,
                parent, false);
        return new CreateCircleUserSelectionViewHolder(view);
    }


    @Override
    public void onBindViewHolder(CreateCircleUserSelectionViewHolder holder, int position) {
        try {
            holder.onBind(position);
        } catch (Exception e) {
            if (context instanceof LandingActivity) {
                ((LandingActivity) context).writeCrashReport(
                        CreateCircleUserSelectadapter.class.getName(),
                        e.getMessage()
                );
            }
        }
    }

    @Override
    public int getItemCount() {
        return dubuquContactSearchList.size();
    }
    @Override
    public int getItemViewType(int position) {
        return dubuquContactSearchList.get(position).hashCode();
    }

    @Override
    public long getItemId(int position) {
        return dubuquContactSearchList.get(position).hashCode();
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {

                List<DubuqContactsShareModel> dubquContactFilterData = new ArrayList<>();
                if (constraint.length() == 0) {
                    dubquContactFilterData = dubuqContactsShareModels;
                } else {
                    dubquContactFilterData = getFilteredResults(constraint.toString().toLowerCase());
                }
                FilterResults results = new FilterResults();

                results.values = dubquContactFilterData;
                return results;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                dubuquContactSearchList = (List<DubuqContactsShareModel>) results.values;
                notifyDataSetChanged();
            }
        };
    }

    private List<DubuqContactsShareModel> getFilteredResults(String constraint) {

        List<DubuqContactsShareModel> results = new ArrayList<>();

        for (DubuqContactsShareModel item : dubuqContactsShareModels) {

            if (checkIsNumber(constraint)) {
                if (item.getModileNumber().toLowerCase().contains(constraint)
                        && item.getCategory() != Utils.DUBUQU_CATEGORY.HEADER) {
                    results.add(item);
                }
            } else {
                if (item.getUserName().toLowerCase().contains(constraint)
                        && item.getCategory() != Utils.DUBUQU_CATEGORY.HEADER) {
                    results.add(item);
                }
            }
        }
        return results;
    }

    private boolean checkIsNumber(String constraint) {
        String regex = "\\d+";
        Pattern pattern = Pattern.compile(regex);
        return pattern.matcher(constraint).matches();
    }


    class CreateCircleUserSelectionViewHolder extends RecyclerView.ViewHolder {

        TextView headerView, userName, phoneNumber;

        RelativeLayout rowItemView;

        CircleImageView userProfileImage;

        ImageView userSelectionIndicator;

        View borderIndicator;

        CreateCircleUserSelectionViewHolder(View itemView) {
            super(itemView);

            headerView = itemView.findViewById(R.id.header_view);

            userName = itemView.findViewById(R.id.create_cricle_user_selection_adapter_user_profile_name);

            rowItemView = itemView.findViewById(R.id.item_view_ll);

            userProfileImage = itemView.findViewById(R.id.create_cricle_user_selection_adapter_user_profile_image);

            userSelectionIndicator = itemView.findViewById(R.id.create_cricle_user_selection_adapter_user_selected);

            phoneNumber = itemView.findViewById(R.id.create_cricle_user_selection_adapter_user_phonenumber);

            borderIndicator = itemView.findViewById(R.id.border_indicator);
        }

        void onBind(final int positon) throws Exception {
            final DubuqContactsShareModel dubuqContactsShareModel = dubuquContactSearchList.get(positon);

            if (dubuqContactsShareModel != null) {

                if (dubuqContactsShareModel.getCategory() == Utils.DUBUQU_CATEGORY.HEADER) {
                    headerView.setVisibility(View.VISIBLE);
                    rowItemView.setVisibility(View.GONE);
                    headerView.setText(dubuqContactsShareModel.getUserName());
                } else {
                    headerView.setVisibility(View.GONE);
                    rowItemView.setVisibility(View.VISIBLE);

                    userName.setText(dubuqContactsShareModel.getUserName());

                    Drawable drawable = new BitmapDrawable(
                            Utils.textAsBitmap(dubuqContactsShareModel.getUserName(), context));
                    if (dubuqContactsShareModel.getProfilePicture() != null &&
                            !dubuqContactsShareModel.getProfilePicture().equalsIgnoreCase("")) {
                        Glide.with(context)
                                .load(dubuqContactsShareModel.getProfilePicture())
                                .placeholder(drawable)
                                .error(drawable)
                                .into(userProfileImage);
                    } else {
                        userProfileImage.setImageDrawable(drawable);
                    }
                    if (dubuqContactsShareModel.isSelected()) {
                        userSelectionIndicator.setVisibility(View.VISIBLE);
                        borderIndicator.setVisibility(View.VISIBLE);
                    } else {
                        userSelectionIndicator.setVisibility(View.GONE);
                        borderIndicator.setVisibility(View.GONE);
                    }
                    if (dubuqContactsShareModel.getModileNumber() != null &&
                            !dubuqContactsShareModel.getModileNumber().equalsIgnoreCase("")) {
                        phoneNumber.setText(dubuqContactsShareModel.getModileNumber());
                    } else {
                        phoneNumber.setVisibility(View.GONE);
                    }
                    rowItemView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            if (dubuqContactsShareModel.isSelected()) {
                                dubuqContactsShareModel.setSelected(false);

                            } else {
                                dubuqContactsShareModel.setSelected(true);

                            }
                            notifyDataSetChanged();
                            onuserSelectedListener.onUserSelected(dubuqContactsShareModel);
                        }
                    });
                }

            }
        }
    }

    public interface OnuserSelectedListener {
        void onUserSelected(DubuqContactsShareModel dubuqContactsShareModel);
    }
}
