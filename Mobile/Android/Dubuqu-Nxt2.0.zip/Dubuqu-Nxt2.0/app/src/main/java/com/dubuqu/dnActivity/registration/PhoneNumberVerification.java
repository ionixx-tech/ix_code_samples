package com.dubuqu.dnActivity.registration;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.annotation.Nullable;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.TextView;

import com.alimuzaffar.lib.pin.PinEntryEditText;
import com.dubuqu.R;
import com.dubuqu.dnActivity.BaseActivity;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnModels.requestModel.PhoneNumberVerificationRequest;
import com.dubuqu.dnRestServices.RestServiceController;
import com.dubuqu.dnRestServices.RestServiceProvider;
import com.dubuqu.dnUtils.RestServiceUtils;
import com.dubuqu.dnUtils.Utils;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;

/**
 * Created by Yogaraj subramanian on 24/10/17
 */

public class PhoneNumberVerification extends BaseActivity {


    private final String TAG = PhoneNumberRegistration.class.getName();

    //EditText
    PinEntryEditText otpVerification;
    //Button
    Button continueButton;
    //Textviews
    TextView timertextview, mobile_number;

    PhoneNumberVerificationRequest phoneNumberVerificationRequest;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.phone_number_verification);

        try {
            intializeView();
        } catch (Exception e) {
            super.writeCrashReport(TAG, e.getMessage());
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(broadcastReceiver, new IntentFilter("verifycodefromsms"));
        if (Constants.RESTRICT_SREENSHOT)
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(broadcastReceiver);
    }

    private void intializeView() throws Exception {

        final Bundle bundle = getIntent().getExtras();

        String userDetails = bundle.getString(Constants.EXTRASTRINGS);

        phoneNumberVerificationRequest = new Gson().fromJson(userDetails,
                new TypeToken<PhoneNumberVerificationRequest>() {
                }.getType());


        otpVerification = findViewById(R.id.sms_code_entered);

        otpVerification.setOnPinEnteredListener(new PinEntryEditText.OnPinEnteredListener() {
            @Override
            public void onPinEntered(CharSequence str) {
                checkIsValidOtp(str);
            }
        });
        otpVerification.setOnEditorActionListener(new PinEntryEditText.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                boolean isHandled = false;
                if (actionId == 0 || actionId == 7 || actionId == EditorInfo.IME_ACTION_DONE || actionId == EditorInfo.IME_ACTION_NONE) {
                    checkIsValidOtp(otpVerification.getText());
                    isHandled = true;
                    Utils.hideSoftKeyBoard(PhoneNumberVerification.this);
                    continueButton.callOnClick();
                }

                return isHandled;
            }
        });


        mobile_number = findViewById(R.id.mobile_number);
        mobile_number.setText(String.format("%s %s",
                phoneNumberVerificationRequest.getCountry_code(),
                phoneNumberVerificationRequest.getMobile_number()
        ));

        checkIfReadSmspermissionIsGranted();

        timertextview = findViewById(R.id.verify_count);
        timertextview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                timertextview.setClickable(false);
                try {
                    runTimer();
                    makeSendVerificationRequest(phoneNumberVerificationRequest);
                } catch (Exception e) {
                    PhoneNumberVerification.super.writeCrashReport(TAG, e.getMessage());
                }

            }

        });
        timertextview.setClickable(false);

        continueButton = findViewById(R.id.verify_button);
        continueButton.setClickable(false);
        continueButton.setTextColor(Color.GRAY);


        continueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Utils.hideSoftKeyBoard(PhoneNumberVerification.this);

                String codeEntered = otpVerification.getText().toString();
                if (codeEntered.length() == 4) {
                    phoneNumberVerificationRequest.setVerification_code(codeEntered);
                    try {
                        checkIfcodeisVaildOrnot();
                    } catch (Exception e) {
                        PhoneNumberVerification.super.writeCrashReport(TAG, e.getMessage());
                    }
                } else if (codeEntered.length() == 0) {
                    try {
                        PhoneNumberVerification.super.showToastMessage(getString(R.string.error_msg_enter_code), false);
                    } catch (Exception e) {
                        PhoneNumberVerification.super.writeCrashReport(TAG, e.getMessage());
                    }
                } else {
                    try {
                        PhoneNumberVerification.super.showToastMessage(getString(R.string.error_msg_invalid_code), false);
                    } catch (Exception e) {
                        PhoneNumberVerification.super.writeCrashReport(TAG, e.getMessage());
                    }
                }


            }

        });


    }


    /**
     * create a 60 sec timer or else resend the otp
     *
     * @throws Exception Runtime stub Exception.
     */
    private void runTimer() throws Exception {
        new CountDownTimer(60000, 1000) {

            public void onTick(long millisUntilFinished) {
                timertextview.setText(String.format("%s%d seconds", new Object[]{getString(R.string.verify_code_timer_text),
                        millisUntilFinished / 1000}));
            }

            public void onFinish() {
                SpannableString spanString = new SpannableString(getString(R.string.resend_code_msg));
                spanString.setSpan(new UnderlineSpan(), 0, spanString.length(), 0);
                timertextview.setText(spanString);
                timertextview.setClickable(true);

            }
        }.start();
    }

    /**
     * make http request to generate otp verification sms
     *
     * @throws Exception
     */
    private void makeSendVerificationRequest(PhoneNumberVerificationRequest phoneNumberVerificationRequest)
            throws Exception {

        if (Utils.isDataConectionAvailable(PhoneNumberVerification.this)) {

            Gson gson = new Gson();
            final String data = gson.toJson(phoneNumberVerificationRequest);
            OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, getApplicationContext());
            Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
            RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
            RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);

            mRetrofitCallBacks.generateVerificationCode(new RestServiceController.ResponseCallBacks() {
                @Override
                public void onResponse(Object o) {
                    //otp generated

                }

                @Override
                public void onFailure(Object o) {
                    if (o != null) {

                        if (o instanceof retrofit2.Response) {
                            //invalid request is made or getting any error
                            try {
                                PhoneNumberVerification.super.showToastMessage(((retrofit2.Response) o).message(), false);
                            } catch (Exception e) {
                                PhoneNumberVerification.super.writeCrashReport(PhoneNumberRegistration.class.getName(),
                                        e.getMessage());
                            }
                        } else if (o instanceof Throwable) {
                            try {
                                PhoneNumberVerification.super.showToastMessage(((Throwable) o).getMessage(), false);
                            } catch (Exception e) {
                                PhoneNumberVerification.super.writeCrashReport(PhoneNumberRegistration.class.getName(),
                                        e.getMessage());
                            }
                        }
                    }
                }
            }, phoneNumberVerificationRequest);


        } else {
            super.showToastMessage(getString(R.string.sp_no_internet_connection), false);
        }
    }

    /**
     * check if read sms premission is provided
     */

    private void checkIfReadSmspermissionIsGranted() throws Exception {

        if (!super.checkIfPermissionIsGranted(Manifest.permission.READ_SMS)) {
            super.requestPermission(new String[]{Manifest.permission.READ_SMS}, new PermissionCallBack() {
                @Override
                public void onPermissionGranted() {
                    try {
                        runTimer();
                    } catch (Exception e) {
                        PhoneNumberVerification.super.writeCrashReport(TAG, e.getMessage());
                    }
                }

                @Override
                public void onPermissionRejected() {
                    try {
                        PhoneNumberVerification.super.showToastMessage(getString(R.string.please_provide_permission_to_continue),
                                false);
                    } catch (Exception e) {
                        PhoneNumberVerification.super.writeCrashReport(TAG, e.getMessage());
                    }
                }
            });
        } else {
            runTimer();
        }
    }

    /**
     * check if the code is valid or not
     */
    private void checkIfcodeisVaildOrnot() throws Exception {

        if (Utils.isDataConectionAvailable(PhoneNumberVerification.this)) {

            PhoneNumberVerification.super.showLoaders(PhoneNumberVerification.this);

            Gson gson = new Gson();
            final String data = gson.toJson(phoneNumberVerificationRequest);
            OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, getApplicationContext());
            Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
            RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
            RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);

            mRetrofitCallBacks.checkIsVerificationCodeIsValid(new RestServiceController.ResponseCallBacks() {
                @Override
                public void onResponse(Object o) {
                    //otp is valid
                    try {
                        PhoneNumberVerification.super.cancelPopUp();
                    } catch (Exception e) {
                        writeCrashReport("Error", e.getMessage());
                    }
                    Intent newIntent = new Intent(PhoneNumberVerification.this, CreateUser.class);
                    Bundle bundle = new Bundle();
                    bundle.putString(Constants.EXTRASTRINGS, data);
                    newIntent.putExtras(bundle);
                    startActivity(newIntent);
                    finish();
                }

                @Override
                public void onFailure(Object o) {
                    if (o != null) {
                        try {
                            PhoneNumberVerification.super.cancelPopUp();
                        } catch (Exception e) {
                            writeCrashReport("Error", e.getMessage());
                        }
                        if (o instanceof retrofit2.Response) {
                            //invalid request is made or getting any error
                            try {
                                PhoneNumberVerification.super.showToastMessage(getString(R.string.error_msg_invalid_code), false);
                            } catch (Exception e) {
                                PhoneNumberVerification.super.writeCrashReport(PhoneNumberRegistration.class.getName(),
                                        e.getMessage());
                            }
                        } else if (o instanceof Throwable) {
                            try {
                                PhoneNumberVerification.super.showToastMessage(getString(R.string.sp_no_internet_connection), false);
                            } catch (Exception e) {
                                PhoneNumberVerification.super.writeCrashReport(PhoneNumberRegistration.class.getName(),
                                        e.getMessage());
                            }
                        }
                    }
                }
            }, phoneNumberVerificationRequest);


        } else {
            super.showToastMessage(getString(R.string.sp_no_internet_connection), false);
        }

    }

    private void checkIsValidOtp(CharSequence str) {
        if (str.length() == 4) {

            continueButton.setBackground(getResources()
                    .getDrawable(R.drawable.registration_vaild_feild_indicator));

            continueButton.setTextColor(Color.WHITE);

            continueButton.setClickable(true);
        } else {

            continueButton.setBackground(getResources()
                    .getDrawable(R.drawable.registration_pages_button));

            continueButton.setTextColor(Color.GRAY);

            continueButton.setClickable(false);
        }
    }

    /**
     * Receiver when sms is received.
     */
    BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            String verifyCode = intent.getStringExtra("verify_code");

            otpVerification.setText(verifyCode);

            phoneNumberVerificationRequest.setVerification_code(verifyCode);

            Utils.hideSoftKeyBoard(PhoneNumberVerification.this);

            continueButton.setBackground(getResources()
                    .getDrawable(R.drawable.registration_vaild_feild_indicator));

            continueButton.setTextColor(Color.WHITE);

            continueButton.setClickable(true);

        }
    };
}
