package com.dubuqu.dnModels.responseModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by ionixx on 10/7/17.
 */

public class PublicMediaResponseModel {
    @SerializedName("signed_url")
    @Expose
    private String signedUrl;
    @SerializedName("media_identifier")
    @Expose
    private String mediaIdentifier;
    @SerializedName("user_identifier")
    @Expose
    private String userIdentifier;
    @SerializedName("content_type")
    @Expose
    private String contentType;

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getSignedUrl() {
        return signedUrl;
    }

    public void setSignedUrl(String signedUrl) {
        this.signedUrl = signedUrl;
    }

    public String getMediaIdentifier() {
        return mediaIdentifier;
    }

    public void setMediaIdentifier(String mediaIdentifier) {
        this.mediaIdentifier = mediaIdentifier;
    }

    public String getUserIdentifier() {
        return userIdentifier;
    }

    public void setUserIdentifier(String userIdentifier) {
        this.userIdentifier = userIdentifier;
    }
}
