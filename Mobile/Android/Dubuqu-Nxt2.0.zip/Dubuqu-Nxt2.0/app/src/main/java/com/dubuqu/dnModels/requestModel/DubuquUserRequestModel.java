package com.dubuqu.dnModels.requestModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

/**
 * Created by ionixx on 14/6/17.
 */

public class DubuquUserRequestModel implements Serializable {

    @SerializedName("mobile_numbers")
    @Expose
    private List<String> mobileNumbers = null;

    public List<String> getMobileNumbers() {
        return mobileNumbers;
    }

    public void setMobileNumbers(List<String> mobileNumbers) {
        this.mobileNumbers = mobileNumbers;
    }
}
