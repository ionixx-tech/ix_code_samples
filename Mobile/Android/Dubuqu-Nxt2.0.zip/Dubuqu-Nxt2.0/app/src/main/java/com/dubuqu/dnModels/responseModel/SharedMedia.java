package com.dubuqu.dnModels.responseModel;

/**
 * Created by ionixx on 11/7/17.
 */

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SharedMedia {

    @SerializedName("media_identifier")
    @Expose
    private String mediaIdentifier;
    @SerializedName("content_type")
    @Expose
    private String contentType;
    @SerializedName("comment_count")
    @Expose
    private Integer commentCount;
    @SerializedName("signed_url")
    @Expose
    private String signedUrl;

    @SerializedName("user_identifier")
    @Expose
    private String userIdentifier;

    public String getUserIdentifier() {
        return userIdentifier;
    }

    public void setUserIdentifier(String userIdentifier) {
        this.userIdentifier = userIdentifier;
    }

    public String getMediaIdentifier() {
        return mediaIdentifier;
    }

    public void setMediaIdentifier(String mediaIdentifier) {
        this.mediaIdentifier = mediaIdentifier;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public Integer getCommentCount() {
        return commentCount;
    }

    public void setCommentCount(Integer commentCount) {
        this.commentCount = commentCount;
    }

    public String getSignedUrl() {
        return signedUrl;
    }

    public void setSignedUrl(String signedUrl) {
        this.signedUrl = signedUrl;
    }

}