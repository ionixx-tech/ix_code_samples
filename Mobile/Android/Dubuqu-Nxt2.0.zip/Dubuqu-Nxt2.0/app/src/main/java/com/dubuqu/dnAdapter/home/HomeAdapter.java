package com.dubuqu.dnAdapter.home;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v4.util.Pair;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.RecyclerView;
import android.text.format.DateUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.dubuqu.R;
import com.dubuqu.dnActivity.LandingActivity;
import com.dubuqu.dnActivity.MultipleShareActivity;
import com.dubuqu.dnActivity.home.AlbumViewActivity;
import com.dubuqu.dnActivity.home.HomeDetailImageViewer;
import com.dubuqu.dnActivity.home.HomeListActivity;
import com.dubuqu.dnActivity.profile.FullImageViewActivity;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnModels.commonModel.ActionConformationDialog;
import com.dubuqu.dnModels.commonModel.DubuqGroupDetails;
import com.dubuqu.dnModels.requestModel.Captions;
import com.dubuqu.dnModels.responseModel.GetAllMediaTimeLine;
import com.dubuqu.dnModels.responseModel.MediaLikeDetails;
import com.dubuqu.dnModels.responseModel.SharedMedias;
import com.dubuqu.dnRestServices.RestServiceController;
import com.dubuqu.dnRestServices.RestServiceProvider;
import com.dubuqu.dnServices.ContactService;
import com.dubuqu.dnStorage.SessionManager;
import com.dubuqu.dnUtils.RestServiceUtils;
import com.dubuqu.dnUtils.Utils;
import com.dubuqu.dnViews.DubuquViewPager;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;
import com.shuhart.bubblepagerindicator.BubblePageIndicator;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;

import static android.content.Context.LAYOUT_INFLATER_SERVICE;

/**
 * Created by Yogaraj subramanian on 29/11/17
 */

public class HomeAdapter extends RecyclerView.Adapter<HomeAdapter.HomeAdapterViewHolder> {

    Activity context;

    boolean isAlbumView = false;

    private List<GetAllMediaTimeLine> getAllMediaTimeLineList;

    HomeAdapterCallback homeAdapterCallback;


    public interface HomeAdapterCallback {

        void startPaginating();

        void refreshHomeContent();

        void removeTimelineMedia(int postion);
    }

    public HomeAdapter(Activity context, HomeAdapterCallback homeAdapterCallback) {
        this.context = context;
        this.homeAdapterCallback = homeAdapterCallback;
    }

    public void setGetAllMediaTimeLineList(List<GetAllMediaTimeLine> getAllMediaTimeLineList) {
        this.getAllMediaTimeLineList = getAllMediaTimeLineList;
    }

    @Override
    public HomeAdapterViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View feedView = null;
        if (isAlbumView) {
            feedView = LayoutInflater.from(context).inflate(R.layout.home_adapter_album_view_viewholder, parent,
                    false);
        } else {
            feedView = LayoutInflater.from(context).inflate(R.layout.home_adapter_viewholder, parent,
                    false);
        }
        return new HomeAdapterViewHolder(feedView);
    }

    @Override
    public void onBindViewHolder(HomeAdapterViewHolder holder, int position) {
        try {
            holder.onBind(position);
            if (getAllMediaTimeLineList.size() - 1 == position)
                homeAdapterCallback.startPaginating();
        } catch (Exception e) {
            if (context instanceof LandingActivity) {
                ((LandingActivity) context).writeCrashReport(HomeAdapter.class.getName(), e.getMessage());
            }
        }
    }

    @Override
    public int getItemCount() {
        if (getAllMediaTimeLineList != null)
            return getAllMediaTimeLineList.size();
        else
            return 0;
    }

    @Override
    public int getItemViewType(int position) {
        return getAllMediaTimeLineList.get(position).hashCode();
    }

    @Override
    public long getItemId(int position) {
        return getAllMediaTimeLineList.get(position).hashCode();
    }


    public void setAlbumView(boolean albumView) {
        isAlbumView = albumView;
    }

    class HomeAdapterViewHolder extends RecyclerView.ViewHolder implements
            FeedViewPagerAdapter.FeedViewPagerCallbacks {

        ImageView profileImage, chatView, unreadCommentCount, moreOptions;

        TextView userName, timePosted, likeCount, commentCount, groupName, captionTv, likeTxt, commentTxt;

        ImageView repost, likeMedia, captionImv;

        DubuquViewPager viewPager;

        LinearLayout rootCollageLayout;

        FeedViewPagerAdapter feedViewPagerAdapter;

        GetAllMediaTimeLine getAllMediaTimeLine;

        int currentPostion = 0;

        boolean isMediaLiked = false, isOwnMedia = false;

        BubblePageIndicator indicator;

        boolean isGroup = false;

        public HomeAdapterViewHolder(View itemView) {
            super(itemView);

            profileImage = itemView.findViewById(R.id.feed_header_profile_image);

            userName = itemView.findViewById(R.id.feed_header_user_name);

            timePosted = itemView.findViewById(R.id.header_time_posted);

            likeCount = itemView.findViewById(R.id.feed_footer_like_count);

            commentCount = itemView.findViewById(R.id.feed_footer_comment_count);

            repost = itemView.findViewById(R.id.feed_header_repost);

            likeMedia = itemView.findViewById(R.id.feed_footer_like_media);

            viewPager = itemView.findViewById(R.id.feed_viewpager);

            indicator = itemView.findViewById(R.id.indicator);

            chatView = itemView.findViewById(R.id.feed_footer_comment_imv);

            groupName = itemView.findViewById(R.id.feed_header_group_name);
            groupName.setPaintFlags(groupName.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);

            rootCollageLayout = itemView.findViewById(R.id.feed_collageView);
            rootCollageLayout.setVisibility(View.GONE);

            unreadCommentCount = itemView.findViewById(R.id.feed_footer_unreadcomment_imv);
            unreadCommentCount.setVisibility(View.GONE);

            captionImv = itemView.findViewById(R.id.feed_add_caption);

            captionTv = itemView.findViewById(R.id.captions_tv);
            captionTv.setVisibility(View.GONE);

            moreOptions = itemView.findViewById(R.id.home_options_imv);
            moreOptions.setColorFilter(context.getResources().getColor(R.color.sp_dark_grey), PorterDuff.Mode.SRC_IN);

            likeTxt = itemView.findViewById(R.id.feed_footer_like_count_text);
            commentTxt = itemView.findViewById(R.id.feed_footer_comment_count_txt);

        }

        @Override
        public void changeViewPagerSize(View view) {
//            viewPager.measureCurrentView(view);
        }

        @Override
        public void onItemViewAdded(Integer position, FeedViewPagerAdapter.FeedViewPagerViewHolder
                feedViewPagerViewHolder)
                throws Exception {
        }

        @Override
        public void onItemViewremoved(int position) throws Exception {

        }

        @Override
        public void onItemViewClicked(int postion) throws Exception {
            openMediaInFullView(postion, false);
        }

        /**
         * Bind Data to view
         *
         * @param posiiton the current position of the adapter
         * @throws Exception {Runtime Stub Exception}
         */
        void onBind(final int posiiton) throws Exception {

            getAllMediaTimeLine = getAllMediaTimeLineList.get(posiiton);

            Bitmap bitmap = null;

            SessionManager sessionManager = new SessionManager(context);
            String userIdentifier = sessionManager.getUserIdentifier();

            if (!userIdentifier.equalsIgnoreCase(getAllMediaTimeLine.getUserIdentifier())) {
                captionImv.setVisibility(View.GONE);
            }

            if (isAlbumView) {
                bitmap = Utils.textAsBitmapRoundRect(getAllMediaTimeLine.getName(), context, 3);
            } else {
                bitmap = Utils.textAsBitmap(getAllMediaTimeLine.getName(), context);
            }


            profileImage.setImageBitmap(bitmap);

            if (getAllMediaTimeLine.getProfileImage() != null
                    &&
                    !getAllMediaTimeLine.getProfileImage().equalsIgnoreCase("")) {

                ImageLoader.getInstance().displayImage(getAllMediaTimeLine.getProfileImage(),
                        profileImage, new ImageLoadingListener() {
                            @Override
                            public void onLoadingStarted(String imageUri, View view) {

                            }

                            @Override
                            public void onLoadingFailed(String imageUri, View view, FailReason failReason) {

                            }

                            @Override
                            public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                                profileImage.setImageBitmap(loadedImage);
                            }

                            @Override
                            public void onLoadingCancelled(String imageUri, View view) {

                            }
                        });
            }

            if (getAllMediaTimeLine.getType().contains("social-group") && !isAlbumView) {

                String nameData = getAllMediaTimeLine.getName();
                String userNames = nameData.substring(0, nameData.indexOf("@"));
                String groupNames = nameData.substring(nameData.indexOf("@"));

                userName.setText(userNames);
                groupName.setVisibility(View.VISIBLE);
                groupName.setText(groupNames);

                isGroup = true;

                /* userName.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        openMedialistActivity();
                    }
                });*/
            } else if (isAlbumView) {
                userName.setText(getAllMediaTimeLine.getName().substring(0, getAllMediaTimeLine.getName().indexOf("@")));
            } else {
                userName.setText(getAllMediaTimeLine.getName());
            }

            timePosted.setText(formatDate(getAllMediaTimeLine.getCreatedTime()));

            if (getAllMediaTimeLine.getAllowRepost() == null ||
                    getAllMediaTimeLine.getAllowRepost().equalsIgnoreCase("false")) {
                repost.setClickable(false);
                repost.setVisibility(View.GONE);
                repost.setEnabled(false);
            }

            if (getAllMediaTimeLine.getSharedMedias() != null) {
                setShareMediaAdapter();
            }

            groupName.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    openAlbumViewActivity();
                }
            });

            viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                @Override
                public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

                }

                @Override
                public void onPageSelected(int position) {
                    try {
                        currentPostion = position;
                        setLikeAndCommentCount();
                        setUnreadCommentDetails();
                        setCaptions();
//                        getMediaLikeList();
                    } catch (Exception e) {
                        if (context instanceof LandingActivity) {
                            ((LandingActivity) context).writeCrashReport(HomeAdapter.class.getName(), e.getMessage());
                        }
                    }
                }

                @Override
                public void onPageScrollStateChanged(int state) {

                }
            });

            likeMedia.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try {

                        YoYo.with(Techniques.Pulse).duration(500).playOn(view);

                        if (isMediaLiked) {
                            likeMedia.setImageDrawable(context.getDrawable(R.drawable.ic_unlike));

                            isMediaLiked = false;
                            postMediaLike("unlike");
                            int likecount = Integer.parseInt(likeCount.getText().toString());
                            setLikeCount(String.valueOf(likecount - 1), isMediaLiked);
                        } else {
                            isMediaLiked = true;
                            likeMedia.setImageDrawable(context.getDrawable(R.drawable.ic_like));
                            postMediaLike("like");
                            int likecount = Integer.parseInt(likeCount.getText().toString());
                            setLikeCount(String.valueOf(likecount + 1), isMediaLiked);
                        }
                    } catch (Exception e) {
                        writeCrashReport(e.getMessage());
                    }
                }
            });

            repost.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    SharedMedias sharedMedias = getCurrentObjectInstance();
                    if (sharedMedias != null) {
                        repostMedia(sharedMedias);
                    }
                }
            });

            chatView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try {
                        openMediaInFullView(posiiton, true);
                    } catch (Exception e) {
                        writeCrashReport(e.getMessage());
                    }
                }
            });

            rootCollageLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    openMedialistActivity();
                }
            });


            captionImv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        showAddCaptionPopup();
                    } catch (Exception e) {
                        writeCrashReport(e.getMessage());
                    }
                }
            });

            profileImage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (getAllMediaTimeLine.getProfileImage() != null
                            && !getAllMediaTimeLine.getProfileImage().equalsIgnoreCase("")) {
                        Intent intent = new Intent(context, FullImageViewActivity.class);
                        intent.putExtra(Constants.IMAGEURI, getAllMediaTimeLine.getProfileImage());
                        Pair<View, String> p2 = Pair.create((View) profileImage, "user_profile");

                        Pair[] views = new Pair[]{p2};

                        ActivityOptionsCompat options = ActivityOptionsCompat.
                                makeSceneTransitionAnimation(context, views);

                        ActivityCompat.startActivity(context, intent, options.toBundle());
                    }
                }
            });

            moreOptions.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        Utils.addReppleEffectToview(context, v);
                        openPopupOptionsMenu();
                    } catch (Exception e) {
                        writeCrashReport(e.getMessage());
                    }
                }
            });

            setLikeAndCommentCount();
            setUnreadCommentDetails();
            setCaptions();

            /*if (getAllMediaTimeLine.isPromoVideo()) {
                itemView.findViewById(R.id.footer_main_rl).setVisibility(View.GONE);
                itemView.findViewById(R.id.feed_footer_ll).setVisibility(View.GONE);
            } else {

            }*/

        }

        /**
         * set media adpater if media is more than 4 pager adapter is replaced with collage view
         *
         * @throws Exception {Runtime Exception}
         */
        private void setShareMediaAdapter() throws Exception {
            if (getAllMediaTimeLine.getSharedMediaCount() <= 4 || getAllMediaTimeLine.getSharedMedias().size() <= 3) {
                feedViewPagerAdapter = new FeedViewPagerAdapter(context, getAllMediaTimeLine.getSharedMedias());
                feedViewPagerAdapter.setFeedViewPagerCallbacks(this);
                viewPager.setAdapter(feedViewPagerAdapter);
                viewPager.setCurrentItem(0, true);
                indicator.setViewPager(viewPager, feedViewPagerAdapter);
                viewPager.setVisibility(View.VISIBLE);
                rootCollageLayout.setVisibility(View.GONE);
                itemView.findViewById(R.id.footer_main_rl).setVisibility(View.VISIBLE);
                itemView.findViewById(R.id.feed_footer_ll).setVisibility(View.VISIBLE);
                indicator.setVisibility(View.VISIBLE);
            } else {
                itemView.findViewById(R.id.footer_main_rl).setVisibility(View.GONE);
                itemView.findViewById(R.id.feed_footer_ll).setVisibility(View.GONE);
                rootCollageLayout.setVisibility(View.VISIBLE);
                viewPager.setVisibility(View.GONE);
                indicator.setVisibility(View.GONE);
                setCollageView();

                if (new SessionManager(context).getUserIdentifier()
                        .equalsIgnoreCase(getAllMediaTimeLine.getUserIdentifier())
                        && isGroup && checkIfIsOwnGroup(getAllMediaTimeLine.getGroupIdentifier())) {
                    moreOptions.setVisibility(View.GONE);
                }

                if (checkIfIsOwnGroup(getAllMediaTimeLine.getGroupIdentifier())) {
                    moreOptions.setVisibility(View.GONE);
                }
            }

            if (getAllMediaTimeLine.isPromoVideo()) {
                moreOptions.setVisibility(View.GONE);
            }
        }

        /**
         * Open media in full view based on type of view clicked the bundle data is passed
         * if comment view is pressed open chat option is enabled in bundle
         */
        private void openMediaInFullView(int currentPostion, boolean shoulShowCommentView) {

            SharedMedias sharedMedias = getCurrentObjectInstance();

            if (sharedMedias != null) {
                if (sharedMedias.getUnreadCommentCount() > 0) {
                    sharedMedias.setUnreadCommentCount(0);
                    try {
                        sendBroadCastData();
                        makeReadCommentAPI();
                    } catch (Exception e) {
                        writeCrashReport(e.getMessage());
                    }
                }
            }

            Intent startDetailImageView = new Intent(context, HomeDetailImageViewer.class);

            Bundle bundle = new Bundle();

            bundle.putString(Constants.EXTRASTRINGS, new Gson().toJson(getAllMediaTimeLine));

            bundle.putInt(Constants.CURRENTIMAGE, currentPostion);

            bundle.putBoolean(Constants.SHOULDSHOWCHAT, shoulShowCommentView);

            startDetailImageView.putExtras(bundle);


            /*context.startActivity(startDetailImageView);*/


//            Pair<View, String> p1 = Pair.create((View) profileImage, "profileimage");

            Pair<View, String> p2 = Pair.create((View) viewPager, "viewpager");

            Pair[] views = new Pair[]{p2};

            ActivityOptionsCompat options = ActivityOptionsCompat.makeSceneTransitionAnimation(context, views);

            ActivityCompat.startActivity(context, startDetailImageView, options.toBundle());
        }

        /**
         * Open Media list activity if the collage view is pressed.
         */
        private void openMedialistActivity() {

            Intent startHomeListActivity = new Intent(context, HomeListActivity.class);
            Bundle bundle = new Bundle();
            bundle.putString(Constants.EXTRASTRINGS,
                    new Gson().toJson(getAllMediaTimeLine));
            startHomeListActivity.putExtras(bundle);

            Pair<View, String> p2 = Pair.create((View) userName, "username");

            Pair[] views = new Pair[]{p2};

            ActivityOptionsCompat options = ActivityOptionsCompat.
                    makeSceneTransitionAnimation(context, views);

            ActivityCompat.startActivity(context, startHomeListActivity, options.toBundle());
        }

        /**
         * open {@link AlbumViewActivity} group name is pressed.
         */
        private void openAlbumViewActivity() {
            Intent startDetailImageView = new Intent(context, AlbumViewActivity.class);

            startDetailImageView.putExtra(Constants.DUBUQU_USER_NAME,
                    userName.getText().toString());

            startDetailImageView.putExtra(Constants.GROUP_IDENTIFIER,
                    getAllMediaTimeLine.getGroupIdentifier());

            Pair<View, String> p2 = Pair.create((View) userName, "username");

            Pair[] views = new Pair[]{p2};

            ActivityOptionsCompat options = ActivityOptionsCompat.
                    makeSceneTransitionAnimation(context, views);

            ActivityCompat.startActivity(context,
                    startDetailImageView,
                    options.toBundle());
        }

        /**
         * format the timestamp send from to dubuqu format
         * for eg: posted 5 hrs ago
         *
         * @param timeStamp the String timestamp got from server
         * @return {@link String} formated time string
         * @throws Exception {Runtime Stub Exception}
         */
        private String formatDate(String timeStamp) throws Exception {

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

            sdf.setTimeZone(TimeZone.getTimeZone("UTC"));

            Date date = sdf.parse(timeStamp);

            long millis = date.getTime();
            long timeInMillis = System.currentTimeMillis();

            CharSequence text = DateUtils.getRelativeTimeSpanString(millis,
                    timeInMillis, 0, DateUtils.FORMAT_ABBREV_ALL);

            if (text.toString().equalsIgnoreCase("0 sec.ago")) {
                return "just now";
            } else {
                return text.toString();
            }

        }

        /**
         * set like and comment count and also check if media is liked by the user or not.
         *
         * @throws Exception {Runtime stub Exception}
         */
        private void setLikeAndCommentCount() throws Exception {

            SharedMedias sharedMedias = getCurrentObjectInstance();
            if (sharedMedias != null) {
                likeCount.setText(String.valueOf(sharedMedias.getLikeCount()));
                likeMedia.setImageDrawable(context.getDrawable(R.drawable.ic_unlike));
                isMediaLiked = sharedMedias.getLiked();
                if (isMediaLiked) {
                    likeMedia.setImageDrawable(context.getDrawable(R.drawable.ic_like));
                } else {
                    likeMedia.setImageDrawable(context.getDrawable(R.drawable.ic_unlike));
                }
                commentCount.setText(String.valueOf(sharedMedias.getCommentCount()));

                if (sharedMedias.getLikeCount() == 1) {
                    likeTxt.setText("Like");
                } else {
                    likeTxt.setText("Likes");
                }

                if (sharedMedias.getCommentCount() == 0) {
                    commentCount.setVisibility(View.GONE);
                    commentTxt.setVisibility(View.GONE);
                } else if (sharedMedias.getCommentCount() > 0) {
                    commentCount.setVisibility(View.VISIBLE);
                    commentTxt.setVisibility(View.VISIBLE);
                    commentTxt.setText(sharedMedias.getCommentCount() == 1 ? "Comment" : "Comments");
                }
            } else {
                throw new Exception("SHARE MEDIA IS NULL");
            }

        }

        /**
         * set like count
         *
         * @param s            {}
         * @param isMediaLiked {set is media is liked by t}
         */
        private void setLikeCount(String s, boolean isMediaLiked) {
            likeCount.setText(s);
            SharedMedias sharedMedias = getCurrentObjectInstance();
            if (sharedMedias != null) {
                sharedMedias.setLikeCount(Integer.parseInt(s));
                sharedMedias.setLiked(isMediaLiked);
                if (sharedMedias.getLikeCount() == 1) {
                    likeTxt.setText("Like");
                } else {
                    likeTxt.setText("Likes");
                }
            }
        }

        /**
         * get media like list who has liked the media
         *
         * @throws Exception {Runtime Stub Exception}
         */
        private void getMediaLikeList() throws Exception {
            String data = "{}";
            OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, context);
            Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
            RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
            RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
            SharedMedias sharedMedias = getCurrentObjectInstance();
            mRetrofitCallBacks.getMediaLikeDetails(sharedMedias.getMediaIdentifier(),
                    new RestServiceController.ResponseCallBacks() {
                        @Override
                        public void onResponse(Object o) {
                            List<MediaLikeDetails> response = (List<MediaLikeDetails>) o;
                            try {
                                if (Utils.isPostLikedByUser(context, response)) {
                                    likeMedia.setImageDrawable(context.getDrawable(R.drawable.ic_like));
                                    isMediaLiked = true;
                                } else {
                                    likeMedia.setImageDrawable(context.getDrawable(R.drawable.ic_unlike));
                                    isMediaLiked = false;
                                }
                                setLikeCount(String.valueOf(response.size()), isMediaLiked);
                            } catch (Exception e) {
                                writeCrashReport(e.getMessage());
                            }
                        }

                        @Override
                        public void onFailure(Object o) {
                            likeMedia.setImageDrawable(context.getDrawable(R.drawable.ic_unlike));
                            isMediaLiked = false;
                        }
                    });

        }

        /**
         * set caption text that is added by the media owner
         */
        private void setCaptions() {
            SharedMedias sharedMedias = getCurrentObjectInstance();

            if (sharedMedias != null && getAllMediaTimeLine.getSharedMediaCount() <= 4) {

                String captions = sharedMedias.getCaption();
                if (captions != null && !captions.equalsIgnoreCase("")) {
                    //show update text
                    captionTv.setVisibility(View.VISIBLE);
                    captionTv.setText(captions);
                } else {
                    //hide text
                    captionTv.setVisibility(View.GONE);
                }
            } else {
                captionTv.setVisibility(View.GONE);
            }
        }

        /**
         * to indicate that user has unread comments against the media.
         */
        private void setUnreadCommentDetails() {
            SharedMedias sharedMedias = getCurrentObjectInstance();
            if (sharedMedias != null) {
                int unreadCommentCount = sharedMedias.getUnreadCommentCount();
                if (unreadCommentCount > 0)
                    this.unreadCommentCount.setVisibility(View.VISIBLE);
                else
                    this.unreadCommentCount.setVisibility(View.GONE);
            }
        }

        private void setCollageView() throws Exception {

            LinearLayout firstLayout = (LinearLayout) rootCollageLayout.getChildAt(0);

            LinearLayout secondLayout = (LinearLayout) rootCollageLayout.getChildAt(1);

            ImageView topImageView = (ImageView) firstLayout.getChildAt(0);

            loadImage(topImageView, 0);

            ImageView bottomFirstView = (ImageView) secondLayout.getChildAt(0);

            loadImage(bottomFirstView, 1);

            ImageView bottomSecondView = (ImageView) secondLayout.getChildAt(1);

            loadImage(bottomSecondView, 2);

            RelativeLayout relativeLayout = (RelativeLayout) secondLayout.getChildAt(2);

            ImageView bottomThirdView = (ImageView) relativeLayout.getChildAt(0);

            loadImage(bottomThirdView, 3);

            TextView bottomOverlay = (TextView) relativeLayout.getChildAt(1);

            int count = getAllMediaTimeLine.getSharedMediaCount() - 4;

            String textContent = "+" + count;

            bottomOverlay.setText(textContent);

        }


        private void loadImage(final ImageView topImageView, int position) {
            SharedMedias sharedMedia = getAllMediaTimeLine.getSharedMedias().get(position);

            Glide.with(context)
                    .load(sharedMedia.getSignedUrl())
                    .centerCrop()
                    .dontTransform()
                    .dontAnimate()
                    .into(topImageView);
        }


        private void showAddCaptionPopup() throws Exception {

            final SharedMedias sharedMedias = getCurrentObjectInstance();

            LayoutInflater inflater = (LayoutInflater) context.getSystemService(LAYOUT_INFLATER_SERVICE);
            assert inflater != null;
            View view = inflater.inflate(R.layout.layout_addcaption, null);

            TextView captionHeader, cancelView, updateView;

            final EditText editText;

            String captions = "";

            captionHeader = view.findViewById(R.id.caption_head_text);

            cancelView = view.findViewById(R.id.caption_cancel);

            updateView = view.findViewById(R.id.caption_save);

            editText = view.findViewById(R.id.caption_edit_text);
            /*mediaType = view.findViewById(R.id.caption_media_type_txt);*/
            final PopupWindow pop = new PopupWindow(context);
            pop.setContentView(view);
            pop.setWidth(LinearLayout.LayoutParams.MATCH_PARENT);
            pop.setHeight(LinearLayout.LayoutParams.MATCH_PARENT);
            pop.setFocusable(true);
            pop.setBackgroundDrawable(null);
            pop.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
            pop.showAtLocation(view, Gravity.TOP, 0, 0);

            if (sharedMedias != null) {
                captions = sharedMedias.getCaption();

               /* if (sharedMedias.getContentType().contains("video")) {
                    mediaType.setText("Add the caption for video");
                } else {
                    mediaType.setText("Add the caption for image");
                }*/

                if (captions != null && !captions.equalsIgnoreCase("")) {
                    editText.setText(captions);
                    captionHeader.setText(context.getString(R.string.update_caption));
                    updateView.setText(context.getString(R.string.update));
                } else {
                    editText.setText("");
                    captionHeader.setText(context.getString(R.string.add_caption));
                    updateView.setText(context.getString(R.string.save));
                }
            }

            cancelView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    pop.dismiss();
                }
            });

            updateView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (sharedMedias != null) {
                        if (!editText.getText().toString()
                                .equalsIgnoreCase(sharedMedias.getCaption())) {
                            //make http request to save caption
                            String text = editText.getText().toString().trim()
                                   /* .replaceAll("\\s{2,}",
                                    "")*/
                                    .replaceAll("\\n{2,}", "\n\n");

                            makeHttpRequestToCaptions(text,

                                    sharedMedias.getMediaIdentifier());
                            sharedMedias.setCaption(text);
                            notifyDataSetChanged();
                            pop.dismiss();
                        } else {
                            pop.dismiss();
                        }
                    }
                }
            });
        }


        private void openPopupOptionsMenu() throws Exception {

            LayoutInflater inflater = (LayoutInflater)
                    context.getSystemService(LAYOUT_INFLATER_SERVICE);

            assert inflater != null;
            final View mediaOptionsMenu = inflater.inflate(R.layout.layout_media_options, null);

            final TextView cancel, reportSpam, block;

            cancel = mediaOptionsMenu.findViewById(R.id.options_cancel);

            reportSpam = mediaOptionsMenu.findViewById(R.id.reportmedia_txt);

            block = mediaOptionsMenu.findViewById(R.id.block_txt);

            View blurView = mediaOptionsMenu.findViewById(R.id.realtimeblurview);

            if (getAllMediaTimeLine.getUserIdentifier().equalsIgnoreCase(new SessionManager(context)
                    .getUserIdentifier())) {
                isOwnMedia = true;
                reportSpam.setText(context.getString(R.string.delete_media));
            }

            if (isGroup || isAlbumView) {
                block.setText(context.getString(R.string.exit_group));
                if (checkIfIsOwnGroup(getAllMediaTimeLine.getGroupIdentifier())) {
                    block.setVisibility(View.GONE);
                }
            } else if (!isOwnMedia) {
                block.setText(context.getString(R.string.block_user));
            }

            if (getAllMediaTimeLine.getSharedMediaCount() > 4) {
                reportSpam.setVisibility(View.GONE);
            }

            final PopupWindow popupWindow = new PopupWindow(context);
            popupWindow.setContentView(mediaOptionsMenu);
            popupWindow.setWidth(LinearLayout.LayoutParams.MATCH_PARENT);
            popupWindow.setHeight(LinearLayout.LayoutParams.MATCH_PARENT);
            popupWindow.setFocusable(true);
            popupWindow.setBackgroundDrawable(null);

            popupWindow.showAtLocation(mediaOptionsMenu, Gravity.TOP, 0, 0);

            cancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    popupWindow.dismiss();
                }
            });

            reportSpam.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    popupWindow.dismiss();
                    if (isOwnMedia)
                        deleteMedia();
                    else
                        reportSpam();
                }
            });

            block.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    popupWindow.dismiss();
                    blockUser();
                }
            });

            blurView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    popupWindow.dismiss();
                }
            });
        }

        /**
         * make delete media request
         */
        private void deleteMedia() {
            new ActionConformationDialog(
                    context.getString(R.string.delete_media),
                    context.getString(R.string.confirm_delete),
                    context, new ActionConformationDialog.OnActionCOnformationListner() {
                @Override
                public void onConformed() {
                    try {
                        SharedMedias sharedMedias = getCurrentObjectInstance();
                        if (sharedMedias != null) {
                            String data = "{}";
                            OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, context);
                            Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
                            RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
                            RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);

                            mRetrofitCallBacks.deleteMedia(sharedMedias.getMediaIdentifier());

                            getAllMediaTimeLine.getSharedMedias().remove(viewPager.getCurrentItem());

                            feedViewPagerAdapter.notifyDataSetChanged();
                            indicator.setViewPager(viewPager, feedViewPagerAdapter);
                            if (getAllMediaTimeLine.getSharedMedias().size() == 0) {
                                homeAdapterCallback.removeTimelineMedia(getAdapterPosition());
                            }
                        }
                    } catch (Exception e) {
                        writeCrashReport(e.getMessage());
                    }
                }

                @Override
                public void onRejected() {

                }
            });
        }

        /**
         * report spam api call
         */
        void reportSpam() {

            new ActionConformationDialog(
                    context.getString(R.string.report_spam),
                    context.getString(R.string.report_media_confirm), context,
                    new ActionConformationDialog.OnActionCOnformationListner() {
                        @Override
                        public void onConformed() {
                            try {
                                SharedMedias sharedMedias = getCurrentObjectInstance();
                                if (sharedMedias != null) {
                                    String data = "{}";
                                    OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, context);
                                    Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
                                    RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
                                    RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);

                                    mRetrofitCallBacks.reportSpam(sharedMedias.getMediaIdentifier());

                                    getAllMediaTimeLine.getSharedMedias().remove(viewPager.getCurrentItem());

                                    feedViewPagerAdapter.notifyDataSetChanged();
                                    indicator.setViewPager(viewPager, feedViewPagerAdapter);
                                    if (getAllMediaTimeLine.getSharedMedias().size() == 0) {
                                        homeAdapterCallback.removeTimelineMedia(getAdapterPosition());
                                    }
                                }
                            } catch (Exception e) {
                                writeCrashReport(e.getMessage());
                            }
                        }

                        @Override
                        public void onRejected() {

                        }
                    });

        }


        /**
         * block or exit group
         */
        private void blockUser() {

            if (isGroup || isAlbumView) {
                new ActionConformationDialog(
                        context.getString(R.string.exit_group),
                        context.getString(R.string.exit_group_confirm)
                        , context, new ActionConformationDialog.OnActionCOnformationListner() {
                    @Override
                    public void onConformed() {
                        try {
                            String data = "{}";
                            OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, context);
                            Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
                            RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
                            RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
                            mRetrofitCallBacks.exitgroup(getAllMediaTimeLine.getGroupIdentifier());
                            homeAdapterCallback.refreshHomeContent();
                            Intent intent = new Intent(context, ContactService.class);
                            context.startService(intent);
                            if (isAlbumView) {
                                if (context instanceof AlbumViewActivity) {
                                    sendHomeRefershEven();
                                    ((AlbumViewActivity) context).finish();

                                }
                            }
                        } catch (Exception e) {
                            writeCrashReport(e.getMessage());
                        }
                    }

                    @Override
                    public void onRejected() {

                    }
                });

            } else {
                new ActionConformationDialog(
                        context.getString(R.string.block_user), context.getString(R.string.confirm_block), context, new ActionConformationDialog.OnActionCOnformationListner() {
                    @Override
                    public void onConformed() {
                        try {
                            String data = "{}";
                            OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, context);
                            Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
                            RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
                            RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
                            mRetrofitCallBacks.blockUser(getAllMediaTimeLine.getUserIdentifier());
                            homeAdapterCallback.refreshHomeContent();
                        } catch (Exception e) {
                            writeCrashReport(e.getMessage());
                        }
                    }

                    @Override
                    public void onRejected() {

                    }
                });
            }

        }


        /**
         * if there is any un read comment is available the below api is hit
         *
         * @throws Exception {Runtime Stub Exception}
         */
        private void makeReadCommentAPI() throws Exception {
            String data = "{}";

            OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, context);
            Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
            RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
            RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
            SharedMedias sharedMedias = getCurrentObjectInstance();
            if (sharedMedias != null) {
                mRetrofitCallBacks.readComments(sharedMedias.getMediaIdentifier());
            }
        }


        /**
         * make http request to server to add caption to media
         *
         * @param s               the caption that need to be added
         * @param mediaIdentifier the unique identifier of the media
         */
        private void makeHttpRequestToCaptions(String s, String mediaIdentifier) {
            try {
                String data = new Gson().toJson(new Captions(s));
                OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, context);
                Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
                RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
                RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
                mRetrofitCallBacks.addCaptions(s, mediaIdentifier);
            } catch (Exception e) {
                writeCrashReport(e.getMessage());
            }

        }


        /**
         * action to like the media or unlike the media
         *
         * @param action the action user has done {LIKE,UNLIKE}
         */
        private void postMediaLike(final String action) throws Exception {

            MediaLikeDetails mediaLikeDetails = new MediaLikeDetails();
            Gson gson = new Gson();
            String data = gson.toJson(mediaLikeDetails);
            OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, context);
            Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
            RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
            RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
            SharedMedias sharedMedias = getCurrentObjectInstance();
            mRetrofitCallBacks.postMediaLikeAction(sharedMedias.getMediaIdentifier(),
                    action, mediaLikeDetails,
                    new RestServiceController.ResponseCallBacks() {
                        @Override
                        public void onResponse(Object o) {
                            sendBroadCastData();
                        }

                        @Override
                        public void onFailure(Object o) {
                            //Utils.showNegativeTost(getApplicationContext(), "Social Circle Creatation Failed.");
                        }
                    });
        }


        private void repostMedia(SharedMedias sharedMedia) {
            Intent intent = new Intent(context, MultipleShareActivity.class);
            Bundle bundle = new Bundle();
            bundle.putBoolean(Constants.RESHAREMEDIA, true);
            bundle.putString(Constants.MEDIA_IDENTIFIER, sharedMedia.getMediaIdentifier());
            intent.putExtras(bundle);
            context.startActivity(intent);
        }


        /**
         * get current view pager object instance
         *
         * @return {@link SharedMedias}
         */
        private SharedMedias getCurrentObjectInstance() {
            List<SharedMedias> sharedMedias = getAllMediaTimeLine.getSharedMedias();
            return sharedMedias.get(currentPostion);
        }

        /**
         * write log report when error occurs
         *
         * @param message {@link String }
         */
        private void writeCrashReport(String message) {
            Log.e(HomeAdapter.class.getName(), message);
        }

        private void sendBroadCastData() {
            try {
                Intent intent = new Intent(Constants.REFRESHHOMEDATA);
                intent.putExtra(Constants.SELECTEDIMAGES, new Gson().toJson(getCurrentObjectInstance()));
                intent.putExtra(Constants.SHAREMEDA_POSITON, viewPager.getCurrentItem());
                intent.putExtra(Constants.TIMELINE_IDENTIFIER, getAllMediaTimeLine.getTimelineIdentifier());
                context.sendBroadcast(intent);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        private void sendHomeRefershEven() {
            context.sendBroadcast(new Intent(Constants.REFRESHHOME));
        }

        /**
         * check if group is own group
         *
         * @return {@link Boolean}
         * @throws Exception {Runtime Stub Exception}
         */
        private boolean checkIfIsOwnGroup(String groupIdentifier) throws Exception {
            File file = new File(context.getCacheDir(), Constants.JSONGROUPFILENAME);
            if (file.exists()) {
                FileInputStream fis = new FileInputStream(file);
                InputStreamReader isr = new InputStreamReader(fis);
                BufferedReader bufferedReader = new BufferedReader(isr);
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    sb.append(line);
                }
                Gson gson = new Gson();

                List<DubuqGroupDetails> dubuqGroupDetailses = gson.fromJson(sb.toString(),
                        new TypeToken<List<DubuqGroupDetails>>() {
                        }.getType());

                if (dubuqGroupDetailses != null && dubuqGroupDetailses.size() > 0) {
                    for (DubuqGroupDetails dubuqGroupDetails : dubuqGroupDetailses) {
                        if (dubuqGroupDetails.getDubuquGetGroupResponse()
                                .getGroupIdentifier().equalsIgnoreCase(groupIdentifier)) {
                            return true;
                        }
                    }
                }

            }
            return false;
        }
    }


}
