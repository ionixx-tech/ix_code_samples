package com.dubuqu.dnModels.commonModel;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by ionixx on 13/6/17.
 */

/*Model Wrapper is to wrap contants
* @userName the users name of the contants "FirstName+LastName".
* @number the phone number of the user.
* */
public class PhoneContacts implements Parcelable {

    String phoneNumber, userName, contactId,profileUrl;

    public PhoneContacts(String phoneNumber, String userName, String contactId, String profileUrl) {
        this.phoneNumber = phoneNumber;
        this.userName = userName;
        this.contactId = contactId;
        this.profileUrl = profileUrl;
    }

    protected PhoneContacts(Parcel in) {
        phoneNumber = in.readString();
        userName = in.readString();
        contactId = in.readString();
        profileUrl = in.readString();
    }


    public String getProfileUrl() {
        return profileUrl;
    }

    public void setProfileUrl(String profileUrl) {
        this.profileUrl = profileUrl;
    }


    public String getContactId() {
        return contactId;
    }

    public void setContactId(String contactId) {
        this.contactId = contactId;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(phoneNumber);
        parcel.writeString(userName);
        parcel.writeString(contactId);
        parcel.writeString(profileUrl);
    }
    public static final Creator<PhoneContacts> CREATOR = new Creator<PhoneContacts>() {
        @Override
        public PhoneContacts createFromParcel(Parcel in) {
            return new PhoneContacts(in);
        }

        @Override
        public PhoneContacts[] newArray(int size) {
            return new PhoneContacts[size];
        }
    };

}
