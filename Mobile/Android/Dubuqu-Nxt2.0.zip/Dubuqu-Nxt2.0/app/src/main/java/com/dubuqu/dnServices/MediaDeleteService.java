package com.dubuqu.dnServices;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.IBinder;
import android.provider.MediaStore;
import android.support.annotation.Nullable;

import com.dubuqu.dnConstants.Constants;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by ionixx on 8/6/17.
 */

public class MediaDeleteService extends Service {


    private String mediaPath;

    private List<String> mediaList = new ArrayList<>();

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onStart(Intent intent, int startId) {
        super.onStart(intent, startId);
        onBind(intent);
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        try {

            mediaPath = intent.getStringExtra(Constants.EXTRASTRINGS);

            mediaList = new Gson().fromJson(mediaPath, new TypeToken<List<String>>() {
            }.getType());


            String[] data = new String[mediaList.size()];
            mediaList.toArray(data);

            new MediaBackground().execute(data);

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    @SuppressLint("StaticFieldLeak")
    private class MediaBackground extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... strings) {

            for (String params : strings) {

                String[] projection = {MediaStore.Files.FileColumns._ID};
                String selection = MediaStore.Files.FileColumns.DATA + " = ?";
                String[] selectionArgs = new String[]{params};

                Uri queryUri = MediaStore.Files.getContentUri("external");

                ContentResolver contentResolver = MediaDeleteService.this.getContentResolver();
                Cursor c = contentResolver.query(queryUri, projection, selection, selectionArgs, null);
                if (c != null && c.moveToFirst()) {
                    long id = c.getLong(c.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID));
                    Uri deleteUri = ContentUris.withAppendedId(MediaStore.Files.getContentUri("external")
                            , id);
                    contentResolver.delete(deleteUri, null, null);
                } else {
                    // File not found in media store DB }
                    if (c != null) {
                        c.close();

                        File file = new File(params);

                        if (file.exists()) {
                            file.delete();
                        }
                    }
                }

            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

            Intent broadCast = new Intent(Constants.ALLMEDIADELETED);
            sendBroadcast(broadCast);

            Intent intent = new Intent(MediaDeleteService.this, MediaDeleteService.class);
            stopService(intent);
        }
    }

}
