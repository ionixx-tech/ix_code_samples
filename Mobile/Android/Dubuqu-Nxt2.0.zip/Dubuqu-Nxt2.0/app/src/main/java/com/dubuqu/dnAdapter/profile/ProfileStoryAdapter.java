package com.dubuqu.dnAdapter.profile;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v4.util.Pair;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.format.DateUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.dubuqu.R;
import com.dubuqu.dnActivity.MultipleShareActivity;
import com.dubuqu.dnActivity.home.HomeDetailImageViewer;
import com.dubuqu.dnActivity.home.HomeListActivity;
import com.dubuqu.dnAdapter.group.GroupParticipantAdapter;
import com.dubuqu.dnAdapter.home.FeedViewPagerAdapter;
import com.dubuqu.dnAdapter.home.HomeAdapter;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnModels.commonModel.ActionConformationDialog;
import com.dubuqu.dnModels.commonModel.DubuqContactsShareModel;
import com.dubuqu.dnModels.requestModel.Captions;
import com.dubuqu.dnModels.responseModel.GetTimeLineStory;
import com.dubuqu.dnModels.responseModel.MediaLikeDetails;
import com.dubuqu.dnModels.responseModel.SharedMedias;
import com.dubuqu.dnRestServices.RestServiceController;
import com.dubuqu.dnRestServices.RestServiceProvider;
import com.dubuqu.dnUtils.RestServiceUtils;
import com.dubuqu.dnUtils.Utils;
import com.dubuqu.dnViews.DubuquViewPager;
import com.google.gson.Gson;
import com.shuhart.bubblepagerindicator.BubblePageIndicator;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;

import static android.content.Context.LAYOUT_INFLATER_SERVICE;

/**
 * Created by Yogaraj subramanian on 11/1/18
 */

public class ProfileStoryAdapter extends RecyclerView.Adapter<ProfileStoryAdapter.ProfileStroyViewHolder> {

    Activity activity;

    List<GetTimeLineStory> storyList;

    ProfileadapterCallBack profileadapterCallBack;

    public ProfileStoryAdapter(Activity activity, List<GetTimeLineStory> storyList,
                               ProfileadapterCallBack profileadapterCallBack) {
        this.activity = activity;
        this.storyList = storyList;
        this.profileadapterCallBack = profileadapterCallBack;
    }


    @Override
    public ProfileStroyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(activity).inflate(R.layout.profile_adapter_list_view_holder,
                parent, false);

        return new ProfileStroyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ProfileStroyViewHolder holder, int position) {
        try {
            holder.onBind(position);
        } catch (Exception e) {
            profileadapterCallBack.onError(e.getMessage());
        }
    }

    @Override
    public int getItemCount() {
        return storyList.size();
    }

    @Override
    public long getItemId(int position) {
        return storyList.get(position).hashCode();
    }

    @Override
    public int getItemViewType(int position) {
        return storyList.get(position).hashCode();
    }

    class ProfileStroyViewHolder extends RecyclerView.ViewHolder implements FeedViewPagerAdapter.FeedViewPagerCallbacks {

        ImageView profileImage, chatImageView, repost, likeMedia, captionImv, moreOptions;

        TextView userName, timePosted, likeCount, commentCount, remainingMemeberCount, captionTv, likeTxt, commentTxt;

        DubuquViewPager viewPager;

        LinearLayout rootCollageLayout;

        FeedViewPagerAdapter feedViewPagerAdapter;

        GetTimeLineStory getTimeLineStory;

        int currentPostion = 0;

        boolean isMediaLiked = false;

        BubblePageIndicator indicator;

        View footer;

        ProfileStroyViewHolder(View itemView) {
            super(itemView);

            profileImage = itemView.findViewById(R.id.profile_adapter_list_userprofileimage);

            chatImageView = itemView.findViewById(R.id.profile_adapter_list_footer_commentmedta);

            repost = itemView.findViewById(R.id.profile_adapter_list_footer_repost);

            likeMedia = itemView.findViewById(R.id.profile_adapter_list_footer_likemedia);

            userName = itemView.findViewById(R.id.profile_adapter_list_username);

            timePosted = itemView.findViewById(R.id.profile_adapter_list_timeposted);

            likeCount = itemView.findViewById(R.id.profile_adapter_list_footer_likecount);

            commentCount = itemView.findViewById(R.id.profile_adapter_list_footer_commentcount);

            footer = itemView.findViewById(R.id.profile_adapter_list_footer_rl);

            remainingMemeberCount = itemView.findViewById(R.id.profile_adapter_list_membercount);
            remainingMemeberCount.setVisibility(View.GONE);


            viewPager = itemView.findViewById(R.id.profile_adapter_list_feedcontent_viewpager);

            rootCollageLayout = itemView.findViewById(R.id.profile_adapter_list_feedcontent_collageview);
            rootCollageLayout.setVisibility(View.GONE);

            indicator = itemView.findViewById(R.id.profile_adapter_list_footer_indicator);

            captionImv = itemView.findViewById(R.id.feed_add_caption);

            captionTv = itemView.findViewById(R.id.captions_tv);
            captionTv.setVisibility(View.GONE);

            moreOptions = itemView.findViewById(R.id.home_options_imv);
            moreOptions.setColorFilter(activity.getResources().getColor(R.color.sp_dark_grey), PorterDuff.Mode.SRC_IN);

            likeTxt = itemView.findViewById(R.id.feed_footer_like_count_text);
            commentTxt = itemView.findViewById(R.id.feed_footer_comment_count_txt);
        }

        @SuppressLint("SetTextI18n")
        void onBind(int postion) throws Exception {

            if (postion % 8 == 0)
                profileadapterCallBack.startPaginating();

            getTimeLineStory = storyList.get(postion);

            if (getTimeLineStory != null) {
                final List<GetTimeLineStory.MembersList> membersLists = getTimeLineStory.getMembersList();
                if (membersLists != null) {

                    GetTimeLineStory.MembersList firstuser = membersLists.get(0);

                    if (firstuser != null) {
                        userName.setText(firstuser.getName());
                        displayProfileImage(firstuser.getProfileImage(), firstuser.getName());
                    }

                    if (membersLists.size() > 1) {
                        remainingMemeberCount.setVisibility(View.VISIBLE);
                        remainingMemeberCount.setText(
                                "&\t" + String.valueOf(membersLists.size() - 1).concat("\tothers")
                        );
                        remainingMemeberCount.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                List<DubuqContactsShareModel> dubuqContactsShareModels = new ArrayList<>();
                                try {
                                    for (GetTimeLineStory.MembersList member : membersLists) {
                                        DubuqContactsShareModel dubuqContactsShareModel
                                                = new DubuqContactsShareModel(
                                                member.getName(),
                                                "",
                                                "",
                                                member.getProfileImage(),
                                                member.getType().contains("social-group")
                                                        ? Utils.DUBUQU_CATEGORY.SOCIAL_GROUP :
                                                        Utils.DUBUQU_CATEGORY.DUBUQU_CONTACT
                                        );
                                        dubuqContactsShareModels.add(dubuqContactsShareModel);
                                    }
                                    openFullList(dubuqContactsShareModels);
                                } catch (Exception e) {
                                    writeCrashReport(e.getMessage());
                                }
                            }
                        });
                    }
                }

                displayPostedTime(getTimeLineStory.getCreatedTime());

                setMediaAdapters();

                viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                    @Override
                    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

                    }

                    @Override
                    public void onPageSelected(int position) {
                        currentPostion = position;

                        setLikeCount();

                        setCommentCount();

                        setCaptions();
                    }

                    @Override
                    public void onPageScrollStateChanged(int state) {

                    }
                });

                rootCollageLayout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        openMeidaList();
                    }
                });

                repost.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        SharedMedias sharedMedias = getCurrnetObjectInstance();
                        if (sharedMedias != null) {
                            repostMedia(sharedMedias);
                        }
                    }
                });
                chatImageView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        try {
                            openMediaInFullView(currentPostion, true);
                        } catch (Exception e) {
                            writeCrashReport(e.getMessage());
                        }
                    }
                });


                likeMedia.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {
                            YoYo.with(Techniques.Pulse).duration(500).playOn(v);
                            SharedMedias sharedMedias = getCurrnetObjectInstance();
                            int likecount = Integer.parseInt(likeCount.getText().toString());
                            if (isMediaLiked) {
                                likeMedia.setImageDrawable(activity.getDrawable(R.drawable.ic_unlike));
                                likeMedia.setAlpha(0.7f);
                                isMediaLiked = false;
                                postMediaLike("unlike");
                                if (sharedMedias != null) {
                                    sharedMedias.setLikeCount(likecount - 1);
                                    sharedMedias.setLiked(isMediaLiked);
                                }
                                setLikeCount();
                            } else {
                                likeMedia.setAlpha(1.0f);
                                isMediaLiked = true;
                                likeMedia.setImageDrawable(activity.getDrawable(R.drawable.ic_like));
                                postMediaLike("like");
                                if (sharedMedias != null) {
                                    sharedMedias.setLikeCount(likecount + 1);
                                    sharedMedias.setLiked(isMediaLiked);
                                }

                                setLikeCount();
                            }
                        } catch (Exception e) {
                            writeCrashReport(e.getMessage());
                        }
                    }
                });

                captionImv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {
                            showAddCaptionPopup();
                        } catch (Exception e) {
                            writeCrashReport(e.getMessage());
                        }
                    }
                });

                moreOptions.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {
                            Utils.addReppleEffectToview(activity, v);
                            openPopupOptionsMenu();
                        } catch (Exception e) {
                            writeCrashReport(e.getMessage());
                        }
                    }
                });

                setLikeCount();

                setCommentCount();

                setCaptions();
            }
        }

        private void openPopupOptionsMenu() throws Exception {

            LayoutInflater inflater = (LayoutInflater)
                    activity.getSystemService(LAYOUT_INFLATER_SERVICE);

            assert inflater != null;
            final View mediaOptionsMenu = inflater.inflate(R.layout.layout_media_options, null);

            final TextView cancel, reportSpam, block;

            cancel = mediaOptionsMenu.findViewById(R.id.options_cancel);

            reportSpam = mediaOptionsMenu.findViewById(R.id.reportmedia_txt);

            block = mediaOptionsMenu.findViewById(R.id.block_txt);

            View blurView = mediaOptionsMenu.findViewById(R.id.realtimeblurview);

            reportSpam.setText(activity.getString(R.string.delete_media));

            block.setVisibility(View.GONE);

            final PopupWindow popupWindow = new PopupWindow(activity);
            popupWindow.setContentView(mediaOptionsMenu);
            popupWindow.setWidth(LinearLayout.LayoutParams.MATCH_PARENT);
            popupWindow.setHeight(LinearLayout.LayoutParams.MATCH_PARENT);
            popupWindow.setFocusable(true);
            popupWindow.setBackgroundDrawable(null);

            popupWindow.showAtLocation(mediaOptionsMenu, Gravity.TOP, 0, 0);

            cancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    popupWindow.dismiss();
                }
            });

            reportSpam.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    popupWindow.dismiss();
                    deleteMedia();
                }
            });

            blurView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    popupWindow.dismiss();
                }
            });
        }

        /**
         * make delete media request
         */
        private void deleteMedia() {

            new ActionConformationDialog(
                    activity.getString(R.string.delete_media),
                    activity.getString(R.string.confirm_delete),
                    activity, new ActionConformationDialog.OnActionCOnformationListner() {
                @Override
                public void onConformed() {
                    try {
                        SharedMedias sharedMedias = getCurrnetObjectInstance();
                        if (sharedMedias != null) {
                            String data = "{}";
                            OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, activity);
                            Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
                            RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
                            RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);

                            mRetrofitCallBacks.deleteMedia(sharedMedias.getMediaIdentifier());

                            getTimeLineStory.getSharedMedias().remove(viewPager.getCurrentItem());

                            feedViewPagerAdapter.notifyDataSetChanged();

                            indicator.setViewPager(viewPager, feedViewPagerAdapter);

                            if (getTimeLineStory.getSharedMedias().size() == 0) {
                                profileadapterCallBack.removeTimelineMedia(getAdapterPosition());
                            }
                        }
                    } catch (Exception e) {
                        writeCrashReport(e.getMessage());
                    }
                }

                @Override
                public void onRejected() {

                }
            });
        }

        private void showAddCaptionPopup() throws Exception {

            final SharedMedias sharedMedias = getCurrnetObjectInstance();

            LayoutInflater inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            assert inflater != null;
            View view = inflater.inflate(R.layout.layout_addcaption, null);

            TextView captionHeader, cancelView, updateView;

            final EditText editText;

            String captions = "";

            captionHeader = view.findViewById(R.id.caption_head_text);

            cancelView = view.findViewById(R.id.caption_cancel);

            updateView = view.findViewById(R.id.caption_save);

            editText = view.findViewById(R.id.caption_edit_text);

//            mediaType = view.findViewById(R.id.caption_media_type_txt);

            final PopupWindow pop = new PopupWindow(activity);
            pop.setContentView(view);
            pop.setWidth(LinearLayout.LayoutParams.MATCH_PARENT);
            pop.setHeight(LinearLayout.LayoutParams.MATCH_PARENT);
            pop.setFocusable(true);
            pop.setBackgroundDrawable(null);
            pop.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
            pop.showAtLocation(view, Gravity.TOP, 0, 0);

            if (sharedMedias != null) {
                captions = sharedMedias.getCaption();

              /*  if (sharedMedias.getContentType().contains("video")) {
                    mediaType.setText("Add the caption for video");
                } else {
                    mediaType.setText("Add the caption for image");
                }*/

                if (captions != null && !captions.equalsIgnoreCase("")) {
                    editText.setText(captions);
                    captionHeader.setText(activity.getString(R.string.update_caption));
                    updateView.setText(activity.getString(R.string.update));
                } else {
                    editText.setText("");
                    captionHeader.setText(activity.getString(R.string.add_caption));
                    updateView.setText(activity.getString(R.string.save));
                }
            }

            cancelView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    pop.dismiss();
                }
            });

            updateView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (sharedMedias != null) {
                        if (!editText.getText().toString()
                                .equalsIgnoreCase(sharedMedias.getCaption())) {
                            //make http request to save caption
                            String text = editText.getText().toString().trim()
                                   /* .replaceAll("\\s{2,}",
                                    "")*/
                                    .replaceAll("\\n{2,}", "\n\n");

                            makeHttpRequestToCaptions(text,

                                    sharedMedias.getMediaIdentifier());
                            sharedMedias.setCaption(text);
                            notifyDataSetChanged();
                            pop.dismiss();
                        } else {
                            pop.dismiss();
                        }
                    }
                }
            });
        }


        private void makeHttpRequestToCaptions(String s, String mediaIdentifier) {
            try {
                String data = new Gson().toJson(new Captions(s));
                OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, activity);
                Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
                RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
                RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
                mRetrofitCallBacks.addCaptions(s, mediaIdentifier);
            } catch (Exception e) {
                writeCrashReport(e.getMessage());
            }

        }

        private void setCaptions() {

            SharedMedias sharedMedias = getCurrnetObjectInstance();

            if (sharedMedias != null && getTimeLineStory.getSharedMediasCount() <= 4) {

                String captions = sharedMedias.getCaption();
                if (captions != null && !captions.equalsIgnoreCase("")) {
                    //show update text
                    captionTv.setVisibility(View.VISIBLE);
                    captionTv.setText(captions);
                } else {
                    //hide text
                    captionTv.setVisibility(View.GONE);
                }
            } else {
                captionTv.setVisibility(View.GONE);
            }
        }

        /**
         * Set comment count a against each media
         */
        private void setCommentCount() {
            SharedMedias sharedMedias = getCurrnetObjectInstance();
            if (sharedMedias != null) {

                commentCount.setText(String.valueOf(sharedMedias.getCommentCount()));

                if (sharedMedias.getCommentCount() == 0) {
                    commentCount.setVisibility(View.GONE);
                    commentTxt.setVisibility(View.GONE);
                } else if (sharedMedias.getCommentCount() > 0) {
                    commentCount.setVisibility(View.VISIBLE);
                    commentTxt.setVisibility(View.VISIBLE);
                    commentTxt.setText(sharedMedias.getCommentCount() == 1 ? "Comment" : "Comments");
                }
            }
        }

        /**
         * set like count against each media
         */
        private void setLikeCount() {
            SharedMedias sharedMedias = getCurrnetObjectInstance();
            if (sharedMedias != null) {
                if (sharedMedias.isLiked()) {
                    isMediaLiked = true;
                    likeMedia.setImageDrawable(activity.getDrawable(R.drawable.ic_like));
                } else {
                    isMediaLiked = false;
                    likeMedia.setImageDrawable(activity.getDrawable(R.drawable.ic_unlike));
                }

                likeCount.setText(String.valueOf(sharedMedias.getLikeCount()));

                if (sharedMedias.getLikeCount() == 1) {
                    likeTxt.setText("Like");
                } else {
                    likeTxt.setText("Likes");
                }
            }
        }


        @Override
        public void onItemViewAdded(Integer position,
                                    FeedViewPagerAdapter.FeedViewPagerViewHolder feedViewPagerViewHolder)
                throws Exception {

        }

        @Override
        public void onItemViewremoved(int position) throws Exception {

        }

        @Override
        public void onItemViewClicked(int postion) throws Exception {
            openMediaInFullView(postion, false);
        }

        @Override
        public void changeViewPagerSize(View view) {

        }

        /**
         * open medias in list view i.e if media is more than 4 the medias are shown in list.
         */
        private void openMeidaList() {
            Intent startHomeListActivity = new Intent(activity, HomeListActivity.class);
            startHomeListActivity.putExtra(Constants.ISSTORYTIMELINE, true);
            Bundle bundle = new Bundle();
            bundle.putString(Constants.EXTRASTRINGS,
                    new Gson().toJson(getTimeLineStory));
            startHomeListActivity.putExtras(bundle);

            activity.startActivity(startHomeListActivity);
        }

        /**
         * Show Medias in View pager or collage View
         */
        private void setMediaAdapters() throws Exception {
            if (getTimeLineStory.getSharedMediasCount() <= 4) {

                feedViewPagerAdapter = new FeedViewPagerAdapter(activity,
                        getTimeLineStory.getSharedMedias());

                feedViewPagerAdapter.setFeedViewPagerCallbacks(this);

                viewPager.setAdapter(feedViewPagerAdapter);

                viewPager.setCurrentItem(0, true);

                indicator.setViewPager(viewPager, feedViewPagerAdapter);

                footer.setVisibility(View.VISIBLE);

                itemView.findViewById(R.id.feed_footer_ll).setVisibility(View.VISIBLE);

                rootCollageLayout.setVisibility(View.GONE);
            } else {
                itemView.findViewById(R.id.profile_adapter_list_feedcontent_viewpager).setVisibility(View.GONE);

                itemView.findViewById(R.id.feed_footer_ll).setVisibility(View.GONE);

                rootCollageLayout.setVisibility(View.VISIBLE);

                viewPager.setVisibility(View.GONE);

                indicator.setVisibility(View.GONE);

                footer.setVisibility(View.GONE);

                setCollageView();

                moreOptions.setVisibility(View.GONE);
            }
        }

        private void repostMedia(SharedMedias sharedMedia) {
            Intent intent = new Intent(activity, MultipleShareActivity.class);
            Bundle bundle = new Bundle();
            bundle.putBoolean(Constants.RESHAREMEDIA, true);
            bundle.putString(Constants.MEDIA_IDENTIFIER, sharedMedia.getMediaIdentifier());
            intent.putExtras(bundle);
            activity.startActivity(intent);
        }

        private void openMediaInFullView(int currentPostion, boolean shoulShowCommentView) {

            Intent startDetailImageView = new Intent(activity, HomeDetailImageViewer.class);
            startDetailImageView.putExtra(Constants.ISSTORYTIMELINE, true);

            Bundle bundle = new Bundle();
            bundle.putString(Constants.EXTRASTRINGS, new Gson().toJson(getTimeLineStory));
            bundle.putInt(Constants.CURRENTIMAGE, currentPostion);
            bundle.putBoolean(Constants.SHOULDSHOWCHAT, shoulShowCommentView);
            startDetailImageView.putExtras(bundle);

//            Pair<View, String> p1 = Pair.create((View) profileImage, "profileimage");
            Pair<View, String> p2 = Pair.create((View) viewPager, "viewpager");

            Pair[] views = new Pair[]{p2};

            ActivityOptionsCompat options = ActivityOptionsCompat.
                    makeSceneTransitionAnimation(activity, views);

            ActivityCompat.startActivity(activity, startDetailImageView, options.toBundle());
        }

        /**
         * set Collage view mode in list to indicate there is more than 4 medias have been shared
         */
        private void setCollageView() {

            LinearLayout firstLayout = (LinearLayout) rootCollageLayout.getChildAt(0);

            LinearLayout secondLayout = (LinearLayout) rootCollageLayout.getChildAt(1);

            ImageView topImageView = (ImageView) firstLayout.getChildAt(0);

            loadImage(topImageView, 0);

            ImageView bottomFirstView = (ImageView) secondLayout.getChildAt(0);

            loadImage(bottomFirstView, 1);

            ImageView bottomSecondView = (ImageView) secondLayout.getChildAt(1);

            loadImage(bottomSecondView, 2);

            RelativeLayout relativeLayout = (RelativeLayout) secondLayout.getChildAt(2);

            ImageView bottomThirdView = (ImageView) relativeLayout.getChildAt(0);

            loadImage(bottomThirdView, 3);

            TextView bottomOverlay = (TextView) relativeLayout.getChildAt(1);

            int count = getTimeLineStory.getSharedMediasCount() - 4;

            String textContent = "+" + count;

            bottomOverlay.setText(textContent);

        }

        /**
         * load image in the collage view section
         *
         * @param topImageView the view the media need to be loded.
         * @param position     the postion of the media that need to be loaded in {@literal topImageView}
         */
        private void loadImage(final ImageView topImageView, int position) {
            SharedMedias sharedMedia = getTimeLineStory.getSharedMedias().get(position);

            Glide.with(activity)
                    .load(sharedMedia.getSignedUrl())
                    .centerCrop()
                    .dontTransform()
                    .dontAnimate()
                    .into(topImageView);

          /*File f = imageLoader.getDiskCache().get(sharedMedia.getSignedUrl());
            if (!f.exists()) {
                ImageLoader.getInstance().displayImage(sharedMedia.getSignedUrl(), topImageView,
                        new ImageLoadingListener() {
                            @Override
                            public void onLoadingStarted(String imageUri, View view) {
                                topImageView.setImageDrawable(activity.getResources().getDrawable(R.drawable.overlay_media));
                            }

                            @Override
                            public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
                                topImageView.setImageDrawable(activity.getResources().getDrawable(R.drawable.overlay_media));
                            }

                            @Override
                            public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                                topImageView.setImageBitmap(loadedImage);
                            }

                            @Override
                            public void onLoadingCancelled(String imageUri, View view) {
                                topImageView.setImageDrawable(activity.getResources().getDrawable(R.drawable.overlay_media));
                            }
                        });
            } else {
                imageLoader.displayImage(f.getAbsolutePath(), topImageView);
            }*/
        }

        /**
         * display the time on which the media is posted.
         *
         * @param createdTime {@link String}time data
         * @throws Exception {@link RuntimeException}
         */
        private void displayPostedTime(String createdTime) throws Exception {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

            sdf.setTimeZone(TimeZone.getTimeZone("UTC"));

            Date date = sdf.parse(createdTime);

            long millis = date.getTime();
            long timeInMillis = System.currentTimeMillis();

            CharSequence text = DateUtils.getRelativeTimeSpanString(millis, timeInMillis, 0, DateUtils.FORMAT_ABBREV_ALL);
            if (text.toString().equalsIgnoreCase("0 sec.ago")) {
                timePosted.setText("just now");
            } else {
                timePosted.setText(text.toString());
            }
        }

        /**
         * display first profile image of the user
         *
         * @param profileUri the amzon signed url of the user or group
         * @param userName   the use name of the user
         * @throws Exception runtime stub exception
         */
        private void displayProfileImage(String profileUri, String userName) throws Exception {

            final Bitmap bitmap = Utils.textAsBitmap(userName, activity);
            profileImage.setImageBitmap(bitmap);
            if (profileUri != null &&
                    !profileUri.equalsIgnoreCase("")) {

                Glide.with(activity)
                        .load(profileUri)
                        .dontAnimate()
                        .dontTransform()
                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                        .into(profileImage);
            }

           /* File f = imageLoader.getDiskCache().get(profileUri);
            if (!f.exists()) {
                ImageLoader.getInstance().displayImage(profileUri, profileImage,
                        new ImageLoadingListener() {
                            @Override
                            public void onLoadingStarted(String imageUri, View view) {
                                profileImage.setImageBitmap(bitmap);
                            }

                            @Override
                            public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
                                profileImage.setImageBitmap(bitmap);
                            }

                            @Override
                            public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                                if (loadedImage != null)
                                    profileImage.setImageBitmap(loadedImage);
                            }

                            @Override
                            public void onLoadingCancelled(String imageUri, View view) {
                                profileImage.setImageBitmap(bitmap);
                            }
                        });
            } else {
                imageLoader.displayImage(f.getAbsolutePath(), profileImage);
            }*/
        }


        /**
         * action to like the media or unlike the media
         *
         * @param action the action user has done {LIKE,UNLIKE}
         */
        private void postMediaLike(final String action) throws Exception {

            MediaLikeDetails mediaLikeDetails = new MediaLikeDetails();
            Gson gson = new Gson();
            String data = gson.toJson(mediaLikeDetails);
            OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, activity);
            Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
            RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
            RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
            SharedMedias sharedMedias = getCurrnetObjectInstance();
            mRetrofitCallBacks.postMediaLikeAction(sharedMedias.getMediaIdentifier(),
                    action, mediaLikeDetails,
                    new RestServiceController.ResponseCallBacks() {
                        @Override
                        public void onResponse(Object o) {
                               /* if (isAlbumView) {
                                    sendBroadCastData();
                                }*/
                        }

                        @Override
                        public void onFailure(Object o) {
                            //Utils.showNegativeTost(getApplicationContext(), "Social Circle Creatation Failed.");
                        }
                    });
        }

        private SharedMedias getCurrnetObjectInstance() {
            return getTimeLineStory.getSharedMedias().get(currentPostion);
        }

        private void writeCrashReport(String message) {
            Log.e(HomeAdapter.class.getName(), message);
        }

    }

    public interface ProfileadapterCallBack {

        void startPaginating();

        void onError(String message);

        void removeTimelineMedia(int postion);
    }

    /**
     * Show list of available user in the group.
     *
     * @param participantList {@link List} of {@link DubuqContactsShareModel}
     * @throws Exception {Runtime Stub Exception}
     */
    private void openFullList(List<DubuqContactsShareModel> participantList) throws Exception {

        RecyclerView recyclerView;

        ImageView back;

        LayoutInflater inflater = (LayoutInflater)
                activity.getSystemService(LAYOUT_INFLATER_SERVICE);

        View inflate = inflater.inflate(R.layout.group_list_memeber_full_list, null);

        final PopupWindow popupWindow = new PopupWindow(activity);

        recyclerView = inflate.findViewById(R.id.group_list_memeber_rcv);
        recyclerView.setLayoutManager(new LinearLayoutManager(activity));
        recyclerView.setAdapter(new GroupParticipantAdapter(splitView(participantList), activity,
                GroupParticipantAdapter.ViewType.SEELIST));

        back = inflate.findViewById(R.id.popup_close);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                popupWindow.dismiss();
            }
        });

        inflate.setFocusableInTouchMode(true);
        inflate.requestFocus();
        inflate.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK) {
                    popupWindow.dismiss();
                    return true;
                }
                return false;
            }
        });


        popupWindow.setContentView(inflate);
        popupWindow.setWidth(LinearLayout.LayoutParams.MATCH_PARENT);
        popupWindow.setHeight(LinearLayout.LayoutParams.MATCH_PARENT);
        popupWindow.setFocusable(true);
        popupWindow.setBackgroundDrawable(null);
        popupWindow.showAtLocation(inflate, Gravity.TOP, 0, 0);
    }

    private List<DubuqContactsShareModel> splitView(List<DubuqContactsShareModel> participantList) throws Exception {

        List<DubuqContactsShareModel> dubuquContacts = new ArrayList<>();

        List<DubuqContactsShareModel> group = new ArrayList<>();

        for (DubuqContactsShareModel contacts : participantList) {

            if (contacts.getCategory() == Utils.DUBUQU_CATEGORY.DUBUQU_CONTACT)
                dubuquContacts.add(contacts);
            else if (contacts.getCategory() == Utils.DUBUQU_CATEGORY.SOCIAL_GROUP)
                group.add(contacts);
        }

        if (dubuquContacts.size() > 0)
            dubuquContacts.add(0, new DubuqContactsShareModel("Dubuqu Contacts", "", "", "", Utils.DUBUQU_CATEGORY.HEADER));

        if (group.size() > 0)
            group.add(0, new DubuqContactsShareModel("Groups", "", "", "", Utils.DUBUQU_CATEGORY.HEADER));

        dubuquContacts.addAll(group);

        return dubuquContacts;
    }
}

