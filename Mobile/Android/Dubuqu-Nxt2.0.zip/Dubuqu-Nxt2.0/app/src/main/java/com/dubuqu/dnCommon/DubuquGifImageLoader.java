package com.dubuqu.dnCommon;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import com.dubuqu.dnModels.requestModel.GifResponse;
import com.dubuqu.dnRestServices.RestServiceController;
import com.dubuqu.dnRestServices.RestServiceProvider;
import com.dubuqu.dnUtils.RestServiceUtils;

import java.util.List;

import retrofit2.Retrofit;

/**
 * Created by Yogaraj subramanian on 6/3/18
 * <p>
 * Load or Search Gif using Tenor.
 */

public class DubuquGifImageLoader {

    private Context context;

    private GifLoaderListenr gifLoaderListenr;

    private RecyclerView recyclerView;

    public DubuquGifImageLoader() {
        getRandomGif(10, 0);
    }

    public DubuquGifImageLoader(Context context, GifLoaderListenr gifLoaderListenr) {
        this.context = context;
        this.gifLoaderListenr = gifLoaderListenr;
    }

    /**
     * Set Recycler view the Gifs need to be populated
     *
     * @param recyclerView {@link RecyclerView} where list need to be updated
     */
    public void setRecyclerView(RecyclerView recyclerView) {
        this.recyclerView = recyclerView;
    }

    /**
     * search for any gifs
     *
     * @param searchQueryText {@link String}searchQueryText
     * @param limt            {@link Integer}limit of the query
     * @param offset          {@link Integer}current list size
     * @return {@link List} && {@link GifResponse}
     */
    public List<GifResponse> searchGif(String searchQueryText, int limt, int offset) {

        return null;
    }

    /**
     * get random gifs if user doesnt search any gif.
     *
     * @param limt         {@link Integer}limit of the query
     * @param offset{@link Integer}current list size
     * @return {@link List} && {@link GifResponse}
     */
    public List<GifResponse> getRandomGif(int limt, int offset) {
        Retrofit retrofit = RestServiceUtils.makeHttpRequest();
        RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
        RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);

        mRetrofitCallBacks.getRandomGifs(offset, limt, new RestServiceController.ResponseCallBacks() {
            @Override
            public void onResponse(Object o) {
                Log.e("Gif Received", o + "");
            }

            @Override
            public void onFailure(Object o) {
                Log.e("Gif Received", o + "");
            }
        });
        return null;
    }

    /**
     * Gif Loading Listener to handle if any gif images cliked or gif loading failed
     */
    public interface GifLoaderListenr {

        void onGifResponse(List<GifResponse> list);

        void onGifLoadFailed(String message);
    }
}
