package com.dubuqu.dnModels.responseModel;

/**
 * Created by root on 14/7/17.
 */

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class UserDetails {

    @SerializedName("user_name")
    @Expose
    private String userName;

    @SerializedName("email_id")
    @Expose
    private String emailId;

    @SerializedName("memory_retain")
    @Expose
    private String memoryRetain;

    @SerializedName("device_notification_key")
    @Expose
    private String device_notification_key;

    public String getDevice_notification_key() {
        return device_notification_key;
    }

    public void setDevice_notification_key(String device_notification_key) {
        this.device_notification_key = device_notification_key;
    }

    public String getMemoryRetain() {
        return memoryRetain;
    }

    public void setMemoryRetain(String memoryRetain) {
        this.memoryRetain = memoryRetain;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

}
