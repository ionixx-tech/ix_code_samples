package com.dubuqu.dnActivity.profile;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.content.FileProvider;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.dubuqu.R;
import com.dubuqu.dnActivity.BaseActivity;
import com.dubuqu.dnActivity.LandingActivity;
import com.dubuqu.dnActivity.RemoveProfileImageActivity;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnModels.commonModel.ErrorBodyModel;
import com.dubuqu.dnModels.responseModel.DubuquUserModel;
import com.dubuqu.dnModels.responseModel.UserDetails;
import com.dubuqu.dnRestServices.RestServiceController;
import com.dubuqu.dnRestServices.RestServiceProvider;
import com.dubuqu.dnStorage.SessionManager;
import com.dubuqu.dnUtils.RestServiceUtils;
import com.dubuqu.dnUtils.Utils;
import com.google.gson.Gson;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;
import com.yalantis.ucrop.UCrop;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;
import retrofit2.Response;
import retrofit2.Retrofit;

/**
 * Created by Yogaraj subramanian on 10/1/18
 */

public class EditProfileActivity extends BaseActivity {

    Button saveButton;

    EditText userNameEditText, phoneNumberEditText, emailEditText;

    ImageView userProfileImageView, coverImageView, backImageView, editProfileImage;

    SessionManager sessionManager;

    private Uri outputFileUri = null, profileUri = null;

    String amazonProfileUri = null;

    boolean isProfilepicRemoved = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        try {
            intializeView();
        } catch (Exception e) {
            writeCrashReport(e.getMessage());
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Constants.RESTRICT_SREENSHOT)
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        try {
            switch (requestCode) {

                case UCrop.REQUEST_CROP:
                    Uri profileUr = UCrop.getOutput(data);
                    if (profileUr != null) {

                        Glide.with(getInstance()).load(profileUr).into(userProfileImageView);
                        Glide.with(getInstance()).load(profileUr).into(coverImageView);

                        profileUri = profileUr;

                        saveButton.setVisibility(View.VISIBLE);
                    }
                    break;

                case Constants.IMAGECPATURE_REQUEST:
                    final boolean isCamera;

                    if (data != null && data.hasExtra(Constants.IMAGEURI)) {
                        String imagePath = data.getStringExtra(Constants.IMAGEURI);
                        if (imagePath != null && !imagePath.equalsIgnoreCase("")) {
                            cropImage(Uri.fromFile(new File(imagePath)));
                        }
                        break;
                    }

                    if (data != null && data.hasExtra("remove_image")) {
                                /*remove image */
                        Bitmap bitmap = Utils.textAsBitmap(sessionManager.getUserName(), getInstance());

                        userProfileImageView.setImageBitmap(bitmap);

                        coverImageView.setImageResource(R.drawable.overlay_media);

                        saveButton.setVisibility(View.VISIBLE);

                        isProfilepicRemoved = true;

                        return;
                    } else if (data == null) {
                        isCamera = true;
                    } else {
                        final String action = data.getAction();
                        isCamera = action != null;
                    }

                    if (isCamera) {
                        profileUri = outputFileUri;
                    } else {
                        profileUri = data.getData();
                    }

                    cropImage(profileUri);
                    profileUri = null;
                    break;


            }
        } catch (Exception e) {
            writeCrashReport(e.getMessage());
        }
    }

    private Context getInstance() {
        return EditProfileActivity.this;
    }

    private void intializeView() throws Exception {

        sessionManager = new SessionManager(this);

        userNameEditText = findViewById(R.id.edit_profile_user_name);

        emailEditText = findViewById(R.id.edit_profile_email_id);

        phoneNumberEditText = findViewById(R.id.edit_profile_phone_number);

        userProfileImageView = findViewById(R.id.edit_profile_user_profile);

        coverImageView = findViewById(R.id.edit_profile_cover_image);

        backImageView = findViewById(R.id.edit_profile_back);

        editProfileImage = findViewById(R.id.edit_profile_edit_image);

        saveButton = findViewById(R.id.edit_profile_save);

        intializeListners();

        getUserDetails();
    }

    private void intializeListners() throws Exception {

        backImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        editProfileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    openImageViewContent();
                } catch (Exception e) {
                    writeCrashReport(e.getMessage());
                }
            }
        });

        userNameEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                try {
                    if (checkIfUserNameOrEmailisChanged()) {
                        saveButton.setVisibility(View.VISIBLE);
                    } else {
                        saveButton.setVisibility(View.GONE);
                    }
                } catch (Exception e) {
                    saveButton.setVisibility(View.GONE);
                    writeCrashReport(e.getMessage());
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        emailEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                try {
                    if (checkIfUserNameOrEmailisChanged()) {
                        saveButton.setVisibility(View.VISIBLE);
                    } else {
                        saveButton.setVisibility(View.GONE);
                    }
                } catch (Exception e) {
                    saveButton.setVisibility(View.GONE);
                    writeCrashReport(e.getMessage());
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {

                    saveButton.setEnabled(false);

                    if (checkIfUserNameOrEmailisChanged() && profileValidation()) {
                        //update profile pic
                        String userName = userNameEditText.getText().toString();

                        String emailId = emailEditText.getText().toString();

                        sessionManager.updateUserDetilas(userName, emailId);

                        updateUserDetailsHttp(userName, emailId);

                        saveButton.setEnabled(true);

                        EditProfileActivity.super.showToastMessage(
                                "Profile Details Updated",
                                true
                        );
                    } else {
                        if (profileUri != null) {

                            //profile picture changed
                            RestServiceUtils.updateUserProfilePic(getInstance(), 120,
                                    sessionManager.getUserIdentifier(),
                                    profileUri.getPath());

                            sessionManager.updateUserProfileImage(profileUri.getPath());

                            EditProfileActivity.super.showToastMessage(
                                    "Profile Picture Updated",
                                    true
                            );

                            sendBroadcast(new Intent(Constants.ONPROFILEPICCHANGED));
                        }

                        if (amazonProfileUri != null && isProfilepicRemoved) {
                            //remvove profile pic
                            RestServiceUtils.updateUserProfilePic(getInstance(), 120,
                                    sessionManager.getUserIdentifier(),
                                    null);
                            sessionManager.updateUserProfileImage("");

                            saveButton.setEnabled(true);

                            EditProfileActivity.super.showToastMessage(
                                    "Profile Picture Removed",
                                    true
                            );

                            sendBroadcast(new Intent(Constants.ONPROFILEPICCHANGED));
                        }
                    }

                } catch (Exception e) {
                    writeCrashReport(e.getMessage());
                }
            }
        });
    }


    /**
     * Make Http call to Server to update profile Pic
     *
     * @param userName
     * @param emailId
     * @throws Exception
     */
    private void updateUserDetailsHttp(String userName, String emailId) throws Exception {
        UserDetails userDetails = new UserDetails();
        userDetails.setUserName(userName);
        userDetails.setEmailId(emailId);
        Gson gson = new Gson();
        String data = gson.toJson(userDetails);
        OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, getApplicationContext());
        Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
        RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
        RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
        mRetrofitCallBacks.updateUserDetails(sessionManager.getUserIdentifier(), userDetails,
                new RestServiceController.ResponseCallBacks() {
                    @Override
                    public void onResponse(Object o) {

                    }

                    @Override
                    public void onFailure(Object object) {
                        handleApiErrorMessage(object);
                    }
                });
    }

    /**
     * get user details.
     *
     * @throws Exception {Runtime Exception}
     */
    private void getUserDetails() throws Exception {

        String userNameS = sessionManager.getUserName();

        userNameEditText.setText(userNameS);

        emailEditText.setText(sessionManager.getEmailId());

        phoneNumberEditText.setText(String.format("+%s %s",
                sessionManager.getCountryCode(),
                sessionManager.getPhoneNumber()));

        Bitmap bitmap = Utils.textAsBitmap(userNameS, getInstance());

        userProfileImageView.setImageBitmap(bitmap);

        String data = "{}";
        OkHttpClient okHttpClient = null;

        okHttpClient = RestServiceUtils.getHeader(data, getInstance());
        Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
        RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
        RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);

        mRetrofitCallBacks.fetchDubuquUserDetails(
                new RestServiceController.ResponseCallBacks() {
                    @Override
                    public void onResponse(Object o) {
                        if (o != null) {

                            final DubuquUserModel userModel =
                                    (DubuquUserModel) o;

                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    String profileImageS = userModel.getProfileImage();
                                    displayProfileImage(profileImageS);
                                }
                            });
                        }
                    }

                    @Override
                    public void onFailure(Object o) {
                        handleApiErrorMessage(o);
                    }
                },
                sessionManager.getUserIdentifier());
    }

    private void displayProfileImage(String profileImageS) {

        if (profileImageS != null && !profileImageS.equalsIgnoreCase("")) {

            amazonProfileUri = profileImageS;

            ImageLoader.getInstance().displayImage(profileImageS, userProfileImageView, new ImageLoadingListener() {
                @Override
                public void onLoadingStarted(String imageUri, View view) {

                }

                @Override
                public void onLoadingFailed(String imageUri, View view, FailReason failReason) {

                }

                @Override
                public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                    userProfileImageView.setImageBitmap(loadedImage);
                    coverImageView.setImageBitmap(loadedImage);
                }

                @Override
                public void onLoadingCancelled(String imageUri, View view) {

                }
            });
        }
    }

    private void writeCrashReport(String message) {
        super.writeCrashReport(EditProfileActivity.class.getName(), message);
    }

    /**
     * Handle API error messages
     *
     * @param o might be Instance of {@link Response} or {@link Throwable}
     */
    private void handleApiErrorMessage(Object o) {
        if (o != null) {
            if (getInstance() instanceof LandingActivity) {
                try {
                    if (o instanceof retrofit2.Response) {
                        ResponseBody responseBody = ((Response) o).errorBody();
                        if (responseBody != null) {
                            String value = responseBody.string();
                            ErrorBodyModel errorBodyModel = new Gson().fromJson(value, ErrorBodyModel.class);
                            if (errorBodyModel != null)
                                super.showToastMessage(errorBodyModel.getMessage(), false);
                        }
                    } else if (o instanceof Throwable) {
                        super.showToastMessage(getString(R.string.sp_no_internet_connection), false);
                    }

                } catch (Exception e) {
                    writeCrashReport(e.getMessage());
                }
            }

        }
    }


    /**
     * Open Crop Activity which allows user to crop their images.
     *
     * @param cropImageUri {@link Uri} the pic user has picked
     * @throws Exception {Runtime Stub Exception}
     */
    private void cropImage(Uri cropImageUri) throws Exception {

        String destinationFileName = String.valueOf(System.currentTimeMillis());
        destinationFileName += ".png";

        UCrop uCrop = UCrop.of(cropImageUri
                , Uri.fromFile(new File(getCacheDir(), destinationFileName)));
        UCrop.Options options = new UCrop.Options();
        options.setCompressionFormat(Bitmap.CompressFormat.PNG);
        options.setCompressionQuality(100);
        options.setHideBottomControls(false);
        options.setFreeStyleCropEnabled(true);
        options.setStatusBarColor(getResources().getColor(R.color.colorPrimaryDark));
        options.setToolbarColor(getResources().getColor(R.color.colorPrimary));
        options.setActiveWidgetColor(getResources().getColor(R.color.colorPrimary));
        uCrop.withOptions(options);
        //uCrop = basisConfig(uCrop);
        //uCrop = advancedConfig(uCrop);
        uCrop.start(EditProfileActivity.this);
    }

    /**
     * Add Image Media Intents
     *
     * @throws Exception {Run time stub Exception.}
     */
    private void openImageViewContent() throws Exception {

        // Determine Uri of camera image to save.
        final File root = new File(Utils.getRootFolderForProfilePicture(getInstance()));
        root.mkdirs();

        final String fname = Utils.getAppName(getInstance()) + "_" + System.currentTimeMillis()
                + "." + Utils.getAppName(getInstance());

        final File sdImageMainDirectory = new File(root.getPath(), fname);

        outputFileUri = Uri.fromFile(sdImageMainDirectory);

        Intent chooserIntent = null;

        List<Intent> intentList = new ArrayList<>();

        Intent pickIntent = new Intent(Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

        pickIntent.setType("image/*");

        Intent takePhotoIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        if (!android.os.Build.MANUFACTURER.contains("samsung")) {
            Uri photoURI = FileProvider.getUriForFile(getInstance(),
                    com.dubuqu.BuildConfig.APPLICATION_ID + ".provider",
                    sdImageMainDirectory);

            takePhotoIntent.putExtra("return-data", true);
            takePhotoIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
        }

        intentList = addIntentsToList(getInstance(), intentList, pickIntent);

        intentList = addIntentsToList(getInstance(), intentList, takePhotoIntent);

//        Intent intent = new Intent(getInstance(), CameraPreviewActivity.class);
//        intent.putExtra(Constants.CAPTUREPROFILEIMAGE, true);
//
//        intentList = addIntentsToList(getInstance(), intentList, intent);


        if (amazonProfileUri != null) {
            Intent removeImageIntent = new Intent(getInstance(), RemoveProfileImageActivity.class);
            intentList = addIntentsToList(getApplicationContext(), intentList, removeImageIntent);
        }

        if (intentList.size() > 0) {

            chooserIntent = Intent.createChooser(intentList.remove(intentList.size() - 1),
                    ("Pick image From"));
            chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, intentList.toArray(new Parcelable[]{}));
        }

        startActivityForResult(chooserIntent, Constants.IMAGECPATURE_REQUEST);

    }

    /**
     * add avialable camera nad gallery apps that can provide images
     *
     * @param context {Context of the Activity}
     * @param list    {package name list}
     * @param intent  {intnet to trigger}
     * @return {List}
     */
    private static List<Intent> addIntentsToList(Context context, List<Intent> list, Intent intent) {
        List<ResolveInfo> resInfo = context.getPackageManager().queryIntentActivities(intent, 0);
        for (ResolveInfo resolveInfo : resInfo) {
            String packageName = resolveInfo.activityInfo.packageName;
            Intent targetedIntent = new Intent(intent);
            targetedIntent.setPackage(packageName);
            list.add(targetedIntent);
        }
        return list;
    }

    /**
     * check if user has changed any tex datas
     *
     * @return {@link Boolean}
     * @throws Exception {@link NullPointerException}
     */
    private boolean checkIfUserNameOrEmailisChanged() throws Exception {

        String userName = sessionManager.getUserName();
        String emailId = sessionManager.getEmailId();
        if (!userNameEditText.getText().toString().trim().equals(userName)) {
            return true;
        }
        return !emailEditText.getText().toString().trim().equals(emailId);
    }

    /**
     * Check if user name and email id is vaild.
     *
     * @throws Exception Runtimr Stub Exception.
     */
    private boolean profileValidation() throws Exception {

        String username = userNameEditText.getText().toString();
        String emailid = emailEditText.getText().toString();

        if (username.equalsIgnoreCase("")) {
            userNameEditText.setError(getString(R.string.user_registration_form_empty_name_message));
            return false;
        }

        if (emailid.equalsIgnoreCase("")) {
            emailEditText.setError(getString(R.string.user_registration_form_empty_email_message));
            return false;
        }

        if (!Utils.isValidEmailId(emailid)) {
            emailEditText.setError(getString(R.string.user_registration_form_invalid_email_message));
            return false;
        }

        if (!Utils.isValidusername(username,24)) {
            userNameEditText.setError(getString(R.string.user_registration_form_invalid_name_message));
            return false;
        }

        return true;
    }

}
