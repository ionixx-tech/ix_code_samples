package com.dubuqu.dnCallbacks;

/**
 * Created by Yogaraj subramanian on 6/6/17
 */

public class Callbacks {

    public interface CompressionCallback {

        void getCompressedFilePath(String filePath);

        void onFailed();

        void onUpdateProgress(int value);
    }


}
