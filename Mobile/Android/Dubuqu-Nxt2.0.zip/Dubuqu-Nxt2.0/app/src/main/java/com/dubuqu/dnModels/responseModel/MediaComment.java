
package com.dubuqu.dnModels.responseModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class MediaComment {

    @SerializedName("comment_identifier")
    @Expose
    private String commentIdentifier;

    @SerializedName("comment_type")
    @Expose
    private String commentType;

    @SerializedName("user_identifier")
    @Expose
    private String userIdentifier;

    @SerializedName("user_name")
    @Expose
    private String userName;

    @SerializedName("comment")
    @Expose
    private String comment;

    @SerializedName("profile_image")
    @Expose
    private String profileImage;

    @SerializedName("created_time")
    @Expose
    private String createdTime;

    @SerializedName("parent_comment")
    @Expose
    private ParentComment parentComment;

    public MediaComment(String commentIdentifier, String commentType, String userIdentifier,
                        String userName, String comment, String profileImage,
                        String createdTime, ParentComment parentComment) {
        this.commentIdentifier = commentIdentifier;
        this.commentType = commentType;
        this.userIdentifier = userIdentifier;
        this.userName = userName;
        this.comment = comment;
        this.profileImage = profileImage;
        this.createdTime = createdTime;
        this.parentComment = parentComment;
    }

    public String getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(String createdTime) {
        this.createdTime = createdTime;
    }

    public String getCommentIdentifier() {
        return commentIdentifier;
    }

    public void setCommentIdentifier(String commentIdentifier) {
        this.commentIdentifier = commentIdentifier;
    }

    public String getCommentType() {
        return commentType;
    }

    public void setCommentType(String commentType) {
        this.commentType = commentType;
    }

    public String getUserIdentifier() {
        return userIdentifier;
    }

    public void setUserIdentifier(String userIdentifier) {
        this.userIdentifier = userIdentifier;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getProfileImage() {
        return profileImage;
    }

    public void setProfileImage(String profileImage) {
        this.profileImage = profileImage;
    }

    public ParentComment getParentComment() {
        return parentComment;
    }

    public void setParentComment(ParentComment parentComment) {
        this.parentComment = parentComment;
    }


    public class ParentComment {


        @SerializedName("comment_identifier")
        @Expose
        private String commentIdentifier;
        @SerializedName("comment_type")
        @Expose
        private String commentType;
        @SerializedName("user_identifier")
        @Expose
        private String userIdentifier;
        @SerializedName("user_name")
        @Expose
        private String userName;
        @SerializedName("comment")
        @Expose
        private String comment;
        @SerializedName("created_time")
        @Expose
        private String createdTime;
        @SerializedName("profile_image")
        @Expose
        private String profileImage;

        public String getCommentIdentifier() {
            return commentIdentifier;
        }

        public void setCommentIdentifier(String commentIdentifier) {
            this.commentIdentifier = commentIdentifier;
        }

        public String getCommentType() {
            return commentType;
        }

        public void setCommentType(String commentType) {
            this.commentType = commentType;
        }

        public String getUserIdentifier() {
            return userIdentifier;
        }

        public void setUserIdentifier(String userIdentifier) {
            this.userIdentifier = userIdentifier;
        }

        public String getUserName() {
            return userName;
        }

        public void setUserName(String userName) {
            this.userName = userName;
        }

        public String getComment() {
            return comment;
        }

        public void setComment(String comment) {
            this.comment = comment;
        }

        public String getCreatedTime() {
            return createdTime;
        }

        public void setCreatedTime(String createdTime) {
            this.createdTime = createdTime;
        }

        public String getProfileImage() {
            return profileImage;
        }

        public void setProfileImage(String profileImage) {
            this.profileImage = profileImage;
        }
    }

}
