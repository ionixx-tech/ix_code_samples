package com.dubuqu.dnAdapter.group;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.dubuqu.R;
import com.dubuqu.dnActivity.LandingActivity;
import com.dubuqu.dnModels.commonModel.DubuqContactsShareModel;
import com.dubuqu.dnUtils.Utils;
import com.dubuqu.dnViews.DubuquTextView;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * Created by Yogaraj subramanian on 8/11/17
 */

public class GroupParticipantAdapter extends RecyclerView.Adapter<GroupParticipantAdapter.GroupParticipantViewHolder> {

    private final String TAG = GroupParticipantAdapter.class.getName();

    private List<DubuqContactsShareModel> participantList;

    Context context;

    private ViewType viewHolderType = ViewType.NORAML;


    public enum ViewType {
        SEELIST,

        NORAML
    }

    public GroupParticipantAdapter(List<DubuqContactsShareModel> participantList, Context context, ViewType viewHolderType) {
        this.participantList = participantList;
        this.context = context;
        this.viewHolderType = viewHolderType;
    }

    @Override
    public GroupParticipantViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        if (viewHolderType == ViewType.SEELIST) {

            View view = LayoutInflater.from(context).inflate(R.layout.create_circle_user_selection_view_holder,
                    parent, false);
            return new GroupParticipantViewHolder(view);
        }

        View view = LayoutInflater.from(context).inflate(R.layout.group_participant_viewholder, parent, false);
        return new GroupParticipantViewHolder(view);
    }

    @Override
    public void onBindViewHolder(GroupParticipantViewHolder holder, int position) {

        try {

            holder.onBind(position);
        } catch (Exception e) {
            if (context instanceof LandingActivity) {
                ((LandingActivity) context).writeCrashReport(TAG, e.getMessage());
            }
        }
    }

    @Override
    public int getItemCount() {

        if (viewHolderType == ViewType.NORAML) {

            if (participantList.size() > 3)
                return 3;

            return participantList.size();
        }

        return participantList.size();
    }

    class GroupParticipantViewHolder extends RecyclerView.ViewHolder {

        CircleImageView circleImageView;

        TextView userName;

        GroupParticipantViewHolder(View itemView) {
            super(itemView);
            circleImageView = itemView.findViewById(R.id.userprofilepic);

            userName = itemView.findViewById(R.id.username);
        }

        void onBind(int postion) throws Exception {

            final DubuqContactsShareModel dubuqContactsShareModel = participantList.get(postion);

            if (viewHolderType == ViewType.SEELIST) {
                DubuquTextView dubuquTextView = itemView.findViewById(R.id.header_view);
                View view = itemView.findViewById(R.id.item_view_ll);
                itemView.findViewById(R.id.create_cricle_user_selection_adapter_user_phonenumber).setVisibility(View.GONE);
                itemView.findViewById(R.id.border_indicator).setVisibility(View.GONE);
                itemView.findViewById(R.id.create_cricle_user_selection_adapter_user_selected).setVisibility(View.GONE);

                if (dubuqContactsShareModel.getCategory() == Utils.DUBUQU_CATEGORY.HEADER) {
                    dubuquTextView.setVisibility(View.VISIBLE);
                    dubuquTextView.setText(dubuqContactsShareModel.getUserName());
                    view.setVisibility(View.GONE);
                } else {
                    userName = null;
                    circleImageView = null;
                    userName = itemView.findViewById(R.id.create_cricle_user_selection_adapter_user_profile_name);
                    circleImageView = itemView.findViewById(R.id.create_cricle_user_selection_adapter_user_profile_image);
                    dubuquTextView.setVisibility(View.GONE);
                    view.setVisibility(View.VISIBLE);
                    loadData(dubuqContactsShareModel);
                }

            } else {
                loadData(dubuqContactsShareModel);

                /*ViewGroup.LayoutParams lp = itemView.getLayoutParams();

                if (lp instanceof FlexboxLayoutManager.LayoutParams) {

                    FlexboxLayoutManager.LayoutParams flexboxLp =

                            (FlexboxLayoutManager.LayoutParams) itemView.getLayoutParams();

                    flexboxLp.setFlexGrow(1.0f);
                }*/
            }

        }

        private void loadData(DubuqContactsShareModel dubuqContactsShareModel) throws Exception {
            final Drawable drawable = new BitmapDrawable(Utils.textAsBitmap(dubuqContactsShareModel.getUserName(), context));

            userName.setText(dubuqContactsShareModel.getUserName());

            if (dubuqContactsShareModel.getProfilePicture() != null &&
                    !dubuqContactsShareModel.getProfilePicture().equalsIgnoreCase("")) {

                if (dubuqContactsShareModel.getProfilePicture().contains("storage")
                        || dubuqContactsShareModel.getProfilePicture().contains("cache")) {
                    Glide.with(context).load(dubuqContactsShareModel.getProfilePicture()).into(circleImageView);
                } else {
                    ImageLoader.getInstance().displayImage(dubuqContactsShareModel.getProfilePicture(),
                            circleImageView,
                            new ImageLoadingListener() {
                                @Override
                                public void onLoadingStarted(String imageUri, View view) {
                                    circleImageView.setImageDrawable(drawable);
                                }

                                @Override
                                public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
                                    circleImageView.setImageDrawable(drawable);
                                }

                                @Override
                                public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                                    circleImageView.setImageBitmap(loadedImage);
                                }

                                @Override
                                public void onLoadingCancelled(String imageUri, View view) {
                                    circleImageView.setImageDrawable(drawable);
                                }
                            });
                }

            } else {
                circleImageView.setImageDrawable(drawable);
            }
        }
    }
}
