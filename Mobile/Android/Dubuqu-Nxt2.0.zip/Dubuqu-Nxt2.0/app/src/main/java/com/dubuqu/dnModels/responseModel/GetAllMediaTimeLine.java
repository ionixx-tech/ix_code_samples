package com.dubuqu.dnModels.responseModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Awesome Pojo Generator
 */
public class GetAllMediaTimeLine {


    @SerializedName("timeline_identifier")
    @Expose
    private String timelineIdentifier;

    @SerializedName("like_count")
    @Expose
    private String likeCount;

    @SerializedName("comment_count")
    @Expose
    private String commentCount;

    @SerializedName("created_time")
    @Expose
    private String createdTime;

    @SerializedName("name")
    @Expose
    private String name;

    @SerializedName("type")
    @Expose
    private String type;

    @SerializedName("group_identifier")
    @Expose
    private String groupIdentifier;

    @SerializedName("profile_image")
    @Expose
    private String profileImage;

    @SerializedName("allow_repost")
    @Expose
    private String allowRepost;

    @SerializedName("shared_medias")
    private List<SharedMedias> sharedMedias;

    @SerializedName("user_identifier")
    @Expose
    private String userIdentifier;

    @SerializedName("shared_medias_count")
    @Expose
    private Integer sharedMediaCount;

    @SerializedName("memory_retain")
    @Expose
    private String memoryRetain;

    @SerializedName("promo_media")
    @Expose
    private boolean isPromoVideo;

    public boolean isPromoVideo() {
        return isPromoVideo;
    }

    public String getMemoryRetain() {
        return memoryRetain;
    }

    public void setMemoryRetain(String memoryRetain) {
        this.memoryRetain = memoryRetain;
    }

    public Integer getSharedMediaCount() {
        return sharedMediaCount;
    }

    public void setSharedMediaCount(Integer sharedMediaCount) {
        this.sharedMediaCount = sharedMediaCount;
    }

    public String getTimelineIdentifier() {
        return timelineIdentifier;
    }

    public void setTimelineIdentifier(String timelineIdentifier) {
        this.timelineIdentifier = timelineIdentifier;
    }

    public String getLikeCount() {
        return likeCount;
    }

    public void setLikeCount(String likeCount) {
        this.likeCount = likeCount;
    }

    public String getCommentCount() {
        return commentCount;
    }

    public void setCommentCount(String commentCount) {
        this.commentCount = commentCount;
    }

    public String getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(String createdTime) {
        this.createdTime = createdTime;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getGroupIdentifier() {
        return groupIdentifier;
    }

    public void setGroupIdentifier(String groupIdentifier) {
        this.groupIdentifier = groupIdentifier;
    }

    public String getProfileImage() {
        return profileImage;
    }

    public void setProfileImage(String profileImage) {
        this.profileImage = profileImage;
    }

    public String getAllowRepost() {
        return allowRepost;
    }

    public void setAllowRepost(String allowRepost) {
        this.allowRepost = allowRepost;
    }

    public List<SharedMedias> getSharedMedias() {
        return sharedMedias;
    }

    public void setSharedMedias(List<SharedMedias> sharedMedias) {
        this.sharedMedias = sharedMedias;
    }

    public String getUserIdentifier() {
        return userIdentifier;
    }

    public void setUserIdentifier(String userIdentifier) {
        this.userIdentifier = userIdentifier;
    }
}