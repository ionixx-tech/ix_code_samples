package com.dubuqu.dnMediaCompression.convertor;

import android.content.Context;
import android.util.Log;

import com.dubuqu.dnApplication.AppController;
import com.github.hiteshsondhi88.libffmpeg.FFmpeg;
import com.github.hiteshsondhi88.libffmpeg.FFmpegExecuteResponseHandler;

import java.io.File;

/**
 * Created by Yogaraj subramanian on 16/11/17
 */

public class ReverseVideo {

    private Context context;

    private OnVideoReversedListener onVideoReversedListener;

    private String originalFilePath;

    private FFmpeg ffmpeg;

    public ReverseVideo(Context context, OnVideoReversedListener onVideoReversedListener, String originalFilePath) {
        this.context = context;
        this.onVideoReversedListener = onVideoReversedListener;
        this.originalFilePath = originalFilePath;

        try {
            initialzeFFmeg();
        } catch (Exception e) {
            Log.e(ReverseVideo.class.getName(), e.getMessage());
        }
    }

    private void initialzeFFmeg() throws Exception {

        ffmpeg = AppController.getfFmpeg();
        try {
            convertVideo();
        } catch (Exception e) {
            onVideoReversedListener.onVideoReverFailed(e.getMessage());
        }

    }

    private void convertVideo() throws Exception {
        final String outputFile = context.getCacheDir() + "/" + String.valueOf(System.currentTimeMillis()) + ".mp4";

        String[] commplexComman = new String[]{
                "-y",
                "-i", originalFilePath,
                "-vf", "reverse",
                "-af", "areverse",
                "-vcodec", "libx264",
                "-crf", "8",
                "-preset", "ultrafast",
                outputFile
        };
        ffmpeg.execute(commplexComman, new FFmpegExecuteResponseHandler() {
            @Override
            public void onSuccess(String message) {
                try {
                    onVideoReversedListener.onVideoReversed(outputFile);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onProgress(String message) {
                Log.d(ReverseVideo.class.getName(), message);
            }

            @Override
            public void onFailure(String message) {
                Log.d(ReverseVideo.class.getName(), message);

            }

            @Override
            public void onStart() {
                Log.d(ReverseVideo.class.getName(), "Started.");
            }

            @Override
            public void onFinish() {
                Log.d(ReverseVideo.class.getName(), "Finished.");
            }
        });

    }

    private void deleteOriginalFile() {
        if (originalFilePath != null && !originalFilePath.equalsIgnoreCase(""))
            new File(originalFilePath).deleteOnExit();
    }

    public interface OnVideoReversedListener {

        void onVideoReversed(String filePath);

        void onVideoReverFailed(String errorMessage);
    }
}
