package com.dubuqu.dnViews;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ImageView;

/**
 * Created by ionixx on 7/2/17.
 */
public class DubuquImageView extends android.support.v7.widget.AppCompatImageView {

    private Object tag = null;

    public DubuquImageView(Context context) {
        super(context);
        this.setAdjustViewBounds(true);
        this.setScaleType(ImageView.ScaleType.CENTER_CROP);
    }

    public DubuquImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.setAdjustViewBounds(true);
        this.setScaleType(ImageView.ScaleType.CENTER_CROP);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        setMeasuredDimension(getMeasuredWidth(), getMeasuredWidth());
    }

    /**
     * @see android.widget.ImageView#onAttachedToWindow()
     */
    @Override
    protected void onAttachedToWindow() {

        super.onAttachedToWindow();
    }

    /**
     * @see android.widget.ImageView#onDetachedFromWindow()
     */
    @Override
    protected void onDetachedFromWindow() {
        // This has been detached from Window, so clear the drawable

        Object tag = getTag();
        if (tag != null) {
            this.tag = tag;
        } else {
            // Will cause displayed bitmap wrapper to
            // be 'free-able'
            setImageDrawable(null);
            this.tag = null;
            super.onDetachedFromWindow();
        }


    }







}
