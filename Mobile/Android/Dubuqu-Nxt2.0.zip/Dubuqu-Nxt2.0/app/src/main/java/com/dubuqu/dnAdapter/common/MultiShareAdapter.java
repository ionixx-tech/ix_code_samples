package com.dubuqu.dnAdapter.common;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.dubuqu.R;
import com.dubuqu.dnActivity.MultipleShareActivity;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnModels.commonModel.DubuqContactsShareModel;
import com.dubuqu.dnUtils.Utils;
import com.dubuqu.dnViews.linearStickView.StickyLayoutManager;
import com.dubuqu.dnViews.linearStickView.exposed.StickyHeaderHandler;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * Created by Yogaraj subramanian on 2/11/17
 */

public class MultiShareAdapter extends RecyclerView.Adapter<MultiShareAdapter.MultiShareViewHolder>
        implements StickyHeaderHandler, Filterable {

    private List<DubuqContactsShareModel> dubuquContactSerchModel, dubuqContactsShareModels;

    private Context context;

    private OnuserSelectedListener onuserSelectedListener;

    private int numberOfgroupsselected = 0, numberofDubuquSelected = 0, numberOfContactsSelected = 0;

    private int[] memberCount = null;

    private boolean[] memeberListChecked = new boolean[]{false, false, false};

    private StickyLayoutManager stickyLayoutManager;

    private View socialCircleHeader, dubuqContactHeader, contactHeader;


    public MultiShareAdapter(List<DubuqContactsShareModel> dubuquContactSerchModel,
                             List<DubuqContactsShareModel> dubuqContactsShareModels,
                             Context context,
                             OnuserSelectedListener onuserSelectedListener,
                             int[] meberCount) {
        this.dubuquContactSerchModel = dubuquContactSerchModel;
        this.dubuqContactsShareModels = dubuqContactsShareModels;
        this.context = context;
        this.onuserSelectedListener = onuserSelectedListener;
        this.memberCount = meberCount;
    }

    public void setStickyLayoutManager(StickyLayoutManager stickyLayoutManager) {
        this.stickyLayoutManager = stickyLayoutManager;
    }

    @Override
    public int getItemViewType(int position) {
        return dubuquContactSerchModel.get(position).hashCode();
    }

    @Override
    public long getItemId(int position) {
        return dubuquContactSerchModel.get(position).hashCode();
    }

    @Override
    public List<?> getAdapterData() {
        return dubuquContactSerchModel;
    }

    @Override
    public MultiShareViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.multishare_adapter_viewholder,
                parent, false);
        return new MultiShareViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MultiShareViewHolder holder, int position) {
        try {
            holder.onBind(position);
        } catch (Exception e) {
            if (context instanceof MultipleShareActivity) {
                ((MultipleShareActivity) context).writeCrashReport(
                        MultipleShareActivity.class.getName(),
                        e.getMessage()
                );
            }
        }
    }

    @Override
    public int getItemCount() {
        return dubuquContactSerchModel.size();
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {

                List<DubuqContactsShareModel> dubquContactFilterData = new ArrayList<>();
                if (constraint.length() == 0) {
                    dubquContactFilterData = dubuqContactsShareModels;
                } else {
                    dubquContactFilterData = getFilteredResults(constraint.toString().toLowerCase());
                }
                FilterResults results = new FilterResults();

                results.values = dubquContactFilterData;
                return results;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                dubuquContactSerchModel = (List<DubuqContactsShareModel>) results.values;
                MultiShareAdapter.this.notifyDataSetChanged();
            }
        };
    }

    private List<DubuqContactsShareModel> getFilteredResults(String constraint) {

        List<DubuqContactsShareModel> results = new ArrayList<>();

        for (DubuqContactsShareModel item : dubuqContactsShareModels) {

            if (checkIsNumber(constraint)) {
                if (item.getModileNumber().toLowerCase().contains(constraint)
                        && item.getCategory() != Utils.DUBUQU_CATEGORY.HEADER) {
                    results.add(item);
                }
            } else {
                if (item.getUserName().toLowerCase().contains(constraint)
                        && item.getCategory() != Utils.DUBUQU_CATEGORY.HEADER) {
                    results.add(item);
                }
            }
        }
        return results;
    }

    private boolean checkIsNumber(String constraint) {
        String regex = "\\d+";
        Pattern pattern = Pattern.compile(regex);
        return pattern.matcher(constraint).matches();
    }

    class MultiShareViewHolder extends RecyclerView.ViewHolder {

        TextView headerView, userName, phoneNumber, numberOfCount;

        RelativeLayout rowItemView, rowHeaderView;

        CircleImageView userProfileImage, borderIndicator;

        ImageView userSelectionIndicator;

        Utils.DUBUQU_CATEGORY category = Utils.DUBUQU_CATEGORY.PHONE_CONTACT;

        CheckBox appCompatCheckBox;

        MultiShareViewHolder(View itemView) {
            super(itemView);

            headerView = itemView.findViewById(R.id.header_view);

            userName = itemView.findViewById(R.id.multishare_adapter_user_profile_name);

            rowItemView = itemView.findViewById(R.id.item_view_ll);

            userProfileImage = itemView.findViewById(R.id.multishare_adapter_user_profile_image);

            userSelectionIndicator = itemView.findViewById(R.id.multishare_adapter_user_selected);

            phoneNumber = itemView.findViewById(R.id.multishare_adapter_user_phonenumber);

            borderIndicator = itemView.findViewById(R.id.border_indicator);

            rowHeaderView = itemView.findViewById(R.id.item_view_header);

            numberOfCount = itemView.findViewById(R.id.header_view_member_count);
            appCompatCheckBox = itemView.findViewById(R.id.header_view_select_all);
        }

        void onBind(final int positon) throws Exception {
            final DubuqContactsShareModel dubuqContactsShareModel = dubuquContactSerchModel.get(positon);

            if (dubuqContactsShareModel != null) {
                if (dubuqContactsShareModel.getCategory() == Utils.DUBUQU_CATEGORY.HEADER) {
                    rowHeaderView.setVisibility(View.VISIBLE);
                    rowItemView.setVisibility(View.GONE);
                    headerView.setText(dubuqContactsShareModel.getUserName());
                    switch (dubuqContactsShareModel.getUserName()) {

                        case Constants.OWNGROUPS:

                            socialCircleHeader = rowHeaderView;

                            numberOfCount.setText(String.valueOf(memberCount[0]).concat("\t" +
                                    context.getString(R.string.groups)));
                            category = Utils.DUBUQU_CATEGORY.SOCIAL_GROUP;
                            appCompatCheckBox.setChecked(memeberListChecked[0]);
                            break;

                        case Constants.DUBUQUCONTACTS:

                            dubuqContactHeader = rowHeaderView;

                            numberOfCount.setText(String.valueOf(memberCount[1]).concat("\t" +
                                    context.getString(R.string.contacts)));
                            category = Utils.DUBUQU_CATEGORY.DUBUQU_CONTACT;
                            appCompatCheckBox.setChecked(memeberListChecked[1]);
                            break;
                        case Constants.CONTACTS:

                            contactHeader = rowHeaderView;
                            numberOfCount.setText(String.valueOf(memberCount[2]).concat("\t" +
                                    context.getString(R.string.contacts)));
                            appCompatCheckBox.setChecked(memeberListChecked[2]);
                            break;
                    }

                    appCompatCheckBox.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            boolean isChecked = !checkIfCheckBoxIsSelcted(positon);

                            appCompatCheckBox.setChecked(isChecked);

                            onuserSelectedListener.onSelectAll(isChecked, category);

                            switch (category) {
                                case SOCIAL_GROUP:
                                    numberOfgroupsselected = isChecked ? memberCount[0] : 0;
                                    memeberListChecked[0] = isChecked;
                                    break;
                                case DUBUQU_CONTACT:
                                    numberofDubuquSelected = isChecked ? memberCount[1] : 0;
                                    memeberListChecked[1] = isChecked;
                                    break;
                                case PHONE_CONTACT:
                                    numberOfContactsSelected = isChecked ? memberCount[2] : 0;
                                    memeberListChecked[2] = isChecked;
                                    break;
                            }

                            onuserSelectedListener.onUserSelected(
                                    numberOfContactsSelected + numberofDubuquSelected + numberOfgroupsselected);
                        }
                    });

                } else {
                    rowHeaderView.setVisibility(View.GONE);
                    rowItemView.setVisibility(View.VISIBLE);
                    userName.setText(dubuqContactsShareModel.getUserName());

                    final Drawable drawable = new BitmapDrawable(
                            Utils.textAsBitmap(dubuqContactsShareModel.getUserName(), context));
                    if (dubuqContactsShareModel.getProfilePicture() != null &&
                            !dubuqContactsShareModel.getProfilePicture().equalsIgnoreCase("")) {

                        if (dubuqContactsShareModel.getCategory() == Utils.DUBUQU_CATEGORY.PHONE_CONTACT) {
                            Glide.with(context).load(dubuqContactsShareModel.getProfilePicture()).into(userProfileImage);
                        } else {
                            ImageLoader.getInstance().displayImage(dubuqContactsShareModel.getProfilePicture(),
                                    userProfileImage, new ImageLoadingListener() {
                                        @Override
                                        public void onLoadingStarted(String imageUri, View view) {
                                            userProfileImage.setImageDrawable(drawable);
                                        }

                                        @Override
                                        public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
                                            userProfileImage.setImageDrawable(drawable);
                                        }

                                        @Override
                                        public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                                            userProfileImage.setImageBitmap(loadedImage);
                                        }

                                        @Override
                                        public void onLoadingCancelled(String imageUri, View view) {
                                            userProfileImage.setImageDrawable(drawable);
                                        }
                                    });

                        }

                    } else {
                        userProfileImage.setImageDrawable(drawable);
                    }
                    if (dubuqContactsShareModel.isSelected()) {
                        userSelectionIndicator.setVisibility(View.VISIBLE);
                        borderIndicator.setVisibility(View.VISIBLE);
                    } else {
                        userSelectionIndicator.setVisibility(View.GONE);
                        borderIndicator.setVisibility(View.GONE);
                    }
                    if (dubuqContactsShareModel.getModileNumber() != null &&
                            !dubuqContactsShareModel.getModileNumber().equalsIgnoreCase("")) {
                        phoneNumber.setText(dubuqContactsShareModel.getModileNumber());
                    } else {
                        phoneNumber.setVisibility(View.GONE);
                    }
                    rowItemView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            try {
                                if (dubuqContactsShareModel.isSelected()) {
                                    dubuqContactsShareModel.setSelected(false);

                                  /*  View headerView = getCurrentHeaderView(positon);
                                    if (headerView != null) {
                                        CheckBox checkBox = headerView.findViewById(R.id.header_view_select_all);
                                        checkBox.setChecked(false);
                                    }*/
                                    calulateSelectedUsers(dubuqContactsShareModel, false);
                                } else {
                                    dubuqContactsShareModel.setSelected(true);
                                    calulateSelectedUsers(dubuqContactsShareModel, true);
                                }
                                notifyDataSetChanged();

                            } catch (Exception e) {
                                Log.e("Crash", e.getMessage());
                            }

                        }
                    });
                }
            }
        }

        private View getCurrentHeaderView(int postion) {

            List<Integer> integerList = stickyLayoutManager.getHeaderPositions();

            int currnetPositon = 0;

            if (postion > integerList.get(0) && postion < integerList.get(1)) {
                currnetPositon = integerList.get(0);
            } else if (postion > integerList.get(1) && postion < integerList.get(2)) {
                currnetPositon = integerList.get(1);
            } else {
                currnetPositon = integerList.get(2);
            }

            if (integerList.size() > 0) {

                if (currnetPositon == stickyLayoutManager.getHeaderPositions().get(0)) {
                    memeberListChecked[0] = false;
                }

                if (currnetPositon == stickyLayoutManager.getHeaderPositions().get(1)) {
                    memeberListChecked[1] = false;
                }

                if (currnetPositon == stickyLayoutManager.getHeaderPositions().get(2)) {
                    memeberListChecked[2] = false;
                }

                return stickyLayoutManager.getChildAt(currnetPositon);
            }

            return null;
        }

        private boolean checkIfCheckBoxIsSelcted(int postion) {

            if (memberCount[0] == 0 && memberCount[1] == 0) {
                return memeberListChecked[2];
            } else if (memberCount[0] == 0) {
                return memeberListChecked[1];
            }

            if (postion < memberCount[0]) {
                return memeberListChecked[0];
            } else if (postion > memberCount[0] && postion <= (memberCount[0]+memberCount[1])) {
                return memeberListChecked[1];
            }

            return memeberListChecked[2];
        }

        private void calulateSelectedUsers(DubuqContactsShareModel dubuqContactsShareModel,
                                           boolean isSelcted) {
            View headerView;

            switch (dubuqContactsShareModel.getCategory()) {
                case PHONE_CONTACT:
                    numberOfContactsSelected = isSelcted ? numberOfContactsSelected + 1 : numberOfContactsSelected - 1;
                    headerView = contactHeader;
                    if (numberOfContactsSelected == memberCount[2]) {
                        if (headerView != null) {
                            CheckBox checkBox = headerView.findViewById(R.id.header_view_select_all);
                            checkBox.setChecked(true);
                            memeberListChecked[2] = true;
                        }
                    } else {
                        if (headerView != null) {
                            CheckBox checkBox = headerView.findViewById(R.id.header_view_select_all);
                            checkBox.setChecked(false);
                            memeberListChecked[2] = false;
                        }
                    }
                    break;
                case DUBUQU_CONTACT:
                    numberofDubuquSelected = isSelcted ? numberofDubuquSelected + 1 : numberofDubuquSelected - 1;
                    headerView = dubuqContactHeader;
                    if (numberofDubuquSelected == memberCount[1]) {
                        if (headerView != null) {
                            CheckBox checkBox = headerView.findViewById(R.id.header_view_select_all);
                            checkBox.setChecked(true);
                            memeberListChecked[1] = true;
                        }
                    } else {
                        if (headerView != null) {
                            CheckBox checkBox = headerView.findViewById(R.id.header_view_select_all);
                            checkBox.setChecked(false);
                            memeberListChecked[1] = false;
                        }
                    }
                    break;
                case SOCIAL_GROUP:
                    numberOfgroupsselected = isSelcted ? numberOfgroupsselected + 1 : numberOfgroupsselected - 1;
                    headerView = socialCircleHeader;
                    if (numberOfgroupsselected == memberCount[0]) {
                        if (headerView != null) {
                            CheckBox checkBox = headerView.findViewById(R.id.header_view_select_all);
                            checkBox.setChecked(true);
                            memeberListChecked[0] = true;
                        }
                    } else {
                        if (headerView != null) {
                            CheckBox checkBox = headerView.findViewById(R.id.header_view_select_all);
                            checkBox.setChecked(false);
                            memeberListChecked[0] = false;
                        }
                    }
                    break;
            }

            onuserSelectedListener.onUserSelected(
                    numberOfContactsSelected + numberofDubuquSelected + numberOfgroupsselected);

        }
    }

    public interface OnuserSelectedListener {
        void onUserSelected(int positon);

        void onSelectAll(boolean toSelect, Utils.DUBUQU_CATEGORY dubuqu_category);
    }
}
