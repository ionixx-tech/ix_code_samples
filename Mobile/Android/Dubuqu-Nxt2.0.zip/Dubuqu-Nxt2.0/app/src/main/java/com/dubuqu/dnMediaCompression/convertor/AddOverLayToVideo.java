package com.dubuqu.dnMediaCompression.convertor;

import android.content.Context;
import android.util.Log;

import com.github.hiteshsondhi88.libffmpeg.FFmpeg;
import com.github.hiteshsondhi88.libffmpeg.FFmpegContextProvider;
import com.github.hiteshsondhi88.libffmpeg.FFmpegExecuteResponseHandler;
import com.github.hiteshsondhi88.libffmpeg.FFmpegLoadBinaryResponseHandler;

import java.io.File;

/**
 * Created by Yogaraj subramanian on 17/11/17
 */

public class AddOverLayToVideo {


    Context context;

    String originalFilePath, overlayImage;

    OnAddOverlayListener onAddOverlayListener;

    private FFmpeg ffmpeg;


    public AddOverLayToVideo(Context context, String filePath,
                             String overlayImage,
                             OnAddOverlayListener onAddOverlayListener) {
        this.context = context;
        this.originalFilePath = filePath;
        this.onAddOverlayListener = onAddOverlayListener;
        this.overlayImage = overlayImage;

        try {
            initialzeFFmeg();
        } catch (Exception e) {
            Log.e(AddOverLayToVideo.class.getName(), e.getMessage());
        }
    }

    private void initialzeFFmeg() throws Exception {

        ffmpeg = FFmpeg.getInstance(new FFmpegContextProvider() {
            @Override
            public Context provide() {
                return context;
            }
        });

        ffmpeg.loadBinary(new FFmpegLoadBinaryResponseHandler() {
            @Override
            public void onFailure() {
                onAddOverlayListener.onOverlayAddedFailed("FFmeg Intialization Failed.");
                try {
                    deleteOriginalFile();
                } catch (Exception e) {
                    Log.e(AddOverLayToVideo.class.getName(), e.getMessage());
                }
            }

            @Override
            public void onSuccess() {
                try {
                    convertVideo();
                } catch (Exception e) {
                    onAddOverlayListener.onOverlayAddedFailed(e.getMessage());
                }
            }

            @Override
            public void onStart() {

            }

            @Override
            public void onFinish() {

            }
        });
    }

    private void convertVideo() throws Exception {

        final String outputFile = context.getCacheDir() + "/" + String.valueOf(System.currentTimeMillis()) + ".mp4";
        /*
        * ffmpeg -y -i video.mp4 -i overlay.png
 -filter_complex "[1][0]scale2ref[i][m];[m][i]overlay[v]"
 -map "[v]" -map 0:a? -ac 2 output.mp4
        * */
        String[] cmd = null;

        cmd = new String[]{
                "-y",
                "-i", originalFilePath,
                "-i", overlayImage,
                "-filter_complex", "[1][0]scale2ref[i][m];[m][i]overlay[v]",
                "-map", "[v]",
                "-map", "0:a?",
                "-vcodec", "libx264",
                "-crf", "8",
                "-preset", "ultrafast",
                outputFile};
        ffmpeg.execute(cmd, new FFmpegExecuteResponseHandler() {
            @Override
            public void onSuccess(String message) {
                try {
                    onAddOverlayListener.onOverlayAdded(outputFile);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onProgress(String message) {
                Log.d(AddOverLayToVideo.class.getName(), message);
            }

            @Override
            public void onFailure(String message) {
                Log.d(AddOverLayToVideo.class.getName(), message);

            }

            @Override
            public void onStart() {
                Log.d(ReverseVideo.class.getName(), "Started.");
            }

            @Override
            public void onFinish() {
                Log.d(ReverseVideo.class.getName(), "Finished.");
            }
        });

    }

    private void deleteOriginalFile() {
        if (originalFilePath != null && !originalFilePath.equalsIgnoreCase(""))
            new File(originalFilePath).deleteOnExit();
    }

    public interface OnAddOverlayListener {

        void onOverlayAdded(String imagePath);

        void onOverlayAddedFailed(String message);
    }
}
