package com.dubuqu.dnAdapter.home;

import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.view.PagerAdapter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.drawable.GlideDrawable;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.GlideDrawableImageViewTarget;
import com.bumptech.glide.request.target.Target;
import com.dubuqu.R;
import com.dubuqu.dnActivity.BaseActivity;
import com.dubuqu.dnActivity.LandingActivity;
import com.dubuqu.dnApplication.AppController;
import com.dubuqu.dnCommon.CacheDataSourceFactory;
import com.dubuqu.dnModels.responseModel.SharedMedias;
import com.github.chrisbanes.photoview.PhotoView;
import com.google.android.exoplayer2.DefaultRenderersFactory;
import com.google.android.exoplayer2.ExoPlaybackException;
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.PlaybackParameters;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.Timeline;
import com.google.android.exoplayer2.extractor.DefaultExtractorsFactory;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.LoopingMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.TrackGroupArray;
import com.google.android.exoplayer2.trackselection.AdaptiveTrackSelection;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelection;
import com.google.android.exoplayer2.trackselection.TrackSelectionArray;
import com.google.android.exoplayer2.ui.SimpleExoPlayerView;
import com.google.android.exoplayer2.upstream.DefaultBandwidthMeter;

import java.io.IOException;
import java.util.List;

/**
 * Created by Yogaraj subramanian on 29/11/17
 */

public class HomeDetailViewPagerAdapter extends PagerAdapter {

    Context context;

    private List<SharedMedias> sharedMediases;

    private HomeDetailCallBacks callBacks;

    public SimpleExoPlayer player;

    private final String TAG = HomeDetailViewPagerAdapter.class.getName();

    private static final DefaultBandwidthMeter BANDWIDTH_METER = new DefaultBandwidthMeter();

    public HomeDetailViewPagerAdapter(Context context, List<SharedMedias> sharedMediases, HomeDetailCallBacks callBacks) {
        this.context = context;
        this.sharedMediases = sharedMediases;
        this.callBacks = callBacks;
        initalizExopLayer();
    }


    @Override
    public int getItemPosition(@NonNull Object object) {
        return POSITION_NONE;
    }

    @Override
    public int getCount() {
        return sharedMediases.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        View view = LayoutInflater.from(context).inflate(R.layout.home_detail_view_pager, container, false);

        HomeDetailViewHolder homeDetailViewHolder = new HomeDetailViewHolder(view);

        try {
            homeDetailViewHolder.onBind(position);

            callBacks.onItemViewAdded(position, homeDetailViewHolder);

            if (position % 8 == 0)
                callBacks.startPaginatingResource();

        } catch (Exception e) {
            if (context instanceof BaseActivity) {
                ((BaseActivity) context).writeCrashReport(TAG, e.getMessage());
            }
        }

        container.addView(homeDetailViewHolder.getView());

        return homeDetailViewHolder.getView();
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((View) object);
        try {
            callBacks.onItemViewremoved(position);
        } catch (Exception e) {
            if (context instanceof BaseActivity) {
                ((BaseActivity) context).writeCrashReport(TAG, e.getMessage());
            }
        }
    }

    /**
     * Initalize Exop player so that the the player is ready for playing videos
     */
    private void initalizExopLayer() {

        if (player == null) {
            boolean preferExtensionDecoders = true;
            @DefaultRenderersFactory.ExtensionRendererMode int extensionRendererMode =
                    AppController.useExtensionRenderers()
                            ? DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER
                            : DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF;

            DefaultRenderersFactory renderersFactory = new DefaultRenderersFactory(context,
                    null, extensionRendererMode);

            TrackSelection.Factory adaptiveTrackSelectionFactory =
                    new AdaptiveTrackSelection.Factory(BANDWIDTH_METER);

            DefaultTrackSelector trackSelector = new DefaultTrackSelector(adaptiveTrackSelectionFactory);
            player = ExoPlayerFactory.newSimpleInstance(renderersFactory, trackSelector);

        }
    }

    /**
     * On #ViewPager Scroll state changed the user player should stop if it is playing.
     */
    public void stopVideoPlayBack() {
        if (player != null) {
            player.setPlayWhenReady(false);
            player.stop();
        }
    }

    public void resumePlayer() {
        if (player != null) {
            player.seekTo(0);
            player.setPlayWhenReady(true);
        }
    }

    /**
     * On Activity destroy the player should release the resource and stop.
     * it avoids {@link  NullPointerException} and {@link RuntimeException}
     */
    public void releasePlayer() {
        if (player != null) {
            player.release();
            player = null;
        }
    }

    public class HomeDetailViewHolder {

        ImageView imageView, muteView;

        SharedMedias sharedMedias;

        SimpleExoPlayerView simpleExoPlayerView;

        public PhotoView photoView;

        View view, videoIndicator, progressIndicator;

        int currentPositon = 0;

        public HomeDetailViewHolder(View view) {
            this.view = view;
            this.imageView = this.view.findViewById(R.id.feed_viewpager_image_view);
            this.videoIndicator = this.view.findViewById(R.id.feed_viewpager_video_indicator);

            this.simpleExoPlayerView = this.view.findViewById(R.id.video_view);

            simpleExoPlayerView.setControllerHideOnTouch(true);

            simpleExoPlayerView.setControllerShowTimeoutMs(2000);

            this.simpleExoPlayerView.setVisibility(View.GONE);

            this.muteView = this.view.findViewById(R.id.exo_mute_option);

            this.photoView = this.view.findViewById(R.id.feed_viewpager_photo_view);
            this.photoView.setVisibility(View.GONE);
            this.photoView.setMaximumScale(10);

            this.progressIndicator = this.view.findViewById(R.id.feed_view_pager_progress_indicator);
            this.progressIndicator.setVisibility(View.GONE);
        }

        public View getView() {
            return view;
        }

        void onBind(final int position) {
            currentPositon = position;
            sharedMedias = sharedMediases.get(position);

            if (sharedMedias != null) {

                final String contentType = sharedMedias.getContentType();

                Glide.with(context)
                        .load(sharedMedias.getThumbnailUrl() != null ? sharedMedias.getThumbnailUrl() :
                                sharedMedias.getSignedUrl())
                        .placeholder(context.getResources()
                                .getDrawable(R.drawable.overlay_media))
                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                        .dontAnimate()
                        .dontTransform()
                        .into(imageView);

                if (contentType != null) {
                    if (contentType.contains("video")) {
                        videoIndicator.setVisibility(View.VISIBLE);
                    } else {
                        videoIndicator.setVisibility(View.GONE);
                    }
                }
            }

            /*this works only for simple exoplaer view photo view will not work*/
            this.view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try {
                        callBacks.onItemViewClicked(position);
                    } catch (Exception e) {
                        if (context instanceof LandingActivity) {
                            ((LandingActivity) context).writeCrashReport(TAG, e.getMessage());
                        }
                    }
                }
            });
            /*to over ride the photo view click listner the listenr is initilaized.*/
            this.photoView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try {
                        callBacks.onItemViewClicked(position);
                    } catch (Exception e) {
                        if (context instanceof LandingActivity) {
                            ((LandingActivity) context).writeCrashReport(TAG, e.getMessage());
                        }
                    }
                }
            });
            /*for gif images this listener is initialized*/
            this.imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try {
                        callBacks.onItemViewClicked(position);
                    } catch (Exception e) {
                        if (context instanceof LandingActivity) {
                            ((LandingActivity) context).writeCrashReport(TAG, e.getMessage());
                        }
                    }
                }
            });

            this.muteView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (player != null) {
                        float muteLevel = player.getVolume();

                        if (muteLevel > 0f) {
                            player.setVolume(0f);
                            muteView.setImageDrawable(context.getResources().getDrawable(R.drawable.ic_mute));
                        } else {
                            player.setVolume(10f);
                            muteView.setImageDrawable(context.getResources().getDrawable(R.drawable.ic_mute_off));
                        }
                    }
                }
            });

        }

        /**
         * Displays the original image of the media.
         *
         * @param mediaDetails {@link }
         */
        public void displayOriginalImage(SharedMedias mediaDetails) {

            photoView.setVisibility(View.VISIBLE);

            Glide.with(context)
                    .load(mediaDetails.getSignedUrl())
                    .dontAnimate()
                    .listener(new RequestListener<String, GlideDrawable>() {
                        @Override
                        public boolean onException(Exception e, String model, Target<GlideDrawable> target,
                                                   boolean isFirstResource) {
                            return false;
                        }

                        @Override
                        public boolean onResourceReady(GlideDrawable resource,
                                                       String model, Target<GlideDrawable> target,
                                                       boolean isFromMemoryCache, boolean isFirstResource) {
                            photoView.setVisibility(View.VISIBLE);
                            imageView.setVisibility(View.GONE);
                            return false;
                        }
                    })
                    .into(photoView);
            /*ImageLoader imageLoader = ImageLoader.getInstance();

            File f = imageLoader.getDiskCache().get(mediaDetails.getSignedUrl());

            if (!f.exists()) {
                ImageLoader.getInstance().displayImage(mediaDetails.getSignedUrl(),
                        imageView, new ImageLoadingListener() {
                            @Override
                            public void onLoadingStarted(String imageUri, View view) {
                            }

                            @Override
                            public void onLoadingFailed(String imageUri, View view, FailReason failReason) {

                            }

                            @Override
                            public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                                photoView.setVisibility(View.VISIBLE);
                                imageView.setVisibility(View.GONE);
                                photoView.setImageBitmap(loadedImage);

                            }

                            @Override
                            public void onLoadingCancelled(String imageUri, View view) {

                            }
                        });
            } else {

                imageLoader.displayImage(f.getAbsolutePath(), photoView);
            }*/
        }

        public void displayGifMedia(SharedMedias mediaDetails) {
            photoView.setVisibility(View.GONE);
            imageView.setVisibility(View.VISIBLE);
            GlideDrawableImageViewTarget imageViewTarget = new GlideDrawableImageViewTarget(imageView);
            Glide.with(context).load(mediaDetails.getSignedUrl()).into(imageViewTarget);
        }

        public void playVideo(final SharedMedias mediaDetails) {
            if (player != null) {
                videoIndicator.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        try {
                            callBacks.onItemViewClicked(currentPositon);
                        } catch (Exception e) {
                            if (context instanceof LandingActivity) {
                                ((LandingActivity) context).writeCrashReport(TAG, e.getMessage());
                            }
                        }


                        if (player.getCurrentPosition() > 0) {
                            player.seekTo(0);
                            simpleExoPlayerView.hideController();
                        }
                        simpleExoPlayerView.setVisibility(View.VISIBLE);

                        videoIndicator.setVisibility(View.GONE);

                        imageView.setVisibility(View.GONE);

                        photoView.setVisibility(View.GONE);


                        stopVideoPlayBack();

                        Handler handler = new Handler();

                        MediaSource mediaSource = new ExtractorMediaSource(Uri.parse(mediaDetails.getSignedUrl()),
                                new CacheDataSourceFactory(context, 10 * 1024 * 1024,
                                        5 * 1024 * 1024),
                                new DefaultExtractorsFactory(), handler,
                                new ExtractorMediaSource.EventListener() {
                                    @Override
                                    public void onLoadError(IOException error) {
                                        Log.e(TAG, error.getMessage());
                                    }
                                });


                        player.seekTo(0);
                        player.setPlayWhenReady(true);
                        player.prepare(new LoopingMediaSource(mediaSource));

                        simpleExoPlayerView.setPlayer(player);

                        player.addListener(new Player.EventListener() {
                            @Override
                            public void onTimelineChanged(Timeline timeline, Object manifest) {

                            }

                            @Override
                            public void onTracksChanged(TrackGroupArray trackGroups, TrackSelectionArray trackSelections) {

                            }

                            @Override
                            public void onLoadingChanged(boolean isLoading) {
                                /*if (isLoading) {
                                    progressIndicator.setVisibility(View.VISIBLE);
                                } else {
                                    progressIndicator.setVisibility(View.GONE);
                                }*/
                            }

                            @Override
                            public void onPlayerStateChanged(boolean playWhenReady, int playbackState) {
                                if (playWhenReady && playbackState == Player.STATE_READY) {
                                    videoIndicator.setVisibility(View.GONE);
                                    progressIndicator.setVisibility(View.GONE);
                                    simpleExoPlayerView.hideController();
                                }

                                if (playbackState != Player.STATE_READY && playbackState == Player.STATE_BUFFERING) {
                                    progressIndicator.setVisibility(View.VISIBLE);
                                }

                                if (playbackState == Player.STATE_IDLE) {
                                    progressIndicator.setVisibility(View.VISIBLE);
                                }

                                if (playbackState == Player.STATE_ENDED) {
                                    player.seekTo(0);
                                    player.setPlayWhenReady(true);
                                    simpleExoPlayerView.hideController();
                                }
                            }

                            @Override
                            public void onRepeatModeChanged(int repeatMode) {

                            }

                            @Override
                            public void onPlayerError(ExoPlaybackException error) {

                            }

                            @Override
                            public void onPositionDiscontinuity() {

                            }

                            @Override
                            public void onPlaybackParametersChanged(PlaybackParameters playbackParameters) {

                            }
                        });
                    }
                });
            }
        }
    }

    public interface HomeDetailCallBacks {

        void onItemViewAdded(Integer position, HomeDetailViewHolder homeDetailViewHolder) throws Exception;

        void onItemViewremoved(int position) throws Exception;

        void onItemViewClicked(int postion) throws Exception;

        void startPaginatingResource();

    }
}
