package com.dubuqu.dnModels.commonModel;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ionixx on 16/6/17.
 */

public class ShareServiceModel implements Parcelable {

    List<String> userlist = new ArrayList<>();

    List<String> fileList = new ArrayList<>();

    String uploadId;

    boolean shouldDeleteMedia;

    public ShareServiceModel(List<String> userlist, List<String> fileList) {
        this.userlist = userlist;
        this.fileList = fileList;
    }


    public List<String> getUserlist() {
        return userlist;
    }

    public void setUserlist(List<String> userlist) {
        this.userlist = userlist;
    }

    public List<String> getFileList() {
        return fileList;
    }

    public void setFileList(List<String> fileList) {
        this.fileList = fileList;
    }

    protected ShareServiceModel(Parcel in) {
        userlist = in.createStringArrayList();
        fileList = in.createStringArrayList();
    }

    public String getUploadId() {
        return uploadId;
    }

    public void setUploadId(String uploadId) {
        this.uploadId = uploadId;
    }

    public boolean isShouldDeleteMedia() {
        return shouldDeleteMedia;
    }

    public void setShouldDeleteMedia(boolean shouldDeleteMedia) {
        this.shouldDeleteMedia = shouldDeleteMedia;
    }

    public static final Creator<ShareServiceModel> CREATOR = new Creator<ShareServiceModel>() {
        @Override
        public ShareServiceModel createFromParcel(Parcel in) {
            return new ShareServiceModel(in);
        }

        @Override
        public ShareServiceModel[] newArray(int size) {
            return new ShareServiceModel[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeStringList(userlist);
        parcel.writeStringList(fileList);
    }
}
