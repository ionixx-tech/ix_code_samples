package com.dubuqu.dnViews;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Typeface;
import android.util.AttributeSet;

import com.dubuqu.R;
import com.dubuqu.dnConstants.Constants;

/**
 * Created by Yogaraj subramanian on 8/6/17
 */

public class DubuquTextView extends android.support.v7.widget.AppCompatTextView {

    boolean isBold = false, isHomeFont = false, isShadowReuired = false;

    public DubuquTextView(Context context) {
        super(context);
        this.setTextIsSelectable(false);
        Typeface typeface = Typeface.createFromAsset(context.getResources().getAssets(), Constants.FONT_LIGHT);
        this.setTypeface(typeface);
    }

    public DubuquTextView(Context context, AttributeSet attrs) {
        super(context, attrs);

        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.DubuquTextView);

        this.setTextIsSelectable(false);
        this.isBold = a.getBoolean(R.styleable.DubuquTextView_fontbold, isBold);
        this.isHomeFont = a.getBoolean(R.styleable.DubuquTextView_font_home, isHomeFont);
        this.isShadowReuired = a.getBoolean(R.styleable.DubuquTextView_shaow_required, isShadowReuired);

        if (isHomeFont) {
            Typeface typeface = Typeface.createFromAsset(context.getResources().getAssets(), Constants.FONT_HOME);
            this.setTypeface(typeface);
        } else if (isBold) {
            Typeface typeface = Typeface.createFromAsset(context.getResources().getAssets(), Constants.FONTBOLD);
            this.setTypeface(typeface);
        } else {
            Typeface typeface = Typeface.createFromAsset(context.getResources().getAssets(), Constants.FONT_LIGHT);
            this.setTypeface(typeface);
        }

        if (isShadowReuired) {
            this.setShadowLayer(5, -1, -1, Color.BLACK);
        }
        a.recycle();
    }

    public DubuquTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.setTextIsSelectable(false);
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.DubuquTextView);

        this.isBold = a.getBoolean(R.styleable.DubuquTextView_fontbold, isBold);
        this.isHomeFont = a.getBoolean(R.styleable.DubuquTextView_font_home, isHomeFont);
        this.isHomeFont = a.getBoolean(R.styleable.DubuquTextView_font_home, isHomeFont);
        this.isShadowReuired = a.getBoolean(R.styleable.DubuquTextView_shaow_required, isShadowReuired);
        if (isHomeFont) {
            Typeface typeface = Typeface.createFromAsset(context.getResources().getAssets(), Constants.FONT_HOME);
            this.setTypeface(typeface);
        } else if (isBold) {
            Typeface typeface = Typeface.createFromAsset(context.getResources().getAssets(), Constants.FONT_LIGHT);
            this.setTypeface(typeface);
        } else {
            Typeface typeface = Typeface.createFromAsset(context.getResources().getAssets(), Constants.FONTBOLD);
            this.setTypeface(typeface);
        }
        if (isShadowReuired) {
            this.setShadowLayer(5, -1, -1, Color.BLACK);
        }
        a.recycle();
    }
}
