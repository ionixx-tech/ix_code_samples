package com.dubuqu.dnMediaCompression.convertor;

import android.content.Context;
import android.os.Environment;
import android.util.Log;

import com.dubuqu.dnUtils.Utils;
import com.github.hiteshsondhi88.libffmpeg.FFmpeg;
import com.github.hiteshsondhi88.libffmpeg.FFmpegContextProvider;
import com.github.hiteshsondhi88.libffmpeg.FFmpegExecuteResponseHandler;
import com.github.hiteshsondhi88.libffmpeg.FFmpegLoadBinaryResponseHandler;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by Yogaraj subramanian on 15/11/17
 */

public class ConvertImageToVideo {

    private Context context;

    private List<String> filePaths;

    private OnPictureConvertedListener pictureConvertedListener;

    private FFmpeg ffmpeg;


    public ConvertImageToVideo(Context context, List<String> filePaths, OnPictureConvertedListener pictureConvertedListener) {
        this.context = context;
        this.filePaths = filePaths;
        this.pictureConvertedListener = pictureConvertedListener;
    }

    public void initializeFFmeg() throws Exception {

        ffmpeg = FFmpeg.getInstance(new FFmpegContextProvider() {
            @Override
            public Context provide() {
                return context;
            }
        });


        ffmpeg.loadBinary(new FFmpegLoadBinaryResponseHandler() {
            @Override
            public void onFailure() {
                pictureConvertedListener.onVideoCreationFailed("FFmeg Intialization Failed.");
                try {
                    deleteCapturedImages();
                } catch (Exception e) {
                    Log.e(ConvertImageToVideo.class.getName(), e.getMessage());
                }
            }

            @Override
            public void onSuccess() {
                try {
                    convertVideo();
                } catch (Exception e) {
                    pictureConvertedListener.onVideoCreationFailed(e.getMessage());
                }
            }

            @Override
            public void onStart() {

            }

            @Override
            public void onFinish() {

            }
        });
    }

    private void convertVideo() throws Exception {

        String preCommand = "-f,concat,-safe,0,-i,";

        String inputFileValue = getInputFilePaths();

        String outputCommand = ",-c:v,libx264,-r,10.315,-vsync,vfr,-pix_fmt,yuv420p,-preset,ultrafast,";

        final String outPutFile = context.getCacheDir() + "/" + String.valueOf(System.currentTimeMillis()) + ".mp4";


        ffmpeg.execute(Utils.utilConvertToComplex(preCommand + inputFileValue + outputCommand + outPutFile), new FFmpegExecuteResponseHandler() {
            @Override
            public void onSuccess(String message) {

                try {
                    reverseVideo();
                } catch (Exception e) {
                    Log.d(ConvertImageToVideo.class.getName(), message);
                }
            }

            @Override
            public void onProgress(String message) {
                Log.d(ConvertImageToVideo.class.getName(), message);
            }

            @Override
            public void onFailure(String message) {
                Log.d(ConvertImageToVideo.class.getName(), message);

            }

            @Override
            public void onStart() {
                Log.d(ConvertImageToVideo.class.getName(), "Started.");
            }

            @Override
            public void onFinish() {
                Log.d(ConvertImageToVideo.class.getName(), "Finised");
            }
        });

    }


    private void reverseVideo() throws Exception {

        Collections.reverse(filePaths);

        String preCommand = "-f,concat,-safe,0,-i,";

        String inputFileValue = getInputFilePaths();

        String outputCommand = ",-c:v,libx264,-r,10.315,-vsync,vfr,-pix_fmt,yuv420p,-preset,ultrafast,";

        final String outPutFile = context.getCacheDir() + "/" + String.valueOf(System.currentTimeMillis()) + ".mp4";


        ffmpeg.execute(Utils.utilConvertToComplex(preCommand + inputFileValue + outputCommand + outPutFile), new FFmpegExecuteResponseHandler() {
            @Override
            public void onSuccess(String message) {
                try {
                    pictureConvertedListener.onVideoCreated(outPutFile);
                    deleteCapturedImages();
                } catch (Exception e) {
                    Log.d(ConvertImageToVideo.class.getName(), message);
                }
            }

            @Override
            public void onProgress(String message) {
                Log.d(ConvertImageToVideo.class.getName(), message);
            }

            @Override
            public void onFailure(String message) {
                Log.d(ConvertImageToVideo.class.getName(), message);

            }

            @Override
            public void onStart() {
                Log.d(ConvertImageToVideo.class.getName(), "Started.");
            }

            @Override
            public void onFinish() {
                Log.d(ConvertImageToVideo.class.getName(), "Finised");
            }
        });
    }

    /**
     * file '/path/to/dog.png'
     * duration 5
     * file '/path/to/cat.png'
     * duration 1
     * file '/path/to/rat.png'
     * duration 3
     * file '/path/to/tapeworm.png'
     * duration 2
     * file '/path/to/tapeworm.png'
     */

    private String getInputFilePaths() throws Exception {

        File file = new File(Environment.getExternalStorageDirectory() + "/" + "filepaths.txt");

        String fileName = "file\t";


        String output = "";
        for (String filePath : filePaths) {
            output = output.concat(fileName.concat(filePath).concat("\n"));
        }

        FileOutputStream fos = new FileOutputStream(file.getAbsolutePath());
        fos.write(output.getBytes());
        fos.flush();
        fos.close();
        return file.getPath();
    }

    /**
     * @param vkLog the log data send form ffmeg console
     * @return the path of the output file
     */
    private static String getOutPutPath(String vkLog) throws Exception {
        String outPutFile = null;

        int firstDubStringIndex = vkLog.indexOf("Output #0,");

        if (firstDubStringIndex != -1) {
            String subStringInput_0 = vkLog.substring(firstDubStringIndex);
            int indexOfColon = subStringInput_0.indexOf(":");
            if (indexOfColon != -1) {
                String inputString = subStringInput_0.substring(0, indexOfColon);
                Pattern p = Pattern.compile("\'([^\']*)\'");
                Matcher m = p.matcher(inputString);
                while (m.find()) {
                    outPutFile = m.group(1);
                }

            }
        }

        return outPutFile;
    }

    private void deleteCapturedImages() throws Exception {

        if (filePaths != null && filePaths.size() > 0) {

            for (String files : filePaths)
                new File(files).deleteOnExit();
        }
    }

    public interface OnPictureConvertedListener {
        void onVideoCreated(String filePath);

        void onVideoCreationFailed(String errorMessage);
    }
}
