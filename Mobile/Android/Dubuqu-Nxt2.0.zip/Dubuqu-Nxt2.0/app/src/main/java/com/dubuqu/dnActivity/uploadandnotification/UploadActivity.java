package com.dubuqu.dnActivity.uploadandnotification;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.WindowManager;

import com.dubuqu.R;
import com.dubuqu.dnActivity.BaseActivity;
import com.dubuqu.dnAdapter.uploadandnotification.UploadListAdapter;
import com.dubuqu.dnAdapter.uploadandnotification.UploadViewPagerAdapter;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnStorage.DbHelper;
import com.dubuqu.dnStorage.upload.UploadDbModel;
import com.dubuqu.dnUtils.Utils;
import com.shuhart.bubblepagerindicator.BubblePageIndicator;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Yogaraj subramanian on 15/12/17
 */

public class UploadActivity extends BaseActivity  {

    final String TAG = UploadActivity.class.getName();

    DbHelper dbHelper;

    UploadListAdapter uploadAdapter;

    RecyclerView recyclerView;

    String currentUploadIdentifier;

    List<UploadDbModel> uploadDbModelList = new ArrayList<>();

    ViewPager viewPager;

    UploadViewPagerAdapter uploadViewPagerAdapter;

    BubblePageIndicator bubblePageIndicator;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload);
        try {
            currentUploadIdentifier = getIntent().getStringExtra(Constants.UPLOADIDENTIFIER);

            initializeViews();

        } catch (Exception e) {
            writeCrashReport(e.getMessage());
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        try {
            registerReceiver(uploadReceiver, new IntentFilter(Constants.UPLOAD_RECEIVER));

            registerReceiver(broadcastReceiver, new IntentFilter(Constants.UPLOAD_LIST_RECEIVER));

            if (Constants.RESTRICT_SREENSHOT)
                getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        } catch (Exception e) {
            writeCrashReport(e.getMessage());
        }

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            unregisterReceiver(uploadReceiver);

            unregisterReceiver(broadcastReceiver);

        } catch (Exception e) {
            writeCrashReport(e.getMessage());
        }
    }

    private void initializeViews() throws Exception {

        dbHelper = new DbHelper(UploadActivity.this);

        recyclerView = findViewById(R.id.upload_list);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(UploadActivity.this);
        recyclerView.setLayoutManager(linearLayoutManager);
        uploadAdapter = new UploadListAdapter(UploadActivity.this, uploadDbModelList);
        recyclerView.setAdapter(uploadAdapter);

        viewPager = findViewById(R.id.upload_view_pager);
        uploadViewPagerAdapter = new UploadViewPagerAdapter(uploadDbModelList, UploadActivity.this);
        viewPager.setAdapter(uploadViewPagerAdapter);

        bubblePageIndicator = findViewById(R.id.bubble_indicator);

        DbHelper dbHelper = new DbHelper(UploadActivity.this);

        List<UploadDbModel> uploadDbModels = dbHelper.fetchDataAgainstIdentifier(currentUploadIdentifier);

        if (uploadDbModels != null && uploadDbModels.size() > 0) {
            uploadDbModelList.addAll(uploadDbModels);
            uploadAdapter.notifyDataSetChanged();
            uploadViewPagerAdapter.notifyDataSetChanged();
            bubblePageIndicator.setViewPager(viewPager, uploadViewPagerAdapter);
        }

        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }


    private void fetchUploadData() {
        try {
            DbHelper dbHelper = new DbHelper(UploadActivity.this);
            List<UploadDbModel> uploadDbModels = dbHelper.fetchDataAgainstIdentifier(currentUploadIdentifier);
            if (uploadDbModels != null && uploadDbModels.size() > 0) {

                if (uploadDbModelList.size() > 0)
                    uploadDbModelList.clear();
                uploadDbModelList.addAll(uploadDbModels);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        uploadAdapter.notifyDataSetChanged();
                    }
                });
            }
        } catch (Exception e) {
            writeCrashReport(e.getMessage());
        }
    }

    private void writeCrashReport(String message) {
        super.writeCrashReport(TAG, message);
    }

    BroadcastReceiver uploadReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            fetchUploadData();
        }
    };


    BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            try {

                int uploadId = intent.getIntExtra(Constants.ID, 0);

                String status = intent.getStringExtra(Constants.EXTRASTRINGS);

                if (Utils.isVaildString(status))
                    updateUploadData(uploadId, status);
                else
                    writeCrashReport("Invalid ID");

            } catch (Exception e) {
                writeCrashReport(e.getMessage());
            }
        }
    };

    private void updateUploadData(int uploadIdentifier, String status) {
        for (UploadDbModel uploadDbModel : uploadDbModelList) {

            if (uploadDbModel.getId() == uploadIdentifier) {

                int indexPostion = uploadDbModelList.indexOf(uploadDbModel);

                uploadDbModel.setUploadProgress(status);

                uploadDbModelList.set(indexPostion, uploadDbModel);

                uploadAdapter.notifyItemChanged(indexPostion);

                break;
            }
        }
    }

}
