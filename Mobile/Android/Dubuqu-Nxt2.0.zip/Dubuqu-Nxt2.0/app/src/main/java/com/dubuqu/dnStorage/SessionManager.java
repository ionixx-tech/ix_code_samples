package com.dubuqu.dnStorage;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.util.Log;

import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnUtils.Utils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.HashMap;

/**
 * Created by Yogaraj subramanian on 23/10/17
 */

public class SessionManager {

    // Shared Preferences
    SharedPreferences pref, oneSignalPref;

    // Editor for Shared preferences
    SharedPreferences.Editor editor;

    // Context
    Context _context;

    // Shared pref mode
    int PRIVATE_MODE = 0;

    // Sharedpref file name
    private static final String PREF_NAME = "DUBUQU";

    private static final String ONE_SIGNAL_PREF_NAME = "OneSignal";

    // PUSHY TOKEN Shared Preferences Keys
    private static final String PUSHY_TOKEN = "notification_token";

    private static final String ONESIGNALTOKEN = "onesignal_token";

    // Notification Settings Shared Preferences Keys
    private static final String NEW_MESSAGE_NOTIFICATION = "NEW_MESSAGE_NOTIFICATION";
    private static final String NOTIFICATION_TONE = "NOTIFICATION_TONE";
    private static final String NOTIFICATION_VIBRATE = "NOTIFICATION_VIBRATE";


    // DATE TIME STAMP Settings Shared Preferences Keys
    private static final String DATE_TIME_STAMP = "DATE_TIME_STAMP";
    private static final String DATE_TIME_STAMP_POSITION = "DATE_TIME_STAMP_POSITION";

    // COLLAGE Settings Shared Preferences Keys
    private static final String COLLAGE = "COLLAGE";

    // VOICE STICKERS Settings Shared Preferences Keys
    private static final String VOICE_STICKERS = "VOICE_STICKERS";

    // MUTE Settings Shared Preferences Keys
    private static final String MUTE = "MUTE";

    private static final String USER_MEMORY_RETAIN = "memoryretain";

    private static final String FIRSTLOGIN = "FIRSTLOGIN";

    private static final String ISQUICKSHAREALLOWED = "isquickshareallowd";

    private static final String COUNTRYCODE = "country_code";

    private static final String ISINTROCOMPLETE = "isIntrocomplete";

    private static final String ISCAMERAINTROCOMPLETED = "isCameraIntrocomplete";

    private static final String ISCAMERASHORTCUTCRETED = "isCameraShortCutCreated";


    private static final String ISEDITPROFILECOMPLETED = "isEditProfileCompleted";

    private static final String ISPROILEINTROCOMPLETED = "isprofileintrocomplted";

    private static final String ISHOMEINTROCOMPLETED = "isHomeintrocomplted";


    private static final String ISQUICKSHARECOMPLETED = "isQuickShareCompleted";

    private static final String ISSOCIALGROUPCOMPLETED = "isSocialCircleCompleted";

    private static final String ISIVITECOMPLETED = "IsInviteCompleted";


    private static final String BADGECOUNT = "badgecount";

    // Constructor
    public SessionManager(Context context) {
        this._context = context;

        pref = _context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);

        oneSignalPref = _context.getSharedPreferences(ONE_SIGNAL_PREF_NAME, PRIVATE_MODE);

        editor = pref.edit();
    }

    public void setCountrycode(String countrycode) {
        editor.putString(COUNTRYCODE, countrycode);
        editor.commit();
    }

    public String getCountryCode() {
        String token = pref.getString(COUNTRYCODE, null);
        return token;
    }

    public void setNotificationToken(String token) {
        editor.putString(PUSHY_TOKEN, token);
        editor.commit();
    }

    public void setOnesignaltoken(String token) {
        editor.putString(ONESIGNALTOKEN, token);
        editor.commit();
    }

    public String getNotificationToken() {
        String token = pref.getString(PUSHY_TOKEN, null);
        return token;
    }

    public String getOneSignaleToken() {
        String token = pref.getString(ONESIGNALTOKEN, null);
        return token;
    }

    public String getOneSingalAppToken() {
        return oneSignalPref.getString("GT_PLAYER_ID", "");
    }

    public boolean getIsProfileIntrocomplted() {
        return pref.getBoolean(ISPROILEINTROCOMPLETED, false);
    }

    public void setIsproileintrocompleted() {
        editor.putBoolean(ISPROILEINTROCOMPLETED, true);
        editor.commit();
    }

    public boolean getIsEditProfileIntroComplted() {
        return pref.getBoolean(ISEDITPROFILECOMPLETED, false);
    }


    public void setIsHomeintrocompleted() {
        editor.putBoolean(ISHOMEINTROCOMPLETED, true);
        editor.commit();
    }

    public boolean getIsHomeIntroComplted() {
        return pref.getBoolean(ISHOMEINTROCOMPLETED, false);
    }

    public void setIsEditProfileIntroComplted() {
        editor.putBoolean(ISEDITPROFILECOMPLETED, true);
        editor.commit();
    }


    public String getISQUICKSHAREALLOWED() {
        String firstLogin = pref.getString(ISQUICKSHAREALLOWED, null);
        return firstLogin;
    }

    public void setUserMemoryRetain(String userMemoryRetain) {
        editor.putString(USER_MEMORY_RETAIN, userMemoryRetain);
        editor.commit();
    }

    public String getUserMemoryRetain() {
        String token = pref.getString(USER_MEMORY_RETAIN, null);
        return token;
    }

    public void setIsquickshareallowed(String isquickshareallowed) {
        editor.putString(ISQUICKSHAREALLOWED, isquickshareallowed);
        editor.commit();
    }

    public void setFirstlogin(String firstlogin) {
        editor.putString(FIRSTLOGIN, firstlogin);
        editor.commit();
    }

    public String getFirstlogin() {
        String firstLogin = pref.getString(FIRSTLOGIN, null);
        return firstLogin;
    }


    //NEW_MESSAGE_NOTIFICATION settings sessions
    public void setNewMessageNotification(boolean isEnable) {
        editor.putBoolean(NEW_MESSAGE_NOTIFICATION, isEnable);
        editor.commit();
    }

    public boolean getNewMessageNotification() {
        return pref.getBoolean(NEW_MESSAGE_NOTIFICATION, true);
    }

    //NOTIFICATION_TONE settings sessions
    public void setNotificationTone(String notificationTone) {
        editor.putString(NOTIFICATION_TONE, notificationTone);
        editor.commit();
    }

    public String getNotificationTone() {
        return pref.getString(NOTIFICATION_TONE, "false");
    }

    //NOTIFICATION_VIBRATE settings sessions
    public void setNotificationVibrate(boolean isEnable) {
        editor.putBoolean(NOTIFICATION_VIBRATE, isEnable);
        editor.commit();
    }

    public boolean getNotificationVibrate() {
        boolean isEnable = pref.getBoolean(NOTIFICATION_VIBRATE, true);
        return isEnable;
    }


    //DATE_TIME_STAMP settings sessions
    public void setDateTimeStamp(boolean isEnable) {
        editor.putBoolean(DATE_TIME_STAMP, isEnable);
        editor.commit();
    }

    public boolean getDateTimeStamp() {
        boolean isEnable = pref.getBoolean(DATE_TIME_STAMP, true);
        return isEnable;
    }

    //DATE_TIME_STAMP_POSITION settings sessions
    public void setDateTimeStampPosition(boolean isEnable) {
        editor.putBoolean(DATE_TIME_STAMP_POSITION, isEnable);
        editor.commit();
    }

    public boolean getDateTimeStampPosition() {
        boolean isEnable = pref.getBoolean(DATE_TIME_STAMP_POSITION, true);
        return isEnable;
    }

    //COLLAGE settings sessions
    public void setCollage(boolean isEnable) {
        editor.putBoolean(COLLAGE, isEnable);
        editor.commit();
    }

    public boolean getCollage() {
        boolean isEnable = pref.getBoolean(COLLAGE, true);
        return isEnable;
    }

    //VOICE_STICKERS settings sessions
    public void setVoiceStickers(boolean isEnable) {
        editor.putBoolean(VOICE_STICKERS, isEnable);
        editor.commit();
    }

    public boolean getVoiceStickers() {
        boolean isEnable = pref.getBoolean(VOICE_STICKERS, true);
        return isEnable;
    }

    //MUTE settings sessions
    public void setMute(boolean isEnable) {
        editor.putBoolean(MUTE, isEnable);
        editor.commit();
    }

    public boolean getMute() {
        boolean isEnable = pref.getBoolean(MUTE, true);
        return isEnable;
    }

    public void setIsintrocomplete(boolean isEnable) {
        editor.putBoolean(ISINTROCOMPLETE, isEnable);
        editor.commit();
    }

    public boolean getIsintroCompleted() {
        boolean isEnable = pref.getBoolean(ISINTROCOMPLETE, false);
        return isEnable;
    }

    public void setIscameraintrocompleted(boolean isEnable) {
        editor.putBoolean(ISCAMERAINTROCOMPLETED, isEnable);
        editor.commit();
    }

    public boolean getIsCameraIntroCompleted() {
        boolean isEnable = pref.getBoolean(ISCAMERAINTROCOMPLETED, false);
        return isEnable;
    }

    public void setIsquicksharecompleted() {
        editor.putBoolean(ISQUICKSHARECOMPLETED, true);
        editor.commit();
    }

    public boolean getIsQuickShareCompleted() {
        boolean isEnable = pref.getBoolean(ISQUICKSHARECOMPLETED, false);
        return isEnable;
    }

    public void setIsSocailGroupCompleted() {
        editor.putBoolean(ISSOCIALGROUPCOMPLETED, true);
        editor.commit();
    }

    public boolean getIsSocialGroupCompleted() {
        boolean isEnable = pref.getBoolean(ISSOCIALGROUPCOMPLETED, false);
        return isEnable;
    }


    /**
     * stroe user details in apps value for one time login session
     *
     * @param userIdentifier unique identifier of the user
     * @param name           user name
     * @param phone          user phone_registration_phone number
     * @param email          user email id
     * @param secrectKey     secrect key to generate hmac
     * @param gender         gender of the user
     * @throws Exception Runtime stub Exception
     */
    public void createLoginSession(String userIdentifier, String name, String phone, String email,
                                   String secrectKey, String gender, String profileUri) throws Exception {


        editor.putBoolean(Constants.DUBUQU_LOGIN_STATUS, true);

        editor.putString(Constants.DUBUQU_USER_NAME, name);
        editor.putString(Constants.DUBUQU_USER_PHONE, phone);
        editor.putString(Constants.DUBUQU_USER_EMAIL, email);
        editor.putString(Constants.DUBUQU_USER_IDENTIFIER, userIdentifier);
        editor.putString(Constants.SECRECT_KEY, secrectKey);
        editor.putString(Constants.DUBUQU_USER_GENDER, gender);
        editor.putString(Constants.ISFIRSTLOGIN, "true");
        if (profileUri != null)
            editor.putString(Constants.PROFILE_IMAGE, profileUri);
        else
            editor.putString(Constants.PROFILE_IMAGE, "");

        editor.commit();

        boolean b = pref.getBoolean(Constants.DUBUQU_LOGIN_STATUS, false);

        registrationCompleted(true);

    }

    public void registrationCompleted(Boolean completed) throws Exception {
        editor.putBoolean("completed", completed);
        editor.commit();
    }


    public static void setFirstLogin(String isFirstLogin, Context context) {
        SharedPreferences mPreference = context.getSharedPreferences(Constants.DUBUQU_LOGIN_DATA_SHARED_PREFERANCE, 0);
        SharedPreferences.Editor editor = mPreference.edit();
        editor.putString(Constants.ISFIRSTLOGIN, "true");
        editor.apply();
    }

    public static String getIsFirstLogin(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(Constants.ISFIRSTLOGIN, 0);
        return sharedPreferences.getString(Constants.ISFIRSTLOGIN, "");
    }


    public void saveUserImage(Context _context, String userIdentifier, String photo, Bitmap largePhoto) throws Exception {

        if (!photo.equals("")) {
            saveProfilePicAsJPG(base64ToBitmap(photo), userIdentifier, _context, true);
            saveProfilePicAsJPG(largePhoto, userIdentifier + "_large", _context, false);
        }

    }

    public HashMap<String, String> getSecrectAndUserIdentifier(Context context) throws Exception {

        HashMap<String, String> values = new HashMap<>();
        values.put(Constants.DUBUQU_USER_IDENTIFIER, pref.getString(Constants.DUBUQU_USER_IDENTIFIER, ""));
        values.put(Constants.SECRECT_KEY, pref.getString(Constants.SECRECT_KEY, ""));
        values.put(Constants.ISFIRSTLOGIN, pref.getString(Constants.ISFIRSTLOGIN, ""));
        return values;
    }

    public void updateUserDetilas(String name,
                                  String email) throws Exception {
        editor.putString(Constants.DUBUQU_USER_NAME, name);
        editor.putString(Constants.DUBUQU_USER_EMAIL, email);
        editor.commit();
    }

    public void updateUserProfileImage(String filePath) throws Exception {
        editor.putString(Constants.PROFILE_IMAGE, filePath);
        editor.commit();
    }

    public void saveProfilePicAsJPG(Bitmap P_BitMap, String userIdentifier, Context _context, boolean insert) throws Exception {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        P_BitMap.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        File file = new File(Utils.getRootFolderForProfilePicture(_context) + userIdentifier + "." + Utils.getAppName(_context));
        try {
            file.createNewFile();


            OutputStream out = new FileOutputStream(file, false);
            out.write(bytes.toByteArray());
            out.close();
        } catch (Exception e) {
            Log.e("addProfilePicture: ", " " + e.getMessage());
        }
    }

    public Bitmap base64ToBitmap(String b64) throws Exception {
        byte[] imageAsBytes = Base64.decode(b64.getBytes(), Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(imageAsBytes, 0, imageAsBytes.length);
    }

    public boolean isLoggedIn() throws Exception {
        return pref.getBoolean(Constants.DUBUQU_LOGIN_STATUS, false);
    }

    public void setIsLoggedIn(boolean isLoggedIn) {
        editor.putBoolean(Constants.DUBUQU_LOGIN_STATUS, isLoggedIn);
        editor.commit();
    }

    public void setIscamerashortcutcreted(boolean iscamerashortcutcreted) {
        editor.putBoolean(ISCAMERASHORTCUTCRETED, iscamerashortcutcreted);
        editor.commit();
    }

    public boolean isCameraShortCutCreated() {
        return pref.getBoolean(ISCAMERASHORTCUTCRETED, false);
    }

    public String getUserProfileUri() {
        return pref.getString(Constants.PROFILE_IMAGE, "");
    }

    public String getUserIdentifier() {
        return pref.getString(Constants.USER_IDENTIFIER, "");
    }

    public String getUserName() {
        return pref.getString(Constants.DUBUQU_USER_NAME, "");
    }

    public String getEmailId() {
        return pref.getString(Constants.DUBUQU_USER_EMAIL, "");
    }

    public String getPhoneNumber() {
        return pref.getString(Constants.DUBUQU_USER_PHONE, "");
    }


    public String[] getUserInfo() throws Exception {

        return new String[]{
                pref.getString(Constants.DUBUQU_USER_IDENTIFIER, null),
                pref.getString(Constants.DUBUQU_USER_NAME, null),
                pref.getString(Constants.DUBUQU_USER_EMAIL, null),
                pref.getString(Constants.DUBUQU_USER_PHONE, null),
                pref.getString(Constants.DUBUQU_USER_GENDER, null)
        };
    }


    public int getBadgeCount() {
        return pref.getInt(BADGECOUNT, 0);
    }

    public void setBadgeCount(int badgeCount) {
        editor.putInt(BADGECOUNT, badgeCount);
        editor.commit();
    }

    public boolean getIsInviteUserNotified() {
        return pref.getBoolean(ISIVITECOMPLETED, false);
    }


    public void setIsInviteUserNotified() {
        editor.putBoolean(ISIVITECOMPLETED, true);
        editor.commit();
    }
}
