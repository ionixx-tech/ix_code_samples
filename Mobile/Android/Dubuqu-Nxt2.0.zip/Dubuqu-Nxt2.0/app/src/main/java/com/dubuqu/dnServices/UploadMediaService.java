package com.dubuqu.dnServices;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.util.Log;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.dubuqu.dnCallbacks.Callbacks;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnMediaCompression.ImageCompressor;
import com.dubuqu.dnModels.responseModel.FormAttributes;
import com.dubuqu.dnModels.responseModel.FormInputs;
import com.dubuqu.dnModels.responseModel.Media;
import com.dubuqu.dnModels.responseModel.SignedUrlResponseModel;
import com.dubuqu.dnModels.responseModel.Thumbnail;
import com.dubuqu.dnRestServices.RestServiceController;
import com.dubuqu.dnRestServices.RestServiceProvider;
import com.dubuqu.dnUtils.RestServiceUtils;
import com.dubuqu.dnUtils.Utils;
import com.google.gson.Gson;

import java.io.File;
import java.io.FileOutputStream;

import okhttp3.MediaType;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Retrofit;

import static android.content.ContentValues.TAG;

/**
 * Created by Yogaraj subramanian on 16/6/17
 */

public class UploadMediaService extends JobService {

    String filePath;

    @Override
    public boolean onStartJob(JobParameters jobParameters) {

        String json = jobParameters.getExtras().getString(Constants.UPLOADMEDIA);
        Gson g = new Gson();
        SignedUrlResponseModel myObj = g.fromJson(json, SignedUrlResponseModel.class);
        filePath = jobParameters.getExtras().getString(Constants.FILE_PATH);
        uploadMediaToS3Server(myObj, filePath);

        return false;
    }

    @Override
    public boolean onStopJob(JobParameters jobParameters) {

        return false;
    }

    private void uploadMediaToS3Server(final SignedUrlResponseModel myObj, final String filePath) {


        if (Utils.getMimeType(filePath).contains("png")
                || Utils.getMimeType(filePath).contains("jpeg") || Utils.getMimeType(filePath).contains("jpg")
                || Utils.getMimeType(filePath).contains("Dubuqu")
                || Utils.getMimeType(filePath).contains("image")
                ) {
            new ImageCompressor(new Callbacks.CompressionCallback() {
                @Override
                public void getCompressedFilePath(String SfilePath) {
                    uploadMedia(myObj, SfilePath);
                    uploadImageThumbnail(myObj, filePath);
                }

                @Override
                public void onFailed() {

                }

                @Override
                public void onUpdateProgress(int value) {

                }
            }, getApplicationContext()).execute(filePath);

        } else if (Utils.getMimeType(filePath).contains("audio")) {
            uploadMedia(myObj, filePath);
        } else if (Utils.getMimeType(filePath).contains("gif")) {
            uploadMedia(myObj, filePath);
            uploadImageThumbnail(myObj, filePath);
        }
    }


    private void uploadMedia(SignedUrlResponseModel myObj, final String compressedFile) {
        try {
            Media media = myObj.getMedia();
            FormAttributes formAttributes = media.getFormAttributes();
            FormInputs formInputs = media.getFormInputs();

            Retrofit retrofit = RestServiceUtils.uploadMediaToS3(formAttributes.getAction());
            RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
            RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);

            // create RequestBody instance from file
            final File file = new File(compressedFile);
            RequestBody requestFile =
                    RequestBody.create(
                            MediaType.parse(compressedFile),
                            file
                    );

            Log.d(TAG, "uploadMedia: uploading dash");
            mRetrofitCallBacks.uploadMediaToS3(convertresquestBofy(formInputs.getXAmzCredential()),
                    convertresquestBofy(formInputs.getXAmzAlgorithm()),
                    convertresquestBofy(formInputs.getXAmzDate()),
                    convertresquestBofy(formInputs.getAcl()),
                    convertresquestBofy(formInputs.getPolicy()),
                    convertresquestBofy(formInputs.getXAmzSignature()),
                    convertresquestBofy(formInputs.getKey()),
                    convertresquestBofy(formInputs.getContentType()),
                    requestFile, new RestServiceController.ResponseCallBacks() {
                        @Override
                        public void onResponse(Object o) {

                        }

                        @Override
                        public void onFailure(Object o) {

                        }
                    }, new RestServiceController.CallEvents() {
                        @Override
                        public void onCallCreated(Call<ResponseBody> responseBodyCall) {

                        }
                    }
            );
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void uploadImageThumbnail(final SignedUrlResponseModel signedUrlResponseModel, final String filePath) {
        try {
            AsyncTask.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        Bitmap thumb = Glide.with(getApplicationContext()).load(filePath).asBitmap().diskCacheStrategy(DiskCacheStrategy.NONE).skipMemoryCache(true).into(240, 240).get();

                        File dir = getCacheDir();
                        if (!dir.exists())
                            dir.mkdirs();
                        final File file = new File(dir, "Thumbnails" + signedUrlResponseModel.getThumbnail() + ".jpg");
                        FileOutputStream fOut = new FileOutputStream(file);

                        thumb.compress(Bitmap.CompressFormat.JPEG, 85, fOut);
                        fOut.flush();
                        fOut.close();

                        Thumbnail media = signedUrlResponseModel.getThumbnail();
                        FormAttributes formAttributes = media.getFormAttributes();
                        FormInputs formInputs = media.getFormInputs();

                        Retrofit retrofit = RestServiceUtils.uploadMediaToS3(formAttributes.getAction());
                        RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
                        RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
                        RequestBody requestFile =
                                RequestBody.create(MediaType.parse(file.getAbsolutePath()), file);

                        Log.d(TAG, "uploadMedia: uploading thumbnail");
                        mRetrofitCallBacks.uploadMediaToS3(convertresquestBofy(formInputs.getXAmzCredential()),
                                convertresquestBofy(formInputs.getXAmzAlgorithm()),
                                convertresquestBofy(formInputs.getXAmzDate()),
                                convertresquestBofy(formInputs.getAcl()),
                                convertresquestBofy(formInputs.getPolicy()),
                                convertresquestBofy(formInputs.getXAmzSignature()),
                                convertresquestBofy(formInputs.getKey()),
                                convertresquestBofy(formInputs.getContentType()),
                                requestFile, new RestServiceController.ResponseCallBacks() {
                                    @Override
                                    public void onResponse(Object o) {
                                        if (file.exists())
                                            file.delete();
                                    }

                                    @Override
                                    public void onFailure(Object o) {

                                    }
                                }, new RestServiceController.CallEvents() {
                                    @Override
                                    public void onCallCreated(Call<ResponseBody> responseBodyCall) {

                                    }
                                }
                        );
                    } catch (Exception e) {
                        e.getMessage();
                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }


    }


    private RequestBody convertresquestBofy(String text) {
        return RequestBody.create(MediaType.parse("text/plain"), text);
    }

}
