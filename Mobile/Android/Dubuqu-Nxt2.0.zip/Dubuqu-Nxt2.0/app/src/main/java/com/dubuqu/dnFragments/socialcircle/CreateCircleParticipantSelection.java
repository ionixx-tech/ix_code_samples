package com.dubuqu.dnFragments.socialcircle;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.PagerSnapHelper;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SnapHelper;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.dubuqu.R;
import com.dubuqu.dnActivity.LandingActivity;
import com.dubuqu.dnAdapter.group.CreateCircleUserSelectadapter;
import com.dubuqu.dnAdapter.group.UserSelectedAdapter;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnModels.commonModel.DubuqContactsShareModel;
import com.dubuqu.dnStorage.SessionManager;
import com.dubuqu.dnUtils.Utils;
import com.dubuqu.dnViews.linearStickView.StickyLayoutManager;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Yogaraj subramanian on 7/11/17
 */

public class CreateCircleParticipantSelection extends Fragment {

    private final String TAG = CreateCircleParticipantSelection.class.getName();

    private View parentView;

    private Activity activity;

    private Fragment parentFragment;

    private RecyclerView selectedUsersRCV;

    private View selectedUserLayout;

    private TextView headerView;

    private CreateCircleUserSelectadapter contactlistAdapter;

    private UserSelectedAdapter userSelectedAdapter;

    private List<DubuqContactsShareModel> dubuqContactsSelected = new ArrayList<>();

    private List<DubuqContactsShareModel> dubuqContactsShareModels = new ArrayList<>();

    private List<DubuqContactsShareModel> addParticipantList = new ArrayList<>();

    private String createCircleData;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_user_selection, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        parentView = view;

        try {
            Bundle bundle = getArguments();
            if (bundle != null) {
                String data = getArguments().getString(Constants.EXTRASTRINGS);

                if (data != null)
                    addParticipantList = new Gson().fromJson(data, new TypeToken<List<DubuqContactsShareModel>>() {
                    }.getType());

                createCircleData = getArguments().getString(Constants.CREATECIRCLEMODELDATAS);
            }
            inializeViews();
        } catch (Exception e) {
            if (activity instanceof LandingActivity) {
                ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();

        try {
            if (((SocialCircleFragment) parentFragment).currentSocialCircleAction != SocialCircleFragment.CurrentSocialCircleAction.EDITCIRCLE) {
                ((SocialCircleFragment) parentFragment).setCurrentSocialCircleAction(SocialCircleFragment.CurrentSocialCircleAction.CREATECIRCLEUSERSELCTION);
                ((SocialCircleFragment) parentFragment).toggleToobarbasedOnOptions();
            } else {
                ((SocialCircleFragment) parentFragment).setCurrentSocialCircleAction(SocialCircleFragment.CurrentSocialCircleAction.EDITCIRCLEADDPARTICIPANT);
                ((SocialCircleFragment) parentFragment).toggleToobarbasedOnOptions();
            }

            if (activity instanceof LandingActivity) {
                try {
                    ((LandingActivity) activity).toggleBottomSheet(true);
                } catch (Exception e) {
                    if (activity instanceof LandingActivity) {
                        ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                    }
                }
            }
            if (getView() != null) {
                getView().setFocusableInTouchMode(true);
                getView().requestFocus();
                getView().setOnKeyListener(new View.OnKeyListener() {
                    @Override
                    public boolean onKey(View v, int keyCode, KeyEvent event) {
                        if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK) {
                            ((SocialCircleFragment) parentFragment).handleSarchView();
                            handleBackpress();
                            return true;
                        }
                        return false;
                    }
                });
            }

        } catch (Exception e) {
            if (activity instanceof LandingActivity) {
                ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
            }
        }
    }

    private void inializeViews() throws Exception {

        parentFragment = getParentFragment();

        activity = getActivity();

        Context context = getContext();

        selectedUsersRCV = parentView.findViewById(R.id.user_selected_rcv);

        RecyclerView contactListRCV = parentView.findViewById(R.id.user_selection_rcv);

        contactlistAdapter = new CreateCircleUserSelectadapter(dubuqContactsShareModels,
                dubuqContactsShareModels,
                context, new CreateCircleUserSelectadapter.OnuserSelectedListener() {

            @Override
            public void onUserSelected(DubuqContactsShareModel dubuqContactsShareModel) {
                try {

                    if (dubuqContactsShareModel.isSelected()) {
                        dubuqContactsSelected.add(dubuqContactsShareModel);
                    } else {
                        int index = dubuqContactsSelected.indexOf(dubuqContactsShareModel);
                        if (index != -1) {
                            dubuqContactsSelected.remove(index);
                        }
                    }
                    updateSelecteduserRcv();

                } catch (Exception e) {
                    if (activity instanceof LandingActivity) {
                        ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                    }
                }
            }
        });

        contactListRCV.setLayoutManager(new StickyLayoutManager(context, contactlistAdapter));

        contactListRCV.setAdapter(contactlistAdapter);

        userSelectedAdapter = new UserSelectedAdapter(dubuqContactsSelected, context, new UserSelectedAdapter.UserSelectedListener() {
            @Override
            public void onUserSelected(DubuqContactsShareModel dubuqContactsShareModel) {

                int index = dubuqContactsShareModels.indexOf(dubuqContactsShareModel);

                if (index != -1) {

                    DubuqContactsShareModel contactsShareModel = dubuqContactsShareModels.get(index);

                    contactsShareModel.setSelected(false);

                    contactlistAdapter.notifyDataSetChanged();
                }

                try {
                    updateSelecteduserRcv();
                } catch (Exception e) {
                    if (activity instanceof LandingActivity) {
                        ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                    }
                }

            }
        }, UserSelectedAdapter.ViewType.USERSELCTION);


        selectedUsersRCV.setLayoutManager(new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false));

        SnapHelper snapHelper = new PagerSnapHelper();
        snapHelper.attachToRecyclerView(selectedUsersRCV);

        selectedUsersRCV.setAdapter(userSelectedAdapter);


        selectedUserLayout = parentView.findViewById(R.id.user_selected_ll);

        selectedUserLayout.setVisibility(View.GONE);

        headerView = parentView.findViewById(R.id.header_view);

        readDetails();

    }


    private void updateSelecteduserRcv() throws Exception {

        if (dubuqContactsSelected.size() == 0) {
            selectedUserLayout.setVisibility(View.GONE);
        } else {
            if (selectedUserLayout.getVisibility() == View.GONE) {
                selectedUserLayout.setVisibility(View.VISIBLE);
            }
            headerView.setText(String.valueOf(dubuqContactsSelected.size()).concat("\t Contacts Selected"));
            selectedUsersRCV.smoothScrollToPosition(dubuqContactsSelected.size() - 1);
            userSelectedAdapter.notifyDataSetChanged();
        }
    }

    /**
     * read phone and group contacts available
     */
    private void readDetails() throws Exception {

        File file = new File(activity.getCacheDir(), Constants.JSONFILENAME);
        FileInputStream fis = new FileInputStream(file.getAbsolutePath());
        InputStreamReader isr = new InputStreamReader(fis);
        BufferedReader bufferedReader = new BufferedReader(isr);
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = bufferedReader.readLine()) != null) {
            sb.append(line);
        }
        Gson gson = new Gson();

        List<DubuqContactsShareModel> dubuqContactsShareModelList = gson.fromJson(sb.toString(),
                new TypeToken<List<DubuqContactsShareModel>>() {
                }.getType());
        updateValues(dubuqContactsShareModelList);

    }


    private void updateValues(List<DubuqContactsShareModel> dubuqContactsShareModelList) throws Exception {

        List<DubuqContactsShareModel> phoneContacts = new ArrayList<>();
        List<DubuqContactsShareModel> dubuquContacts = new ArrayList<>();


        for (DubuqContactsShareModel dubuqContactsShareModel : dubuqContactsShareModelList) {

            switch (dubuqContactsShareModel.getCategory()) {

                case DUBUQU_CONTACT:
                    dubuquContacts.add(dubuqContactsShareModel);
                    break;
                case PHONE_CONTACT:
                    phoneContacts.add(dubuqContactsShareModel);
                    break;

            }
        }

        if (dubuquContacts.size() > 0) {
            DubuqContactsShareModel dubuqContactsShareModel = new DubuqContactsShareModel(Constants.DUBUQUCONTACTS,
                    "", "", "", Utils.DUBUQU_CATEGORY.HEADER);
            dubuqContactsShareModels.add(dubuqContactsShareModel);
            dubuqContactsShareModels.addAll(dubuquContacts);
        }

        if (phoneContacts.size() > 0) {

            DubuqContactsShareModel dubuqContactsShareModel = new DubuqContactsShareModel(Constants.CONTACTS,
                    "", "", "", Utils.DUBUQU_CATEGORY.HEADER);
            dubuqContactsShareModels.add(dubuqContactsShareModel);
            dubuqContactsShareModels.addAll(phoneContacts);
        }
        if (addParticipantList != null && addParticipantList.size() > 0) {

            SessionManager sessionManager = new SessionManager(getContext());

            for (DubuqContactsShareModel dubuqContactsShareModel : dubuqContactsShareModels) {

                if (dubuqContactsShareModel.getCategory() == Utils.DUBUQU_CATEGORY.DUBUQU_CONTACT
                        || dubuqContactsShareModel.getCategory() == Utils.DUBUQU_CATEGORY.PHONE_CONTACT) {

                    for (DubuqContactsShareModel shareModel : addParticipantList) {

                        if (checkIfUserisSame(shareModel, dubuqContactsShareModel)) {

                            if (!shareModel.getModileNumber().contains(sessionManager.getPhoneNumber())){
                                dubuqContactsSelected.add(dubuqContactsShareModel);
                                dubuqContactsShareModel.setSelected(true);
                            }
                        }
                    }
                }

                if (addParticipantList.size() == dubuqContactsSelected.size())
                    break;
            }

            if (createCircleData != null )
                addOwnerToList();

            updateSelecteduserRcv();
        }
    }

    private void addOwnerToList() {
        SessionManager sessionManager = new SessionManager(getContext());

        for (DubuqContactsShareModel shareModel : addParticipantList) {

            if (shareModel.getIdentifier().equalsIgnoreCase(sessionManager.getUserIdentifier())) {
                dubuqContactsSelected.add(shareModel);
                break;
            }
        }
    }

    private boolean checkIfUserisSame(DubuqContactsShareModel shareModel, DubuqContactsShareModel contactsShareModel) {
        return shareModel.getIdentifier().equalsIgnoreCase(contactsShareModel.getIdentifier())
                && shareModel.getModileNumber().equalsIgnoreCase(contactsShareModel.getModileNumber());
    }

    public void saveDetails() throws Exception {
        if (dubuqContactsSelected.size() > 0) {

            if (((SocialCircleFragment) parentFragment).currentSocialCircleAction ==
                    SocialCircleFragment.CurrentSocialCircleAction.EDITCIRCLEADDPARTICIPANT) {
                ((SocialCircleFragment) parentFragment).setCurrentSocialCircleAction(SocialCircleFragment.CurrentSocialCircleAction.EDITCIRCLE);
                ((SocialCircleFragment) parentFragment).toggleToobarbasedOnOptions();
            }


            String data = new Gson().toJson(dubuqContactsSelected);
            Bundle bundle = new Bundle();
            bundle.putString(Constants.EXTRASTRINGS, data);
            if (createCircleData != null) {
                bundle.putString(Constants.CREATECIRCLEMODELDATAS, createCircleData);
            }
            CreateGroup createGroup = new CreateGroup();
            createGroup.setArguments(bundle);
            ((SocialCircleFragment) parentFragment).replaceFragments(createGroup);
        } else {
            ((LandingActivity) activity).showToastMessage("Please select atleast one contact", false);
        }
    }

    /**
     * If user particaption screen is launched from {@link CreateGroup} on back press it need to go
     * to  {@link CreateGroup}
     * <p>
     * Or if from add group on back press it need to go to {@link SocialCircleDashboard}
     * </p>
     */
    protected void handleBackpress() {

        try {
            ((SocialCircleFragment) parentFragment).replaceFragments(new SocialCircleDashboard());
        } catch (Exception e) {
            ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
        }

    }

    public void searchUser(CharSequence text) {
        contactlistAdapter.getFilter().filter(text);
    }
}
