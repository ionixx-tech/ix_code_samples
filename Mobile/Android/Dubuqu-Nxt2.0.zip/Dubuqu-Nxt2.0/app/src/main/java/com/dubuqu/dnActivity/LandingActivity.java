package com.dubuqu.dnActivity;

import android.Manifest;
import android.app.job.JobScheduler;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v4.app.Fragment;
import android.support.v4.util.Pair;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.drawable.GlideDrawable;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.dubuqu.MainActivity;
import com.dubuqu.R;
import com.dubuqu.dnActivity.profile.ProfileActivity;
import com.dubuqu.dnActivity.uploadandnotification.UploadAndNotification;
import com.dubuqu.dnCommon.BottomViewController;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnConstants.UploadConstants;
import com.dubuqu.dnFragments.gallery.GalleryFragment;
import com.dubuqu.dnFragments.home.HomeFragment;
import com.dubuqu.dnFragments.settings.SettingsFragment;
import com.dubuqu.dnFragments.socialcircle.SocialCircleFragment;
import com.dubuqu.dnModels.commonModel.ActionConformationDialog;
import com.dubuqu.dnModels.responseModel.DubuquUserModel;
import com.dubuqu.dnModels.responseModel.UserDetails;
import com.dubuqu.dnReceiver.upload.UploadBroadcastReceiver;
import com.dubuqu.dnRestServices.RestServiceController;
import com.dubuqu.dnRestServices.RestServiceProvider;
import com.dubuqu.dnServices.ContactService;
import com.dubuqu.dnStorage.DbHelper;
import com.dubuqu.dnStorage.SessionManager;
import com.dubuqu.dnStorage.upload.UploadMapModel;
import com.dubuqu.dnUtils.RestServiceUtils;
import com.dubuqu.dnUtils.Utils;
import com.google.gson.Gson;
import com.nostra13.universalimageloader.core.ImageLoader;

import java.io.File;
import java.util.List;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;

/**
 * Created by Yogaraj subramanian on 25/10/17
 */

public class LandingActivity extends BaseActivity implements BottomViewController.OnItemReclickedListener {

    private final String TAG = LandingActivity.class.getName();

    private RelativeLayout toolBar;

    private RelativeLayout bottomViewLayout;

    private TextView toolBarText;

    private ImageView cameraView, notification, toolbarImageView, indicatorView, indicatorWarning, profileImageImv;

    BottomViewController controller;

    UploadBroadcastReceiver uploadBroadcastReceiver = new UploadBroadcastReceiver();

    SessionManager sessionManager;

    boolean isErrorOccured = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            sessionManager = new SessionManager(this);

            checkIfUserIsregisterToOneSignal();

            setContentView(R.layout.landing_activity);

            initializeViews();

            startContactService();

            checkBadgeCount();

        } catch (Exception e) {
            super.writeCrashReport(TAG, e.getMessage());
        }
    }

    /**
     * Start Upload manager if there is any stuck age of medias.
     */
    private void startUploadManagerService() {

        sendBroadcast(new Intent("com.dubuqu.STARTFILESHARE"));

        try {
            DbHelper dbHelper = new DbHelper(this);
            if (dbHelper.checkIfAnyCanceledupload()) {
                sendBroadcast(new Intent(Constants.ONMEDIAUPLOADFAILED));
            }

            JobScheduler jobScheduler = (JobScheduler) getSystemService(Context.JOB_SCHEDULER_SERVICE);
            assert jobScheduler != null;
            if (jobScheduler.getAllPendingJobs().size() == 0) {
                List<UploadMapModel> uploadMapModelList = dbHelper.checkIfRunningProcess();
                if (uploadMapModelList != null && uploadMapModelList.size() > 0) {
                    for (UploadMapModel uploadMapModel : uploadMapModelList)
                        dbHelper.updateProgressStateOfUpload(uploadMapModel.getUploadId(),
                                UploadConstants.UPLOADSTATUS.FAILURE);
                }
            }
        } catch (Exception e) {
            super.writeCrashReport(TAG, e.getMessage());
        }
    }


    /**
     * check if badge is enabled or not.
     */
    private void checkBadgeCount() throws Exception {

        int count = sessionManager.getBadgeCount();
        if (count > 0) {
            sessionManager.setBadgeCount(0);
            Utils.setBadge(this);
            indicatorView.setVisibility(View.VISIBLE);
        }
    }

    private void initializeViews() throws Exception {

        View[] views = new View[]{
                findViewById(R.id.landing_activity_home_imv),
                findViewById(R.id.landing_activity_gallery_imv),
                findViewById(R.id.landing_activity_social_circle_imv),
                findViewById(R.id.landing_activity_settings_imv)
        };

        Fragment[] fragments = new Fragment[]{
                new HomeFragment(),
                new GalleryFragment(),
                new SocialCircleFragment(),
                new SettingsFragment()
        };

        toolBarText = findViewById(R.id.landing_activity_toolbar_textview);
        toolBarText.setVisibility(View.GONE);

        toolbarImageView = findViewById(R.id.landing_activity_toolbar_image_view);

        controller = new BottomViewController.BottomViewBuilder()
                .setContext(LandingActivity.this)
                .setFragment(fragments)
                .setView(views)
                .setFragmentManager(getSupportFragmentManager())
                .setFrameLayout(R.id.landing_activity_framelayout)
                .setOnItemClick(this)
                .build();

        toolBar = findViewById(R.id.landing_activity_toolbar_ll);

        bottomViewLayout = findViewById(R.id.bottom_view_rl);

        profileImageImv = findViewById(R.id.landing_activity_profile_image);

        cameraView = findViewById(R.id.landing_activity_camera_imv);

        controller.highlightSelectedPostion(views[0]);

        notification = findViewById(R.id.notification);

        indicatorView = findViewById(R.id.indicator_view);
        indicatorView.setVisibility(View.GONE);

        indicatorWarning = findViewById(R.id.indicator_view_warning);
        indicatorWarning.setVisibility(View.GONE);

        intializeListeners();

        updateUserProfileImage();

        showHomeIntroTutorial();
    }


    private void intializeListeners() throws Exception {

        profileImageImv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Pair<View, String> p2 = Pair.create(view, "user_profile_pic");

                Pair[] views = new Pair[]{p2};

                ActivityOptionsCompat options = ActivityOptionsCompat.
                        makeSceneTransitionAnimation(LandingActivity.this, views);

                ActivityCompat.startActivity(
                        LandingActivity.this,
                        new Intent(LandingActivity.this, ProfileActivity.class),
                        options.toBundle());

            }
        });
        File saveDir = new File(Environment.getExternalStorageDirectory(), getString(R.string.app_name));
        saveDir.mkdirs();

        cameraView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    checkIfPermissionAdded();
                } catch (Exception e) {
                    writeCrashReport(TAG, e.getMessage());
                }
            }
        });

        notification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LandingActivity.this, UploadAndNotification.class);
                if (isErrorOccured) {
                    indicatorWarning.setVisibility(View.GONE);
                    indicatorView.setVisibility(View.GONE);
                    intent.putExtra(Constants.EXTRASTRINGS, false);
                } else if (indicatorView.getVisibility() == View.VISIBLE) {
                    indicatorView.setVisibility(View.GONE);
                    indicatorWarning.setVisibility(View.GONE);
                    try {
                        controller.refreshHomeFragment();
                    } catch (Exception e) {
                        writeCrashReport(TAG, e.getMessage());
                    }
                }

                startActivity(intent);
            }
        });

    }

    private void updateUserProfileImage() throws Exception {

        SessionManager sessionManager = new SessionManager(this);

        String userName = sessionManager.getUserName();

        final Bitmap bitmap = Utils.textAsBitmap(userName, this);

        profileImageImv.setImageBitmap(bitmap);

        String profileImage = sessionManager.getUserProfileUri();

        if (profileImage != null && !profileImage.equalsIgnoreCase("")) {
            File file = new File(profileImage);
            if (file.exists()) {
                Glide.with(LandingActivity.this).load(file).centerCrop().listener(new RequestListener<File, GlideDrawable>() {
                    @Override
                    public boolean onException(Exception e, File model, Target<GlideDrawable> target, boolean isFirstResource) {
                        try {
                            loadImageFromServer();
                        } catch (Exception e1) {
                            writeCrashReport(TAG, e1.getMessage());
                        }
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(GlideDrawable resource, File model, Target<GlideDrawable> target, boolean isFromMemoryCache, boolean isFirstResource) {
                        profileImageImv.setImageDrawable(resource);
                        return false;
                    }
                }).into(profileImageImv);
            } else {
                loadImageFromServer();
            }
        } else {
            loadImageFromServer();
        }
    }

    private void loadImageFromServer() throws Exception {
        String data = "{}";
        OkHttpClient okHttpClient = null;

        final SessionManager sessionManager = new SessionManager(LandingActivity.this);

        okHttpClient = RestServiceUtils.getHeader(data, LandingActivity.this);
        Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
        RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
        RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
        mRetrofitCallBacks.fetchDubuquUserDetails(
                new RestServiceController.ResponseCallBacks() {
                    @Override
                    public void onResponse(Object o) {
                        if (o != null) {

                            final DubuquUserModel userModel =
                                    (DubuquUserModel) o;

                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {

                                    String profileImaege = userModel.getProfileImage();
                                    if (profileImaege != null && !profileImaege.equalsIgnoreCase("")) {
                                        ImageLoader.getInstance().displayImage(profileImaege, profileImageImv);
                                    }
                                    try {
                                        if (Utils.isVaildString(profileImaege) &&
                                                !Utils.isVaildString(sessionManager.getUserProfileUri()))
                                            sessionManager.updateUserProfileImage(profileImaege);
                                    } catch (Exception e) {
                                        writeCrashReport(TAG, e.getMessage());
                                    }


                                }
                            });
                        }
                    }

                    @Override
                    public void onFailure(Object o) {

                    }
                },
                sessionManager.getUserIdentifier());
    }


    private void startContactService() throws Exception {

        if (super.checkIfPermissionIsGranted(Manifest.permission.READ_CONTACTS)) {
            Intent intent = new Intent(LandingActivity.this, ContactService.class);
            startService(intent);
        } else {
            super.requestPermission(new String[]{Manifest.permission.READ_CONTACTS},
                    new PermissionCallBack() {
                        @Override
                        public void onPermissionGranted() {
                            Intent intent = new Intent(LandingActivity.this, ContactService.class);
                            startService(intent);
                        }

                        @Override
                        public void onPermissionRejected() {
                            try {
                                LandingActivity.super.showToastMessage(getString(R.string.please_provide_permission_to_continue),
                                        false);
                            } catch (Exception e) {
                                LandingActivity.super.writeCrashReport(MainActivity.class.getName(), e.getMessage());
                            }
                        }
                    });
        }
    }

    /*--------------------------------Functions related to Gallery---------------------------------*/

    /**
     * toogle botttom Navigation bar
     * <p>
     * true=> hide ;  false= >show;
     *
     * @param toogleOption whether to hide or show
     * @throws Exception {Runtime Stub Exception}
     */
    public void toggleBottomSheet(boolean toogleOption) throws Exception {
        if (toogleOption) {

            if (bottomViewLayout.getVisibility() == View.VISIBLE) {
                bottomViewLayout.setVisibility(View.GONE);
                cameraView.setVisibility(View.GONE);
            }

            if (toolBar.getVisibility() == View.VISIBLE)
                toolBar.setVisibility(View.GONE);


        } else {

            if (bottomViewLayout.getVisibility() == View.GONE) {
                bottomViewLayout.setVisibility(View.VISIBLE);
                cameraView.setVisibility(View.VISIBLE);
            }
            if (toolBar.getVisibility() == View.GONE) {
                toolBar.setVisibility(View.VISIBLE);

            }
        }
    }

    /**
     * Hide tool bar contents
     *
     * @throws Exception {Runtime Stub Exception}
     */
    public void hidetoolbar() throws Exception {
        toolBar.setVisibility(View.GONE);
    }

    /*show tool bars*/

    public void showToolbar() throws Exception {
        toolBar.setVisibility(View.VISIBLE);
    }

    /*hibe bottom views*/

    public void hideBottomView() throws Exception {

        bottomViewLayout.setVisibility(View.GONE);
    }

    /*show bottom views*/

    public void showBottomView() throws Exception {

        bottomViewLayout.setVisibility(View.VISIBLE);
        cameraView.setVisibility(View.VISIBLE);
    }

    public void setToolBarText(String text) throws Exception {

        toolBarText.setText(text);

        YoYo.with(Techniques.Pulse).duration(500).playOn(toolBarText);

    }


    @Override
    public void onItemClicked(int viewId) {
        switch (viewId) {
            case R.id.landing_activity_home_imv:
                toolbarImageView.setVisibility(View.VISIBLE);
                toolBarText.setVisibility(View.GONE);
                profileImageImv.setVisibility(View.VISIBLE);
                break;
            case R.id.landing_activity_gallery_imv:
                toolbarImageView.setVisibility(View.GONE);
                toolBarText.setVisibility(View.VISIBLE);
                toolBarText.setText(getString(R.string.gallery));
                profileImageImv.setVisibility(View.GONE);
                break;
            case R.id.landing_activity_social_circle_imv:
                break;
            case R.id.landing_activity_settings_imv:
                toolbarImageView.setVisibility(View.GONE);
                toolBarText.setVisibility(View.VISIBLE);
                toolBarText.setText(getString(R.string.settings));
                profileImageImv.setVisibility(View.GONE);
                break;
        }
    }

    @Override
    public void onBackPressed() {
        Fragment currentFragment = getSupportFragmentManager().findFragmentById(R.id.landing_activity_framelayout);

        if (currentFragment != null) {
            if (currentFragment instanceof HomeFragment) {
                super.onBackPressed();
            } else {
                if (currentFragment instanceof SocialCircleFragment) {
                    ((SocialCircleFragment) currentFragment).handleSarchView();
                }
                controller.onClick(findViewById(R.id.landing_activity_home_imv));
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

    }

    @Override
    protected void onResume() {
        super.onResume();

        if (Constants.RESTRICT_SREENSHOT)
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);

        registerReceiver(onNewMediaReceived, new IntentFilter(Constants.ONNOTIFICATIONRECEIVE));

        registerReceiver(broadcastReceiver, new IntentFilter(Constants.ONPROFILEPICCHANGED));

        registerReceiver(uploadBroadcastReceiver, new IntentFilter("com.dubuqu.STARTFILESHARE"));

        registerReceiver(onErrorReceived, new IntentFilter(Constants.ONMEDIAUPLOADFAILED));

        registerReceiver(noDubuquContactAvaialbleReciever, new IntentFilter(Constants.NODUBQUCONTACTAVAILABLEEVENT));

        startUploadManagerService();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(onNewMediaReceived);

        unregisterReceiver(broadcastReceiver);

        unregisterReceiver(uploadBroadcastReceiver);

        unregisterReceiver(onErrorReceived);

        unregisterReceiver(noDubuquContactAvaialbleReciever);
    }

    BroadcastReceiver onNewMediaReceived = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            try {
                if (!isErrorOccured)
                    indicatorView.setVisibility(View.VISIBLE);
            } catch (Exception e) {
                writeCrashReport(TAG, e.getMessage());
            }
        }
    };

    BroadcastReceiver onErrorReceived = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            isErrorOccured = true;

            indicatorWarning.setVisibility(View.VISIBLE);

            indicatorView.setVisibility(View.GONE);
        }
    };

    private void checkIfPermissionAdded() throws Exception {
        if (super.checkIfPermissionIsGranted(Manifest.permission.CAMERA)) {
            if (!super.checkIfPermissionIsGranted(Manifest.permission.RECORD_AUDIO)) {
                super.requestPermission(new String[]{Manifest.permission.RECORD_AUDIO},
                        new PermissionCallBack() {
                            @Override
                            public void onPermissionGranted() {
                                try {

                                } catch (Exception e) {
                                    writeCrashReport(TAG, e.getMessage());
                                }
                            }

                            @Override
                            public void onPermissionRejected() {
                                try {
                                    LandingActivity.super.showToastMessage(
                                            getString(R.string.please_provide_permission_to_continue),
                                            false);
                                } catch (Exception e) {
                                    writeCrashReport(TAG, e.getMessage());
                                }
                            }
                        }
                );
            }
        } else {
            super.requestPermission(
                    new String[]{Manifest.permission.CAMERA}, new PermissionCallBack() {
                        @Override
                        public void onPermissionGranted() {
                            try {
                                checkIfPermissionAdded();
                            } catch (Exception e) {
                                writeCrashReport(TAG, e.getMessage());
                            }
                        }

                        @Override
                        public void onPermissionRejected() {
                            try {
                                LandingActivity.super.showToastMessage(
                                        getString(R.string.please_provide_permission_to_continue),
                                        false);
                            } catch (Exception e) {
                                writeCrashReport(TAG, e.getMessage());
                            }
                        }
                    }
            );
        }
    }



    BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            try {
                updateUserProfileImage();
            } catch (Exception e) {
                writeCrashReport(LandingActivity.class.getName(), e.getMessage());
            }
        }
    };


    public void toogleToGallery() {
        controller.onClick(findViewById(R.id.landing_activity_gallery_imv));
    }

    public void showProfileTutorial() {

        if (!sessionManager.getIsProfileIntrocomplted()) {
            super.showTutorialScreenView(
                    profileImageImv,
                    getString(R.string.intro_my_profile),
                    getString(R.string.intro_my_profile_brief),
                    true,
                    new OnTutorialFinishLisenter() {
                        @Override
                        public void onfinished(boolean isFinished) {
                            sessionManager.setIsproileintrocompleted();
                        }
                    }
            );
        }
    }

    public void showHomeIntroTutorial() {
        if (!sessionManager.getIsHomeIntroComplted()) {
            super.showTutorialScreenView(
                    findViewById(R.id.landing_activity_home_imv),
                    getString(R.string.intro_home),
                    getString(R.string.intro_home_brief),
                    true,
                    new OnTutorialFinishLisenter() {
                        @Override
                        public void onfinished(boolean isFinished) {
                            sessionManager.setIsHomeintrocompleted();
                            showQuickShareIntro();
                        }
                    }
            );
        }
    }

    private void showQuickShareIntro() {

        if (!sessionManager.getIsQuickShareCompleted()) {
            super.showTutorialScreenView(
                    findViewById(R.id.landing_activity_gallery_imv),
                    getString(R.string.intro_show_contact_list),
                    getString(R.string.intro_show_contact_list_brief),
                    false,
                    new OnTutorialFinishLisenter() {
                        @Override
                        public void onfinished(boolean isFinished) {
                            showSocialCircleIntro();
                            sessionManager.setIsquicksharecompleted();
                        }
                    }
            );
        }
    }

    private void showSocialCircleIntro() {

        if (!sessionManager.getIsSocialGroupCompleted()) {
            super.showTutorialScreenView(
                    findViewById(R.id.landing_activity_social_circle_imv),
                    getString(R.string.intro_social_circle_list),
                    getString(R.string.intro_social_circle_list_brief),
                    false,
                    new OnTutorialFinishLisenter() {
                        @Override
                        public void onfinished(boolean isFinished) {
                            sessionManager.setIsSocailGroupCompleted();
                            showProfileTutorial();
                        }
                    }
            );
        }
    }

    private void checkIfUserIsregisterToOneSignal() throws Exception {
        if (!sessionManager.getOneSingalAppToken().equalsIgnoreCase("")) {
            if (!sessionManager.getOneSingalAppToken()
                    .equalsIgnoreCase(sessionManager.getOneSignaleToken())) {
                sessionManager.setOnesignaltoken(sessionManager.getOneSingalAppToken());
                updateUserDetails(sessionManager.getUserIdentifier(), sessionManager.getOneSignaleToken());
            }
        }
    }

    /**
     * Update Subscription Token For OneSignal
     *
     * @param userIdentifier the unique identifier of the user
     * @param deviceToken    the onesignal device token.
     * @throws Exception Runtime stub exception.
     */
    private void updateUserDetails(final String userIdentifier, String deviceToken) throws Exception {

        UserDetails userDetails = new UserDetails();
        userDetails.setDevice_notification_key(deviceToken);
        Gson gson = new Gson();
        String data = gson.toJson(userDetails);
        OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, getApplicationContext());
        Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
        RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
        RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
        mRetrofitCallBacks.updateUserDetails(userIdentifier, userDetails,
                new RestServiceController.ResponseCallBacks() {
                    @Override
                    public void onResponse(Object o) {


                    }

                    @Override
                    public void onFailure(Object object) {
                        //Utils.showNegativeTost(getApplicationContext(), "Social Circle Creatation Failed.");
                    }
                });
    }

    BroadcastReceiver noDubuquContactAvaialbleReciever = new BroadcastReceiver() {
        @Override
        public void onReceive(final Context context, Intent intent) {

            int count = intent.getIntExtra(Constants.EXTRASTRINGS, 0);

            String confirmationText = "";

            if (count == 0) {
                confirmationText = getString(R.string.invite_confirmation_text);
            } else {
                confirmationText = "You have " + count + "contact(s)+ using Dubuqu. Would you like to invite more friends.";
            }
            new ActionConformationDialog(
                    getString(R.string.invite_friends),
                    confirmationText,
                    "Send Invites",
                    context,
                    true,
                    new ActionConformationDialog.OnActionCOnformationListner() {
                        @Override
                        public void onConformed() {
                            Utils.inviteFriends(context);
                        }

                        @Override
                        public void onRejected() {

                        }
                    }
            );
        }
    };


}
