
package com.dubuqu.dnModels.responseModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class MediaDetails {

    @SerializedName("signed_url")
    @Expose
    private String signedUrl;

    @SerializedName("content_type")
    @Expose
    private String contentType;
    @SerializedName("like_count")
    @Expose
    private String likeCount;
    @SerializedName("comment_count")
    @Expose
    private String commentCount;

    @SerializedName("thumbnail_signed_url")
    @Expose
    private String thumbnail_signed_url;

    public String getThumbnail_signed_url() {
        return thumbnail_signed_url;
    }

    public void setThumbnail_signed_url(String thumbnail_signed_url) {
        this.thumbnail_signed_url = thumbnail_signed_url;
    }

    public String getSignedUrl() {
        return signedUrl;
    }

    public void setSignedUrl(String signedUrl) {
        this.signedUrl = signedUrl;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getLikeCount() {
        return likeCount;
    }

    public void setLikeCount(String likeCount) {
        this.likeCount = likeCount;
    }

    public String getCommentCount() {
        return commentCount;
    }

    public void setCommentCount(String commentCount) {
        this.commentCount = commentCount;
    }
}
