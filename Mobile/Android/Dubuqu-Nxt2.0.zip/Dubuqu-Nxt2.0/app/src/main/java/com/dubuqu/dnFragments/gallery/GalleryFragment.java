package com.dubuqu.dnFragments.gallery;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.dubuqu.R;
import com.dubuqu.dnActivity.BaseActivity;
import com.dubuqu.dnActivity.LandingActivity;
import com.dubuqu.dnActivity.MultipleShareActivity;
import com.dubuqu.dnActivity.mediapreview.DubuquMediaViewerActivity;
import com.dubuqu.dnAdapter.gallery.CollageAdapter;
import com.dubuqu.dnAdapter.gallery.GalleryListAdapter;
import com.dubuqu.dnAdapter.gallery.GalleryMediaAlbumAdapter;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnModels.commonModel.ActionConformationDialog;
import com.dubuqu.dnModels.commonModel.GalleryAlbumList;
import com.dubuqu.dnModels.commonModel.GalleryMediaListModel;
import com.dubuqu.dnReceiver.ImageListLoaderReceiver;
import com.dubuqu.dnServices.MediaDeleteService;
import com.dubuqu.dnServices.MediaLoadAlbumService;
import com.dubuqu.dnServices.MediaLoadService;
import com.dubuqu.dnStorage.DbHelper;
import com.dubuqu.dnStorage.RecentShareDbModel;
import com.dubuqu.dnUtils.RestServiceUtils;
import com.dubuqu.dnUtils.Utils;
import com.dubuqu.dnViews.DragSelectTouchListener;
import com.dubuqu.dnViews.DubuquCollageView;
import com.dubuqu.dnViews.StickyHeaderGridLayoutManager;
import com.google.gson.Gson;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

/**
 * Created by Yogaraj subramanian on 30/10/17
 */

public class GalleryFragment extends Fragment implements ImageListLoaderReceiver.Receiver,
        GalleryListAdapter.GalleryAdapterCallBack {

    private Context context;

    private Activity activity;

    private final String TAG = GalleryFragment.class.getName();
    //Collections
    private HashMap<Date, List<GalleryMediaListModel>> galleryHashMap = new HashMap<>();

    private HashMap<String, GalleryAlbumList> galleryAlbumListHashMap = new HashMap<>();

    private List<String> selectedImage = new ArrayList<>();
    //adpaters
    private GalleryListAdapter galleryListAdapter;

    private GalleryMediaAlbumAdapter galleryMediaAlbumAdapter;
    //recyelrview
    private RecyclerView mediaRecyclerView;
    //floatingactionbutton
    private FloatingActionButton floatingActionButton;

    private int totalNumberOfVideos = 0, totalNumberOfImages = 0;

    private View parentView, quickSahreView;
    //Image View
    ImageView closeQuickSharePopup, collagePictures, deleteMedias, shareMedia, quickShareuserOneImv,
            quickShareuserTwoImv, quickShareuserThreeImv;
    //TextView
    TextView noOfImagesSelectedTV, quickShareUserOneTv, quickShareUserTwoTv, quickShareUserThreeTv;
    //LinearfrequentUserLL
    LinearLayout frequentUserLL, showMoreContacts;

    private PopupWindow popupWindow = null;

    private DragSelectTouchListener touchListener;

    RecyclerView collageRcv;

    private enum GalleryOption {
        GALLERY,
        ALBUMS,
        LOADALBUMANDGALLERY
    }

    GalleryOption currentOption = GalleryOption.GALLERY;


    @Override
    public void onResume() {
        super.onResume();

        context.registerReceiver(onMediaItemsChanged, new IntentFilter(Constants.MEDIAITEMCHANGED));

        activity.registerReceiver(updateRecentShare, new IntentFilter(Constants.UPDATERECENTSHARE));

        try {
            checkifReadandWriteSDcardPermissionisProvided();
        } catch (Exception e) {
            if (activity instanceof LandingActivity) {
                ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
            }
        }

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        try {
            activity.unregisterReceiver(updateRecentShare);
            activity.unregisterReceiver(onMediaItemsChanged);
        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        }

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (parentView == null)
            return inflater.inflate(R.layout.fragment_gallery, container, false);
        else
            return parentView;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        try {
            if (parentView == null) {
                this.parentView = view;
                initalizeViews();
            }
        } catch (Exception e) {
            if (activity instanceof LandingActivity) {
                ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
            }
        }
    }

    @Override
    public void onReceiveResult(HashMap<Date, List<GalleryMediaListModel>> galleryListModel) {
        if (galleryHashMap.size() > 0)
            galleryHashMap.clear();
        galleryHashMap.putAll(galleryListModel);
        galleryListAdapter.setDateValues(new ArrayList<>(galleryHashMap.keySet()));
        try {
            loadGalerryListData();
        } catch (Exception e) {
            if (activity instanceof LandingActivity) {
                ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
            }
        }
    }

    @Override
    public void onReceiveAlbumList(HashMap<String, GalleryAlbumList> albumList) {
        if (galleryAlbumListHashMap.size() > 0)
            galleryAlbumListHashMap.clear();

        galleryAlbumListHashMap.putAll(albumList);

        galleryMediaAlbumAdapter.setAlbumList(new ArrayList<>(galleryAlbumListHashMap.keySet()));
        galleryMediaAlbumAdapter.notifyDataSetChanged();

        try {
            loadAlbumData();
        } catch (Exception e) {
            if (activity instanceof LandingActivity) {
                ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
            }
        }
    }

    @Override
    public void onMediaClicked() {
        try {
            getSelectedMedias();
        } catch (Exception e) {
            if (activity instanceof LandingActivity) {
                ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
            }
        }
    }

    @Override
    public void openMediaInFullView(String imagePath) {

        try {
            Bundle bundle = new Bundle();

            List<String> listOfImages = new ArrayList<>();

            for (Object key : galleryListAdapter.getDateValues()) {

                List<GalleryMediaListModel> galleryMediaListModels =
                        galleryHashMap.get(key);

                if (galleryMediaListModels != null && galleryMediaListModels.size() > 0) {

                    for (GalleryMediaListModel galleryMediaListModel
                            : galleryMediaListModels) {

                        listOfImages.add(galleryMediaListModel.getMediaPath());

                        if (galleryMediaListModel.getMediaPath().equalsIgnoreCase(imagePath))
                            bundle.putInt(Constants.CURRENTIMAGE, listOfImages.size());
                    }
                }
            }

            String formattedDate = new Gson().toJson(listOfImages);

            bundle.putString(Constants.EXTRASTRINGS, formattedDate);

            Intent intent = new Intent(activity, DubuquMediaViewerActivity.class);

            intent.putExtras(bundle);

            activity.startActivity(intent);

        } catch (Exception e) {
            ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
        }

    }

    private void initalizeViews() throws Exception {

        context = getContext();

        activity = getActivity();

        galleryListAdapter = new GalleryListAdapter(context, galleryHashMap);
        galleryListAdapter.setGalleryAdapterCallBack(this);

        galleryMediaAlbumAdapter = new GalleryMediaAlbumAdapter(galleryAlbumListHashMap, context);

        floatingActionButton = parentView.findViewById(R.id.switch_layouts_fab);

        mediaRecyclerView = parentView.findViewById(R.id.fragment_gallery_rcv);

        quickSahreView = parentView.findViewById(R.id.fragment_gallery_quickshareview);

        quickSahreView.setVisibility(View.GONE);

        touchListener = new DragSelectTouchListener();

        closeQuickSharePopup = parentView.findViewById(R.id.quick_share_cancel);

        noOfImagesSelectedTV = parentView.findViewById(R.id.quick_share_number_of_media_selected);

        collagePictures = parentView.findViewById(R.id.quick_share_collage_images);

        shareMedia = parentView.findViewById(R.id.quick_share_external_share);

        frequentUserLL = parentView.findViewById(R.id.quick_share_frequent_users_ll);

        deleteMedias = parentView.findViewById(R.id.quick_share_delete_medias);

        showMoreContacts = parentView.findViewById(R.id.showMoreContacts);

        quickShareuserOneImv = parentView.findViewById(R.id.rcntprofileone);

        quickShareUserOneTv = parentView.findViewById(R.id.rcntusernameone);

        quickShareuserTwoImv = parentView.findViewById(R.id.rcntuserprofiletwo);

        quickShareUserTwoTv = parentView.findViewById(R.id.rcntusernametwo);

        quickShareuserThreeImv = parentView.findViewById(R.id.rcntuserProfilethree);

        quickShareUserThreeTv = parentView.findViewById(R.id.rcntusernamethree);

        collageRcv = parentView.findViewById(R.id.quick_share_collage_rcv);

        initalizeListeners();

        updateUserForQuickShare();
    }


    /**
     * initlaize event or click lisenters used here
     *
     * @throws Exception {Run time Stub Exception.}
     */
    private void initalizeListeners() throws Exception {

        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switch (currentOption) {
                    case ALBUMS:
                        currentOption = GalleryOption.GALLERY;
                        try {
                            floatingActionButton.setImageResource(R.mipmap.ic_album);
                            loadGalerryListData();
                        } catch (Exception e) {
                            if (activity instanceof LandingActivity) {
                                ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                            }
                        }
                        break;
                    case GALLERY:
                        currentOption = GalleryOption.ALBUMS;
                        try {
                            floatingActionButton.setImageResource(R.mipmap.ic_gallery);
                                loadAlbumData();
                        } catch (Exception e) {
                            if (activity instanceof LandingActivity) {
                                ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                            }
                        }
                        break;


                }

                try {

                    toggleCollageIcon(false);
                    toogleQuickSahre(false);
                    deSelectMedias();

                    if (galleryHashMap.size() == 0 || galleryAlbumListHashMap.size() == 0) {
                        stopServices();
                        startServices();
                    }
                } catch (Exception e) {
                    if (activity instanceof LandingActivity) {
                        ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                    }
                }


            }
        });


        galleryListAdapter.setLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                try {
                    int position = mediaRecyclerView.getChildAdapterPosition(view);
                    if (galleryListAdapter.isInMultipselectMode()) {
                        touchListener.setStartSelectPosition(position);
                    }
                    galleryListAdapter.onItemMove(position);

                } catch (Exception e) {
                    if (activity instanceof LandingActivity) {
                        ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                    }
                }

                return false;
            }
        });

        touchListener.setSelectListener(new DragSelectTouchListener.onSelectListener() {
            @Override
            public void onSelectChange(int start, int end, boolean isSelected) {
                try {
                    galleryListAdapter.onItemMove(end);
                } catch (Exception e) {
                    if (activity instanceof LandingActivity) {
                        ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                    }
                }
            }
        });

        closeQuickSharePopup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    deSelectMedias();
                    toggleCollageIcon(false);
                    toogleQuickSahre(false);
                } catch (Exception e) {
                    if (activity instanceof LandingActivity) {
                        ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                    }
                }
            }
        });

        shareMedia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    shareMediaToExternalApps();
                } catch (Exception e) {
                    if (activity instanceof LandingActivity) {
                        ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                    }
                }
            }
        });

        collagePictures.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (frequentUserLL.getVisibility() == View.VISIBLE)
                        showCollageOptions();

                } catch (Exception e) {
                    if (activity instanceof LandingActivity) {
                        ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                    }
                }
            }
        });

        deleteMedias.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    showDeleteMediaConformation();
                } catch (Exception e) {
                    if (activity instanceof LandingActivity) {
                        ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                    }
                }
            }
        });

        showMoreContacts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (selectedImage.size() > 0) {

                    Intent intent = new Intent(context, MultipleShareActivity.class);
                    String imageData = new Gson().toJson(selectedImage);
                    Bundle bundle = new Bundle();
                    bundle.putString(Constants.EXTRASTRINGS, imageData);
                    intent.putExtras(bundle);
                    activity.startActivity(intent);
                    try {
                        toggleCollageIcon(false);
                        toogleQuickSahre(false);
                        deSelectMedias();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        mediaRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
                if (newState == RecyclerView.SCROLL_STATE_IDLE) {
                    floatingActionButton.show();
                }
            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (dy > 0 || dy < 0 && floatingActionButton.isShown()) {
                    floatingActionButton.hide();
                }
                /*if (dy > 0 || dy < 0 && currentOption == GalleryOption.GALLERY
                        && frequentUserLL.getVisibility() == View.VISIBLE && galleryListAdapter.isInMultipselectMode()) {
                    YoYo.with(Techniques.SlideOutUp).duration(200).onEnd(new YoYo.AnimatorCallback() {
                        @Override
                        public void call(Animator animator) {
                            frequentUserLL.setVisibility(View.GONE);
                        }
                    }).playOn(frequentUserLL);
                }*/

            }

        });

        quickShareuserOneImv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    shareMediaToFregquentUsers(0);
                } catch (Exception e) {
                    if (activity instanceof LandingActivity) {
                        ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                    }
                }
            }
        });

        quickShareuserTwoImv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    shareMediaToFregquentUsers(1);
                } catch (Exception e) {
                    if (activity instanceof LandingActivity) {
                        ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                    }
                }
            }
        });

        quickShareuserThreeImv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    shareMediaToFregquentUsers(2);
                } catch (Exception e) {
                    if (activity instanceof LandingActivity) {
                        ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                    }
                }
            }
        });
    }


    private void shareMediaToFregquentUsers(int position) throws Exception {
        DbHelper dbHelper = new DbHelper(getContext());
        List<RecentShareDbModel> recentShareDbModels = dbHelper.getAllRecentusers();
        if (recentShareDbModels != null) {

            RecentShareDbModel recentShareDbModel = recentShareDbModels.get(position);

            List<String> selectedUsers = new ArrayList<>();
            selectedUsers.add(recentShareDbModel.getIdentifier());
            Gson g = new Gson();
            String json = g.toJson(selectedImage);
            String SselectedUsers = g.toJson(selectedUsers);
            Random random = new Random();
            RestServiceUtils.scheduleUploadMediaFile(activity, json, SselectedUsers, false);

        }

        toggleCollageIcon(false);
        toogleQuickSahre(false);
        deSelectMedias();
    }

    /**
     * delte media from hashmaps and also start service to change album data counts
     *
     * @throws Exception {Runtime Stub Exception}
     */
    private void deleteMediaFromSdCard() throws Exception {
        List<Date> values = new ArrayList<>(galleryHashMap.keySet());

        List<Date> tempKey = new ArrayList<>();

        for (Date date : values) {

            List<GalleryMediaListModel> galleryMediaListModels = galleryHashMap.get(date);

            List<GalleryMediaListModel> tempIndex = new ArrayList<>();

            for (GalleryMediaListModel galleryMediaListModel : galleryMediaListModels) {

                if (galleryMediaListModel.isSelected()) {
                    tempIndex.add(galleryMediaListModel);
                }
            }

            galleryMediaListModels.removeAll(tempIndex);
            galleryHashMap.put(date, galleryMediaListModels);

            if (galleryMediaListModels.size() <= 0) {
                tempKey.add(date);
            }
        }

        for (int i = 0; i < tempKey.size(); i++) {
            galleryHashMap.remove(tempKey.get(i));
            galleryListAdapter.removeDate(tempKey.get(i));
        }

        Utils.showToast(getContext(), "Media Deleted Sucessfully.");

        toogleQuickSahre(false);

        selectedImage.clear();

        deSelectMedias();

    }

    /**
     * Start Image Service for loding images based on date.
     * <p>
     * based on galleryOption enum the adapter and the data sets are loaded.
     * </p>
     *
     * @throws Exception {Run time Stub Exception.}
     */

    public void startServices() throws Exception {

        ImageListLoaderReceiver imageListLoaderReceiver = new ImageListLoaderReceiver(new Handler(),
                this);

        if (currentOption == GalleryOption.LOADALBUMANDGALLERY) {

            Intent albumIntent = new Intent(activity, MediaLoadAlbumService.class);
            albumIntent.putExtra(Constants.EXTRASTRINGS, imageListLoaderReceiver);
            context.startService(albumIntent);

            Intent galleyIntent = new Intent(activity, MediaLoadService.class);
            galleyIntent.putExtra(Constants.EXTRASTRINGS, imageListLoaderReceiver);
            context.startService(galleyIntent);
        } else {

            Intent intent = null;

            switch (currentOption) {
                case GALLERY:
                    intent = new Intent(activity, MediaLoadService.class);
                    break;
                case ALBUMS:
                    intent = new Intent(activity, MediaLoadAlbumService.class);
                    break;
            }

            intent.putExtra(Constants.EXTRASTRINGS, imageListLoaderReceiver);
            context.startService(intent);
        }
    }

    private void startAlbumService() throws Exception {
        ImageListLoaderReceiver imageListLoaderReceiver = new ImageListLoaderReceiver(new Handler(),
                this);
        Intent albumIntent = new Intent(activity, MediaLoadAlbumService.class);
        albumIntent.putExtra(Constants.EXTRASTRINGS, imageListLoaderReceiver);
        context.startService(albumIntent);
    }

    /**
     * On continous click of floating action button i.e if user switches the service will be started
     * mulitple times.
     * <p>
     * for example : if medialoadservice is running it need to be stopped when album is loaded.
     *
     * @throws Exception {Runtime stub exception}
     */
    private void stopServices() throws Exception {

        if (currentOption == GalleryOption.LOADALBUMANDGALLERY) {

        } else {
            Intent intent = null;
            switch (currentOption) {
                case GALLERY:
                    intent = new Intent(context, MediaLoadAlbumService.class);
                    break;
                case ALBUMS:
                    intent = new Intent(context, MediaLoadService.class);
                    break;
            }
            activity.stopService(intent);
        }


    }

    /**
     * change adapter to album view
     *
     * @throws Exception {Runtime stub exception}
     */
    private void loadAlbumData() throws Exception {
        if (currentOption == GalleryOption.ALBUMS) {
            mediaRecyclerView.setAdapter(null);
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context,
                    LinearLayoutManager.VERTICAL, false);

            if (galleryMediaAlbumAdapter.getAlbumList().size() == 0 && galleryAlbumListHashMap.size() > 0)
                galleryMediaAlbumAdapter.setAlbumList(new ArrayList<String>(galleryAlbumListHashMap.keySet()));

            mediaRecyclerView.setLayoutManager(linearLayoutManager);
            mediaRecyclerView.setAdapter(galleryMediaAlbumAdapter);

            if (activity instanceof LandingActivity)
                ((LandingActivity) activity).setToolBarText(getString(R.string.album));
        }

    }

    /**
     * change adater gallery list view
     *
     * @throws Exception{Runtime stub exception}
     */
    private void loadGalerryListData() throws Exception {

        mediaRecyclerView.setAdapter(null);

        StickyHeaderGridLayoutManager gridLayoutManager = new StickyHeaderGridLayoutManager(3);
        gridLayoutManager.setHeaderBottomOverlapMargin(20);
        if (galleryListAdapter.getDateValues().size() == 0 && galleryHashMap.size() > 0) {
            galleryListAdapter.setDateValues(new ArrayList<>(galleryHashMap.keySet()));
        }
        mediaRecyclerView.setAdapter(galleryListAdapter);
        mediaRecyclerView.setLayoutManager(gridLayoutManager);

        if (galleryHashMap.size() > 0)
            mediaRecyclerView.addOnItemTouchListener(touchListener);

        galleryListAdapter.notifyAllSectionsDataSetChanged();

        if (activity instanceof LandingActivity)
            ((LandingActivity) activity).setToolBarText(getString(R.string.gallery));
    }

    private void getSelectedMedias() throws Exception {
        if (selectedImage.size() > 0)
            selectedImage.clear();

        if (galleryHashMap.size() == 0)
            return;

        List<Date> values = new ArrayList<>(galleryHashMap.keySet());

        for (Date date : values) {

            List<GalleryMediaListModel> galleryMediaListModels = galleryHashMap.get(date);

            for (GalleryMediaListModel galleryMediaListModel : galleryMediaListModels) {

                if (galleryMediaListModel.isSelected()) {
                    selectedImage.add(galleryMediaListModel.getMediaPath());
                }

            }
        }
        if (checkIfVideoSelected() || selectedImage.size() <= 1)
            toggleCollageIcon(true);
        else
            toggleCollageIcon(false);
        if (selectedImage.size() > 0) {
            toogleQuickSahre(true);
            noOfImagesSelectedTV.setText(String.valueOf(selectedImage.size()).concat(getString(R.string.media_selected)));
        } else {
            toogleQuickSahre(false);
            galleryListAdapter.setInMultipselectMode(false);
        }
    }

    /**
     * checks if any video or images is selcted more than 9
     * if yes need to hide the collage icon
     */
    private boolean checkIfVideoSelected() throws Exception {

        if (selectedImage.size() > 9) {
            return true;
        }

        for (String selectedMedia : selectedImage) {

            if (Utils.getMimeType(selectedMedia).contains("video")
                    || Utils.getMimeType(selectedMedia).contains("mp4")
                    || Utils.getMimeType(selectedMedia).contains("3gp"))
                return true;
        }

        return false;
    }

    /**
     * toogle quickshare Navigation bar
     * <p>
     * true=> show ;  false= >hide;
     *
     * @param toogleOption whether to hide or show
     * @throws Exception {Runtime Stub Exception}
     */
    private void toogleQuickSahre(boolean toogleOption) throws Exception {
        if (toogleOption) {
            if (quickSahreView.getVisibility() == View.GONE) {
                if (activity instanceof LandingActivity) {
                    ((LandingActivity) activity).toggleBottomSheet(true);
                }
                quickSahreView.setVisibility(View.VISIBLE);
                YoYo.with(Techniques.SlideInDown)
                        .duration(Constants.ANIMATIONTIME)
                        .playOn(quickSahreView);

                floatingActionButton.setVisibility(View.GONE);
            }

        } else {
            floatingActionButton.setVisibility(View.VISIBLE);
            quickSahreView.setVisibility(View.GONE);

            if (collageRcv.getVisibility() == View.VISIBLE) {
                collageRcv.setVisibility(View.GONE);
                frequentUserLL.setVisibility(View.VISIBLE);
            }


            if (activity instanceof LandingActivity) {
                ((LandingActivity) activity).toggleBottomSheet(false);
            }
        }
    }

    /**
     * if fragment is replaced the data must be deselected
     *
     * @throws Exception {Runtime Stub Exception}
     */
    private void deSelectMedias() throws Exception {

        List<Date> values = new ArrayList<>(galleryHashMap.keySet());

        for (Date date : values) {

            List<GalleryMediaListModel> galleryMediaListModels = galleryHashMap.get(date);

            for (GalleryMediaListModel galleryMediaListModel : galleryMediaListModels) {

                if (galleryMediaListModel.isSelected()) {
                    galleryMediaListModel.setSelected(false);
                }
            }
        }

        if (selectedImage.size() > 0) {
            selectedImage.clear();
        }

        galleryListAdapter.setInMultipselectMode(false);

        galleryListAdapter.notifyAllSectionsDataSetChanged();
    }

    /**
     * Show or Hide Collage icon
     * <p>
     * false => show collage option
     * true =>  hides i.e video or images more than 9 is selected.
     * </p>
     *
     * @param shouldHideCOllageIcon Boolean Value
     */
    private void toggleCollageIcon(boolean shouldHideCOllageIcon) throws Exception {
        if (shouldHideCOllageIcon) {
            collagePictures.setVisibility(View.GONE);
        } else
            collagePictures.setVisibility(View.VISIBLE);
    }

    /**
     * Share media to external applications
     *
     * @throws Exception {Runtime Stub Exception}
     */

    private void shareMediaToExternalApps() throws Exception {

        if (selectedImage.size() > 0) {

            ArrayList<Uri> imageUris = new ArrayList<>();

            for (String s : selectedImage)
                imageUris.add(Uri.fromFile(new File(s)));

            Intent shareIntent = new Intent();
            shareIntent.setAction(Intent.ACTION_SEND_MULTIPLE);
            shareIntent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, imageUris);
            shareIntent.setType("image/*");
            startActivity(Intent.createChooser(shareIntent, "Share images to.."));

            deSelectMedias();
            toggleCollageIcon(false);
            toogleQuickSahre(false);
        }
    }

    /**
     * Hide frequent User Layout and show Collage layout
     *
     * @throws Exception {Runtime Stub Exception}
     */
    private void showCollageOptions() throws Exception {

        TypedArray collageTemplates = context.getResources().obtainTypedArray(R.array.collage_templates);

        CollageAdapter collageAdapter = new CollageAdapter(collageTemplates, context, new CollageAdapter.OnItemClick() {
            @Override
            public void getPostion(int postion) {
                DubuquCollageView.CollageOption collageOption = DubuquCollageView.CollageOption.COLLAGE_2_1;
                switch (postion) {
                    case 0:
                        collageOption = DubuquCollageView.CollageOption.COLLAGE_2_2;
                        break;
                    case 1:
                        collageOption = DubuquCollageView.CollageOption.COLLAGE_2_1;
                        break;
                    case 2:
                        collageOption = DubuquCollageView.CollageOption.COLLAGE_3_2;
                        break;
                    case 3:
                        collageOption = DubuquCollageView.CollageOption.COLLAGE_3_1;
                        break;
                    case 4:
                        collageOption = DubuquCollageView.CollageOption.COLLAGE_4_1;
                        break;
                    case 5:
                        collageOption = DubuquCollageView.CollageOption.COLLAGE_4_2;
                        break;
                    case 6:
                        collageOption = DubuquCollageView.CollageOption.COLLAGE_5_1;
                        break;
                    case 7:
                        collageOption = DubuquCollageView.CollageOption.COLLAGE_5_2;
                        break;
                    case 8:
                        collageOption = DubuquCollageView.CollageOption.COLLAGE_6_1;
                        break;
                    case 9:
                        collageOption = DubuquCollageView.CollageOption.COLLAGE_7_1;
                        break;
                    case 10:
                        collageOption = DubuquCollageView.CollageOption.COLLAGE_8_1;
                        break;
                    case 11:
                        collageOption = DubuquCollageView.CollageOption.COLLAGE_9_1;
                        break;
                }

                try {
                    showCollageView(collageOption);
                    hideCollageOptions();
                    toggleCollageIcon(false);
                    toogleQuickSahre(false);
                    deSelectMedias();
                } catch (Exception e) {
                    if (activity instanceof LandingActivity) {
                        ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                    }
                }
            }
        });

        collageRcv.setLayoutManager(new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false));
        collageRcv.setAdapter(collageAdapter);

        frequentUserLL.setVisibility(View.GONE);

        collageRcv.setVisibility(View.VISIBLE);

        YoYo.with(Techniques.SlideInRight)
                .duration(Constants.ANIMATIONTIME)
                .playOn(collageRcv);

    }

    /**
     * Hide collage layout and show frequent user layout
     *
     * @throws Exception {Runtime Stub Exception}
     */
    private void hideCollageOptions() throws Exception {

        frequentUserLL.setVisibility(View.VISIBLE);

        YoYo.with(Techniques.SlideInLeft)
                .duration(Constants.ANIMATIONTIME)
                .playOn(frequentUserLL);

        RecyclerView collageRcv = parentView.findViewById(R.id.quick_share_collage_rcv);

        collageRcv.setVisibility(View.GONE);

    }

    /**
     * Show Collage View PopUp
     *
     * @param collageOption {@link DubuquCollageView} refer for details
     * @throws Exception {@link Exception}
     */

    private void showCollageView(DubuquCollageView.CollageOption collageOption) throws Exception {

        LayoutInflater inflater = (LayoutInflater) getActivity().
                getSystemService(getActivity().LAYOUT_INFLATER_SERVICE);

        View reportDreamView = inflater.inflate(R.layout.dubuqucollagelayout, null);
        final LinearLayout collageLayoutLL = reportDreamView.findViewById(R.id.collageview);
        collageLayoutLL.setDrawingCacheEnabled(true);
        collageLayoutLL.setDrawingCacheBackgroundColor(Color.WHITE);

        DubuquCollageView dubuquCollageView = new DubuquCollageView(getContext(), selectedImage);
        dubuquCollageView.setCollageOption(collageOption);
        collageLayoutLL.addView(dubuquCollageView);

        TextView createCollageTV = reportDreamView.findViewById(R.id.collage_done);

        TextView cloaseCollageView = reportDreamView.findViewById(R.id.collage_close);

        cloaseCollageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                popupWindow.dismiss();
                popupWindow = null;
            }
        });
        createCollageTV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (activity instanceof LandingActivity)
                        ((LandingActivity) activity).showLoaders(view.getContext());
                    popupWindow.dismiss();
                    saveCollageImage(collageLayoutLL);
                } catch (Exception e) {
                    if (activity instanceof LandingActivity) {
                        ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                    }
                }
            }
        });

        popupWindow = new PopupWindow(reportDreamView);
        popupWindow.setWidth(ViewGroup.LayoutParams.MATCH_PARENT);
        popupWindow.setHeight(ViewGroup.LayoutParams.MATCH_PARENT);
        popupWindow.setOutsideTouchable(true);
        popupWindow.setFocusable(true);
        popupWindow.setBackgroundDrawable(new ColorDrawable(Color.WHITE));

        if (!popupWindow.isShowing()) {
            popupWindow.showAtLocation(reportDreamView, 0, 0, Gravity.NO_GRAVITY);
        }
    }

    /**
     * Save CollagedImages
     *
     * @param collageLayoutLL the View that contains the images
     * @throws Exception {@link Exception}
     */
    private void saveCollageImage(LinearLayout collageLayoutLL) throws Exception {
        Date now = new Date();
        android.text.format.DateFormat.format("yyyy-MM-dd_hh:mm:ss", now);

        // image naming and path  to include sd card  appending name you choose for file
        String mPath = Environment.getExternalStorageDirectory().toString() + "/" + now + ".png";

        // create bitmap screen capture
        Bitmap bitmap = Bitmap.createBitmap(collageLayoutLL.getDrawingCache());
        collageLayoutLL.setDrawingCacheEnabled(false);

        File imageFile = new File(mPath);

        FileOutputStream outputStream = new FileOutputStream(imageFile);
        int quality = 100;
        bitmap.compress(Bitmap.CompressFormat.PNG, quality, outputStream);
        outputStream.flush();
        outputStream.close();
        Uri imagePath = Uri.fromFile(imageFile);

        ContentValues values = new ContentValues();

        values.put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis());
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
        values.put(MediaStore.MediaColumns.DATA, imagePath.getPath());

        getContext().getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        popupWindow.dismiss();
        Utils.showToast(getContext(), "Collage Created Sucessfully.");

        deSelectMedias();
        startServices();

        if (activity instanceof LandingActivity)
            ((LandingActivity) activity).cancelPopUp();
    }

    /**
     * Show delete media popup UI for conformation
     *
     * @throws Exception{Runtime Stub Exception.}
     */
    private void showDeleteMediaConformation() throws Exception {

        new ActionConformationDialog(getString(R.string.delete_media), getString(R.string.confirm_delete), context,
                new ActionConformationDialog.OnActionCOnformationListner() {
                    @Override
                    public void onConformed() {
                        try {
                            if (selectedImage.size() > 0) {

                                Bundle bundle = new Bundle();

                                String formattedDate = new Gson().toJson(selectedImage);

                                bundle.putString(Constants.EXTRASTRINGS, formattedDate);

                                Intent intent = new Intent(activity, MediaDeleteService.class);

                                intent.putExtras(bundle);

                                context.startService(intent);

                                deleteMediaFromSdCard();

                                startAlbumService();

                            }
                        } catch (Exception e) {
                            if (activity instanceof LandingActivity) {
                                ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                            }
                        }
                    }

                    @Override
                    public void onRejected() {
                        try {
                            deSelectMedias();
                            toggleCollageIcon(false);
                            toogleQuickSahre(false);
                        } catch (Exception e) {
                            if (activity instanceof LandingActivity) {
                                ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                            }
                        }
                    }
                });

    }

    /**
     * Update quick share options to views.
     *
     * @throws Exception{Runtime Stub Exception}
     */
    private void updateUserForQuickShare() throws Exception {

        DbHelper dbHelper = new DbHelper(getContext());
        List<RecentShareDbModel> recentShareDbModels = dbHelper.getAllRecentusers();

        int iterator = 0;

        for (RecentShareDbModel shareDbModel : recentShareDbModels) {
            final Drawable drawable = new BitmapDrawable(
                    Utils.textAsBitmap(shareDbModel.getUserName(), context));
            String userName = shareDbModel.getUserName();

            switch (iterator) {

                case 0:
                    if (shareDbModel.getProfilePic() != null &&
                            !shareDbModel.getProfilePic().equalsIgnoreCase("")) {
                        ImageLoader.getInstance().displayImage(
                                shareDbModel.getProfilePic(),
                                quickShareuserOneImv, new ImageLoadingListener() {
                                    @Override
                                    public void onLoadingStarted(String imageUri, View view) {
                                        quickShareuserOneImv.setImageDrawable(drawable);
                                    }

                                    @Override
                                    public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
                                        quickShareuserOneImv.setImageDrawable(drawable);
                                    }

                                    @Override
                                    public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                                        quickShareuserOneImv.setImageBitmap(loadedImage);
                                    }

                                    @Override
                                    public void onLoadingCancelled(String imageUri, View view) {
                                        quickShareuserOneImv.setImageDrawable(drawable);
                                    }
                                });
                    } else {
                        quickShareuserOneImv.setImageDrawable(drawable);
                    }
                    quickShareUserOneTv.setText(userName);
                    break;

                case 1:
                    if (shareDbModel.getProfilePic() != null &&
                            !shareDbModel.getProfilePic().equalsIgnoreCase("")) {
                        ImageLoader.getInstance().displayImage(
                                shareDbModel.getProfilePic(),
                                quickShareuserTwoImv, new ImageLoadingListener() {
                                    @Override
                                    public void onLoadingStarted(String imageUri, View view) {
                                        quickShareuserTwoImv.setImageDrawable(drawable);
                                    }

                                    @Override
                                    public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
                                        quickShareuserTwoImv.setImageDrawable(drawable);
                                    }

                                    @Override
                                    public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                                        quickShareuserTwoImv.setImageBitmap(loadedImage);
                                    }

                                    @Override
                                    public void onLoadingCancelled(String imageUri, View view) {
                                        quickShareuserTwoImv.setImageDrawable(drawable);
                                    }
                                });
                    } else {
                        quickShareuserTwoImv.setImageDrawable(drawable);
                    }
                    quickShareUserTwoTv.setText(userName);
                    break;

                case 2:
                    if (shareDbModel.getProfilePic() != null &&
                            !shareDbModel.getProfilePic().equalsIgnoreCase("")) {
                        ImageLoader.getInstance().displayImage(
                                shareDbModel.getProfilePic(),
                                quickShareuserThreeImv, new ImageLoadingListener() {
                                    @Override
                                    public void onLoadingStarted(String imageUri, View view) {
                                        quickShareuserThreeImv.setImageDrawable(drawable);
                                    }

                                    @Override
                                    public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
                                        quickShareuserThreeImv.setImageDrawable(drawable);
                                    }

                                    @Override
                                    public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                                        quickShareuserThreeImv.setImageBitmap(loadedImage);
                                    }

                                    @Override
                                    public void onLoadingCancelled(String imageUri, View view) {
                                        quickShareuserThreeImv.setImageDrawable(drawable);
                                    }
                                });
                    } else {
                        quickShareuserThreeImv.setImageDrawable(drawable);
                    }
                    quickShareUserThreeTv.setText(userName);
                    break;
            }

            iterator++;
        }
    }

    /**
     * check if read and write external storage permission is provided.
     *
     * @throws Exception Rutime Stub Exception.
     */

    private void checkifReadandWriteSDcardPermissionisProvided() throws Exception {
        if (activity instanceof LandingActivity) {

            if (!((LandingActivity) activity).checkIfPermissionIsGranted(
                    android.Manifest.permission.READ_EXTERNAL_STORAGE)) {
                ((LandingActivity) activity).requestPermission(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
                                Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        new BaseActivity.PermissionCallBack() {
                            @Override
                            public void onPermissionGranted() {
                            }

                            @Override
                            public void onPermissionRejected() {
                                try {
                                    if (activity instanceof LandingActivity) {
                                        ((LandingActivity) activity).showToastMessage(getString(R.string.please_provide_permission_to_continue),
                                                false);
                                    }
                                } catch (Exception e) {
                                    if (activity instanceof LandingActivity) {
                                        ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                                    }
                                }
                            }
                        });
            } else {
                if (activity instanceof LandingActivity) {
                    try {
                        ((LandingActivity) activity).toggleBottomSheet(false);
                    } catch (Exception e) {
                        if (activity instanceof LandingActivity) {
                            ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                        }
                    }
                }

                if (galleryHashMap.size() == 0 && galleryAlbumListHashMap.size() == 0) try {
                    startServices();
                } catch (Exception e) {
                    if (activity instanceof LandingActivity) {
                        ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                    }
                }

                if (quickSahreView.getVisibility() == View.VISIBLE) {
                    try {
                        ((LandingActivity) activity).toggleBottomSheet(true);
                    } catch (Exception e) {
                        if (activity instanceof LandingActivity) {
                            ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                        }
                    }
                }
            }
        }
    }


    BroadcastReceiver onMediaItemsChanged = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            currentOption = GalleryOption.LOADALBUMANDGALLERY;
            try {
                startServices();
                currentOption = GalleryOption.GALLERY;
            } catch (Exception e) {
                if (activity instanceof LandingActivity) {
                    ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                }
            }
        }
    };

    BroadcastReceiver updateRecentShare = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            try {
                updateUserForQuickShare();
            } catch (Exception e) {
                Log.e(TAG, e.getMessage());
            }
        }
    };


}
