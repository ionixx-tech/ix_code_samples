package com.dubuqu.dnAdapter.common;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.dubuqu.R;
import com.dubuqu.dnModels.requestModel.GifResponse;
import com.dubuqu.dnModels.requestModel.Medium;
import com.dubuqu.dnModels.requestModel.Nanogif;

import java.util.List;

/**
 * Created by Yogaraj subramanian on 14/3/18
 */

public class DubuquGifAdapter extends RecyclerView.Adapter {

    Context context;

    DubuqGifAdapterCallback dubuqGifAdapterCallback;

    GifResponse gifResponses;

    public DubuquGifAdapter(Context context, DubuqGifAdapterCallback dubuqGifAdapterCallback,
                            GifResponse gifResponses) {
        this.context = context;
        this.dubuqGifAdapterCallback = dubuqGifAdapterCallback;
        this.gifResponses = gifResponses;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.layout_dubuqu_gif_loader, parent, false);
        return new RecyclerView.ViewHolder(view) {
            @Override
            public String toString() {
                return super.toString();
            }
        };
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        loadGifInImage(holder, position);
    }

    @Override
    public int getItemCount() {
        return this.gifResponses.getResults().size();
    }


    private void loadGifInImage(RecyclerView.ViewHolder holder, int postion) {

        ImageView imageView = holder.itemView.findViewById(R.id.adpater_gif_viewholder_imv);

        List<Medium> media = gifResponses.getResults().get(postion).getMedia();

        if (media != null && media.size() > 0) {

            Nanogif nanogif = media.get(0).getNanogif();

            Glide.with(context).load(nanogif.getUrl()).into(imageView);
        }
    }

    public interface DubuqGifAdapterCallback {
        void onItemClicked(int postion);
    }
}
