package com.dubuqu.dnActivity.mediapreview;

import android.os.Bundle;
import android.support.annotation.Nullable;

import com.dubuqu.dnActivity.BaseActivity;

/**
 * Created by Yogaraj subramanian on 7/12/17
 */

public class DubuqCameraMediaPreview extends BaseActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    void playVideo() throws Exception{

    }

    void initializeView() throws Exception{

    }

    void initializeListners() throws Exception{

    }
}
