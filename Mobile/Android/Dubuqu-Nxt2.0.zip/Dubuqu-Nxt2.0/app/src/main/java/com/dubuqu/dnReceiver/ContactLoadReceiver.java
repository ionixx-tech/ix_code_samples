package com.dubuqu.dnReceiver;

import android.os.Bundle;
import android.os.Handler;
import android.os.ResultReceiver;

import com.dubuqu.dnConstants.Constants;

/**
 * Created by Yogaraj subramanian on 8/11/17
 */

public class ContactLoadReceiver extends ResultReceiver {

    private addOnContactLoadListener addOnContactLoadListener;


    public interface addOnContactLoadListener {

        void onContactsLoaded();
    }

    public ContactLoadReceiver(Handler handler, ContactLoadReceiver.addOnContactLoadListener addOnContactLoadListener) {
        super(handler);
        this.addOnContactLoadListener = addOnContactLoadListener;
    }

    @Override
    protected void onReceiveResult(int resultCode, Bundle resultData) {
        super.onReceiveResult(resultCode, resultData);
        if (resultCode == Constants.CONTACTSERVICE_REQUESTCODE) {
            addOnContactLoadListener.onContactsLoaded();
        }
    }
}
