
package com.dubuqu.dnModels.responseModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class UpdateGroupProfileRequest {

    @SerializedName("profile_image_identifier")
    @Expose
    private String profileImageIdentifier;

    public String getProfileImageIdentifier() {
        return profileImageIdentifier;
    }

    public void setProfileImageIdentifier(String profileImageIdentifier) {
        this.profileImageIdentifier = profileImageIdentifier;
    }

}
