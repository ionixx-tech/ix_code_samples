package com.dubuqu.dnModels.commonModel;

import android.content.Context;
import android.support.annotation.Nullable;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.dubuqu.R;

import static android.content.Context.LAYOUT_INFLATER_SERVICE;

/**
 * Created by Yogaraj subramanian on 8/2/18
 */

public class ActionConformationDialog {


    private String conformationText = "Are You Sure.", conformationHeading = "Confirm", confirmActionText = "";

    private Context context;

    private OnActionCOnformationListner onActionCOnformationListner;

    private OnVideoCompleteListner onVideoCompleteListner;


    public ActionConformationDialog(@Nullable String conformationHeading,
                                    String conformationText,
                                    Context context,
                                    OnActionCOnformationListner onActionCOnformationListner) {

        this.conformationText = conformationText;

        this.context = context;

        this.onActionCOnformationListner = onActionCOnformationListner;

        this.confirmActionText = context.getString(R.string.confirm);

        if (conformationHeading != null)
            this.conformationHeading = conformationHeading;

        inflateView();
    }

    public ActionConformationDialog(@Nullable String conformationHeading,
                                    String conformationText,
                                    String confirmText,
                                    Context context,
                                    boolean toOpenFullScreenAlert,
                                    OnActionCOnformationListner onActionCOnformationListner) {
        this.conformationText = conformationText;

        this.context = context;

        this.onActionCOnformationListner = onActionCOnformationListner;

        this.confirmActionText = confirmText;

        if (conformationHeading != null)
            this.conformationHeading = conformationHeading;

        if (!toOpenFullScreenAlert)
            inflateView();
        else
            inflateFullView();

    }


    public ActionConformationDialog(String videoUrl, OnVideoCompleteListner onVideoCompleteListner) {
        inflateVideoView(videoUrl);
        this.onVideoCompleteListner = onVideoCompleteListner;
    }

    private void inflateFullView() {
        LayoutInflater inflater = (LayoutInflater)
                context.getSystemService(LAYOUT_INFLATER_SERVICE);

        final View mediaOptionsMenu = inflater.inflate(R.layout.layout_action_conformation_fullview, null);

        TextView skip, confirm, conformationText;

        skip = mediaOptionsMenu.findViewById(R.id.action_fullscreen_skiptxt);

        conformationText = mediaOptionsMenu.findViewById(R.id.action_fullscreen_txt);
        conformationText.setText(this.confirmActionText);

        confirm = mediaOptionsMenu.findViewById(R.id.action_fullscreen_confirm);

        conformationText.setText(this.conformationText);

        final PopupWindow popupWindow = new PopupWindow(context);
        popupWindow.setContentView(mediaOptionsMenu);
        popupWindow.setWidth(LinearLayout.LayoutParams.MATCH_PARENT);
        popupWindow.setHeight(LinearLayout.LayoutParams.MATCH_PARENT);
        popupWindow.setFocusable(true);
        popupWindow.setBackgroundDrawable(null);
        popupWindow.setOutsideTouchable(false);

        popupWindow.showAtLocation(mediaOptionsMenu, Gravity.TOP, 0, 0);

        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onActionCOnformationListner.onConformed();
                popupWindow.dismiss();
            }
        });

        skip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onActionCOnformationListner.onRejected();
                popupWindow.dismiss();
            }
        });

    }

    private void inflateView() {
        LayoutInflater inflater = (LayoutInflater)
                context.getSystemService(LAYOUT_INFLATER_SERVICE);

        final View mediaOptionsMenu = inflater.inflate(R.layout.layout_action_conformation, null);

        TextView cancel, confirm, conformationText, heading;

        View blurView;

        heading = mediaOptionsMenu.findViewById(R.id.action_txt_title);

        cancel = mediaOptionsMenu.findViewById(R.id.action_cancel);

        conformationText = mediaOptionsMenu.findViewById(R.id.action_txt);
        conformationText.setText(this.confirmActionText);

        confirm = mediaOptionsMenu.findViewById(R.id.action_ok);

        conformationText.setText(this.conformationText);

        blurView = mediaOptionsMenu.findViewById(R.id.action_blur_view);

        heading.setText(conformationHeading);

        final PopupWindow popupWindow = new PopupWindow(context);
        popupWindow.setContentView(mediaOptionsMenu);
        popupWindow.setWidth(LinearLayout.LayoutParams.MATCH_PARENT);
        popupWindow.setHeight(LinearLayout.LayoutParams.MATCH_PARENT);
        popupWindow.setFocusable(true);
        popupWindow.setBackgroundDrawable(null);
        popupWindow.setOutsideTouchable(false);

        popupWindow.showAtLocation(mediaOptionsMenu, Gravity.TOP, 0, 0);

        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onActionCOnformationListner.onConformed();
                popupWindow.dismiss();
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onActionCOnformationListner.onRejected();
                popupWindow.dismiss();
            }
        });

        blurView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onActionCOnformationListner.onRejected();
                popupWindow.dismiss();
            }
        });
    }


    private void inflateVideoView(String videoUrl) {

        LayoutInflater inflater = (LayoutInflater)
                context.getSystemService(LAYOUT_INFLATER_SERVICE);

        final View mediaOptionsMenu = inflater.inflate(R.layout.layout_action_video_view, null);

        TextView skip;

        mediaOptionsMenu.setFocusableInTouchMode(true);
        mediaOptionsMenu.requestFocus();
        mediaOptionsMenu.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK) {
//                    handleBackpress();
                    return true;
                }
                return false;
            }
        });
        final PopupWindow popupWindow = new PopupWindow(context);
        popupWindow.setContentView(mediaOptionsMenu);
        popupWindow.setWidth(LinearLayout.LayoutParams.MATCH_PARENT);
        popupWindow.setHeight(LinearLayout.LayoutParams.MATCH_PARENT);
        popupWindow.setFocusable(true);
        popupWindow.setBackgroundDrawable(null);
        popupWindow.setOutsideTouchable(false);

        popupWindow.showAtLocation(mediaOptionsMenu, Gravity.TOP, 0, 0);

    }

    public interface OnActionCOnformationListner {
        void onConformed();

        void onRejected();
    }

    private void playVideo() {

    }
    public interface OnVideoCompleteListner {

        void onVideoPlayCompleted();

        void onVideoPlayError();

    }
}
