package com.dubuqu.dnServices;

import android.app.IntentService;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.ResultReceiver;
import android.provider.MediaStore;
import android.support.annotation.Nullable;

import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnModels.commonModel.GalleryAlbumList;

import java.util.HashMap;

/**
 * Created by Yogaraj subramanian on 26/10/17
 */

public class MediaLoadAlbumService extends IntentService {

    HashMap<String, GalleryAlbumList> albumList = new HashMap<>();

    private ResultReceiver receiver;

    public MediaLoadAlbumService() {
        super(MediaLoadAlbumService.class.getName());
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        try {
            receiver = intent.getParcelableExtra(Constants.EXTRASTRINGS);
            loadAlbums();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadAlbums() throws Exception {

        String[] mediaProjection = {
                MediaStore.Images.Media.BUCKET_ID,
                MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
                MediaStore.Video.Media.BUCKET_DISPLAY_NAME,
                MediaStore.Files.FileColumns.DATA
        };

        String selection = MediaStore.Files.FileColumns.MEDIA_TYPE + "="
                + MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE
                + " OR "
                + MediaStore.Files.FileColumns.MEDIA_TYPE + "="
                + MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO;

        Uri queryUri = MediaStore.Files.getContentUri("external");

        Cursor cursor = getContentResolver().query(
                queryUri,
                mediaProjection,
                selection,
                null,
                null);

        if (cursor != null) {

            int totalSize = cursor.getCount();

            int iterator = 0;

            while (iterator < totalSize) {

                cursor.moveToPosition(iterator);

                int parentDiretory = cursor.getColumnIndexOrThrow(mediaProjection[1]);

                int videoDirectory = cursor.getColumnIndexOrThrow(mediaProjection[2]);

                int mediaDataIndex = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA);

                String parentName = "";
                if (parentDiretory != -1)
                    parentName = cursor.getString(parentDiretory);

                if (videoDirectory != -1)
                    parentName = cursor.getString(videoDirectory);

                String data = cursor.getString(mediaDataIndex);


                GalleryAlbumList parentValue = albumList.get(parentName);
                if (parentValue == null) {
                    parentValue = new GalleryAlbumList();
                    parentValue.setBucketName(parentName);
                    parentValue.setFirstImagePath(data);
                    parentValue.setImageCount(getNmberOfImagesInFolder(parentName));
                    parentValue.setVideoCount(getNumberOfVideosInFolder(parentName));
                    fetchMeidasInBucket(parentName);
                    albumList.put(parentName, parentValue);
                }

                iterator++;
            }

            Bundle bundle = new Bundle();
            bundle.putSerializable(Constants.EXTRASTRINGS, albumList);

            if (receiver != null)
                receiver.send(Constants.ALBUMLOADRECEIVEREQUEST, bundle);

            cursor.close();

            this.stopSelf();
        }

    }

    /**
     * get number of images count present in a folder.
     *
     * @param folderName String contains the name of the
     * @return Integer count of images
     */
    private int getNmberOfImagesInFolder(String folderName) {

        Uri uri = MediaStore.Files.getContentUri("external");

        String[] mediaProjection = {
                MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
        };

        String selection = MediaStore.Images.ImageColumns.BUCKET_DISPLAY_NAME + " =?";


        Cursor cursor = getContentResolver().query(uri, mediaProjection, selection, new String[]{folderName}, null);

        if (cursor != null) {
            int count = cursor.getCount();
            cursor.close();
            return count;
        }
        return 0;

    }

    /**
     * get number of videos count present in a folder.
     *
     * @param folderName String contains the name of the
     * @return Integer count of videos
     */
    private int getNumberOfVideosInFolder(String folderName) throws Exception {
        Uri uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {MediaStore.Video.Media.DATA};
        String selection = MediaStore.Video.Media.BUCKET_DISPLAY_NAME + " =?";
        String orderBy = MediaStore.Video.Media.DATE_ADDED + " DESC";


        Cursor cursor = getContentResolver().query(uri, projection, selection, new String[]{folderName}, orderBy);

        if (cursor != null) {
            int count = cursor.getCount();
            cursor.close();
            return count;
        }
        return 0;
    }

    private void fetchMeidasInBucket(String bucketName) throws Exception{


        String[] mediaProjection = {
                MediaStore.Files.FileColumns._ID,
                MediaStore.Files.FileColumns.DATE_ADDED,
                MediaStore.Files.FileColumns.MIME_TYPE,
                MediaStore.Files.FileColumns.DATA
        };

        String orderBy = MediaStore.Video.Media.DATE_ADDED + " DESC";

        String selection = MediaStore.Video.Media.BUCKET_DISPLAY_NAME + " =?"
                + " OR "
                + MediaStore.Images.ImageColumns.BUCKET_DISPLAY_NAME + " =?";

        Uri queryUri = MediaStore.Files.getContentUri("external");

        Cursor cursor = getContentResolver().query(queryUri, mediaProjection, selection,
                new String[]{bucketName, bucketName}, orderBy);

        if (cursor != null) {


            int count = cursor.getCount();

            cursor.close();
        }

    }
}
