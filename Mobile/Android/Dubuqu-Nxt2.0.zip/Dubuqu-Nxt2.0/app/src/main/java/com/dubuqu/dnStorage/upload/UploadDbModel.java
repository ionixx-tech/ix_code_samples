package com.dubuqu.dnStorage.upload;

import com.dubuqu.dnConstants.Constants;
import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

/**
 * Created by Yogaraj subramanian on 14/12/17
 * <p>
 * {@link UploadDbModel} the DB model defines the table structure of{#see Constants.UPLOADTABLE}
 * </p>
 */

@DatabaseTable(tableName = Constants.UPLOADTABLE)
public class UploadDbModel {

    @DatabaseField(columnName = Constants.ID, generatedId = true)
    private int id;

    @DatabaseField(columnName = Constants.UPLOADIDENTIFIER)
    private String uploadId;

    @DatabaseField(columnName = Constants.FILE_PATH)
    private String filePath;

    @DatabaseField(columnName = Constants.UPLOAD_STATUS)
    private String uploadStatus;

    @DatabaseField(columnName = Constants.UPLOAD_PROGRESS)
    private int progressValue;

    @DatabaseField(columnName = Constants.UPLOAD_PROGRESS_FILE)
    private String uploadProgress;

    public String getUploadProgress() {
        return uploadProgress;
    }

    public void setUploadProgress(String uploadProgress) {
        this.uploadProgress = uploadProgress;
    }

    public String getUploadId() {
        return uploadId;
    }

    public void setUploadId(String uploadId) {
        this.uploadId = uploadId;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getUploadStatus() {
        return uploadStatus;
    }

    public void setUploadStatus(String uploadStatus) {
        this.uploadStatus = uploadStatus;
    }

    public int getProgressValue() {
        return progressValue;
    }

    public void setProgressValue(int progressValue) {
        this.progressValue = progressValue;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

}
