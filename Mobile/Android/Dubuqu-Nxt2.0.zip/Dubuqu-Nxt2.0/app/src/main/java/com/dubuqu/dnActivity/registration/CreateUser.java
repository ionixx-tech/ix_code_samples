package com.dubuqu.dnActivity.registration;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.content.FileProvider;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.dubuqu.R;
import com.dubuqu.dnActivity.BaseActivity;
import com.dubuqu.dnActivity.LandingActivity;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnModels.requestModel.CreateUserRequest;
import com.dubuqu.dnModels.requestModel.PhoneNumberVerificationRequest;
import com.dubuqu.dnModels.responseModel.CreateUserResponse;
import com.dubuqu.dnRestServices.RestServiceController;
import com.dubuqu.dnRestServices.RestServiceProvider;
import com.dubuqu.dnStorage.SessionManager;
import com.dubuqu.dnUtils.RestServiceUtils;
import com.dubuqu.dnUtils.Utils;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.yalantis.ucrop.UCrop;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import okhttp3.OkHttpClient;
import retrofit2.Retrofit;

/**
 * Created by Yogaraj subramanian on 24/10/17
 */

public class CreateUser extends BaseActivity {

    private final String TAG = CreateUser.class.getName();
    //Image view
    private CircleImageView profileimage;

    //Button
    private Button saveUser;
    //EditText
    private EditText userName, emailId;
    //Text view
    private TextView mobileNumber;
    //boolean
    private boolean isProfileimageSelected = false;
    //Stirng
    private String deviceName;

    private Uri outputFileUri, profilePictureUri = null;

    private PhoneNumberVerificationRequest phoneNumberVerificationRequest;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.create_user);

        try {
            initalizeView();
        } catch (Exception e) {
            CreateUser.super.writeCrashReport(TAG, e.getMessage());
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        if (Constants.RESTRICT_SREENSHOT)
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent result) {
        super.onActivityResult(requestCode, resultCode, result);
        if (resultCode == RESULT_OK) {
            try {

                if (UCrop.REQUEST_CROP == requestCode) {
                    Uri profileUr = UCrop.getOutput(result);
                    if (profileUr != null) {

                        Glide.with(CreateUser.this).load(profileUr).into(profileimage);

                        profilePictureUri = profileUr;
                    }
                } else if (requestCode == Constants.IMAGECPATURE_REQUEST && resultCode == RESULT_OK) {
                    final boolean isCamera;
                    if (result != null && result.hasExtra("remove_image")) {
                                /*remove image */
                        profilePictureUri = null;
                        profileimage.setImageResource(R.drawable.profile);
                        return;
                    } else if (result == null) {
                        isCamera = true;
                    } else {
                        final String action = result.getAction();
                        isCamera = action != null;
                    }

                    if (isCamera) {

                        if (result != null) {
                            profilePictureUri = outputFileUri;
                        } else {
                            profilePictureUri = outputFileUri;
                        }

                    } else {

                        profilePictureUri = result == null ? null : result.getData();
                    }
                    if (profilePictureUri != null)
                        cropImage(profilePictureUri);

                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


    /**
     * Open Crop Activity which allows user to crop their images.
     *
     * @param cropImageUri {@link Uri} the pic user has picked
     * @throws Exception {Runtime Stub Exception}
     */
    private void cropImage(Uri cropImageUri) throws Exception {

        String destinationFileName = String.valueOf(System.currentTimeMillis());
        destinationFileName += ".png";

        UCrop uCrop = UCrop.of(cropImageUri
                , Uri.fromFile(new File(getCacheDir(), destinationFileName)));
        UCrop.Options options = new UCrop.Options();
        options.setCompressionFormat(Bitmap.CompressFormat.PNG);
        options.setCompressionQuality(100);
        options.setHideBottomControls(false);
        options.setFreeStyleCropEnabled(true);
        options.setStatusBarColor(getResources().getColor(R.color.colorPrimaryDark));
        options.setToolbarColor(getResources().getColor(R.color.colorPrimary));
        options.setActiveWidgetColor(getResources().getColor(R.color.colorPrimary));
        uCrop.withOptions(options);
        //uCrop = basisConfig(uCrop);
        //uCrop = advancedConfig(uCrop);
        uCrop.start(CreateUser.this);
    }

    private void initalizeView() throws Exception {

        profileimage = findViewById(R.id.create_user_profile_image);

        saveUser = findViewById(R.id.create_user_save_btn);

        mobileNumber = findViewById(R.id.create_user_mobie_number);

        emailId = findViewById(R.id.create_user_email_edt);

        userName = findViewById(R.id.create_user_name_edt);

        Bundle bundle = getIntent().getExtras();

        phoneNumberVerificationRequest = new Gson().fromJson(
                bundle.getString(Constants.EXTRASTRINGS),
                new TypeToken<PhoneNumberVerificationRequest>() {
                }.getType()
        );

        mobileNumber.setText(phoneNumberVerificationRequest.getCountry_code() + "" +
                phoneNumberVerificationRequest.getMobile_number());

        deviceName = android.os.Build.MANUFACTURER;

        initalizeLiteners();
    }

    private void initalizeLiteners() throws Exception {

        findViewById(R.id.create_user_terms_and_condition).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(
                        "http://52.76.204.166/dubuqu_site/termsandconditions.php"
                ));
                startActivity(browserIntent);
            }
        });
        profileimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    checkifCameraPermissionisProvided();
                } catch (Exception e) {
                    CreateUser.super.writeCrashReport(TAG, e.getMessage());
                }
            }
        });

        saveUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    CheckBox checkBox = findViewById(R.id.create_user_check_box);
                    if (checkBox.isChecked()) {
                        if (profileValidation()) {
                            CreateUser.super.showLoaders(CreateUser.this);
                            createUserHttp();
                        }
                    } else {
                        CreateUser.super.showToastMessage("please accept our terms and conditions", false);
                    }

                } catch (Exception e) {
                    CreateUser.super.writeCrashReport(TAG, e.getMessage());
                }
            }
        });

        userName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                enableSaveButton();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        emailId.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                enableSaveButton();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private void enableSaveButton() {
        if (Utils.isValidusername(userName.getText().toString(), 24)
                && Utils.isValidEmailId(emailId.getText().toString())) {
            saveUser.setBackground(getResources()
                    .getDrawable(R.drawable.registration_vaild_feild_indicator));

            saveUser.setEnabled(true);
        } else {

            saveUser.setBackground(getResources()
                    .getDrawable(R.drawable.registration_pages_button));

            saveUser.setEnabled(false);
        }

    }

    /**
     * check if camera permission is provided.
     *
     * @throws Exception Rutime Stub Exception.
     */
    private void checkifCameraPermissionisProvided() throws Exception {
        if (!super.checkIfPermissionIsGranted(Manifest.permission.CAMERA)) {
            super.requestPermission(new String[]{Manifest.permission.CAMERA}, new PermissionCallBack() {
                @Override
                public void onPermissionGranted() {
                    try {
                        checkifReadandWriteSDcardPermissionisProvided();
                    } catch (Exception e) {
                        CreateUser.super.writeCrashReport(TAG, e.getMessage());
                    }
                }

                @Override
                public void onPermissionRejected() {
                    try {
                        CreateUser.super.showToastMessage(getString(R.string.please_provide_permission_to_continue),
                                false);
                    } catch (Exception e) {
                        CreateUser.super.writeCrashReport(TAG, e.getMessage());
                    }
                }
            });
        } else {
            checkifReadandWriteSDcardPermissionisProvided();
        }
    }

    /**
     * check if read and write external storage permission is provided.
     *
     * @throws Exception Rutime Stub Exception.
     */

    private void checkifReadandWriteSDcardPermissionisProvided() throws Exception {
        if (!super.checkIfPermissionIsGranted(Manifest.permission.READ_EXTERNAL_STORAGE)) {
            super.requestPermission(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE}, new PermissionCallBack() {
                @Override
                public void onPermissionGranted() {
                    try {
                        openImageViewContent();
                    } catch (Exception e) {
                        CreateUser.super.writeCrashReport(TAG, e.getMessage());
                    }
                }

                @Override
                public void onPermissionRejected() {
                    try {
                        CreateUser.super.showToastMessage(getString(R.string.please_provide_permission_to_continue),
                                false);
                    } catch (Exception e) {
                        CreateUser.super.writeCrashReport(TAG, e.getMessage());
                    }
                }
            });
        } else {
            openImageViewContent();
        }
    }

    /**
     * Add Image Media Intents
     *
     * @throws Exception {Run time stub Exception.}
     */
    private void openImageViewContent() throws Exception {
        // Determine Uri of camera image to save.
        final File root = new File(Utils.getRootFolderForProfilePicture(CreateUser.this));
        root.mkdirs();
        final String fname = Utils.getAppName(CreateUser.this) + "_" + System.currentTimeMillis() + "." + Utils.getAppName(CreateUser.this);
        final File sdImageMainDirectory = new File(root.getPath(), fname);
        outputFileUri = Uri.fromFile(sdImageMainDirectory);

        Intent chooserIntent = null;

        List<Intent> intentList = new ArrayList<>();
        Intent pickIntent = new Intent(Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        pickIntent.setType("image/*");

        Intent takePhotoIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (!deviceName.contains("samsung")) {
            Uri photoURI = FileProvider.getUriForFile(CreateUser.this,
                    com.dubuqu.BuildConfig.APPLICATION_ID + ".provider",
                    sdImageMainDirectory);
            takePhotoIntent.putExtra("return-data", true);
            takePhotoIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
        }
        intentList = addIntentsToList(CreateUser.this, intentList, pickIntent);
        intentList = addIntentsToList(CreateUser.this, intentList, takePhotoIntent);

        if (intentList.size() > 0) {
            for (int i = 0; i < intentList.size(); i++) {
            }
            chooserIntent = Intent.createChooser(intentList.remove(intentList.size() - 1),
                    ("Pick image From"));
            chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, intentList.toArray(new Parcelable[]{}));
        }

        startActivityForResult(chooserIntent, Constants.IMAGECPATURE_REQUEST);

    }

    /**
     * add avialable camera nad gallery apps that can provide images
     *
     * @param context {Context of the Activity}
     * @param list    {package name list}
     * @param intent  {intnet to trigger}
     * @return {List}
     */
    private static List<Intent> addIntentsToList(Context context, List<Intent> list, Intent intent) {
        List<ResolveInfo> resInfo = context.getPackageManager().queryIntentActivities(intent, 0);
        for (ResolveInfo resolveInfo : resInfo) {
            String packageName = resolveInfo.activityInfo.packageName;
            Intent targetedIntent = new Intent(intent);
            targetedIntent.setPackage(packageName);
            list.add(targetedIntent);
        }
        return list;
    }

    /**
     * Check if user name and email id is vaild.
     *
     * @throws Exception Runtimr Stub Exception.
     */
    private boolean profileValidation() throws Exception {

        String username = userName.getText().toString();
        String emailid = emailId.getText().toString();

        if (username.equalsIgnoreCase("")) {
            userName.setError(getString(R.string.user_registration_form_empty_name_message));
            return false;
        }

        if (emailid.equalsIgnoreCase("")) {
            emailId.setError(getString(R.string.user_registration_form_empty_email_message));
            return false;
        }

        if (!Utils.isValidEmailId(emailid)) {
            emailId.setError(getString(R.string.user_registration_form_invalid_email_message));
            return false;
        }

        if (!Utils.isValidusername(username, 24)) {
            userName.setError(getString(R.string.user_registration_form_invalid_name_message));
            return false;
        }

        return true;
    }

    /**
     * make http request to create user in Dubuqu Server.
     */

    private void createUserHttp() throws Exception {

        CreateUserRequest createUserRequest = new CreateUserRequest();

        SessionManager sessionManager = new SessionManager(CreateUser.this);

        createUserRequest.setUser_name(userName.getText().toString().trim());
        createUserRequest.setEmail_id(emailId.getText().toString().trim());
        createUserRequest.setMobile_number(phoneNumberVerificationRequest.getMobile_number());
        createUserRequest.setVerification_code(phoneNumberVerificationRequest.getVerification_code());
        createUserRequest.setCountry_code(phoneNumberVerificationRequest.getCountry_code());
        createUserRequest.setDevice_id(Utils.getDeviceIMEI(CreateUser.this));
        createUserRequest.setDevice_notification_key(sessionManager.getOneSignaleToken());
        createUserRequest.setDevice_type(Constants.DEVICE_TYPE);
        createUserRequest.setGender("male");

        String requestData = new Gson().toJson(createUserRequest);

        OkHttpClient okHttpClient = RestServiceUtils.getHeader(requestData, getApplicationContext());
        Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
        RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
        RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);

        mRetrofitCallBacks.createUser(new RestServiceController.ResponseCallBacks() {
            @Override
            public void onResponse(Object o) {
                try {
                    storeUserDataInSession((CreateUserResponse) o);
                } catch (Exception e) {
                    CreateUser.super.writeCrashReport(CreateUser.class.getName(),
                            e.getMessage());
                }
            }

            @Override
            public void onFailure(Object o) {
                if (o != null) {
                    try {
                        CreateUser.super.cancelPopUp();
                    } catch (Exception e) {
                        writeCrashReport(TAG, e.getMessage());
                    }
                    if (o instanceof retrofit2.Response) {
                        //invalid request is made or getting any error
                        try {
                            CreateUser.super.showToastMessage(((retrofit2.Response) o).message(), false);
                        } catch (Exception e) {
                            CreateUser.super.writeCrashReport(CreateUser.class.getName(),
                                    e.getMessage());
                        }
                    } else if (o instanceof Throwable) {
                        try {
                            CreateUser.super.showToastMessage(((Throwable) o).getMessage(), false);
                        } catch (Exception e) {
                            CreateUser.super.writeCrashReport(CreateUser.class.getName(),
                                    e.getMessage());
                        }
                    }
                }
            }
        }, createUserRequest);
    }


    /**
     * store user data locally so that it can be used later.
     *
     * @param createUserResponse {CreateUserResponse} which contains the userid and secrect key.
     * @throws Exception {RunTime Stub Exception}
     */
    private void storeUserDataInSession(CreateUserResponse createUserResponse) throws Exception {
        SessionManager sessionManager = new SessionManager(CreateUser.this);
        //sets that user is logged in.
        sessionManager.setIsLoggedIn(true);
        //save user details in session.
        sessionManager.createLoginSession(
                createUserResponse.getUser_identifier(),
                userName.getText().toString(),
                phoneNumberVerificationRequest.getMobile_number(),
                emailId.getText().toString(),
                createUserResponse.getSecret_key(),
                "male",
                getRealPathFormUri()
        );

        sessionManager.setCountrycode(phoneNumberVerificationRequest.getCountry_code());

        if (profilePictureUri != null) {

            uploadProfilePhoto(createUserResponse.getUser_identifier());

            sessionManager.updateUserProfileImage(
                    profilePictureUri.getPath()
            );
        }

        CreateUser.super.cancelPopUp();

        Intent intent = new Intent(CreateUser.this, LandingActivity.class);
        startActivity(intent);
        finish();
    }

    /**
     * upload user profile profile photo to server.
     */
    private void uploadProfilePhoto(String userIdentifier) throws Exception {
        RestServiceUtils.updateUserProfilePic(CreateUser.this, 150, userIdentifier,
                profilePictureUri.getPath());
    }


    private String getRealPathFormUri() throws Exception {

        if (profilePictureUri == null)
            return null;

        return profilePictureUri.getPath();
    }
}
