package com.dubuqu.dnConstants;

/**
 * Created by Yogaraj subramanian on 14/12/17
 */

public class UploadConstants {

    public enum UPLOADSTATUS {
        SUCCESS,
        FAILURE,
        PROGRESS,
        UPLOADING,
        PAUSE,
        CANCELLED,
        NOTYETSTARTED
    }
}
