package com.dubuqu.dnMediaCompression;

import android.annotation.SuppressLint;
import android.content.Context;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;

import com.dubuqu.dnApplication.AppController;
import com.dubuqu.dnCallbacks.Callbacks;
import com.dubuqu.dnUtils.Utils;
import com.github.hiteshsondhi88.libffmpeg.FFmpeg;
import com.github.hiteshsondhi88.libffmpeg.FFmpegExecuteResponseHandler;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static android.content.ContentValues.TAG;


/**
 * Created by Yogaraj subramanian on 26/4/17
 */
@SuppressLint("StaticFieldLeak")
public class VideoCompressor {

    private Callbacks.CompressionCallback compressionCallback;
    private Context context;

    private FFmpeg ffmpeg;
    private int bitRate = 0, frameRate = 0;
    private long videoLengthInSec;
    private long fileSize = 0;

    private CompressVideoBackgound compressVideoBackgound;

    public VideoCompressor(Callbacks.CompressionCallback compressionCallback, Context context) {
        this.compressionCallback = compressionCallback;
        this.context = context;
    }

    public void startCompression(String filepath) throws Exception {
        compressVideoBackgound = new CompressVideoBackgound();
        compressVideoBackgound.execute(filepath);
    }


    public void cancelCompression() throws Exception {
        ffmpeg.killRunningProcesses();
        compressVideoBackgound.cancel(true);
    }

    class CompressVideoBackgound extends AsyncTask<String, String, String> {

        @Override
        protected String doInBackground(final String... params) {
            try {
                if (checkIfConentIntent(params[0])) {
                    String filePath = getLocalVideoPath(Uri.parse(params[0]));
                    initalizeFFmeg(filePath);
                } else {
                    initalizeFFmeg(params);
                }
            } catch (Exception e) {
                return null;
            }
            return null;
        }

    }


    private boolean checkIfConentIntent(String filePath) {

        return filePath.contains("content://");

    }


    private String getLocalVideoPath(Uri videoUri) throws Exception {

        if (videoUri.toString().contains("content://")) {

            InputStream inputStream =
                    context.getContentResolver().openInputStream(videoUri);

            File filesDir = context.getCacheDir();
            File imageFile = new File(filesDir, Math.random() + ".mp4");

            if (inputStream != null) {

                OutputStream os = new FileOutputStream(imageFile);

                byte[] buffer = new byte[1024];
                int bytesRead;
                //read from is to buffer
                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    os.write(buffer, 0, bytesRead);
                }
                inputStream.close();
                //flush OutputStream to write any buffered data to file
                os.flush();
                os.close();
            }

            return imageFile.getPath();
        }

        return null;
    }


    private boolean checkifoverloded(String message) throws Exception {

        String currentSizeS = Utils.getVideoSize(message);
        if (currentSizeS == null)
            return false;
        long currentsize = Long.parseLong(currentSizeS);
        return currentsize > fileSize;
    }


    /**
     * get video bitrate from Vlog
     *
     * @param vkLog path of the vidoe file
     * @return Integer value
     */
    private String getVideoBitRate(String vkLog) throws Exception {
        String bitRate = null;

        int i1 = vkLog.indexOf("bitrate:");

        String subString = vkLog.substring(i1);

        int i2 = subString.indexOf("kb/s");
        if (i1 != -1 && i2 != -1) {
            bitRate = subString.substring(0, i2);

            bitRate = bitRate.replaceAll("[-+.^:,]", "");

            bitRate = bitRate.replaceAll("[^\\d.]", "");
        }

        return bitRate;
    }

    /**
     * get video frame rate from Vlog
     *
     * @param vkLog path of the vidoe file
     * @return Integer value
     */
    private String getVideoFrameRate(String vkLog) throws Exception {
        String frameRate = null;

        int i1 = vkLog.indexOf("fps");

        String subString = vkLog.substring(0, i1);

        int i2 = subString.lastIndexOf(",");

        frameRate = subString.substring(i2 + 1, i1);

//        Pattern pt = Pattern.compile("[^0-9]");
//        Matcher match = pt.matcher(frameRate);
//        while (match.find()) {
//            String s = match.group();
//            frameRate = frameRate.replaceAll("\\" + s, "");
//        }

        return frameRate.trim();
    }

    /**
     * get orientation of the video
     *
     * @param filePath path of the video file
     * @return Integer value {0,1}
     */
    private int getVideoOrientaion(String filePath) throws Exception {
        MediaMetadataRetriever metaRetriever = new MediaMetadataRetriever();
        metaRetriever.setDataSource(filePath);
        return Integer.valueOf(metaRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION));
    }

    /**
     * Split string into char array or string array
     *
     * @param str the strinfg need to be splited
     * @return array of strings.
     */
    private String[] utilConvertToComplex(String str) throws Exception {
        String[] complex = str.split(",");
        return complex;
    }

    /**
     * calculate the progress value on compression
     *
     * @param message the log retruned from compiler
     * @return Long value.
     */
    private long getProgress(String message) {
        Pattern pattern = Pattern.compile("time=([\\d\\w:]+)");
        if (message.contains("speed")) {
            Matcher matcher = pattern.matcher(message);
            matcher.find();
            String tempTime = String.valueOf(matcher.group(1));
            String[] arrayTime = tempTime.split(":");
            long currentTime =
                    TimeUnit.HOURS.toSeconds(Long.parseLong(arrayTime[0]))
                            + TimeUnit.MINUTES.toSeconds(Long.parseLong(arrayTime[1]))
                            + Long.parseLong(arrayTime[2]);

            return 100 * currentTime / videoLengthInSec;
        }
        return 0;
    }


    /**
     * @param vkLog the log data send form ffmeg console
     * @return the path of the output file
     */
    private static String getOutPutPath(String vkLog) {
        String outPutFile = null;
        try {
            int firstDubStringIndex = vkLog.indexOf("Output #0,");

            if (firstDubStringIndex != -1) {
                String subStringInput_0 = vkLog.substring(firstDubStringIndex);
                int indexOfColon = subStringInput_0.indexOf(":");
                if (indexOfColon != -1) {
                    String inputString = subStringInput_0.substring(0, indexOfColon);
                    Pattern p = Pattern.compile("\'([^\']*)\'");
                    Matcher m = p.matcher(inputString);
                    while (m.find()) {
                        outPutFile = m.group(1);
                    }
                }
            }

        } catch (Exception e) {
            return null;
        }
        return outPutFile;
    }


    /**
     * initalize ffmeg compressor
     */
    private void initalizeFFmeg(final String... params) throws Exception {

        ffmpeg = AppController.getfFmpeg();

        try {
            getVideoDetails(params);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * get information for the video.
     *
     * @param params the video file path.
     * @throws Exception exception may be thrown.
     */
    private void getVideoDetails(final String[] params) throws Exception {

        String command = "-i," + params[0];
        ffmpeg.execute(utilConvertToComplex(command), new FFmpegExecuteResponseHandler() {
            @Override
            public void onSuccess(String message) {
                try {
                    double bitRate = Double.parseDouble(getVideoBitRate(message));

                    double frameRate = Double.parseDouble(getVideoFrameRate(message));

                    VideoCompressor.this.bitRate = (int) bitRate;
                    VideoCompressor.this.frameRate = (int) frameRate;

                    compressVideo(params);

                } catch (Exception e) {
                    compressionCallback.onFailed();
                    e.printStackTrace();
                }

            }

            @Override
            public void onProgress(String message) {

            }

            @Override
            public void onFailure(String message) {
                try {

                    double bitRate = Double.parseDouble(getVideoBitRate(message));

                    double frameRate = Double.parseDouble(getVideoFrameRate(message));

                    VideoCompressor.this.bitRate = (int) bitRate;

                    VideoCompressor.this.frameRate = (int) frameRate;

                    compressVideo(params);
                } catch (Exception e) {
                    e.printStackTrace();
                    compressionCallback.onFailed();
                }
            }

            @Override
            public void onStart() {

            }

            @Override
            public void onFinish() {

            }
        });
    }

    /**
     * compresses the video
     *
     * @param params url of the file path
     */
    private void compressVideo(final String... params) throws Exception {

        final File file = new File(params[0]);
        fileSize = file.length();
        fileSize = fileSize / 1024;

        MediaPlayer mp = MediaPlayer.create(context, Uri.parse(params[0]));
        videoLengthInSec = TimeUnit.MILLISECONDS.toSeconds(mp.getDuration());

        Random random = new Random();
        String mOutputFile = context.getCacheDir() + "/" + random.nextInt(1000) + ".mp4";

        if (bitRate < 1300) {
            compressionCallback.getCompressedFilePath(params[0]);
        } else {


            if (frameRate > 26) {
                int tenPercentOftotalRate = (bitRate * 60) / 100;
                frameRate = 25;
                bitRate = bitRate - tenPercentOftotalRate;
            } else if (frameRate <= 26 && bitRate > 2000) {
                bitRate = bitRate / 2;
                frameRate = 23;
            }

            String[] command = {"-y", "-i",
                    params[0], "-vcodec", "mpeg4",
                    "-preset", "veryfast", "-b:v", bitRate + "k", "-r",
                    frameRate + "", "-acodec", "copy", mOutputFile};

            ffmpeg.execute(command, new

                    FFmpegExecuteResponseHandler() {
                        @Override
                        public void onSuccess(String message) {
                            String outPutfilePath = getOutPutPath(message);
                            try {
                                File file1 = new File(outPutfilePath);
                                Log.d(TAG, "CompressedFileSize---------------> " +
                                        file1.length() / 1204 + "kb");

                                compressionCallback.getCompressedFilePath(outPutfilePath);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }

                        @Override
                        public void onProgress(String message) {

                            Log.d(TAG, "Compression Progess------------>:" +
                                    getProgress(message));

                            String duration = Utils.getVideoDuration(message);
                            if (duration != null) {

                            } else {
                                try {
                                    if (checkifoverloded(message)) {
                                        ffmpeg.killRunningProcesses();
                                        Log.d(TAG, "CompressedFileSize---------------> " +
                                                params[0].length() / 1204 + "kb");
                                        compressionCallback.getCompressedFilePath(params[0]);

                                    } else {
                                        compressionCallback.onUpdateProgress((int) getProgress(message));
                                    }

                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        }

                        @Override
                        public void onFailure(String message) {
                            Log.d(TAG, "onFailure Compression---------->: " + message);
                            compressionCallback.onFailed();
                        }

                        @Override
                        public void onStart() {

                        }

                        @Override
                        public void onFinish() {

                        }
                    });
        }
    }


}

