package com.dubuqu.dnUtils;

import android.Manifest;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.media.ExifInterface;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.telephony.TelephonyManager;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.webkit.MimeTypeMap;

import com.amulyakhare.textdrawable.TextDrawable;
import com.dubuqu.R;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnModels.responseModel.MediaLikeDetails;
import com.dubuqu.dnStorage.SessionManager;
import com.onesignal.shortcutbadger.ShortcutBadger;
import com.valdesekamdem.library.mdtoast.MDToast;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Formatter;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/**
 * Created by Yogaraj subramanian on 8/6/17
 */

public class Utils {

    private static final Bitmap.Config BITMAP_CONFIG = Bitmap.Config.ARGB_8888;


    /**
     * get resolution the video.
     *
     * @param filepath the file where the video is located
     * @return Array of String Array[0]=>width, Array[1]=> height
     * @throws Exception Runtime Stub Exception
     */
    public static String[] getResolution(String filepath) throws Exception {
        String[] values = new String[2];
        if (getContentType(filepath).contains("mp4") || getContentType(filepath).contains("video")) {
            MediaMetadataRetriever metaRetriever = new MediaMetadataRetriever();
            metaRetriever.setDataSource(filepath);
            values[0] = metaRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT);
            values[1] = metaRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH);

            return values;
        } else {
            ExifInterface exif = new ExifInterface(filepath);
            int width = exif.getAttributeInt(ExifInterface.TAG_IMAGE_WIDTH, 1280);
            int height = exif.getAttributeInt(ExifInterface.TAG_IMAGE_LENGTH, 720);
            values[0] = String.valueOf(width);
            values[1] = String.valueOf(height);
            return values;
        }
    }

    public static void getVideoContentURI(int id) {

    }

    /**
     * for video compression we need to check the current frame rate.
     *
     * @param path the video path which contains the video
     * @return Integer value example: 24,30,...
     */
    public static int getFrameRate(String path) throws Exception {
        MediaExtractor mex = new MediaExtractor();
        try {
            mex.setDataSource(path);// the adresss location of the sound on sdcard.
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        MediaFormat mf = mex.getTrackFormat(0);

        return mf.getInteger(MediaFormat.KEY_FRAME_RATE);
    }


    /**
     * get the bitrate of the video retruns in KB
     *
     * @param filepath the actual location of the video
     * @return Integer value eg.1200 kB
     * @throws Exception Runtime Stub Exception.
     */
    public static int getBitrate(String filepath) throws Exception {
        String[] values = new String[2];

        MediaMetadataRetriever metaRetriever = new MediaMetadataRetriever();
        metaRetriever.setDataSource(filepath);
        return Integer.valueOf(metaRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE));

    }

    /**
     * get the actual video duration the original video duration is needed to calulate the progress.
     *
     * @param filePath the file path of the video file
     * @return Integer value example:12000 seconds.
     */
    public static int getVideoOrientaion(String filePath) throws Exception {
        MediaMetadataRetriever metaRetriever = new MediaMetadataRetriever();
        metaRetriever.setDataSource(filePath);
        return Integer.valueOf(metaRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION));
    }

    public static boolean isVaildString(String profileUrl) {
        return profileUrl != null && !profileUrl.equalsIgnoreCase("");
    }

    /*enum for choosing tyoe of contact
    * i.e dubuqcontact or phonecontact or socialgroup*/
    public enum DUBUQU_CATEGORY {
        DUBUQU_CONTACT,
        PHONE_CONTACT,
        SOCIAL_GROUP,
        SOCIAL_OPEN_GROUP,
        HEADER
    }

    /*get the mime type of a file*/
    public static String getMimeType(String url) {
        String type = "image";
        String extension = MimeTypeMap.getFileExtensionFromUrl(url);
        if (extension != null) {
            type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
            if (type != null)
                type = type.substring(0, type.indexOf("/"));
        }
        if (type == null) {
            type = extension;
        }
        if (type == null || type.length() == 0) {
            type = url.substring(url.lastIndexOf(".") + 1); // Without dot jpg, png

        }
        return type.toLowerCase();
    }

    /**
     * get the content type of the media.
     *
     * @param url file path of the media.
     * @return Stirng example:image/png,video/mp4,image/gif etc.
     */
    public static String getContentType(String url) {
        String type = null;
        String extension = url.substring(url.lastIndexOf(".") + 1);

        if (extension.equalsIgnoreCase("gif"))
            return "gif";
        if (extension != null) {
            type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
            if (type != null)
                type = type.substring(0, type.indexOf("/"));
        }
        if (type == null) {
            type = "image";
        }
        return type;
    }

    /**
     * Check if media is liked by the user or not.
     *
     * @param context  {@link Context } context of the calling Activity or Fragment
     * @param response {@link MediaLikeDetails} {@link List} list of like response data.
     * @return {@link Boolean} true or false
     */
    public static boolean isPostLikedByUser(Context context, List<MediaLikeDetails> response) {
        SessionManager sessionManager = new SessionManager(context);
        String userIdentifier = sessionManager.getUserIdentifier();
        if (userIdentifier == null)
            return false;
        for (MediaLikeDetails item : response) {
            if (userIdentifier.equalsIgnoreCase(item.getUserIdentifier()))
                return true;
        }

        return false;
    }

    public static String getFileExtension(String url) {
        try {
            return url.substring(url.lastIndexOf(".") + 1).toLowerCase();
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }

    }


    /**
     * format the date of the medias
     *
     * @param d Date the meida is created
     * @return Date
     */
    public static Date formatDate(long d) throws Exception {
        try {
            SimpleDateFormat fmtOut = new SimpleDateFormat("EEEE, MMM d yyyy");

            String dates = fmtOut.format(d * 1000);
            return fmtOut.parse(dates);
        } catch (Exception e) {
            return new Date(d * 1000);
        }
    }


    /*------------------------------------HMAC CALULATOR------------------------------------------*/

    /*@params value payload to be send
 * @params key secret key at time of registration*/
    private static String hmacSha1(String value, String key) throws Exception {
        String type = "HmacSHA1";
        SecretKeySpec secret = new SecretKeySpec(key.getBytes(), type);
        Mac mac = Mac.getInstance(type);
        mac.init(secret);
        byte[] bytes = mac.doFinal(value.getBytes());
        return bytesToHex(bytes);
    }


    private static final String HMAC_SHA1_ALGORITHM = "HmacSHA1";
    /**
     * converts string to char array.
     * <p>
     * please donot remove \' HmacSHA1 doesnt accept ' value.
     */
    private final static char[] hexArray = "0123456789abcdef\'".toCharArray();

    /**
     * calulates the hmac values.
     *
     * @param bytes the byte array whoes hmac need to be found
     * @return String of HMAC Values
     */
    private static String bytesToHex(byte[] bytes) throws Exception {
        char[] hexChars = new char[bytes.length * 2];
        int v;
        for (int j = 0; j < bytes.length; j++) {
            v = bytes[j] & 0xFF;
            hexChars[j * 2] = hexArray[v >>> 4];
            hexChars[j * 2 + 1] = hexArray[v & 0x0F];
        }
        return new String(hexChars);
    }

    private static String toHexString(byte[] bytes) {
        Formatter formatter = new Formatter();

        for (byte b : bytes) {
            formatter.format("%02x", b);
        }

        return formatter.toString();
    }

    public static String calculateRFC2104HMAC(String data, String key) {
        try {
            SecretKeySpec signingKey = new SecretKeySpec(key.getBytes(), HMAC_SHA1_ALGORITHM);
            Mac mac = Mac.getInstance(HMAC_SHA1_ALGORITHM);
            mac.init(signingKey);
            return toHexString(mac.doFinal(data.getBytes()));
        } catch (Exception e) {
            return "";
        }
    }

    public static boolean checkIfServiceRunning(final Class<?> serviceClass, final Context context) {
        ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        assert manager != null;
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }


    public static void hideSoftKeyBoard(Activity activity) {
        try {

            InputMethodManager imm = (InputMethodManager) activity.getSystemService(
                    Context.INPUT_METHOD_SERVICE);
            assert imm != null;
            imm.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), 0);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static void showSoftKeyBoard(Activity activity) {
        try {
            InputMethodManager imm = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /*
   * converts file size into MegaBytes
   * @params file => the file whoes size need to be found.
   * @return double => the size of the file in double value type;
   * */
    public static double getFileSize(File file) {
        double bytes = file.length();
        double kilobytes = (bytes / 1024);
        double megabytes = (kilobytes / 1024);
        return megabytes;
    }


    /* ************************ Checking Internet Connection ******************* */

    public static boolean isDataConectionAvailable(Context _context) {
        ConnectivityManager connectivity = (ConnectivityManager) _context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivity != null) {
            NetworkInfo[] info = connectivity.getAllNetworkInfo();
            if (info != null)
                for (int i = 0; i < info.length; i++)
                    if (info[i].getState() == NetworkInfo.State.CONNECTED) {
                        return true;
                    }
        }
        return false;
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR1)
    public static boolean isRtl(Resources res) {
        return (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) &&
                (res.getConfiguration().getLayoutDirection() == View.LAYOUT_DIRECTION_RTL);
    }

    /**
     * convert string to drawable to display inital letter as indicator if no image is available
     *
     * @param text    the name of the gorup or user
     * @param context context of the calling activity or fragment
     * @return Bitmap
     * @throws Exception
     */
    public static Bitmap textAsBitmap(String text, Context context) throws Exception {
        Typeface typeface = Typeface.createFromAsset(context.getResources().getAssets(), Constants.FONT_LIGHT);

        int firstChar = (int) text.charAt(0);


        int randomColor = (firstChar % 4) == 0 ? context.getResources().getColor(R.color.red_color_picker)
                : context.getResources().getColor(R.color.red_color_picker);

        TextDrawable textDrawable = TextDrawable.builder().beginConfig()
                .useFont(typeface)
                .toUpperCase()
                .endConfig()
                .buildRound(String.valueOf(text.charAt(0)),
                        randomColor);

        return getBitmapFromDrawable(textDrawable);
    }

    public static Bitmap textAsBitmapRoundRect(String text, Context context, int radius)
            throws Exception {
        Typeface typeface = Typeface.createFromAsset(context.getResources().getAssets(), Constants.FONT_LIGHT);

        int firstChar = (int) text.charAt(0);


        int randomColor = (firstChar % 4) == 0 ? Color.parseColor("#000000")
                : Color.parseColor("#000000");

        TextDrawable textDrawable = TextDrawable.builder().beginConfig()
                .useFont(typeface)
                .toUpperCase()
                .endConfig()
                .buildRoundRect(String.valueOf(text.charAt(0)),
                        randomColor, radius);

        return getBitmapFromDrawable(textDrawable);
    }

    public static Bitmap createNoOfMediaLeft(String text, Context context) {
        Typeface typeface = Typeface.createFromAsset(context.getResources().getAssets(), Constants.FONT_LIGHT);

        int randomColor = Color.parseColor("#99000000");

        TextDrawable textDrawable = TextDrawable.builder().beginConfig()
                .useFont(typeface)
                .toUpperCase()
                .endConfig()
                .buildRect(text,
                        randomColor);

        return getBitmapFromDrawable(textDrawable);
    }

    /**
     * @param drawable
     * @return
     */
    private static Bitmap getBitmapFromDrawable(TextDrawable drawable) {

        if (drawable == null) {
            return null;
        }
        try {
            Bitmap bitmap;
            int w = drawable.getIntrinsicWidth() > 0 ? drawable.getIntrinsicWidth() : 500;
            int h = drawable.getIntrinsicHeight() > 0 ? drawable.getIntrinsicHeight() : 500;
            bitmap = Bitmap.createBitmap(w, h, BITMAP_CONFIG);
            Canvas canvas = new Canvas(bitmap);
            drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
            drawable.draw(canvas);
            return bitmap;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static Bitmap getBitmapFromDrawable(Drawable drawable) {

        if (drawable == null) {
            return null;
        }
        try {
            Bitmap bitmap;
            int w = drawable.getIntrinsicWidth() > 0 ? drawable.getIntrinsicWidth() : 100;
            int h = drawable.getIntrinsicHeight() > 0 ? drawable.getIntrinsicHeight() : 100;
            bitmap = Bitmap.createBitmap(w, h, BITMAP_CONFIG);
            Canvas canvas = new Canvas(bitmap);
            drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
            drawable.draw(canvas);
            return bitmap;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }


    /**
     * show toast in green color for indicating positive senario.
     *
     * @param context context of the calling activity or fragments.
     * @param message the message that need to be shown in the toast.
     */
    public static void showToast(Context context, String message) {
        MDToast mdToast = MDToast.makeText(context, message, MDToast.LENGTH_SHORT, MDToast.TYPE_SUCCESS);
        mdToast.show();
    }

    /**
     * show toast in red color for indicating negative senario.
     *
     * @param context context of the calling activity or fragments.
     * @param message the message that need to be shown in the toast.
     */
    public static void showNegativeTost(Context context, String message) {
        MDToast mdToast = MDToast.makeText(context, message, MDToast.LENGTH_SHORT, MDToast.TYPE_ERROR);
        mdToast.show();
    }

    /**
     * @param vkLog the log data send form ffmeg console
     * @return the path of the output file
     */
    public static String getOutPutPath(String vkLog) {
        String outPutFile = null;
        try {
            int firstDubStringIndex = vkLog.indexOf("Output #0,");

            if (firstDubStringIndex != -1) {
                String subStringInput_0 = vkLog.substring(firstDubStringIndex);
                int indexOfColon = subStringInput_0.indexOf(":");
                if (indexOfColon != -1) {
                    String inputString = subStringInput_0.substring(0, indexOfColon);
                    Pattern p = Pattern.compile("\'([^\']*)\'");
                    Matcher m = p.matcher(inputString);
                    while (m.find()) {
                        outPutFile = m.group(1);
                    }

                }
            }

        } catch (Exception e) {

        }
        return outPutFile;
    }

    public static String[] utilConvertToComplex(String str) {
        String[] complex = str.split(",");
        return complex;
    }

    /**
     * get the total duration of the video need to be compressed.
     *
     * @param progressLog the log data returned form ffmeg console,
     * @return null if the duration and start text is missing,
     * or string of time in format 00:00:00.00
     * sample out put: 00:04:30.55
     */
    public static String getVideoDuration(String progressLog) {
        String duration = null;
        try {
            int i1 = progressLog.indexOf("Duration:");
            int i2 = progressLog.indexOf(", start");
            if (i1 != -1 && i2 != -1) {
                duration = progressLog.substring(i1 + 10, i2);

            }
        } catch (Exception e) {

        }
        return duration;
    }


    /**
     * @param progressLog
     * @return null if the size is not available or string of size in length
     */
    public static String getVideoSize(String progressLog) throws Exception {
        String size = null;
        try {
            int i1 = progressLog.indexOf("size=");
            int i2 = progressLog.indexOf("time=");
            if (i1 != -1 && i2 != -1) {
                size = progressLog.substring(i1, i2);
                size = size.replaceAll("[^\\d.]", "");
                size = size.trim();
            }
        } catch (Exception e) {

        }
        return size;
    }

    /**
     * store the profile pic of the user in the root directory of the app folder
     *
     * @param mContext context of the resource
     * @return return String value
     */
    public static String getRootFolderForProfilePicture(Context mContext) throws Exception {
        String appName = getAppName(mContext);
        String dirName = getRootFolderOfApp(mContext) + appName + " Profile Pictures" + File.separator;
        isDirectoryExists(dirName);
        return dirName;
    }

    public static String getAppName(Context mContext) throws Exception {
        return mContext.getResources().getString(R.string.app_name);
    }

    /**
     * get the root director of the app folder
     *
     * @param mContext context
     * @return string value
     */
    public static String getRootFolderOfApp(Context mContext) throws Exception {
        String appName = getAppName(mContext);
        String dirName = Environment.getExternalStorageDirectory().toString() + File.separator + appName + File.separator;
        isDirectoryExists(dirName);
        return dirName;
    }

    /**
     * check if directory exits
     *
     * @param dirName name of the dir
     * @return boolean value true or false
     */
    public static boolean isDirectoryExists(String dirName) throws Exception {
        File dirStructure = new File(dirName);
        if (!dirStructure.exists()) {
            dirStructure.mkdirs();
            return true;
        } else {
            return false;
        }
    }

    @SuppressLint("HardwareIds")
    public static String getDeviceIMEI(Context context) throws Exception {
        String deviceIEMI = null;
        TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        if (telephonyManager != null) {

            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE)
                    == PackageManager.PERMISSION_GRANTED) {
                deviceIEMI = telephonyManager.getDeviceId();
                return deviceIEMI;
            }

        }
        return null;
    }

    /**
     * checks if entered phonenUmber is valid or not
     *
     * @param phoneNumber string that need to be validated
     * @return boolean value.
     */
    public static boolean isValidPhoneNumber(String phoneNumber) {

        String phoneNumberPattern = "^[0-9]{1,15}$";

        Pattern pattern = Pattern.compile(phoneNumberPattern);
        Matcher matcher = pattern.matcher(phoneNumber.substring(1));

        return matcher.matches();
        // return false;
    }

    public static boolean isValidEmailId(String emailId) {

        return emailId != null && emailId.length() != 0 &&
                android.util.Patterns.EMAIL_ADDRESS.matcher(emailId).matches();
    }

    public static boolean isValidusername(String userName, int length) {

        if (userName.length() == 0)
            return false;

        String lengths = String.valueOf(length);
        String userNamePatern = "^[a-zA-Z0-9 ]{3," + lengths + "}$";
        Pattern pattern = Pattern.compile(userNamePatern);
        Matcher matcher = pattern.matcher(userName.substring(1));

        return matcher.matches();

    }

    /*-----------------------------------------Media Service Utis---------------------------------*/


    /**
     * Fetch number of images present in sd card.
     *
     * @param context Context of the calling activity or class
     * @return Integer value
     * @throws Exception Runtime Stub Exception
     */
    public int getImageCount(Context context) throws Exception {

        String selection = MediaStore.Files.FileColumns.MEDIA_TYPE + "="
                + MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE;

        Uri queryUri = MediaStore.Files.getContentUri("external");

        Cursor cursor = context.getContentResolver().query(
                queryUri,
                null,
                selection,
                null,
                null);

        if (cursor != null) {

            int c = cursor.getCount();

            cursor.close();
            return c;
        } else {
            return 0;
        }

    }

    /**
     * Fetch number of Videos present in sd card.
     *
     * @param context Context of the calling activity or class
     * @return Integer value
     * @throws Exception Runtime Stub Exception
     */
    public int getVideoCount(Context context) throws Exception {

        String selection = MediaStore.Files.FileColumns.MEDIA_TYPE + "="
                + MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO;

        Uri queryUri = MediaStore.Files.getContentUri("external");

        Cursor cursor = context.getContentResolver().query(
                queryUri,
                null,
                selection,
                null,
                null);

        if (cursor != null)
            return cursor.getCount();
        else
            return 0;
    }


    public static long getVideoDurationInMilliSec(String url) throws Exception {
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        retriever.setDataSource(url);
        String time = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
        return time == null ? 00 : Long.parseLong(time);
    }

    public static String getVideoDurationString(long millis) throws Exception {
        return String.format("%02d : %02d ",
                TimeUnit.MILLISECONDS.toMinutes(millis),
                TimeUnit.MILLISECONDS.toSeconds(millis) -
                        TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millis))
        );
    }

    public static int convertUnitToDp(Context context, int sizeInDp) throws Exception {

        float scale = context.getResources().getDisplayMetrics().density;

        return (int) (sizeInDp * scale + 0.5f);
    }


    /**
     * on item click add reppel effect to view
     *
     * @param view the view the reppel effect need to be added
     */
    public static void addReppleEffectToview(Context context, View view) throws Exception {
        int[] attrs = new int[]{R.attr.selectableItemBackground};

        TypedArray ta = context.obtainStyledAttributes(attrs);

        Drawable drawableFromTheme = ta.getDrawable(0);

        view.setBackground(drawableFromTheme);

        ta.recycle();
    }


    public static void setBadge(Context context) throws Exception {

        int count = new SessionManager(context).getBadgeCount();
        if (count == 0) {
            ShortcutBadger.removeCount(context);
        } else {
            ShortcutBadger.applyCount(context, count);
        }
    }


    public static boolean checkisImage(String filePath) throws Exception {
        return getContentType(filePath).contains("png") || getContentType(filePath).contains("jpeg")
                || getContentType(filePath).contains("jpg") || getContentType(filePath).contains("Dubuqu")
                || getContentType(filePath).contains("image");
    }

    public static boolean checkisGif(String filePath) throws Exception {
        return Utils.getContentType(filePath).contains("gif");
    }

    public static boolean checkIsVideo(String filePath) throws Exception {
        return getContentType(filePath).contains("video")
                || getContentType(filePath).contains("mp4")
                || getContentType(filePath).contains("3gp");
    }

    public static boolean checkIsVideoType(String type) throws Exception {
        return type.contains("video") || type.contains("mp4") || type.contains("3gp") || type.contains("mpeg");
    }

    public static boolean checkIsImageType(String type) throws Exception {
        return type.contains("png") || type.contains("jpeg")
                || type.contains("jpg") || type.contains("Dubuqu")
                || type.contains("image");
    }


    /**
     * open invite friends intent.
     */
    public static void inviteFriends(Context context) {
        Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
        sharingIntent.setType("text/plain");
        sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, context.getResources().getString(R.string.invite_friends_text));
        context.startActivity(Intent.createChooser(sharingIntent,context.getResources().getString(R.string.settings_about_help_invite_friends)));
    }

}
