package com.dubuqu.dnApplication;

import android.app.Application;
import android.content.Context;
import android.support.multidex.MultiDex;
import android.util.Log;

import com.dubuqu.BuildConfig;
import com.dubuqu.R;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnReceiver.DubuquOneSignalReceiver;
import com.facebook.stetho.Stetho;
import com.github.hiteshsondhi88.libffmpeg.FFmpeg;
import com.github.hiteshsondhi88.libffmpeg.FFmpegContextProvider;
import com.github.hiteshsondhi88.libffmpeg.FFmpegLoadBinaryResponseHandler;
import com.github.tamir7.contacts.Contacts;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DefaultBandwidthMeter;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.google.android.exoplayer2.upstream.DefaultHttpDataSourceFactory;
import com.google.android.exoplayer2.upstream.HttpDataSource;
import com.google.android.exoplayer2.util.Util;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.onesignal.OneSignal;

import java.util.HashMap;
import java.util.Map;

import vc908.stickerfactory.StickersManager;
import vc908.stickerfactory.User;
import vc908.stickerfactory.billing.Prices;

/**
 * Created by Yogaraj subramanian on 24/10/17
 */
public class AppController extends Application {

    private static AppController mInstance;

    protected static String userAgent = "exoplayer-codelab";

    public static FFmpeg fFmpeg;

    @Override
    public void onCreate() {
        super.onCreate();
        mInstance = this;

        new Runnable() {
            @Override
            public void run() {

                Stetho.initializeWithDefaults(mInstance);

                Contacts.initialize(mInstance);

                OneSignal.startInit(mInstance)
                        .setNotificationReceivedHandler(new DubuquOneSignalReceiver(mInstance))
                        .inFocusDisplaying(OneSignal.OSInFocusDisplayOption.None)
                        .init();
                try {
                    StickersManager.initialize(Constants.API_StickerPipe, mInstance);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                DisplayImageOptions defaultOptions = new DisplayImageOptions.Builder()
                        .cacheInMemory(true)
                        .build();

                ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(getApplicationContext())
                        .defaultDisplayImageOptions(defaultOptions)
                        .build();

                com.nostra13.universalimageloader.core.ImageLoader.getInstance().init(config);

                Map<String, String> meta = new HashMap<>();
                meta.put(User.KEY_GENDER, User.GENDER_MALE);
                meta.put(User.KEY_AGE, "23");

                StickersManager.setUser(vc908.stickerfactory.utils.Utils.getDeviceId(mInstance), meta);

                StickersManager.setPrices(new Prices()
                        .setPricePointB("$0.99", 9.99f)
                        .setPricePointC("$1.99", 19.99f)
                );

                StickersManager.setLicenseKey("NO LICENSE");

                userAgent = Util.getUserAgent(mInstance, getString(R.string.app_name));

                try {
                    loadFfmeg();
                } catch (Exception e) {
                    Log.d(AppController.class.getName(), "FFMEG load Failed");
                }
            }
        }.run();
    }

    public static Context getInstance() {
        return mInstance;
    }

    public static boolean useExtensionRenderers() {
        return BuildConfig.FLAVOR.equals("withExtensions");
    }

    public static DataSource.Factory buildDataSourceFactory(DefaultBandwidthMeter bandwidthMeter) {
        return new DefaultDataSourceFactory(mInstance, bandwidthMeter,
                buildHttpDataSourceFactory(bandwidthMeter));
    }

    public static HttpDataSource.Factory buildHttpDataSourceFactory(DefaultBandwidthMeter bandwidthMeter) {
        return new DefaultHttpDataSourceFactory(userAgent, bandwidthMeter);
    }

    public static void loadFfmeg() throws Exception {

        fFmpeg = FFmpeg.getInstance(new FFmpegContextProvider() {
            @Override
            public Context provide() {
                return mInstance;
            }
        });

        fFmpeg.loadBinary(new FFmpegLoadBinaryResponseHandler() {
            @Override
            public void onFailure() {

            }

            @Override
            public void onSuccess() {

            }

            @Override
            public void onStart() {

            }

            @Override
            public void onFinish() {

            }
        });
    }

    public static FFmpeg getfFmpeg() {
        return fFmpeg;
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);
    }

    public static void stopFFmeg() {
        if (fFmpeg != null && fFmpeg.isFFmpegCommandRunning()) {
            fFmpeg.killRunningProcesses();
        }
    }
}
