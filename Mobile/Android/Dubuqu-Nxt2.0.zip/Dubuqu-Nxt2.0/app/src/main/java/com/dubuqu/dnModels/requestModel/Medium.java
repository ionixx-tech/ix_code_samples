
package com.dubuqu.dnModels.requestModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Medium {

    @SerializedName("nanomp4")
    @Expose
    private Nanomp4 nanomp4;
    @SerializedName("tinygif")
    @Expose
    private Tinygif tinygif;
    @SerializedName("tinymp4")
    @Expose
    private Tinymp4 tinymp4;
    @SerializedName("gif")
    @Expose
    private Gif gif;
    @SerializedName("mp4")
    @Expose
    private Mp4 mp4;
    @SerializedName("nanogif")
    @Expose
    private Nanogif nanogif;

    public Nanomp4 getNanomp4() {
        return nanomp4;
    }

    public void setNanomp4(Nanomp4 nanomp4) {
        this.nanomp4 = nanomp4;
    }

    public Tinygif getTinygif() {
        return tinygif;
    }

    public void setTinygif(Tinygif tinygif) {
        this.tinygif = tinygif;
    }

    public Tinymp4 getTinymp4() {
        return tinymp4;
    }

    public void setTinymp4(Tinymp4 tinymp4) {
        this.tinymp4 = tinymp4;
    }

    public Gif getGif() {
        return gif;
    }

    public void setGif(Gif gif) {
        this.gif = gif;
    }

    public Mp4 getMp4() {
        return mp4;
    }

    public void setMp4(Mp4 mp4) {
        this.mp4 = mp4;
    }

    public Nanogif getNanogif() {
        return nanogif;
    }

    public void setNanogif(Nanogif nanogif) {
        this.nanogif = nanogif;
    }

}
