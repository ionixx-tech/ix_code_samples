package com.dubuqu.dnFragments.socialcircle;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.dubuqu.R;
import com.dubuqu.dnActivity.LandingActivity;
import com.dubuqu.dnAdapter.group.SocialCircleGroupListAdapter;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnModels.commonModel.CreateGroupAddParticipantsModel;
import com.dubuqu.dnModels.commonModel.DubuqContactsShareModel;
import com.dubuqu.dnModels.commonModel.DubuqGroupDetails;
import com.dubuqu.dnModels.responseModel.DubuquGetGroupResponse;
import com.dubuqu.dnStorage.DbHelper;
import com.dubuqu.dnStorage.RecentShareDbModel;
import com.dubuqu.dnUtils.Utils;
import com.dubuqu.dnViews.ExpandableRecyclerView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Yogaraj subramanian on 2/11/17
 */

public class SocialCircleDashboard extends Fragment {

    final String TAG = SocialCircleDashboard.class.getName();

    View parentView;

    Context context;

    Activity activity;

    Fragment parentFragment;

    List<DubuqGroupDetails> dubuqGroupDetailses = new ArrayList<>();

    ExpandableRecyclerView recyclerView;

    TextView noGroupText;

    SocialCircleGroupListAdapter socialCircleGroupListAdapter;

    @Override
    public void onResume() {
        super.onResume();
        if (activity instanceof LandingActivity) {
            try {
                ((SocialCircleFragment) parentFragment).setCurrentSocialCircleAction(SocialCircleFragment.CurrentSocialCircleAction.LISTCIRCLE);
                ((SocialCircleFragment) parentFragment).toggleToobarbasedOnOptions();

                ((LandingActivity) activity).showBottomView();

                if (socialCircleGroupListAdapter != null)
                    socialCircleGroupListAdapter.notifyDataSetChanged();

            } catch (Exception e) {
                ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
            }
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_social_circle_list, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        try {

            this.parentView = view;
            context = getContext();

            activity = getActivity();

            readDetails();

            inializeView();

            parentFragment = getParentFragment();

        } catch (Exception e) {
            ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
        }
    }

    private void inializeView() throws Exception {

        recyclerView = parentView.findViewById(R.id.socialcircle_list_rcv);

        noGroupText = parentView.findViewById(R.id.socailcircle_list_no_groups);

        if (dubuqGroupDetailses.size() > 0) {

            noGroupText.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
        } else {
            noGroupText.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        }

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);

        socialCircleGroupListAdapter = new SocialCircleGroupListAdapter(linearLayoutManager, context,
                dubuqGroupDetailses, dubuqGroupDetailses, new SocialCircleGroupListAdapter.SocialCircleListCallBacks() {
            @Override
            public void writeDataToLocal() {

                try {
                    writeGroupUpdateToLocal(new Gson().toJson(dubuqGroupDetailses));
                } catch (Exception e) {
                    ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                }
            }

            @Override
            public void onItemClicked(int position, SocialCircleGroupListAdapter.OptionsSelected optionsSelected) {

                switch (optionsSelected) {
                    case DELTE_GROUP:
                        try {
                            deleteGroupFromContactFiles(
                                    dubuqGroupDetailses.get(position).getDubuquGetGroupResponse().getGroupIdentifier()
                            );
                            dubuqGroupDetailses.remove(position);
                            writeGroupUpdateToLocal(new Gson().toJson(dubuqGroupDetailses));

                        } catch (Exception e) {
                            ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                        }
                        break;
                    case EDIT_GROUP:
                        try {
                            openEditCircle(position);
                        } catch (Exception e) {
                            ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                        }

                        break;
                }
            }
        });
        recyclerView.setLayoutManager(linearLayoutManager);

        recyclerView.setAdapter(socialCircleGroupListAdapter);
    }


    /**
     * Allow user to edit circles {@link CreateGroup } in edit mode
     *
     * @param positon the group position the user has to edit.
     * @throws Exception {Run time stub exception}
     */
    private void openEditCircle(int positon) throws Exception {

        ((SocialCircleFragment) parentFragment).setCurrentSocialCircleAction(SocialCircleFragment.CurrentSocialCircleAction.EDITCIRCLE);
        ((SocialCircleFragment) parentFragment).toggleToobarbasedOnOptions();

        final DubuqGroupDetails dubuqGroupDetails = dubuqGroupDetailses.get(positon);

        final DubuquGetGroupResponse dubuquGetGroupResponse = dubuqGroupDetails.getDubuquGetGroupResponse();

        final List<DubuqContactsShareModel> participantList = dubuqGroupDetails.getDubuquUserResponseModels();


        CreateGroupAddParticipantsModel model = new CreateGroupAddParticipantsModel();

        if (dubuquGetGroupResponse.getProfileImage() != null && !dubuquGetGroupResponse.getProfileImage().equalsIgnoreCase(""))
            model.setAmazonUrl(dubuquGetGroupResponse.getProfileImage());
        else
            model.setAmazonUrl("");

        model.setGroupName(dubuquGetGroupResponse.getGroupName());


        model.setAllowRespost(Boolean.parseBoolean(dubuquGetGroupResponse.getAllow_repost()));

        model.setPrivateGroup(!dubuquGetGroupResponse.getGroupType().equalsIgnoreCase("open"));

        model.setSaveasAlbum(Boolean.parseBoolean(dubuquGetGroupResponse.getMemoryRetain()));

        model.setGroupIdentifier(dubuquGetGroupResponse.getGroupIdentifier());

        String data = new Gson().toJson(model);

        Bundle bundle = new Bundle();
        bundle.putString(Constants.CREATECIRCLEMODELDATAS, data);
        bundle.putString(Constants.EXTRASTRINGS, new Gson().toJson(participantList));

        CreateGroup createGroup = new CreateGroup();
        createGroup.setArguments(bundle);

        ((SocialCircleFragment) parentFragment).replaceFragments(createGroup);
    }

    /**
     * Write changes that are made in the group to local data.
     *
     * @param content the json data that need to be written.
     * @throws Exception {Runtime Stub Exception}
     */
    private void writeGroupUpdateToLocal(String content) throws Exception {

        File file = new File(getContext().getCacheDir(), Constants.JSONGROUPFILENAME);

        FileOutputStream fos = new FileOutputStream(file.getAbsolutePath());
        fos.write(content.getBytes());
        fos.flush();
        fos.close();

    }

    /**
     * Over Write Dubqu Contacts File.
     *
     * @param data the data that need to be writen.
     */
    private void writeContactToLocal(String data) {

        File file = new File(getContext().getCacheDir(), Constants.JSONFILENAME);

        try {
            FileOutputStream fos = new FileOutputStream(file.getAbsolutePath());
            fos.write(data.getBytes());
            fos.flush();
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Read Group Details that are stored in local file path Name JSONGROUPFILENAME
     *
     * @throws Exception {Runtime Stub Exception}
     */
    private void readDetails() throws Exception {

        File file = new File(getContext().getCacheDir(), Constants.JSONGROUPFILENAME);
        if (file.exists()) {
            FileInputStream fis = new FileInputStream(file);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader bufferedReader = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                sb.append(line);
            }
            Gson gson = new Gson();

            dubuqGroupDetailses = gson.fromJson(sb.toString(),
                    new TypeToken<List<DubuqGroupDetails>>() {
                    }.getType());


        }
    }

    public void searchGroup(CharSequence text) {
        socialCircleGroupListAdapter.getFilter().filter(text);
    }

    /**
     * Delete Group From Dubuqu Contacts JSON file So that the group doesnt re appear in MultiShare Activity.
     * And Also if the group is present in Quick Share table the value need to be replaced with
     * first contact that is present after deletion.
     *
     * @param groupIdentifier the unique Identifier
     * @throws Exception{Runtime Stub Exception}
     */

    private void deleteGroupFromContactFiles(final String groupIdentifier) {

        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    int index = 0;

                    File file = new File(getContext().getCacheDir(), Constants.JSONFILENAME);
                    FileInputStream fis = new FileInputStream(file.getAbsolutePath());
                    InputStreamReader isr = new InputStreamReader(fis);
                    BufferedReader bufferedReader = new BufferedReader(isr);
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        sb.append(line);
                    }

                    fis.close();
                    isr.close();
                    bufferedReader.close();

                    Gson gson = new Gson();

                    List<DubuqContactsShareModel> dubuqContactsShareModels = gson.fromJson(sb.toString(),
                            new TypeToken<List<DubuqContactsShareModel>>() {
                            }.getType());

                    for (DubuqContactsShareModel dubuqContactsShareModel : dubuqContactsShareModels) {
                        if (dubuqContactsShareModel.getCategory() == Utils.DUBUQU_CATEGORY.SOCIAL_GROUP) {
                            if (dubuqContactsShareModel.getIdentifier().equalsIgnoreCase(groupIdentifier)) {
                                index = dubuqContactsShareModels.indexOf(dubuqContactsShareModel);
                                break;
                            }
                        }
                    }

                    dubuqContactsShareModels.remove(index);

                    writeContactToLocal(new Gson().toJson(dubuqContactsShareModels));

                    DubuqContactsShareModel shareModel = dubuqContactsShareModels.get(0);

                    DbHelper dbHelper = new DbHelper(getContext());

                    RecentShareDbModel recentShareDbModel = new RecentShareDbModel();
                    recentShareDbModel.setProfilePic(dubuqContactsShareModels.get(index).getProfilePicture());
                    recentShareDbModel.setUserName(dubuqContactsShareModels.get(index).getUserName());
                    recentShareDbModel.setIdentifier(dubuqContactsShareModels.get(index).getIdentifier());

                    if (dbHelper.checkIfUserAvailable(recentShareDbModel)) {
                        RecentShareDbModel dbModel = new RecentShareDbModel();
                        dbModel.setProfilePic(shareModel.getProfilePicture());
                        dbModel.setUserName(shareModel.getUserName());
                        dbModel.setIdentifier(shareModel.getIdentifier());
                        dbHelper.insertUser(dbModel);
                        dbHelper.deleteUser(dubuqContactsShareModels.get(index).getIdentifier());
                    }
                } catch (Exception e) {
                    if (activity instanceof LandingActivity) {
                        ((LandingActivity) activity).writeCrashReport(TAG, e.getMessage());
                    }
                }

            }
        });


    }


}
