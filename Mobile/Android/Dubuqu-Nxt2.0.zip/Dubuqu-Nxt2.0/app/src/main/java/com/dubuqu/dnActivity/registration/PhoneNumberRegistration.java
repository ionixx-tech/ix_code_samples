package com.dubuqu.dnActivity.registration;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.telephony.TelephonyManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

import com.dubuqu.R;
import com.dubuqu.dnActivity.BaseActivity;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnModels.requestModel.PhoneNumberVerificationRequest;
import com.dubuqu.dnRestServices.RestServiceController;
import com.dubuqu.dnRestServices.RestServiceProvider;
import com.dubuqu.dnUtils.RestServiceUtils;
import com.dubuqu.dnUtils.Utils;
import com.google.gson.Gson;
import com.hbb20.CountryCodePicker;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;

/**
 * Created by Yogaraj subramanian on 24/10/17
 */

public class PhoneNumberRegistration extends BaseActivity implements View.OnClickListener {

    //EditTexts
    EditText phoneNumberEditText;
    //Cpp
    CountryCodePicker countryCodePicker;
    //Buton
    Button continueButton;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.phone_number_registration);
        try {
            intializeViews();
        } catch (Exception e) {
            super.writeCrashReport(PhoneNumberRegistration.class.getName(), e.getMessage());
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Constants.RESTRICT_SREENSHOT)
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {

            case R.id.phone_number_registration_button:
                try {
                    checkIfReadSmsIsGranted();
                } catch (Exception e) {
                    PhoneNumberRegistration.super.writeCrashReport(
                            PhoneNumberRegistration.class.getName(),
                            e.getMessage()
                    );
                }
                break;

        }
    }

    private void intializeViews() throws Exception {

        phoneNumberEditText = findViewById(R.id.phone_number_registration_edit_text);

        phoneNumberEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                try {
                    validatePhonenNumber();
                } catch (Exception e) {
                    PhoneNumberRegistration.super.writeCrashReport(PhoneNumberRegistration.class.getName(),
                            e.getMessage());
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        countryCodePicker = findViewById(R.id.phone_number_registration_cpp);

        continueButton = findViewById(R.id.phone_number_registration_button);

        setCountryCode();

        continueButton.setOnClickListener(this);
    }

    /**
     * check if the app is provided with read and receive sms permission
     *
     * @throws Exception Runtime Stub Exceoption.
     */
    private void checkIfReadSmsIsGranted() throws Exception {

        if (!super.checkIfPermissionIsGranted(Manifest.permission.RECEIVE_SMS)) {
            super.requestPermission(new String[]{Manifest.permission.RECEIVE_SMS}, new PermissionCallBack() {
                @Override
                public void onPermissionGranted() {
                    //makehttpcall
                    try {
                        makeSendVerificationRequest();
                    } catch (Exception e) {
                        PhoneNumberRegistration.super.writeCrashReport(PhoneNumberRegistration.class.getName(),
                                e.getMessage());
                    }
                }

                @Override
                public void onPermissionRejected() {
                    try {
                        PhoneNumberRegistration.super.showToastMessage(getString(R.string.please_provide_permission_to_continue)
                                , false);
                    } catch (Exception e) {
                        PhoneNumberRegistration.super.writeCrashReport(PhoneNumberRegistration.class.getName(),
                                e.getMessage());
                    }
                }
            });
        } else {
            makeSendVerificationRequest();
        }
    }

    /**
     * make the country code as the device registered emi value .
     *
     * @throws Exception Runtime stub exception
     */
    private void setCountryCode() throws Exception {

        String countryID = "";

        TelephonyManager manager = (TelephonyManager) getApplicationContext().getSystemService(Context.TELEPHONY_SERVICE);
        //getNetworkCountryIso
        countryID = manager.getNetworkCountryIso().toUpperCase();

        countryCodePicker.setCountryForNameCode(countryID);
    }


    /**
     * validate phone number entered by the user
     *
     * @throws Exception Runtime Stub  Exception.
     */
    private void validatePhonenNumber() throws Exception {

        if (phoneNumberEditText.getText().toString().isEmpty()) {
            continueButton.setClickable(false);
            continueButton.setTextColor(Color.GRAY);
            continueButton.setBackground(getResources().getDrawable(R.drawable.registration_pages_button));
        } else if (phoneNumberEditText.getText().toString().length() < 8 || !Utils.isValidPhoneNumber(phoneNumberEditText.getText().toString())) {
            continueButton.setClickable(false);
            continueButton.setTextColor(Color.GRAY);
            continueButton.setBackground(getResources().getDrawable(R.drawable.registration_pages_button));
        } else {
            continueButton.setClickable(true);
            continueButton.setTextColor(Color.WHITE);
            continueButton.setBackground(getResources().getDrawable(R.drawable.registration_vaild_feild_indicator));
        }
    }

    /**
     * make http request to generate otp verification sms
     *
     * @throws Exception
     */
    private void makeSendVerificationRequest() throws Exception {

        if (Utils.isDataConectionAvailable(PhoneNumberRegistration.this)) {

            PhoneNumberRegistration.super.showLoaders(this);

            PhoneNumberVerificationRequest phoneNumberVerificationRequest = new PhoneNumberVerificationRequest();

            phoneNumberVerificationRequest.setCountry_code(countryCodePicker.getSelectedCountryCode());
            phoneNumberVerificationRequest.setMobile_number(phoneNumberEditText.getText().toString().trim());

            Gson gson = new Gson();
            final String data = gson.toJson(phoneNumberVerificationRequest);
            OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, getApplicationContext());
            Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
            RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
            RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);

            mRetrofitCallBacks.generateVerificationCode(new RestServiceController.ResponseCallBacks() {
                @Override
                public void onResponse(Object o) {
                    //otp generated
                    try {
                        PhoneNumberRegistration.super.cancelPopUp();
                    } catch (Exception e) {
                        writeCrashReport("Error", e.getMessage());
                    }
                    Intent newIntent = new Intent(PhoneNumberRegistration.this, PhoneNumberVerification.class);
                    Bundle bundle = new Bundle();
                    bundle.putString(Constants.EXTRASTRINGS, data);
                    newIntent.putExtras(bundle);
                    startActivity(newIntent);
                    finish();
                }

                @Override
                public void onFailure(Object o) {
                    if (o != null) {
                        try {
                            PhoneNumberRegistration.super.cancelPopUp();
                        } catch (Exception e) {
                            writeCrashReport("Error", e.getMessage());
                        }
                        if (o instanceof retrofit2.Response) {
                            //invalid request is made or getting any error
                            try {
                                PhoneNumberRegistration.super.showToastMessage(((retrofit2.Response) o).message(), false);
                            } catch (Exception e) {
                                PhoneNumberRegistration.super.writeCrashReport(PhoneNumberRegistration.class.getName(),
                                        e.getMessage());
                            }
                        } else if (o instanceof Throwable) {
                            try {
                                PhoneNumberRegistration.super.showToastMessage(((Throwable) o).getMessage(), false);
                            } catch (Exception e) {
                                PhoneNumberRegistration.super.writeCrashReport(PhoneNumberRegistration.class.getName(),
                                        e.getMessage());
                            }
                        }
                    }
                }
            }, phoneNumberVerificationRequest);


        } else {
            super.showToastMessage(getString(R.string.sp_no_internet_connection), false);
        }
    }

}
