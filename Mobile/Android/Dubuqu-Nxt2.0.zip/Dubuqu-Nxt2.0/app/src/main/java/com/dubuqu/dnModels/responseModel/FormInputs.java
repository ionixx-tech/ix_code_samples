
package com.dubuqu.dnModels.responseModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class FormInputs {

    @SerializedName("acl")
    @Expose
    private String acl;
    @SerializedName("key")
    @Expose
    private String key;
    @SerializedName("X-Amz-Credential")
    @Expose
    private String xAmzCredential;
    @SerializedName("X-Amz-Algorithm")
    @Expose
    private String xAmzAlgorithm;
    @SerializedName("X-Amz-Date")
    @Expose
    private String xAmzDate;
    @SerializedName("Policy")
    @Expose
    private String policy;
    @SerializedName("X-Amz-Signature")
    @Expose
    private String xAmzSignature;
    @SerializedName("content-type")
    @Expose
    private String contentType;

    public String getAcl() {
        return acl;
    }

    public void setAcl(String acl) {
        this.acl = acl;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getXAmzCredential() {
        return xAmzCredential;
    }

    public void setXAmzCredential(String xAmzCredential) {
        this.xAmzCredential = xAmzCredential;
    }

    public String getXAmzAlgorithm() {
        return xAmzAlgorithm;
    }

    public void setXAmzAlgorithm(String xAmzAlgorithm) {
        this.xAmzAlgorithm = xAmzAlgorithm;
    }

    public String getXAmzDate() {
        return xAmzDate;
    }

    public void setXAmzDate(String xAmzDate) {
        this.xAmzDate = xAmzDate;
    }

    public String getPolicy() {
        return policy;
    }

    public void setPolicy(String policy) {
        this.policy = policy;
    }

    public String getXAmzSignature() {
        return xAmzSignature;
    }

    public void setXAmzSignature(String xAmzSignature) {
        this.xAmzSignature = xAmzSignature;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

}
