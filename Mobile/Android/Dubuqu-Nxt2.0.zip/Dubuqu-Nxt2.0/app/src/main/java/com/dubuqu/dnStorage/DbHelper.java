package com.dubuqu.dnStorage;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.dubuqu.dnApplication.AppController;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnConstants.UploadConstants;
import com.dubuqu.dnStorage.upload.UploadDbModel;
import com.dubuqu.dnStorage.upload.UploadMapModel;
import com.j256.ormlite.android.apptools.OrmLiteSqliteOpenHelper;
import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.stmt.DeleteBuilder;
import com.j256.ormlite.stmt.QueryBuilder;
import com.j256.ormlite.support.ConnectionSource;
import com.j256.ormlite.table.TableUtils;

import java.sql.SQLException;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;

/**
 * Created by Yogaraj subramanian on 19/6/17
 * <p>
 * SQLite database open helper which can be extended by your application to help
 * manage when the application needs to
 * create or upgrade its database.
 * </p>
 */

public class DbHelper extends OrmLiteSqliteOpenHelper {

    Context context;

    /**
     * constructor to use the orm db
     *
     * @param context context of the calling Activity or Fragment.
     */
    public DbHelper(Context context) throws Exception {
        super(AppController.getInstance(), Constants.DB_NAME,
                null, Constants.DBVERSION);
        this.context = context;
    }

    /**
     * oncreate method is called when ever the db is created i.e create only once.
     *
     * @param database         SQLiteDatabase object to map which db to be used.
     * @param connectionSource is used to connect the db to the application.
     */
    @Override
    public void onCreate(SQLiteDatabase database, ConnectionSource connectionSource) {
        try {
            // Create Table with given table name with columnName
            TableUtils.createTable(connectionSource, RecentShareDbModel.class);
            TableUtils.createTable(connectionSource, UploadDbModel.class);
            TableUtils.createTable(connectionSource, UploadMapModel.class);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * @param database         the database to be updated
     * @param connectionSource to connect the database to the application.
     * @param oldVersion       older version of the db to be mapped.
     * @param newVersion       of the db to be replace the old db structure.
     */
    @Override
    public void onUpgrade(SQLiteDatabase database, ConnectionSource connectionSource, int oldVersion, int newVersion) {
        try {
            TableUtils.dropTable(connectionSource, RecentShareDbModel.class, true);
            TableUtils.dropTable(connectionSource, UploadDbModel.class, true);
            TableUtils.dropTable(connectionSource, UploadMapModel.class, true);
            onCreate(database, connectionSource);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * insert new quick share user.
     *
     * @param newRecentShareDaoModle which contains the values need to inserted @link(RecentShareDbModel)
     * @throws SQLException the exception thrown while perorming action.
     */
    public void insertUser(RecentShareDbModel newRecentShareDaoModle) throws SQLException {
        Dao<RecentShareDbModel, ?> insertDao = getDao(RecentShareDbModel.class);
        List<RecentShareDbModel> recentShareDbModels = insertDao.queryForAll();
        if (recentShareDbModels.size() >= 3) {
            try {
                if (!checkIfUserAvailable(newRecentShareDaoModle)) {
                    for (RecentShareDbModel recentShareDbModel : recentShareDbModels) {
                        DeleteBuilder<RecentShareDbModel, ?> deleteBuilder = insertDao.deleteBuilder();
                        deleteBuilder.where().eq(Constants.USER_IDENTIFIER, recentShareDbModel.getIdentifier());
                        deleteBuilder.delete();
                        break;
                    }
                    insertDao.createOrUpdate(newRecentShareDaoModle);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        } else {
            insertDao.createOrUpdate(newRecentShareDaoModle);
        }
    }

    /**
     * checks whether the user is already inserted or not.
     *
     * @param newRecentShareDaoModle which contains the values need to be checked @link(RecentShareDbModel)
     * @return true if user is present , false if user is not present.
     * @throws Exception
     */
    public boolean checkIfUserAvailable(RecentShareDbModel newRecentShareDaoModle) throws Exception {
        Dao<RecentShareDbModel, ?> insertDao = getDao(RecentShareDbModel.class);
        List<RecentShareDbModel> recentShareDbModels = insertDao.queryForAll();

        for (RecentShareDbModel recentShareDbModel : recentShareDbModels) {
            if (newRecentShareDaoModle.getUserName().equalsIgnoreCase(recentShareDbModel.getUserName())) {
                return true;
            }
        }
        return false;
    }

    /**
     * reads the list of quick share contacts stored in db.
     *
     * @return List of @link(RecentShareDbModel) max length of 3.
     * @throws SQLException
     */
    public List<RecentShareDbModel> getAllRecentusers() throws SQLException {
        Dao<RecentShareDbModel, ?> getAllDao = getDao(RecentShareDbModel.class);
        return getAllDao.queryForAll();
    }

    /**
     * delete the user if any new user comes in place of recent share.
     *
     * @param userIdentifier the idntifier which need to rplaced from the db
     * @throws SQLException
     */
    public void deleteUser(String userIdentifier) throws SQLException {
        Dao<RecentShareDbModel, ?> insertDao = getDao(RecentShareDbModel.class);
        DeleteBuilder<RecentShareDbModel, ?> deleteBuilder = insertDao.deleteBuilder();
        deleteBuilder.where().eq(Constants.USER_IDENTIFIER, userIdentifier);
        deleteBuilder.delete();
    }


    /**
     * get the last inserted data id.
     *
     * @return
     * @throws SQLException
     */
    public int getNumberOfQueuedProcess() throws SQLException {
        Dao<UploadMapModel, ?> fetchDao = super.getDao(UploadMapModel.class);
        QueryBuilder<UploadMapModel, ?> qb = fetchDao.queryBuilder();
        List<UploadMapModel> uploadMapModelList = qb.query();
        if (uploadMapModelList != null && uploadMapModelList.size() > 0) {
            UploadMapModel uploadMapModel = uploadMapModelList.get(uploadMapModelList.size() - 1);
            return uploadMapModel.getId();
        }
        return 0;
    }

    /**
     * Insert a new upload datas that are need to be shared.
     *
     * @throws SQLException
     */
    public void insertNewUpload(final UploadDbModel uploadDbModel) throws SQLException {

        final Dao<UploadDbModel, ?> insertDao = getDao(UploadDbModel.class);
        try {
            insertDao.callBatchTasks(new Callable<Void>() {
                public Void call() throws Exception {
                    insertDao.create(uploadDbModel);
                    return null;
                }
            });
        } catch (Exception e) {
            Log.e(DbHelper.class.getName(), e.getMessage());
        }

    }

    public void insertNewUpload(final UploadMapModel uploadMapModel) throws Exception {

        final Dao<UploadMapModel, ?> insertDao = getDao(UploadMapModel.class);

        try {
            insertDao.callBatchTasks(new Callable<Void>() {
                public Void call() throws Exception {
                    insertDao.create(uploadMapModel);
                    return null;
                }
            });
        } catch (Exception e) {
            Log.e(DbHelper.class.getName(), e.getMessage());
        }
    }

    /**
     * get next set of upload datas to file share
     *
     * @return {@link UploadDbModel}
     * @throws SQLException
     */
    public List<UploadDbModel> fetchDataAgainstIdentifier(String uploadIDentifier) throws SQLException {
        Dao<UploadDbModel, ?> fetchDao = super.getDao(UploadDbModel.class);
        QueryBuilder<UploadDbModel, ?> qb = fetchDao.queryBuilder();
        qb.where().eq(Constants.UPLOADIDENTIFIER, uploadIDentifier);
        return qb.query();
    }

    public UploadMapModel fetchDataAgainstIdentifier() throws SQLException {
        Dao<UploadMapModel, ?> fetchDao = getDao(UploadMapModel.class);
        QueryBuilder<UploadMapModel, ?> qb = fetchDao.queryBuilder();
        qb.where().eq(Constants.UPLOAD_STATUS, String.valueOf(UploadConstants.UPLOADSTATUS.NOTYETSTARTED));
        List<UploadMapModel> modelList = qb.query();
        if (modelList != null && modelList.size() > 0) {
            return modelList.get(0);
        }
        return null;
    }

    /**
     * fetch all updload details
     */

    public List<UploadMapModel> fetchAllModels() throws Exception {
        Dao<UploadMapModel, ?> fetchDao = getDao(UploadMapModel.class);
        List<UploadMapModel> uploadMapModels = fetchDao.queryForAll();
        if (uploadMapModels != null) {
            Collections.reverse(uploadMapModels);
            return uploadMapModels;
        }
        return null;
    }

    /**
     * once upload is done the data need to be removed form table.
     *
     * @param uploadIdentifier the unique id for upload datas.
     * @throws SQLException
     */
    public void deleteUploadData(String uploadIdentifier) throws SQLException {
        Dao<UploadDbModel, ?> deleteDao = getDao(UploadDbModel.class);
        DeleteBuilder<UploadDbModel, ?> deleteBuilder = deleteDao.deleteBuilder();
        deleteBuilder.where().eq(Constants.UPLOADIDENTIFIER, uploadIdentifier);
        deleteBuilder.delete();

        Dao<UploadMapModel, ?> uploadMapModelDao = getDao(UploadMapModel.class);
        DeleteBuilder<UploadMapModel, ?> dbModelDeleteBuilder = uploadMapModelDao.deleteBuilder();
        dbModelDeleteBuilder.where().eq(Constants.UPLOADIDENTIFIER, uploadIdentifier);
        dbModelDeleteBuilder.delete();

        this.context.sendBroadcast(new Intent(Constants.UPLOAD_RECEIVER));
    }

    /**
     * update progress of compressing datas
     *
     * @throws SQLException
     */
    public void updateProgressValueForUpload(UploadDbModel uploadDbModel,
                                             int progressValue,
                                             String status) throws SQLException {

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();

        sqLiteDatabase.execSQL("UPDATE " +
                Constants.UPLOADTABLE +
                " SET " + Constants.UPLOAD_PROGRESS + " = " + " \"" + String.valueOf(progressValue) + "\"" + ", " +
                Constants.UPLOAD_STATUS + " = " + " \"" + status + "\"" +
                " WHERE " + Constants.ID + " = " + uploadDbModel.getId());

        if (sqLiteDatabase.isOpen()) {
            sqLiteDatabase.close();
        }

        /*if (sqLiteDatabase != null) {
            Dao<UploadDbModel, ?> update = getDao(UploadDbModel.class);
            UpdateBuilder<UploadDbModel, ?> updateBuilder = update.updateBuilder();
            updateBuilder.where().eq(Constants.ID, uploadDbModel.getId());
            updateBuilder.updateColumnValue(Constants.UPLOAD_PROGRESS, progressValue);
            updateBuilder.updateColumnValue(Constants.UPLOAD_STATUS, status);
            updateBuilder.update();
            if (sqLiteDatabase.isOpen()) {
                sqLiteDatabase.close();
            }
        }*/
    }

    /**
     * update progress state of the upload.
     */
    public void updateProgressStateOfUpload(String uploadIdentifier, UploadConstants.UPLOADSTATUS uploadstatus)
            throws SQLException {

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();

        sqLiteDatabase.execSQL("UPDATE " +
                Constants.UPLOADTABLEMAPER +
                " SET " + Constants.UPLOAD_STATUS + " = " + " \"" + String.valueOf(uploadstatus) + "\"" +
                " WHERE " + Constants.UPLOADIDENTIFIER + " = " + "\"" + uploadIdentifier + "\"");

        if (sqLiteDatabase.isOpen()) {
            sqLiteDatabase.close();
        }
    }

    public void updateUploadProgressForFile(UploadDbModel uploadDbModel, String uploadData) throws SQLException {

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();

        if (sqLiteDatabase != null) {

            sqLiteDatabase.execSQL("UPDATE " +
                    Constants.UPLOADTABLE +
                    " SET " + Constants.UPLOAD_PROGRESS_FILE + " = " + " \"" + uploadData + "\"" +
                    " WHERE " + Constants.ID + " = " + uploadDbModel.getId());

            sqLiteDatabase.close();
        }
    }


    public void delteAllUploadMapData() throws Exception {

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();

        if (sqLiteDatabase != null) {

            Dao<UploadMapModel, ?> deleteMapData = getDao(UploadMapModel.class);

            DeleteBuilder<UploadMapModel, ?> deleteMapBuilder = deleteMapData.deleteBuilder();

           /* deleteMapBuilder.where().not().
                    eq(Constants.UPLOAD_STATUS,
                            String.valueOf(UploadConstants.UPLOADSTATUS.PROGRESS));*/

            if (!sqLiteDatabase.isDbLockedByCurrentThread()) {
                deleteMapBuilder.delete();
            }
        }

        delteAllUploadData();
    }

    private void delteAllUploadData() throws Exception {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        if (sqLiteDatabase != null) {

            Dao<UploadDbModel, ?> deleteMapData = getDao(UploadDbModel.class);

            DeleteBuilder<UploadDbModel, ?> deleteMapBuilder = deleteMapData.deleteBuilder();

           /* deleteMapBuilder.where().not().
                    eq(Constants.UPLOAD_STATUS,
                            String.valueOf(UploadConstants.UPLOADSTATUS.PROGRESS));*/

            if (!sqLiteDatabase.isDbLockedByCurrentThread()) {
                deleteMapBuilder.delete();
                if (sqLiteDatabase.isOpen()) {
                    sqLiteDatabase.close();
                }
            }
        }
    }

    public UploadMapModel getMapModelDetails(String id) throws Exception {

        Dao<UploadMapModel, ?> fetchDao = getDao(UploadMapModel.class);

        QueryBuilder<UploadMapModel, ?> qb = fetchDao.queryBuilder();

        qb.where().eq(Constants.UPLOADIDENTIFIER, id);

        List<UploadMapModel> modelList = qb.query();

        if (modelList != null && modelList.size() > 0) {
            return modelList.get(0);
        }

        return null;
    }

    public UploadDbModel getDbModelDetails(String id) throws Exception {

        Dao<UploadDbModel, ?> fetchDao = getDao(UploadDbModel.class);

        QueryBuilder<UploadDbModel, ?> qb = fetchDao.queryBuilder();

        qb.where().eq(Constants.UPLOADIDENTIFIER, id);

        List<UploadDbModel> modelList = qb.query();

        if (modelList != null && modelList.size() > 0) {
            return modelList.get(0);
        }

        return null;
    }

    public boolean checkIfAnyCanceledupload() throws Exception {

        Dao<UploadMapModel, ?> fetchDao = getDao(UploadMapModel.class);

        QueryBuilder<UploadMapModel, ?> qb = fetchDao.queryBuilder();

        qb.where().eq(Constants.UPLOAD_STATUS, String.valueOf(UploadConstants.UPLOADSTATUS.FAILURE)).or().eq(
                Constants.UPLOAD_STATUS, String.valueOf(UploadConstants.UPLOADSTATUS.CANCELLED)
        );

        List<UploadMapModel> modelList = qb.query();

        return modelList != null && modelList.size() > 0;

    }

    public List<UploadMapModel> checkIfRunningProcess() throws Exception {

        Dao<UploadMapModel, ?> fetchDao = getDao(UploadMapModel.class);

        QueryBuilder<UploadMapModel, ?> qb = fetchDao.queryBuilder();

        qb.where().eq(Constants.UPLOAD_STATUS, String.valueOf(UploadConstants.UPLOADSTATUS.PROGRESS));

        return qb.query();
    }
}
