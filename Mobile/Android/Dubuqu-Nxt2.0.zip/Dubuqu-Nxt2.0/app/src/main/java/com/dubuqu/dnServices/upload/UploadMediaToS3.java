package com.dubuqu.dnServices.upload;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.media.ExifInterface;
import android.util.Log;
import android.webkit.MimeTypeMap;

import com.bumptech.glide.Glide;
import com.dubuqu.dnCallbacks.Callbacks;
import com.dubuqu.dnConstants.UploadConstants;
import com.dubuqu.dnMediaCompression.ImageCompressor;
import com.dubuqu.dnMediaCompression.VideoCompressor;
import com.dubuqu.dnModels.responseModel.FormAttributes;
import com.dubuqu.dnModels.responseModel.FormInputs;
import com.dubuqu.dnModels.responseModel.Media;
import com.dubuqu.dnModels.responseModel.SignedUrlResponseModel;
import com.dubuqu.dnModels.responseModel.Thumbnail;
import com.dubuqu.dnRestServices.RestServiceController;
import com.dubuqu.dnRestServices.RestServiceProvider;
import com.dubuqu.dnStorage.upload.UploadDbModel;
import com.dubuqu.dnUtils.RestServiceUtils;
import com.dubuqu.dnUtils.Utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import okio.BufferedSink;
import retrofit2.Call;
import retrofit2.Retrofit;

import static com.dubuqu.dnConstants.UploadConstants.UPLOADSTATUS.FAILURE;
import static com.dubuqu.dnConstants.UploadConstants.UPLOADSTATUS.PROGRESS;
import static com.dubuqu.dnConstants.UploadConstants.UPLOADSTATUS.SUCCESS;
import static com.dubuqu.dnConstants.UploadConstants.UPLOADSTATUS.UPLOADING;

/**
 * Created by Yogaraj subramanian on 21/3/18
 * <p>
 * An Upload media controller which handles  uploading media to S3 server.
 * <p>
 * Initialy the media is compressed for compression refer {@link UploadMediaToS3#compressImageMedia()}
 * or {@link UploadMediaToS3#compressVideoMedia()}
 * <p>
 * Then signed url and upload credientials that are needed to upload the media to s3 are request from
 * server {@link UploadMediaToS3#getSignedUrl(String, boolean)})} ()}
 * <p>
 * then the media is uploaded to server
 * </p>
 * <p>
 * A listener to track the events that are occured while compression and also in upload. {@link UploadMediaListner}
 * </p>
 */

public class UploadMediaToS3 implements Callbacks.CompressionCallback {

    private UploadDbModel uploadDbModel;

    private UploadMediaListner uploadMediaListner;

    private Context context;

    private VideoCompressor videoCompressor = null;

    private Call call;

    public UploadMediaToS3(UploadDbModel uploadDbModel, boolean shouldDeleteOriginalMedia,
                           UploadMediaListner uploadMediaListner, Context context) {
        this.uploadDbModel = uploadDbModel;
        this.uploadMediaListner = uploadMediaListner;
        this.context = context;
    }

    public void startProcess() throws Exception {
        compressMedia();
    }

    public void stopProcess() throws Exception {

        if (videoCompressor != null)
            videoCompressor.cancelCompression();

        if (call != null)
            call.cancel();
    }

    @Override
    public void getCompressedFilePath(String filePath) {

        try {
            boolean shouldDeleteMedia = !filePath.equalsIgnoreCase(uploadDbModel.getFilePath());

            getSignedUrl(filePath, shouldDeleteMedia);

            uploadMediaListner.updateProcesssState(uploadDbModel, 100, UPLOADING);

            if (videoCompressor != null)
                videoCompressor = null;

        } catch (Exception e) {
            uploadMediaListner.onMediaUploadFailed(e.getMessage());
        }
    }

    @Override
    public void onFailed() {
        uploadMediaListner.onMediaUploadFailed("Media Compression Failed");
        if (videoCompressor != null)
            videoCompressor = null;
    }

    @Override
    public void onUpdateProgress(int value) {
        uploadMediaListner.updateProcesssState(uploadDbModel, value, UploadConstants.UPLOADSTATUS.PROGRESS);
    }

    /**
     * Start compressing media check if the media is video or image or gif
     *
     * @throws Exception {Runtime exception}
     */
    private void compressMedia() throws Exception {

        if (uploadDbModel.getFilePath().contains("content:/") ?
                Utils.checkIsImageType(getMimeType(Uri.parse(uploadDbModel.getFilePath())))
                : Utils.checkisImage(uploadDbModel.getFilePath())) {
            uploadMediaListner.updateProcesssState(uploadDbModel, 1, PROGRESS);
            compressImageMedia();
        } else if (uploadDbModel.getFilePath().contains("content:/") ?
                Utils.checkIsVideoType(getMimeType(Uri.parse(uploadDbModel.getFilePath())))
                : Utils.checkIsVideo(uploadDbModel.getFilePath())) {
            uploadMediaListner.updateProcesssState(uploadDbModel, 1, PROGRESS);
            compressVideoMedia();
        } else if (Utils.checkisGif(uploadDbModel.getFilePath())) {
            uploadMediaListner.updateProcesssState(uploadDbModel, 100, UPLOADING);
            getSignedUrl(uploadDbModel.getFilePath(), false);
        } else {
            uploadMediaListner.updateProcesssState(uploadDbModel, 100, FAILURE);
            uploadMediaListner.onMediaUploadFailed("Media File Is not supported");
        }
    }

    private String getMimeType(Uri uri) {

        String extension;

        //Check uri format to avoid null
        if (uri.getScheme().equals(ContentResolver.SCHEME_CONTENT)) {
            //If scheme is a content
            final MimeTypeMap mime = MimeTypeMap.getSingleton();
            extension = mime.getExtensionFromMimeType(context.getContentResolver().getType(uri));
        } else {
            //If scheme is a File
            //This will replace white spaces with %20 and also other special characters. This will avoid returning null values on file name with spaces and special characters.
            extension = MimeTypeMap.getFileExtensionFromUrl(Uri.fromFile(new File(uri.getPath())).toString());
        }

        return extension;
    }


    /**
     * Compress Image Media {@link ImageCompressor}
     *
     * @throws Exception {Runtime compression}
     */
    private void compressImageMedia() throws Exception {

        new ImageCompressor(this, context).execute(uploadDbModel.getFilePath());
    }

    /**
     * Compress Video Media {@link VideoCompressor}
     *
     * @throws Exception {Runtime Compression}
     */
    private void compressVideoMedia() throws Exception {

        if (uploadDbModel.getFilePath().contains("dubuqu")) {
            getSignedUrl(uploadDbModel.getFilePath(), false);
        } else {
            videoCompressor = new VideoCompressor(this, context);
            videoCompressor.startCompression(uploadDbModel.getFilePath());
        }
    }

    /**
     * Get Signed Url form the server with required feilds
     *
     * @param compressedFilePath {@link String} the file path where the compressed media is stored
     * @throws Exception {Runtime Exception}
     */
    private void getSignedUrl(final String compressedFilePath, final boolean shoulddelteMedia) throws Exception {

        String[] resolution = Utils.getResolution(compressedFilePath);
        String width = "320";
        String height = "640";
        if (resolution != null && resolution.length == 2) {
            width = resolution[0];
            height = resolution[1];
        }
        String data = "{}";
        OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, context);
        Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);

        RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
        RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);

        mRetrofitCallBacks.getSignedUrl(
                new RestServiceController.ResponseCallBacks() {
                    @Override
                    public void onResponse(Object o) {
                        try {
                            uploadMedia((SignedUrlResponseModel) o, compressedFilePath, shoulddelteMedia);

                            if (!Utils.checkIsVideo(compressedFilePath)) {
                                uploadImageThumbnail((SignedUrlResponseModel) o, compressedFilePath);
                            } else {
                                uploadVideoThumbnail((SignedUrlResponseModel) o, compressedFilePath);
                            }

                        } catch (Exception e) {
                            uploadMediaListner.updateProgressForUpload(uploadDbModel, "No Internet");
                            uploadMediaListner.onMediaUploadFailed(e.getMessage());
                        }
                    }

                    @Override
                    public void onFailure(Object object) {
                        uploadMediaListner.updateProgressForUpload(uploadDbModel, "No Internet");
                        uploadMediaListner.onMediaUploadFailed("Get Signed URl Failed");
                    }
                }, "media",
                Utils.getContentType(compressedFilePath),
                Utils.getFileExtension(compressedFilePath),
                width, height);
    }


    /*upload original media to server*/
    private void uploadMedia(final SignedUrlResponseModel myObj,
                             final String compressedFile, final boolean toDeleted) throws Exception {
        Media media = myObj.getMedia();
        FormAttributes formAttributes = media.getFormAttributes();
        FormInputs formInputs = media.getFormInputs();

        Retrofit retrofit = RestServiceUtils.uploadMediaToS3(formAttributes.getAction());
        RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
        RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);

        // create RequestBody instance from file
        final File file = new File(compressedFile);

            /*MediaType.parse(file.getAbsolutePath()), file*/

        MultiPartUploadProgressCalulator requestFile = new MultiPartUploadProgressCalulator(MediaType.parse(file.getAbsolutePath()), file, uploadDbModel);

        mRetrofitCallBacks.uploadMediaToS3(convertresquestBofy(formInputs.getXAmzCredential()),
                convertresquestBofy(formInputs.getXAmzAlgorithm()),
                convertresquestBofy(formInputs.getXAmzDate()),
                convertresquestBofy(formInputs.getAcl()),
                convertresquestBofy(formInputs.getPolicy()),
                convertresquestBofy(formInputs.getXAmzSignature()),
                convertresquestBofy(formInputs.getKey()),
                convertresquestBofy(formInputs.getContentType()),
                requestFile, new RestServiceController.ResponseCallBacks() {
                    @Override
                    public void onResponse(Object o) {

                        uploadMediaListner.onMediaUploadComplted(myObj.getMediaIdentifier());

                        uploadMediaListner.updateProcesssState(uploadDbModel, 100, SUCCESS);

                        if (toDeleted) {
                            file.delete();
                        }
                    }

                    @Override
                    public void onFailure(Object o) {
                        uploadMediaListner.updateProgressForUpload(uploadDbModel, "No Internet");
                        uploadMediaListner.onMediaUploadFailed("Original Media Upload failed");
                    }
                }, new RestServiceController.CallEvents() {
                    @Override
                    public void onCallCreated(Call<ResponseBody> responseBodyCall) {
                        call = responseBodyCall;
                    }
                }
        );

    }

    private void uploadImageThumbnail(final SignedUrlResponseModel signedUrlResponseModel,
                                      final String filePath) throws Exception {

        final File file = getTumbnail(filePath);

        if (file != null) {
            Thumbnail media = signedUrlResponseModel.getThumbnail();
            FormAttributes formAttributes = media.getFormAttributes();
            FormInputs formInputs = media.getFormInputs();

            Retrofit retrofit = RestServiceUtils.uploadMediaToS3(formAttributes.getAction());
            RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
            RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);

            RequestBody requestFile =
                    RequestBody.create(MediaType.parse(file.getAbsolutePath()), file);

            mRetrofitCallBacks.uploadMediaToS3(convertresquestBofy(formInputs.getXAmzCredential()),
                    convertresquestBofy(formInputs.getXAmzAlgorithm()),
                    convertresquestBofy(formInputs.getXAmzDate()),
                    convertresquestBofy(formInputs.getAcl()),
                    convertresquestBofy(formInputs.getPolicy()),
                    convertresquestBofy(formInputs.getXAmzSignature()),
                    convertresquestBofy(formInputs.getKey()),
                    convertresquestBofy(formInputs.getContentType()),
                    requestFile, new RestServiceController.ResponseCallBacks() {
                        @Override
                        public void onResponse(Object o) {
                            Log.e(UploadMediaToS3.class.getName(), "Image Upload Sucessful");
                        }

                        @Override
                        public void onFailure(Object object) {


                        }
                    }, new RestServiceController.CallEvents() {
                        @Override
                        public void onCallCreated(Call<ResponseBody> responseBodyCall) {

                        }
                    }
            );
        } else {
            throw new Exception("Thumbnail Generation Failed");
        }
    }


    private void uploadVideoThumbnail(final SignedUrlResponseModel signedUrlResponseModel,
                                      final String filePath) throws Exception {

        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    Bitmap thumb = Glide.with(context).load(filePath).asBitmap().into(300,
                            300).get();

                    final File file = new File(context.getCacheDir(), "Thumbnails"
                            + signedUrlResponseModel.getThumbnail() + ".png");
                    FileOutputStream fOut = new FileOutputStream(file);

                    thumb.compress(Bitmap.CompressFormat.PNG, 100, fOut);
                    fOut.flush();
                    fOut.close();

                    Thumbnail media = signedUrlResponseModel.getThumbnail();
                    FormAttributes formAttributes = media.getFormAttributes();
                    FormInputs formInputs = media.getFormInputs();

                    Retrofit retrofit = RestServiceUtils.uploadMediaToS3(formAttributes.getAction());
                    RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
                    RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
                    RequestBody requestFile =
                            RequestBody.create(MediaType.parse(file.getAbsolutePath()), file);

                    mRetrofitCallBacks.uploadMediaToS3(convertresquestBofy(formInputs.getXAmzCredential()),
                            convertresquestBofy(formInputs.getXAmzAlgorithm()),
                            convertresquestBofy(formInputs.getXAmzDate()),
                            convertresquestBofy(formInputs.getAcl()),
                            convertresquestBofy(formInputs.getPolicy()),
                            convertresquestBofy(formInputs.getXAmzSignature()),
                            convertresquestBofy(formInputs.getKey()),
                            convertresquestBofy(formInputs.getContentType()),
                            requestFile, new RestServiceController.ResponseCallBacks() {
                                @Override
                                public void onResponse(Object o) {
                                    if (file.exists()) {
                                        boolean delete = file.delete();
                                        if (delete)
                                            Log.e(UploadMediaToS3.class.getName(), "");
                                    }
                                }

                                @Override
                                public void onFailure(Object o) {

                                }
                            }, new RestServiceController.CallEvents() {
                                @Override
                                public void onCallCreated(Call<ResponseBody> responseBodyCall) {

                                }
                            }
                    );
                } catch (Exception e) {

                    uploadMediaListner.onMediaUploadFailed(e.getMessage());
                }

            }
        });


    }

    private void updateProgress() throws Exception {

    }

    private RequestBody convertresquestBofy(String text) {
        return RequestBody.create(MediaType.parse("text/plain"), text);
    }

    /**
     * generate low quality thumb for image
     *
     * @param file the file whoes quality need to be reduced
     * @return {@link String} output file name
     */
    private File getTumbnail(String file) {
        try {
            // First decode with inJustDecodeBounds=true to check dimensions
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(file, options);

            // Calculate inSampleSize req.width and req.height determines the quality of the media and size
            /*
            * 72 x 72 output file size ~10kb
            * 120 x 120 output file size ~10kb
            * 240 x 240 output file size ~30kb
            * 700 x 700 output file size ~150kb
            * */
            options.inSampleSize = calculateInSampleSize(options);
            // Decode bitmap with inSampleSize set
            options.inJustDecodeBounds = false;

            Bitmap scaledBitmap = BitmapFactory.decodeFile(file, options);

            //check the rotation of the image and display it properly
            ExifInterface exif;
            exif = new ExifInterface(file);
            int orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, 0);
            Matrix matrix = new Matrix();
            if (orientation == 6) {
                matrix.postRotate(90);
            } else if (orientation == 3) {
                matrix.postRotate(180);
            } else if (orientation == 8) {
                matrix.postRotate(270);
            }
            scaledBitmap = Bitmap.createBitmap(scaledBitmap,
                    0, 0, scaledBitmap.getWidth(),
                    scaledBitmap.getHeight(), matrix, true);

            File compressdFile = new File(context.getCacheDir(),
                    "Dubuquee".concat(String.valueOf(System.currentTimeMillis())).concat(".jpeg"));

            FileOutputStream outputStream = new FileOutputStream(compressdFile);

            scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 50, outputStream);

            return compressdFile;
        } catch (Exception e) {
            Log.e("Image Compress Failed", e.getMessage());
            return null;
        }
    }

    private static int calculateInSampleSize(
            BitmapFactory.Options options) {
        // Raw height and width of image
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > 450 || width > 450) {

            final int halfHeight = height / 2;
            final int halfWidth = width / 2;

            // Calculate the largest inSampleSize value that is a power of 2 and keeps both
            // height and width larger than the requested height and width.
            while ((halfHeight / inSampleSize) >= 450
                    && (halfWidth / inSampleSize) >= 450) {
                inSampleSize *= 3.5;
            }
        }

        return inSampleSize;
    }

    /**
     * An interface to triger events based on the uploads
     * <p>
     * {@link UploadMediaListner {@link #onMediaUploadFailed(String)}} called when complete upload of file is done.
     * <p>
     * {@link UploadMediaListner {@link #updateProcesssState(UploadDbModel, int, UploadConstants.UPLOADSTATUS)} to update the process state in db/
     * </p>
     * {@link UploadMediaListner#onMediaUploadFailed(String)} to indicate there is failure in media upload
     */
    public interface UploadMediaListner {

        void onMediaUploadComplted(String mediaIdentifier);

        void onMediaUploadFailed(String exceptionMessage);

        void updateProcesssState(UploadDbModel uploadDbModel, int progressValue, UploadConstants.UPLOADSTATUS uploadstatus);

        void updateProgressForUpload(UploadDbModel uploadDbModel, String progressValue);
    }

    /**
     * Upload Progress manager to calulate the amount of file uploaded
     */
    private class MultiPartUploadProgressCalulator extends RequestBody {

        File mFile;

        UploadDbModel uploadDbModel;

        MediaType mediaType;

        private MultiPartUploadProgressCalulator(MediaType mediaType, File mFile, UploadDbModel uploadMapModel) {
            this.mFile = mFile;
            this.uploadDbModel = uploadMapModel;
            this.mediaType = mediaType;
        }

        @Override
        public MediaType contentType() {
            return mediaType;
        }

        @Override
        public long contentLength() throws IOException {
            return mFile.length();
        }

        @Override
        public void writeTo(BufferedSink sink) throws IOException {

            int buffersize = 100 * 1024;

            long fileLength = mFile.length();
            byte[] buffer = new byte[buffersize];
            long uploaded = 0;

            try (FileInputStream in = new FileInputStream(mFile)) {
                int read;
                while ((read = in.read(buffer)) != -1) {
                    uploaded += read;
                    sink.write(buffer, 0, read);

                    int percentage = (int) ((uploaded / (float) fileLength) * 100);

                    uploadMediaListner.updateProgressForUpload(uploadDbModel,
                            String.valueOf(percentage));
                }

            }
        }

    }
}
