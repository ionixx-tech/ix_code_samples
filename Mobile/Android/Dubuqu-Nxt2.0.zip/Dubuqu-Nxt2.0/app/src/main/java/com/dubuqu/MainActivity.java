package com.dubuqu;

import android.Manifest;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.airbnb.lottie.LottieAnimationView;
import com.dubuqu.dnActivity.BaseActivity;
import com.dubuqu.dnActivity.LandingActivity;
import com.dubuqu.dnActivity.registration.PhoneNumberRegistration;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnModels.responseModel.UserDetails;
import com.dubuqu.dnRestServices.RestServiceController;
import com.dubuqu.dnRestServices.RestServiceProvider;
import com.dubuqu.dnStorage.SessionManager;
import com.dubuqu.dnUtils.RestServiceUtils;
import com.google.gson.Gson;
import com.onesignal.OSSubscriptionObserver;
import com.onesignal.OSSubscriptionStateChanges;
import com.onesignal.OneSignal;

import org.json.JSONObject;

import java.util.HashMap;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;

public class MainActivity extends BaseActivity implements OSSubscriptionObserver {

    //viewgroups
    LinearLayout dubuquTextLL;
    RelativeLayout parentView;
    //ImageViews
    ImageView dubuquLogoIMV;
    //TextView
    TextView toastText;
    //session managers
    SessionManager sessionManager;
    //LottieAnimations
    LottieAnimationView lottieAnimationViewLoder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {
            initalizeViews();
        } catch (Exception e) {
            super.writeCrashReport(MainActivity.class.getName(), e.getMessage());
        }
    }




    /**
     * initalize views for the screen
     *
     * @throws Exception Run time Stub exception.
     */
    private void initalizeViews() throws Exception {

        dubuquTextLL = findViewById(R.id.dubuqu_main_activity_ll);

        parentView = findViewById(R.id.main_activity_parent_view_rl);

        dubuquLogoIMV = findViewById(R.id.dubuqu_logo_mainactivity_imv);

        /*animateObjects();*/

        sessionManager = new SessionManager(this);


        checkIfPhoneStatePermissionIsprovided();

        checkIfDeviceRegistered();

        lottieAnimationViewLoder = findViewById(R.id.main_activity_lottie_loder);
        lottieAnimationViewLoder.loop(true);

        toastText = findViewById(R.id.main_activity_toast_text);
        toastText.setVisibility(View.VISIBLE);

        lottieAnimationViewLoder.playAnimation();

        Typeface typeface = Typeface.createFromAsset(getResources().getAssets(), "font_tag.ttf");
        toastText.setTypeface(typeface);

    }


    /**
     * animate the @link{dubuquTextLL} to the top of the screen,
     * while its going up the @link{dubuqu_logo_mainactivity_imv} must scale up
     *
     * @throws Exception Runtime stub exception.
     */
    private void animateObjects() throws Exception {

        //scaling the dubuquLogoIMV to a size
        dubuquLogoIMV.setVisibility(View.VISIBLE);
        Animation animation = AnimationUtils.loadAnimation(MainActivity.this, R.anim.zoomin_animation);
        animation.setStartOffset(200);
        animation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                toastText.setVisibility(View.VISIBLE);

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });

        dubuquLogoIMV.setAnimation(animation);


    }

    /**
     * wait until the device is registered to onsignal api.
     *
     * @param stateChanges @link{OSSubscriptionStateChanges}
     */
    @Override
    public void onOSSubscriptionChanged(OSSubscriptionStateChanges stateChanges) {

        if (!stateChanges.getFrom().getSubscribed() &&
                stateChanges.getTo().getSubscribed()) {

            if (sessionManager.getNotificationToken() != null) {
                try {
                    final HashMap<String, String> userCredentials = sessionManager.getSecrectAndUserIdentifier(getApplicationContext());

                    String userIdnetifier = userCredentials.get(Constants.DUBUQU_USER_IDENTIFIER);

                    updateUserDetails(userIdnetifier, stateChanges.getTo().getUserId());

                } catch (Exception e) {
                    MainActivity.super.writeCrashReport(MainActivity.class.getName(), e.getMessage());
                }
            }
            sessionManager.setOnesignaltoken(stateChanges.getTo().getUserId());

            lottieAnimationViewLoder.cancelAnimation();

            toastText.setVisibility(View.GONE);
            try {
                navigateUserToMainScreens();
            } catch (Exception e) {
                MainActivity.super.writeCrashReport(MainActivity.class.getName(), e.getMessage());
            }
        }
    }

    private void checkIfPhoneStatePermissionIsprovided() throws Exception {

        if (super.checkIfPermissionIsGranted(Manifest.permission.READ_PHONE_STATE)) {
            if (sessionManager.getOneSignaleToken() == null)
                OneSignal.addSubscriptionObserver(this);
            else
                navigateUserToMainScreens();
        } else {

            super.requestPermission(new String[]{Manifest.permission.READ_PHONE_STATE},
                    new PermissionCallBack() {
                        @Override
                        public void onPermissionGranted() {
                            if (sessionManager.getOneSignaleToken() == null)
                                OneSignal.addSubscriptionObserver(MainActivity.this);
                            else {
                                try {
                                    navigateUserToMainScreens();
                                } catch (Exception e) {
                                    MainActivity.super.writeCrashReport(MainActivity.class.getName(), e.getMessage());
                                }
                            }
                        }

                        @Override
                        public void onPermissionRejected() {
                            try {
                                MainActivity.super.showToastMessage(getString(R.string.please_provide_permission_to_continue),
                                        false);
                            } catch (Exception e) {
                                MainActivity.super.writeCrashReport(MainActivity.class.getName(), e.getMessage());
                            }
                        }
                    });
        }
    }

    /**
     * check if device is registered to one signal since we have migrated from pushy to onesignal.
     */
    private void checkIfDeviceRegistered() throws Exception {
        if (sessionManager.getNotificationToken() != null) {
            JSONObject jsonObject = OneSignal.getPermissionSubscriptionState().getSubscriptionStatus().toJSONObject();

            final HashMap<String, String> userCredentials = sessionManager.getSecrectAndUserIdentifier(getApplicationContext());

            String userIdnetifier = userCredentials.get(Constants.DUBUQU_USER_IDENTIFIER);

            if (jsonObject.has("pushToken")) {
                try {
                    updateUserDetails(userIdnetifier, jsonObject.getString("pushToken"));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }


    /**
     * if user is in pushy service the device token must be updated with Onesignal token
     *
     * @param userIdentifier the unique identifier of the user
     * @param deviceToken    the onesignal device token.
     * @throws Exception Runtime stub exception.
     */
    private void updateUserDetails(final String userIdentifier, String deviceToken) throws Exception {

        UserDetails userDetails = new UserDetails();
        userDetails.setDevice_notification_key(deviceToken);
        Gson gson = new Gson();
        String data = gson.toJson(userDetails);
        OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, getApplicationContext());
        Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
        RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
        RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
        mRetrofitCallBacks.updateUserDetails(userIdentifier, userDetails,
                new RestServiceController.ResponseCallBacks() {
                    @Override
                    public void onResponse(Object o) {


                    }

                    @Override
                    public void onFailure(Object object) {
                        //Utils.showNegativeTost(getApplicationContext(), "Social Circle Creatation Failed.");
                    }
                });
    }

    /**
     * If user is not registered his/her phone_registration_phone number user is navigated to PhoneNumberRegistration
     * <p>
     * else user is navigated to the Landing Page Screen.
     *
     * @throws Exception Runtime Stub Exception.
     */
    private void navigateUserToMainScreens() throws Exception {

        boolean isRegistrationCompleted = sessionManager.isLoggedIn();


        if (isRegistrationCompleted) {
            //navigate to root  landing page
            Intent intent = new Intent(MainActivity.this, LandingActivity.class);
            startActivity(intent);
            finish();
        } else {
            //navigate to PhonenUmber Registration.
            Intent intent = new Intent(MainActivity.this, PhoneNumberRegistration.class);
            startActivity(intent);
            finish();
        }
    }

}
