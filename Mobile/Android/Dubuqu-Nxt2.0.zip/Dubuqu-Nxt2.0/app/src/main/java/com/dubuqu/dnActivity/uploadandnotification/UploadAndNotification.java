package com.dubuqu.dnActivity.uploadandnotification;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.transition.Explode;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.dubuqu.R;
import com.dubuqu.dnActivity.BaseActivity;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnFragments.uploadandnotification.Notificationfragmet;
import com.dubuqu.dnFragments.uploadandnotification.UploadFragment;

/**
 * Created by Yogaraj subramanian on 2/1/18
 */

public class UploadAndNotification extends BaseActivity {

    TextView tabIndicator;

    LinearLayout uploadTab, notificationTab;

    View back;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_upload_and_notification);

        setAnimation();
        try {
            initlaizeviews();
        } catch (Exception e) {
            writeCrashReport(e.getMessage());
        }
    }

    private void setAnimation() {

        Explode enterExplode, exitExplode;

        enterExplode = new Explode();
        exitExplode = new Explode();

        exitExplode.setMode(Explode.MODE_IN);
        enterExplode.setMode(Explode.MODE_IN);

        exitExplode.setDuration(400);
        enterExplode.setDuration(400);

        getWindow().setEnterTransition(enterExplode);
        getWindow().setExitTransition(exitExplode);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Constants.RESTRICT_SREENSHOT)
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
    }

    private void initlaizeviews() throws Exception {
        tabIndicator = findViewById(R.id.upload_and_notification_text_inidcator);

        back = findViewById(R.id.upload_and_notification_back);

        uploadTab = findViewById(R.id.upload_and_notification_upload_tab);

        notificationTab = findViewById(R.id.upload_and_notification_notification_tab);

        toogleTabs(getIntent().getBooleanExtra(Constants.EXTRASTRINGS, true));

        initlaizeListeners();
    }

    private void initlaizeListeners() throws Exception {

        uploadTab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toogleTabs(false);
            }
        });

        notificationTab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toogleTabs(true);
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    private void toogleTabs(boolean toShowNotification) {
        try {
            if (toShowNotification) {
                notificationTab.setBackgroundColor(getResources().getColor(R.color.red_color_picker));
                uploadTab.setBackgroundColor(getResources().getColor(android.R.color.transparent));
                changeFragment(new Notificationfragmet());
                tabIndicator.setText(getString(R.string.notification));
                YoYo.with(Techniques.Pulse).duration(Constants.ANIMATIONTIME).playOn(notificationTab.getChildAt(0));
            } else {
                uploadTab.setBackgroundColor(getResources().getColor(R.color.red_color_picker));
                notificationTab.setBackgroundColor(getResources().getColor(android.R.color.transparent));
                changeFragment(new UploadFragment());
                tabIndicator.setText(getString(R.string.upload));

                YoYo.with(Techniques.Pulse).duration(Constants.ANIMATIONTIME).playOn(uploadTab.getChildAt(0));
            }
        } catch (Exception e) {
            writeCrashReport(e.getMessage());
        }

    }

    private void changeFragment(Fragment fragment) throws Exception {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.upload_and_notification_frame_container, fragment);
        fragmentTransaction.commit();
    }

    private void writeCrashReport(@Nullable String message) {
        super.writeCrashReport(UploadAndNotification.class.getName(), message);
    }

}
