package com.dubuqu.dnAdapter.common;

import android.annotation.SuppressLint;
import android.support.annotation.NonNull;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;

import com.dubuqu.R;
import com.dubuqu.dnViews.DubuquTextView;

import java.util.List;

/**
 * Created by Yogaraj subramanian on 6/12/17
 */

public class CameraOptionsAdapter extends PagerAdapter {

    private List<String> mData;

    private float mBaseElevation;

    onItemClickListner onItemClickListner;

    public CameraOptionsAdapter(List<String> mData, CameraOptionsAdapter.onItemClickListner onItemClickListner) {
        this.mData = mData;
        this.onItemClickListner = onItemClickListner;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, final int position) {
        View view = LayoutInflater.from(container.getContext())
                .inflate(R.layout.camera_adpter_view_holder, container, false);
        container.addView(view);

        DubuquTextView textView = view.findViewById(R.id.camera_adapter_viewholder_text_view);
        textView.setText(mData.get(position));

        view.setOnTouchListener(new View.OnTouchListener() {
            @SuppressLint("ClickableViewAccessibility")
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                onItemClickListner.onItemClicked(position);
                return true;
            }
        });


        return view;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }

    public interface onItemClickListner {
        void onItemClicked(int position);
    }

}
