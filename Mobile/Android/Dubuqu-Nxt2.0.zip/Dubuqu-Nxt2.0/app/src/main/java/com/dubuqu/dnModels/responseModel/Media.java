
package com.dubuqu.dnModels.responseModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Media {

    @SerializedName("form_attributes")
    @Expose
    private FormAttributes formAttributes;
    @SerializedName("form_inputs")
    @Expose
    private FormInputs formInputs;

    public FormAttributes getFormAttributes() {
        return formAttributes;
    }

    public void setFormAttributes(FormAttributes formAttributes) {
        this.formAttributes = formAttributes;
    }

    public FormInputs getFormInputs() {
        return formInputs;
    }

    public void setFormInputs(FormInputs formInputs) {
        this.formInputs = formInputs;
    }

}
