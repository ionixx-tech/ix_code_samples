package com.dubuqu.dnModels.responseModel;

/**
 * Created by ionixx on 14/7/17.
 */

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PublicMediaSharedByUserModel {

    @SerializedName("signed_url")
    @Expose
    private String signedUrl;
    @SerializedName("media_identifier")
    @Expose
    private String mediaIdentifier;

    public String getSignedUrl() {
        return signedUrl;
    }

    public void setSignedUrl(String signedUrl) {
        this.signedUrl = signedUrl;
    }

    public String getMediaIdentifier() {
        return mediaIdentifier;
    }

    public void setMediaIdentifier(String mediaIdentifier) {
        this.mediaIdentifier = mediaIdentifier;
    }

}