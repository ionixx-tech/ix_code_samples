package com.dubuqu.dnAdapter.home;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.view.PagerAdapter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.dubuqu.R;
import com.dubuqu.dnActivity.LandingActivity;
import com.dubuqu.dnModels.responseModel.SharedMedias;
import com.dubuqu.dnViews.RealtimeBlurView;
import com.shuhart.bubblepagerindicator.ViewPagerProvider;

import java.util.List;

/**
 * Created by Yogaraj subramanian on 29/11/17
 */

public class FeedViewPagerAdapter extends PagerAdapter implements ViewPagerProvider {

    private Context context;

    private List<SharedMedias> sharedMediases;

    private FeedViewPagerCallbacks feedViewPagerCallbacks;

    private final String TAG = FeedViewPagerAdapter.class.getName();

    public FeedViewPagerAdapter(Context context,
                                List<SharedMedias> sharedMediases) {
        this.context = context;
        this.sharedMediases = sharedMediases;
    }

    public void setFeedViewPagerCallbacks(FeedViewPagerCallbacks feedViewPagerCallbacks) {
        this.feedViewPagerCallbacks = feedViewPagerCallbacks;
    }


    @Override
    public int getItemPosition(Object object) {
        return POSITION_NONE;
    }

    @Override
    public int getCount() {
        return sharedMediases.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        View view = LayoutInflater.from(context).inflate(R.layout.feed_view_pager_view, container, false);

        FeedViewPagerViewHolder feedViewPagerViewHolder = new FeedViewPagerViewHolder(view);

        try {
            feedViewPagerViewHolder.onBind(position);

        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        }

        container.addView(feedViewPagerViewHolder.getView());

        return feedViewPagerViewHolder.getView();
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        try {
            container.removeView((View) object);
        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
            if (context instanceof LandingActivity) {
                ((LandingActivity) context).writeCrashReport(TAG, e.getMessage());
            }
        }
    }

    @Override
    public int getRealCount() {
        return getCount();
    }

    @Override
    public int getRealPosition(int position) {
        return position;
    }

    public class FeedViewPagerViewHolder {

        View view, videoIndicator;

        ImageView imageView;

        SharedMedias sharedMedias;

        RealtimeBlurView realtimeBlurView;

        FeedViewPagerViewHolder(View view) {
            this.view = view;
            this.imageView = this.view.findViewById(R.id.feed_viewpager_image_view);
            this.videoIndicator = this.view.findViewById(R.id.feed_viewpager_video_indicator);
            this.realtimeBlurView = this.view.findViewById(R.id.feed_viewpager_real_time_blur_view);
            this.realtimeBlurView.setVisibility(View.GONE);
        }

        View getView() {
            return this.view;
        }

        /**
         * Bind views  to containers.
         * <p>
         * if content type of the media is  video show the video indicator icons.
         *
         * @param position the current position of the view.
         * @throws Exception {@link Exception} {Runtime stub Exception}
         */
        void onBind(final int position) throws Exception {

            sharedMedias = sharedMediases.get(position);

            if (sharedMedias != null) {

                final String contentType = sharedMedias.getContentType();

                if (contentType != null) {

                    Glide.with(context).load(sharedMedias.getSignedUrl())
                            .centerCrop()
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .dontAnimate()
                            .dontTransform()
                            .into(imageView);

                   /* File f = imageLoader.getDiskCache().get(sharedMedias.getSignedUrl());
                    if (!f.exists()) {
                        ImageLoader.getInstance().displayImage(sharedMedias.getSignedUrl(),
                                imageView, new ImageLoadingListener() {
                                    @Override
                                    public void onLoadingStarted(String imageUri, View view) {
                                        imageView.setImageDrawable(context.getResources().getDrawable(R.drawable.overlay_media));
                                    }

                                    @Override
                                    public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
                                        imageView.setImageDrawable(context.getResources().getDrawable(R.drawable.overlay_media));
                                    }

                                    @Override
                                    public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                                        realtimeBlurView.setVisibility(View.GONE);
                                        imageView.setImageBitmap(loadedImage);
                                        feedViewPagerCallbacks.changeViewPagerSize(view);
                                    }

                                    @Override
                                    public void onLoadingCancelled(String imageUri, View view) {
                                        imageView.setImageDrawable(context.getResources().getDrawable(R.drawable.overlay_media));
                                    }
                                });
                    } else {
                        realtimeBlurView.setVisibility(View.GONE);
                        imageLoader.displayImage(f.getAbsolutePath(), imageView);
                    }
*/
                    if (contentType.contains("video")) {
                        videoIndicator.setVisibility(View.VISIBLE);
                    } else {
                        videoIndicator.setVisibility(View.GONE);
                    }
                }
            }

            this.view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try {
                        feedViewPagerCallbacks.onItemViewClicked(position);
                    } catch (Exception e) {
                        if (context instanceof LandingActivity) {
                            ((LandingActivity) context).writeCrashReport(TAG, e.getMessage());
                        }
                    }
                }
            });
        }

    }

    public interface FeedViewPagerCallbacks {

        void onItemViewAdded(Integer position, FeedViewPagerViewHolder feedViewPagerViewHolder) throws Exception;

        void onItemViewremoved(int position) throws Exception;

        void onItemViewClicked(int postion) throws Exception;

        void changeViewPagerSize(View view);
    }
}
