package com.dubuqu.dnAdapter.common;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.view.PagerAdapter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.drawable.GlideDrawable;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.dubuqu.R;
import com.dubuqu.dnActivity.MultipleShareActivity;
import com.dubuqu.dnActivity.mediapreview.VideoPlayerActivity;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnPhotoEditor.BrushDrawingView;
import com.dubuqu.dnPhotoEditor.OnPhotoEditorSDKListener;
import com.dubuqu.dnPhotoEditor.PhotoEditorSDK;
import com.dubuqu.dnPhotoEditor.ViewType;
import com.dubuqu.dnUtils.RestServiceUtils;
import com.dubuqu.dnUtils.Utils;
import com.github.chrisbanes.photoview.PhotoView;
import com.google.gson.Gson;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;


/**
 * Created by Yogaraj subramanian on 31/10/17
 */

public class DubuquMediaAdapter extends PagerAdapter {

    private List<String> mediaList = new ArrayList<>();

    private Context context;

    private OnItemClick onItemClick;


    public interface OnItemClick {
        void onItemClicked(int position);

        void setOnEditMode(boolean isInEditMode) throws Exception;

        void onNewViewAdded(Integer position, DubuquMediaAdapterViewHolder dubuquMediaAdapterViewHolder)
                throws Exception;

        void onViewRemoved(int position);

        void onEdittextChangeListener(String text, int colorCode);

        void onItemMoved(boolean isItemMoved);

        void onImageSaved();
    }


    public DubuquMediaAdapter(List<String> mediaList, Context context, OnItemClick onItemClick) {
        this.mediaList = mediaList;
        this.context = context;
        this.onItemClick = onItemClick;
    }

    @Override
    public int getItemPosition(Object object) {
        return POSITION_NONE;
    }

    @Override
    public int getCount() {
        return mediaList.size();
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        View view = LayoutInflater.from(context).inflate(R.layout.dubuqu_media_adapter_view_holder,
                container, false);
        DubuquMediaAdapterViewHolder viewInflate = new DubuquMediaAdapterViewHolder();
        try {
            onItemClick.onNewViewAdded(position, viewInflate);
            viewInflate.initalizeView(view);
            viewInflate.onBind(position);

        } catch (Exception e) {
            e.printStackTrace();
        }

        container.addView(viewInflate.getView());
        return viewInflate.getView();

    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
        onItemClick.onViewRemoved(position);
    }


    public class DubuquMediaAdapterViewHolder implements OnPhotoEditorSDKListener {

        View view;

        PhotoView photoView;

        ImageView videoIndicator;

        ImageView imageEditView;

        RelativeLayout deleteLayout, parentView;

        public BrushDrawingView brushDrawingView;

        private PhotoEditorSDK photoEditorSDK;

        int currentPostion = 0;

        boolean isImageEdited = false;

        ProgressBar progressBar;

        void initalizeView(View view) {
            this.view = view;

            this.photoView = this.view.findViewById(R.id.dubuqu_media_adapter_imageview);
            this.photoView.setMaximumScale(10);

            this.videoIndicator = this.view.findViewById(R.id.dubuqu_media_adapter_video_indicator);
            this.deleteLayout = this.view.findViewById(R.id.dubuqu_media_adapter_delete_rl);
            this.brushDrawingView = this.view.findViewById(R.id.dubuqu_media_adapter_drawing_view);
            this.brushDrawingView.setVisibility(View.GONE);
            this.parentView = this.view.findViewById(R.id.dubuqu_media_adapter_parent_view);
            this.imageEditView = this.view.findViewById(R.id.dubuqu_media_adapter_editimageview);
            this.imageEditView.setVisibility(View.GONE);

            photoEditorSDK = new PhotoEditorSDK.PhotoEditorSDKBuilder(context)
                    .parentView(this.parentView) // add parent image view
                    .childView(this.imageEditView) // add the desired image view
                    .deleteView(this.deleteLayout) // add the deleted view that will appear during the movement of the views
                    .brushDrawingView(brushDrawingView) // add the brush drawing view that is responsible for drawing on the image view
                    .buildPhotoEditorSDK();

            photoEditorSDK.setOnPhotoEditorSDKListener(this);

            this.progressBar = this.view.findViewById(R.id.dubuqu_media_adapter_progress_bar);
            this.progressBar.setVisibility(View.GONE);
        }

        public View getView() {
            return view;
        }

        void onBind(final int position) throws Exception {

            currentPostion = position;

            String imageUrl = mediaList.get(position);

            String value = Utils.getContentType(imageUrl);
            if (value.contains("video") || value.equalsIgnoreCase("mp4") || value.equalsIgnoreCase("3gp"))
                this.videoIndicator.setVisibility(View.VISIBLE);
            else
                this.videoIndicator.setVisibility(View.GONE);

            this.parentView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    onItemClick.onItemClicked(position);
                }
            });

            File file = new File(imageUrl);

            Glide.with(context).load(file).into(imageEditView);
            if (value.contains("gif")) {
                imageEditView.setVisibility(View.VISIBLE);
                photoView.setVisibility(View.GONE);
                Glide.with(context).load(file).asGif()
                        .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                        .into(imageEditView);
            } else {
                progressBar.setVisibility(View.VISIBLE);

                if (value.contains("video") || value.equalsIgnoreCase("mp4")
                        || value.equalsIgnoreCase("3gp")) {
                    photoView.setVisibility(View.GONE);
                    imageEditView.setVisibility(View.VISIBLE);
                    Glide.with(context)
                            .load(file)
                            .listener(new RequestListener<File, GlideDrawable>() {
                                @Override
                                public boolean onException(Exception e, File model, Target<GlideDrawable> target, boolean isFirstResource) {
                                    return false;
                                }

                                @Override
                                public boolean onResourceReady(GlideDrawable resource, File model, Target<GlideDrawable> target,
                                                               boolean isFromMemoryCache, boolean isFirstResource) {

                                    progressBar.setVisibility(View.GONE);

                                    return false;
                                }
                            }).into(imageEditView);

                } else {

                    ExifInterface exif = new ExifInterface(file.getPath());
                    int width = exif.getAttributeInt(ExifInterface.TAG_IMAGE_WIDTH, 1280);
                    int height = exif.getAttributeInt(ExifInterface.TAG_IMAGE_LENGTH, 720);


                    Glide.with(context).load(file)
                            .override(
                                    width == 0 ? Target.SIZE_ORIGINAL : width,
                                    height == 0 ? Target.SIZE_ORIGINAL : height)
                            .listener(new RequestListener<File, GlideDrawable>() {
                                @Override
                                public boolean onException(Exception e, File model, Target<GlideDrawable> target, boolean isFirstResource) {
                                    return false;
                                }

                                @Override
                                public boolean onResourceReady(GlideDrawable resource, File model, Target<GlideDrawable> target,
                                                               boolean isFromMemoryCache, boolean isFirstResource) {

                                    progressBar.setVisibility(View.GONE);
                                    imageEditView.setImageDrawable(resource);
                                    return false;
                                }
                            }).into(photoView);

                }
            }

            this.photoView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    onItemClick.onItemClicked(position);
                }
            });
            this.brushDrawingView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    onItemClick.onItemClicked(position);
                }
            });

            this.imageEditView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    onItemClick.onItemClicked(position);
                }
            });

            this.videoIndicator.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(context, VideoPlayerActivity.class);
                    intent.putExtra(Constants.EXTRASTRINGS, mediaList.get(position));
                    context.startActivity(intent);
                }
            });
        }


        public void addFilterToMedia(String filter) {
            photoEditorSDK.addFilter(filter);
        }

        public void addStrickers(String stickerCode) throws Exception {
            isImageEdited = true;
            if (photoView.getVisibility() == View.VISIBLE && imageEditView.getVisibility() == View.GONE) {
                photoView.setVisibility(View.GONE);
                imageEditView.setVisibility(View.VISIBLE);
            }
            photoEditorSDK.addImage(stickerCode);
            parentView.setDrawingCacheEnabled(true);
        }

        public void addText(String text, int colorCode) throws Exception {
            if (photoView.getVisibility() == View.VISIBLE && imageEditView.getVisibility() == View.GONE) {
                photoView.setVisibility(View.GONE);
                imageEditView.setVisibility(View.VISIBLE);
            }
            isImageEdited = true;
            photoEditorSDK.addText(text, colorCode);
            parentView.setDrawingCacheEnabled(true);
        }

        public void addEmoji(String emojiCode) throws Exception {
            if (photoView.getVisibility() == View.VISIBLE && imageEditView.getVisibility() == View.GONE) {
                photoView.setVisibility(View.GONE);
                imageEditView.setVisibility(View.VISIBLE);
            }
            isImageEdited = true;
            photoEditorSDK.addEmoji(emojiCode);
            parentView.setDrawingCacheEnabled(true);
        }

        public void updateBrushDrawingView(boolean brushDrawingMode) {
            photoEditorSDK.setBrushDrawingMode(brushDrawingMode);
            if (brushDrawingMode) {
                if (photoView.getVisibility() == View.VISIBLE && imageEditView.getVisibility() == View.GONE) {
                    photoView.setVisibility(View.GONE);
                    imageEditView.setVisibility(View.VISIBLE);
                }
                brushDrawingView.setVisibility(View.VISIBLE);
                isImageEdited = true;
                parentView.setDrawingCacheEnabled(true);
            }
        }

        public void setFilterMode() {
            if (photoView.getVisibility() == View.VISIBLE && imageEditView.getVisibility() == View.GONE) {
                photoView.setVisibility(View.GONE);
                imageEditView.setVisibility(View.VISIBLE);
            }
            isImageEdited = true;
            parentView.setDrawingCacheEnabled(true);
        }

        public boolean checkIfAnyViewAvailable() {
            return photoEditorSDK.getNumberOfViewsAdded() > 0;
        }

        public void clearView() {
            photoEditorSDK.clearAllViews();
            photoEditorSDK.clearBrushAllViews();
            brushDrawingView.setVisibility(View.GONE);
            parentView.setDrawingCacheEnabled(false);
            isImageEdited = false;

            photoView.setVisibility(View.VISIBLE);
            imageEditView.setVisibility(View.GONE);
        }

        public void clearAllBrushView() {
            photoEditorSDK.clearBrushAllViews();
            brushDrawingView.setVisibility(View.GONE);
        }

        @Override
        public void onEditTextChangeListener(String text, int colorCode) {
            onItemClick.onEdittextChangeListener(text, colorCode);
        }

        @Override
        public void onAddViewListener(ViewType viewType, int numberOfAddedViews) {

        }

        @Override
        public void onRemoveViewListener(int numberOfAddedViews) {
            if (numberOfAddedViews == 0)
                try {
                    onItemClick.setOnEditMode(false);
                    if (brushDrawingView.getVisibility() != View.VISIBLE) {
                        parentView.setDrawingCacheEnabled(false);

                        photoView.setVisibility(View.VISIBLE);
                        imageEditView.setVisibility(View.GONE);

                        isImageEdited = false;
                    }
                } catch (Exception e) {
                    Log.d(DubuquMediaAdapterViewHolder.class.getName(),
                            e.getLocalizedMessage());
                }
        }

        @Override
        public void onStartViewChangeListener(ViewType viewType) {
            if (!viewType.equals(ViewType.BRUSH_DRAWING))
                onItemClick.onItemMoved(true);
        }

        @Override
        public void onStopViewChangeListener(ViewType viewType) {
            if (!viewType.equals(ViewType.BRUSH_DRAWING))
                onItemClick.onItemMoved(false);
        }

        public void saveImage() throws Exception {

            String savedPath = photoEditorSDK.saveImage(context.getString(R.string.app_name),
                    String.valueOf(System.currentTimeMillis()));

            clearView();

            mediaList.add(currentPostion, savedPath);
            notifyDataSetChanged();

            onItemClick.onImageSaved();

        }

        public void cropImage(Uri filePath) throws Exception {

            File file = new File(filePath.getPath());

            Glide.with(context)
                    .load(file)
                    .into(this.imageEditView);

            Glide.with(context)
                    .load(file)
                    .into(this.photoView);

            clearView();

            isImageEdited = true;
            parentView.setDrawingCacheEnabled(true);
        }


        public void openMultiShareActivity() throws Exception {
            Intent intent = new Intent(context, MultipleShareActivity.class);
            Bundle bundle = new Bundle();
            List<String> seletedImages = new ArrayList<>();

            if (!isImageEdited) {
                seletedImages.add(mediaList.get(currentPostion));
            } else {

                Date now = new Date();
                android.text.format.DateFormat.format("yyyy-MM-dd_hh:mm:ss", now);
                // image naming and path  to include sd card  appending name you choose for file
                String mPath = Environment.getExternalStorageDirectory().toString() + "/" + now + ".png";
                // create bitmap screen capture
                Bitmap bitmap = Bitmap.createBitmap(parentView.getDrawingCache());

                parentView.setDrawingCacheEnabled(false);
                File imageFile = new File(mPath);
                FileOutputStream outputStream = new FileOutputStream(imageFile);
                int quality = 100;
                bitmap.compress(Bitmap.CompressFormat.PNG, quality, outputStream);
                outputStream.flush();
                outputStream.close();
                Uri imagePath = Uri.fromFile(imageFile);
                seletedImages.add(imagePath.getPath());
            }
            String imageData = new Gson().toJson(seletedImages);
            bundle.putString(Constants.EXTRASTRINGS, imageData);
            intent.putExtras(bundle);
            context.startActivity(intent);
        }

        public void shareMediaToFrequentUssers(List<String> selectedUsers) throws Exception {

            List<String> seletedImages = new ArrayList<>();

            if (!isImageEdited) {
                seletedImages.add(mediaList.get(currentPostion));

            } else {

                Date now = new Date();
                android.text.format.DateFormat.format("yyyy-MM-dd_hh:mm:ss", now);
                // image naming and path  to include sd card  appending name you choose for file
                String mPath = Environment.getExternalStorageDirectory().toString() + "/" + now + ".png";
                // create bitmap screen capture
                Bitmap bitmap = Bitmap.createBitmap(parentView.getDrawingCache());

                parentView.setDrawingCacheEnabled(false);
                File imageFile = new File(mPath);
                FileOutputStream outputStream = new FileOutputStream(imageFile);
                int quality = 100;
                bitmap.compress(Bitmap.CompressFormat.PNG, quality, outputStream);
                outputStream.flush();
                outputStream.close();
                Uri imagePath = Uri.fromFile(imageFile);
                seletedImages.add(imagePath.getPath());
            }

            Gson g = new Gson();
            String SselectedUsers = g.toJson(selectedUsers);
            Random random = new Random();
            String fileList = g.toJson(seletedImages);
            RestServiceUtils.scheduleUploadMediaFile(context, fileList, SselectedUsers,
                    false);
        }

        public void setBrushColor(int colorCode) {
            photoEditorSDK.setBrushColor(colorCode);
        }
    }
}
