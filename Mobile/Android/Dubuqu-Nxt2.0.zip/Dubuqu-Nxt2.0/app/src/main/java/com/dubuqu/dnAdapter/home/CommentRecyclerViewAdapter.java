package com.dubuqu.dnAdapter.home;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.support.v7.widget.RecyclerView;
import android.text.format.DateUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.dubuqu.R;
import com.dubuqu.dnModels.responseModel.MediaComment;
import com.dubuqu.dnStorage.SessionManager;
import com.dubuqu.dnUtils.Utils;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import de.hdodenhof.circleimageview.CircleImageView;
import vc908.stickerfactory.StickersManager;

/**
 * {@link CommentRecyclerViewAdapter} helps to load the comments which are passed against the media.
 * <p>
 * Two types of comments are loaded here text and stickers which are provided by {@link vc908.stickerfactory.model.Sticker}
 */
public class CommentRecyclerViewAdapter extends RecyclerView.Adapter<CommentRecyclerViewAdapter.ViewHolder> {

    private List<MediaComment> mediaComment;

    private Context context;

    private final ImageLoader imageLoader;

    private String userIdentifier = "";

    private boolean isStoryTimeLine = false;

    private CommentCallback commentCallback;


    public interface CommentCallback {
        void onLongPressed(MediaComment mediaComment);
    }

    public CommentRecyclerViewAdapter(Context context,
                                      List<MediaComment> mediaComment,
                                      boolean isStoryTimeLine,
                                      CommentCallback commentCallback
                                      ) {
        this.context = context;
        this.mediaComment = mediaComment;
        imageLoader = ImageLoader.getInstance();
        imageLoader.init(ImageLoaderConfiguration.createDefault(context));

        SessionManager sessionManager = new SessionManager(context);
        userIdentifier = sessionManager.getUserIdentifier();

        this.isStoryTimeLine = isStoryTimeLine;

        this.commentCallback = commentCallback;


    }


    public void add(int position, MediaComment item) {
        mediaComment.add(position, item);
        /*notifyItemInserted(position);*/
    }

    public void add(List<MediaComment> mediaComments) throws Exception {
        mediaComment.addAll(0, mediaComments);
        notifyDataSetChanged();

    }

    public void add(int size, List<MediaComment> mediaComments) throws Exception {
        mediaComment.addAll(size, mediaComments);
        notifyItemRangeInserted(size, mediaComments.size());
    }

    public void remove(int position) {
        mediaComment.remove(position);
        notifyItemRemoved(position);
    }

    @Override
    public CommentRecyclerViewAdapter.ViewHolder onCreateViewHolder(ViewGroup parent,
                                                                    int viewType) {
        LayoutInflater inflater = LayoutInflater.from(
                parent.getContext());
        View v = inflater.inflate(R.layout.dn_public_image_viewer_comment_item, parent, false);

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        try {
            holder.onBindPostion(position);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

   /* @Override
    public long getItemId(int position) {
        return mediaComment.get(position).hashCode();
    }

    @Override
    public int getItemViewType(int position) {
        return mediaComment.get(position).hashCode();
    }*/

    private String calulateTime(String timeStamp) throws Exception {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));

        Date date = sdf.parse(timeStamp);

        long millis = date.getTime();
        long timeInMillis = System.currentTimeMillis();

        CharSequence text = DateUtils.getRelativeTimeSpanString(millis, timeInMillis, 0,
                DateUtils.FORMAT_ABBREV_ALL);

        if (text.toString().equalsIgnoreCase("0 sec.ago")) {
            return "just now.";
        } else {
            return text.toString();
        }

    }

    @Override
    public int getItemCount() {
        return mediaComment.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        /*receiver*/
        TextView receiverUserName, receiverTextComment, receiverCommentTime;
        CircleImageView imgProfile;
        ImageView receiverImgStickers, receiverReplyImv;

        /*sender*/
        TextView senderTextComment, senderCommentTime;
        ImageView senderImgStickers, senderReplyImv;

        /*parnet receiver*/
        TextView parentTextComment, parentTextCommentUser;
        ImageView parentImgStickers;

        /*paren sender*/
        TextView parentSenderTextComment, parentSenderTextCommentUser;
        ImageView parentSenderImgStickers;

        LinearLayout receiverComment, senderComment;

        RelativeLayout parentComment, parentSenderComment;

        public ViewHolder(View v) {
            super(v);

            receiverUserName = v.findViewById(R.id.receiver_user_name);

            receiverTextComment = v.findViewById(R.id.receiver_text_comment);

            imgProfile = v.findViewById(R.id.receiver_profile_icon);

            receiverImgStickers = v.findViewById(R.id.receiver_sticker_comment);

            receiverCommentTime = v.findViewById(R.id.receiver_comment_time);

            senderTextComment = v.findViewById(R.id.sender_text_comment);

            senderImgStickers = v.findViewById(R.id.sender_sticker_comment);

            senderCommentTime = v.findViewById(R.id.sender_comment_time);

            receiverComment = v.findViewById(R.id.comment_from_others);

            senderComment = v.findViewById(R.id.comment_from_sender);

            parentComment = v.findViewById(R.id.parent_comment_rl);

            parentComment.setVisibility(View.GONE);

            parentTextComment = v.findViewById(R.id.parent_text_comment);

            parentImgStickers = v.findViewById(R.id.parent_sticker_comment);

            senderReplyImv = v.findViewById(R.id.adapter_comment_viewholder_sender_rply_imv);

            receiverReplyImv = v.findViewById(R.id.adapter_comment_viewholder_receiver_rply_imv);

            parentTextCommentUser = v.findViewById(R.id.parent_text_comment_user);

            parentSenderComment = v.findViewById(R.id.parent_comment_sender_rl);

            parentSenderTextComment = v.findViewById(R.id.parent_text__sender_comment);

            parentSenderTextCommentUser = v.findViewById(R.id.parent_text_comment_sender__user);

            parentSenderImgStickers = v.findViewById(R.id.parent_sticker__sender_comment);

        }

        void onBindPostion(final int position) throws Exception {

            if (userIdentifier.equalsIgnoreCase(mediaComment.get(position).getUserIdentifier())) {

                /*comment is send by the user*/
                setSenderComment(position);

                setSenderParentComment(position);

            } else {

                setReceiverComment(position);

                setReceiverParentComment(position);
            }

            senderReplyImv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    commentCallback.onLongPressed(mediaComment.get(position));
                }
            });

            receiverReplyImv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    commentCallback.onLongPressed(mediaComment.get(position));
                }
            });
        }

        private void setSenderComment(int position) throws Exception {

            String comment = mediaComment.get(position).getComment();

            String time = calulateTime(mediaComment.get(position).getCreatedTime());

            senderComment.setVisibility(View.VISIBLE);
            receiverComment.setVisibility(View.GONE);

            senderCommentTime.setText(time);

            receiverTextComment.setVisibility(View.GONE);
            receiverImgStickers.setVisibility(View.GONE);

            switch (mediaComment.get(position).getCommentType().toLowerCase()) {
                case "text":
                    senderTextComment.setVisibility(View.VISIBLE);
                    senderTextComment.setText(comment);
                    senderImgStickers.setVisibility(View.GONE);
                    break;

                case "sticker":
                    if (comment != null) {
                        senderTextComment.setVisibility(View.GONE);
                        senderImgStickers.setVisibility(View.VISIBLE);
                        StickersManager.with(context).loadSticker(comment).into(senderImgStickers);
                    }

                    break;
            }

        }

        private void setSenderParentComment(int position) throws Exception {

            MediaComment.ParentComment parentComments = mediaComment.get(position).getParentComment();

            String comment = mediaComment.get(position).getComment();

            if (parentComments != null && parentComments.getCommentType() != null) {

                if (parentComments.getUserIdentifier().equalsIgnoreCase(userIdentifier)) {
                    parentTextCommentUser.setText("You");
                } else {
                    parentTextCommentUser.setText(parentComments.getUserName());
                }

                parentComment.setVisibility(View.VISIBLE);
                switch (parentComments.getCommentType().toLowerCase()) {
                    case "text":
                        parentTextComment.setVisibility(View.VISIBLE);
                        parentTextComment.setText(parentComments.getComment());
                        parentImgStickers.setVisibility(View.GONE);
                        break;

                    case "sticker":
                        if (comment != null) {
                            parentTextComment.setVisibility(View.GONE);
                            parentImgStickers.setVisibility(View.VISIBLE);
                            StickersManager.with(context).loadSticker(parentComments.getComment())
                                    .into(parentImgStickers);
                        }
                        break;
                }
            } else {
                parentComment.setVisibility(View.GONE);
            }
        }

        private void setReceiverComment(int position) throws Exception {

            String name = mediaComment.get(position).getUserName();

            String comment = mediaComment.get(position).getComment();

            String time = calulateTime(mediaComment.get(position).getCreatedTime());

            senderComment.setVisibility(View.GONE);
            receiverComment.setVisibility(View.VISIBLE);

            receiverUserName.setText(name);

            receiverCommentTime.setText(time);
            String imagePath = mediaComment.get(position).getProfileImage();

            final Drawable drawable = new BitmapDrawable(Utils.textAsBitmap(name, context));
            if (!Utils.isVaildString(imagePath)) {
                imgProfile.setImageDrawable(drawable);
            } else {
                setUserProfileImage(imagePath, position);
            }

            receiverTextComment.setVisibility(View.GONE);
            receiverImgStickers.setVisibility(View.GONE);

            if (mediaComment.get(position).getCommentType() != null)
                switch (mediaComment.get(position).getCommentType().toLowerCase()) {
                    case "text":
                        receiverTextComment.setVisibility(View.VISIBLE);
                        receiverTextComment.setText(comment);
                        receiverImgStickers.setVisibility(View.GONE);
                        break;

                    case "sticker":
                        if (comment != null) {
                            receiverTextComment.setVisibility(View.GONE);
                            receiverImgStickers.setVisibility(View.VISIBLE);
                            StickersManager.with(context).loadSticker(comment).into(receiverImgStickers);
                        }

                        break;
                }

        }

        private void setReceiverParentComment(int position) throws Exception {
            MediaComment.ParentComment parentComments = mediaComment.get(position).getParentComment();

            String comment = mediaComment.get(position).getComment();

            if (parentComments != null && parentComments.getCommentType() != null) {

                if (parentComments.getUserIdentifier().equalsIgnoreCase(userIdentifier)) {
                    parentSenderTextCommentUser.setText("You");
                } else {
                    parentSenderTextCommentUser.setText(parentComments.getUserName());
                }

                parentSenderComment.setVisibility(View.VISIBLE);

                switch (parentComments.getCommentType().toLowerCase()) {
                    case "text":
                        parentSenderTextComment.setVisibility(View.VISIBLE);
                        parentSenderTextComment.setText(parentComments.getComment());
                        parentSenderImgStickers.setVisibility(View.GONE);
                        break;

                    case "sticker":
                        if (comment != null) {
                            parentSenderTextComment.setVisibility(View.GONE);
                            parentSenderImgStickers.setVisibility(View.VISIBLE);
                            StickersManager.with(context).loadSticker(parentComments.getComment())
                                    .into(parentSenderImgStickers);
                        }
                        break;
                }
            } else {
                parentSenderComment.setVisibility(View.GONE);
            }
        }

        private void setUserProfileImage(String name, int position) throws Exception {

            final Drawable drawable = new BitmapDrawable(Utils.textAsBitmap(name, context));

            imageLoader.displayImage(mediaComment.get(position).getProfileImage(), imgProfile, new ImageLoadingListener() {
                @Override
                public void onLoadingStarted(String imageUri, View view) {
                    imgProfile.setImageDrawable(drawable);
                }

                @Override
                public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
                    imgProfile.setImageDrawable(drawable);
                }

                @Override
                public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                    imgProfile.setImageBitmap(loadedImage);
                }

                @Override
                public void onLoadingCancelled(String imageUri, View view) {
                    imgProfile.setImageDrawable(drawable);
                }
            });
        }
    }


}