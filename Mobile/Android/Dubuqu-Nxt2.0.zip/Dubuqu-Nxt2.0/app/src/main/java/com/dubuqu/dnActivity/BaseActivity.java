package com.dubuqu.dnActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.SwipeDismissBehavior;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.dubuqu.R;
import com.dubuqu.dnActivity.uploadandnotification.UploadAndNotification;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnModels.commonModel.NotificationModel;
import com.dubuqu.dnModels.responseModel.SharedMedias;
import com.dubuqu.dnRestServices.RestServiceController;
import com.dubuqu.dnRestServices.RestServiceProvider;
import com.dubuqu.dnStorage.SessionManager;
import com.dubuqu.dnUtils.RestServiceUtils;
import com.dubuqu.dnUtils.Utils;
import com.google.gson.Gson;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.valdesekamdem.library.mdtoast.MDToast;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import uk.co.samuelwall.materialtaptargetprompt.MaterialTapTargetPrompt;
import uk.co.samuelwall.materialtaptargetprompt.extras.backgrounds.CirclePromptBackground;
import uk.co.samuelwall.materialtaptargetprompt.extras.backgrounds.RectanglePromptBackground;

/**
 * Created by Yogaraj subramanian on 23/10/17
 */

public class BaseActivity extends AppCompatActivity {


    private PermissionCallBack permissionCallBack;

    private final int REQUEST_CODE = 1234;

    private PopupWindow popupWindow = null, inAppNotificationPopup = null;

    /**
     * interface to notify datas
     */
    public interface PermissionCallBack {
        void onPermissionGranted();

        void onPermissionRejected();
    }

    @Override
    protected void onResume() {
        super.onResume();

        registerReceiver(broadcastReceiver, new IntentFilter("ShowINAPP"));

        if (Constants.RESTRICT_SREENSHOT)
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            unregisterReceiver(broadcastReceiver);
        } catch (Exception e) {
            writeCrashReport(BaseActivity.class.getName(), e.getMessage());
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            cancelInApp();
        } catch (Exception e) {
            writeCrashReport(BaseActivity.class.getName(), e.getMessage());
        }
    }

    @Override
    public void onRequestPermissionsResult(int reqCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(reqCode, permissions, grantResults);
        switch (reqCode) {
            case REQUEST_CODE: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    permissionCallBack.onPermissionGranted();
                } else {
                    permissionCallBack.onPermissionRejected();
                }
            }
            break;
        }
    }

    /**
     * to show toast message form any part of the application.
     *
     * @param dataTobeShown the data need to be shown in the toast.
     * @param isPostive     to detect whether a positive or negative toast should be shown.
     */
    public void showToastMessage(String dataTobeShown, boolean isPostive) {
        MDToast mdToast = null;

        if (isPostive)
            mdToast = MDToast.makeText(BaseActivity.this, dataTobeShown, MDToast.LENGTH_SHORT, MDToast.TYPE_SUCCESS);
        else
            mdToast = MDToast.makeText(BaseActivity.this, dataTobeShown, MDToast.LENGTH_SHORT, MDToast.TYPE_WARNING);

        mdToast.show();

    }

    /**
     * if any anonymous class need any context Mainactivity context can be used instead of applications
     * context.
     *
     * @return Context the main activity
     */
    public Context getMainActivityInstance() {
        return BaseActivity.this;
    }

    /**
     * if any class need to be broad cast any data the broad cast can be done here to reduce redunancy
     * of code.
     *
     * @param intentFilter to detect which broadcast receiver need to be called while broadcasting.
     */
    public void broadCastData(String intentFilter) throws Exception {
        Intent intent = new Intent(intentFilter);
        sendBroadcast(intent);
    }


    /**
     * request permission from all class i.e from any part of activity.
     *
     * @param permissions        permissions which need to be granted.
     * @param permissionCallBack callback to indicate whether permission is granted or not.
     */
    public void requestPermission(String[] permissions, PermissionCallBack permissionCallBack)
            throws Exception {

        this.permissionCallBack = permissionCallBack;

        ActivityCompat.requestPermissions(BaseActivity.this, permissions, REQUEST_CODE);

    }

    /**
     * check if the permission is granted or not.
     *
     * @param permission permission which is to be checked.
     * @throws Exception Runtime stub Exception.
     */
    public boolean checkIfPermissionIsGranted(String permission)
            throws Exception {

        int permissionCheck = ContextCompat.checkSelfPermission(BaseActivity.this, permission);

        return permissionCheck == PackageManager.PERMISSION_GRANTED;
    }

    /**
     * handle if any crash occurs in the application
     *
     * @param className the class where the crash has occured.
     * @param data      the data to be printed.
     */
    public void writeCrashReport(String className, String data) {
        Log.e(className, "Error : -----------------> : " + data);
    }

    /**
     * inflate @link{R.layout,no_internetview} to intimate that  user has no internet connectivity
     *
     * @throws Exception Runtime Stub Exception.
     */
    public void showNoInternetView() throws Exception {

        if (popupWindow != null) {

            LayoutInflater inflater = (LayoutInflater)
                    getSystemService(LAYOUT_INFLATER_SERVICE);

            View noInternetView = inflater.inflate(R.layout.no_intetrnet_view, null);

            popupWindow = new PopupWindow(BaseActivity.this);
            popupWindow.setContentView(noInternetView);
            popupWindow.setWidth(LinearLayout.LayoutParams.MATCH_PARENT);
            popupWindow.setHeight(LinearLayout.LayoutParams.MATCH_PARENT);
            popupWindow.setFocusable(true);
            popupWindow.setBackgroundDrawable(null);
            popupWindow.showAtLocation(noInternetView, Gravity.TOP, 0, 0);

        }
    }

    /**
     * Show Loading view if needed.
     *
     * @throws Exception {Runtime Stub Exception}
     */
    public void showLoaders(Context context) throws Exception {

        LayoutInflater inflater = (LayoutInflater)
                getSystemService(LAYOUT_INFLATER_SERVICE);


        final View noInternetView = inflater.inflate(R.layout.layout_loader, null);

        popupWindow = new PopupWindow(context);
        popupWindow.setContentView(noInternetView);
        popupWindow.setWidth(LinearLayout.LayoutParams.MATCH_PARENT);
        popupWindow.setHeight(LinearLayout.LayoutParams.MATCH_PARENT);
        popupWindow.setFocusable(true);
        popupWindow.setBackgroundDrawable(null);

        popupWindow.showAtLocation(noInternetView, Gravity.CENTER, 0, 0);
    }

    public void showCameraintro(Context context) throws Exception {
        LayoutInflater inflater = (LayoutInflater)
                getSystemService(LAYOUT_INFLATER_SERVICE);

        final View noInternetView = inflater.inflate(R.layout.camera_intro_layout, null);

        popupWindow = new PopupWindow(context);
        popupWindow.setContentView(noInternetView);
        popupWindow.setWidth(LinearLayout.LayoutParams.MATCH_PARENT);
        popupWindow.setHeight(LinearLayout.LayoutParams.MATCH_PARENT);
        popupWindow.setFocusable(true);
        popupWindow.setBackgroundDrawable(null);

        noInternetView.post(new Runnable() {
            @Override
            public void run() {
                popupWindow.showAtLocation(noInternetView, Gravity.TOP, 0, 0);
            }
        });
    }

    public void showTutorialScreenView(View view,
                                       String primaryText,
                                       String secondaryText,
                                       boolean isRound,
                                       final OnTutorialFinishLisenter onTutorialFinishLisenter) {


        Typeface typeface = Typeface.createFromAsset(getResources().getAssets(), Constants.FONTBOLD);

        Typeface typefaceBold = Typeface.createFromAsset(getResources().getAssets(), Constants.FONT_LIGHT);

        new MaterialTapTargetPrompt.Builder(BaseActivity.this)
                .setTarget(view)
                .setPrimaryText(primaryText)
                .setPrimaryTextTypeface(typefaceBold)
                .setSecondaryText(secondaryText)
                .setSecondaryTextTypeface(typeface)
                .setAutoDismiss(true)
                .setBackButtonDismissEnabled(true)
                .setBackgroundColour(getResources().getColor(R.color.black_transperant))
                .setPromptBackground(isRound ? new CirclePromptBackground() : new RectanglePromptBackground())
                .setPromptStateChangeListener(new MaterialTapTargetPrompt.PromptStateChangeListener() {
                    @Override
                    public void onPromptStateChanged(MaterialTapTargetPrompt prompt, int state) {
                        if (state == MaterialTapTargetPrompt.STATE_FOCAL_PRESSED
                                || state == MaterialTapTargetPrompt.STATE_NON_FOCAL_PRESSED) {
                            if (onTutorialFinishLisenter != null) {
                                prompt.dismiss();
                                onTutorialFinishLisenter.onfinished(true);
                            }
                        }
                    }
                })
                .show();

    }

    /*private void show inbuild notiifcation*/

    public void showInAppNotiifcation(String stringExtra) throws Exception {

        NotificationModel notificationModel = new Gson().fromJson(stringExtra, NotificationModel.class);

        LayoutInflater inflater = (LayoutInflater)
                getSystemService(LAYOUT_INFLATER_SERVICE);

        if (inAppNotificationPopup != null) {
            inAppNotificationPopup.dismiss();
            inAppNotificationPopup = null;
        }

        final View inappView = inflater.inflate(R.layout.layout_in_app_notification, null);

        inAppNotificationPopup = new PopupWindow(BaseActivity.this);
        inAppNotificationPopup.setContentView(inappView);
        inAppNotificationPopup.setWidth(LinearLayout.LayoutParams.MATCH_PARENT);
        inAppNotificationPopup.setHeight(LinearLayout.LayoutParams.WRAP_CONTENT);
        inAppNotificationPopup.setFocusable(false);
        inAppNotificationPopup.setBackgroundDrawable(null);
        inAppNotificationPopup.setOutsideTouchable(true);
        inAppNotificationPopup.showAtLocation(inappView, Gravity.TOP, 0, 0);

        setInAppNotificationData(inappView, notificationModel);

        setSwipeBehaviour(inappView);

        inappView.findViewById(R.id.layout_inappnotification_rl).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(BaseActivity.this, UploadAndNotification.class));
                inAppNotificationPopup.dismiss();
                inAppNotificationPopup = null;
            }
        });

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                cancelInApp();
            }
        }, 5000);
    }

    private void cancelInApp() {
        try {
            if (inAppNotificationPopup != null) {
                inAppNotificationPopup.dismiss();
                inAppNotificationPopup = null;
            }
        } catch (Exception e) {
            writeCrashReport(BaseActivity.class.getName(), e.getMessage());
        }
    }

    private void setSwipeBehaviour(View parentView) throws Exception {
        SwipeDismissBehavior<View> swipeDismissBehavior = new SwipeDismissBehavior<>();

        swipeDismissBehavior.setSwipeDirection(SwipeDismissBehavior.SWIPE_DIRECTION_ANY);

        CoordinatorLayout.LayoutParams layoutParams = (CoordinatorLayout.LayoutParams)
                parentView.findViewById(R.id.layout_inappnotification_rl).getLayoutParams();

        layoutParams.setBehavior(swipeDismissBehavior);
    }


    private void setInAppNotificationData(View parentView, NotificationModel notificationModel) throws Exception {

        if (notificationModel != null) {

            TextView message = parentView.findViewById(R.id.layout_inappnotification_txt);
            message.setText(notificationModel.getMessage());
            TextView comment = parentView.findViewById(R.id.layout_inappnotification_commenttxt);
            if (notificationModel.getType().equalsIgnoreCase("comment")) {
                comment.setText(notificationModel.getCommentIdentifier());
            } else {
                comment.setVisibility(View.GONE);
            }
            final ImageView circleImageView = parentView.findViewById(R.id.layout_inappnotification_cimv);

            String mediaIdentifier = notificationModel.getMediaIdentifier();
            if (Utils.isVaildString(mediaIdentifier)) {
                String data = "{}";
                OkHttpClient okHttpClient = RestServiceUtils.getHeader(data, this);
                Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
                RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
                RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
                mRetrofitCallBacks.getMediaDetails(mediaIdentifier, new RestServiceController.ResponseCallBacks() {
                    @Override
                    public void onResponse(Object o) {
                        if (o != null) try {
                            final SharedMedias response = (SharedMedias) o;

                            ImageLoader.getInstance().displayImage(response.getThumbnailUrl(), circleImageView);

                            if (new SessionManager(getMainActivityInstance()).getNewMessageNotification()) {
                                Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                                Ringtone r = RingtoneManager.getRingtone(getApplicationContext(), notification);
                                r.play();
                            }


                        } catch (Exception e) {
                            circleImageView.setImageResource(R.mipmap.ic_launcher);
                        }
                    }

                    @Override
                    public void onFailure(Object o) {
                        circleImageView.setImageResource(R.mipmap.ic_launcher);
                    }
                });
            } else {
                circleImageView.setImageResource(R.mipmap.ic_launcher);
            }

        }
    }

    /**
     * Stop popup view.
     *
     * @throws Exception {Runtime Stub Exception}
     */
    public void cancelPopUp() throws Exception {
        if (popupWindow != null)
            popupWindow.dismiss();

    }

    public interface OnTutorialFinishLisenter {
        void onfinished(boolean isFinished);
    }

    /**
     * Overrides the pending Activity transition by performing the "Enter" animation.
     */
    protected void overridePendingTransitionEnter() {
        overridePendingTransition(R.anim.slide_from_right, R.anim.slide_to_left);
    }

    /**
     * Overrides the pending Activity transition by performing the "Exit" animation.
     */
    protected void overridePendingTransitionExit() {
        overridePendingTransition(R.anim.slide_from_left, R.anim.slide_to_right);
    }


    BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            try {
                showInAppNotiifcation(intent.getStringExtra(Constants.EXTRASTRINGS));
            } catch (Exception e) {
                writeCrashReport(BaseActivity.class.getName(), e.getMessage());
            }
        }
    };
}
