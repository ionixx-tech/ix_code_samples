
package com.dubuqu.dnFragments.profile;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.FileProvider;
import android.support.v4.util.Pair;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.drawable.GlideDrawable;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.dubuqu.R;
import com.dubuqu.dnActivity.BaseActivity;
import com.dubuqu.dnActivity.RemoveProfileImageActivity;
import com.dubuqu.dnActivity.profile.EditProfileActivity;
import com.dubuqu.dnActivity.profile.FullImageViewActivity;
import com.dubuqu.dnActivity.profile.ProfileActivity;
import com.dubuqu.dnAdapter.profile.ProfileStoryAdapter;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnModels.commonModel.ErrorBodyModel;
import com.dubuqu.dnModels.responseModel.DubuquUserModel;
import com.dubuqu.dnModels.responseModel.GetTimeLineStory;
import com.dubuqu.dnModels.responseModel.SharedMedias;
import com.dubuqu.dnRestServices.RestServiceController;
import com.dubuqu.dnRestServices.RestServiceProvider;
import com.dubuqu.dnStorage.SessionManager;
import com.dubuqu.dnUtils.RestServiceUtils;
import com.dubuqu.dnUtils.Utils;
import com.dubuqu.dnViews.DubuquLinearLayoutManager;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.yalantis.ucrop.UCrop;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;
import retrofit2.Response;
import retrofit2.Retrofit;

/**
 * Created by Yogaraj subramanian on 10/1/18
 */

public class ProfileFragment extends Fragment implements ProfileStoryAdapter.ProfileadapterCallBack {

    View parnetView;

    Activity activity;

    View backImageView, editImageView, noFeedRl;

    TextView userNameTextView, mediaCountTextView, groupCountTextView;

    ImageView profieCoverImageView, circleImageView, editProfileImv;

    SessionManager sessionManager;

    int totalMediaCount = 0;

    List<GetTimeLineStory> storyLists = new ArrayList<>();

    ProfileStoryAdapter profileStoryAdapter;

    String profileImaege = "";

    ProgressBar progressBar;

    RecyclerView recyclerView;

    boolean isPaginating = false;

    private Uri outputFileUri = null, profileUri = null;

    private boolean isProfilepicRemoved = false;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_profile, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        try {
            parnetView = view;

            activity = getActivity();

            intializeView();
        } catch (Exception e) {
            Log.e(ProfileFragment.class.getName(), e.getMessage());
            isPaginating = false;
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        try {
            activity.registerReceiver(receive, new IntentFilter(Constants.REFRESHHOMEDATA));
            updateUserProfileImage();
        } catch (Exception e) {
            writeCrashReport(e.getMessage());
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        try {
            activity.unregisterReceiver(receive);
        } catch (Exception e) {
            writeCrashReport(e.getMessage());
        }
    }

    @Override
    public void startPaginating() {

    }

    @Override
    public void onError(String message) {
        writeCrashReport(message);
    }

    @Override
    public void removeTimelineMedia(int postion) {
        storyLists.remove(postion);
        profileStoryAdapter.notifyItemRemoved(postion);
        if (storyLists.size() > 0) {
            noFeedRl.setVisibility(View.GONE);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try {
            switch (requestCode) {

                case UCrop.REQUEST_CROP:
                    Uri profileUr = UCrop.getOutput(data);
                    if (profileUr != null) {

                        Glide.with(getInstance()).load(profileUr).into(circleImageView);

                        profileUri = profileUr;
                        updateProfilePhotoToserver();
                    }
                    break;

                case Constants.IMAGECPATURE_REQUEST:
                    final boolean isCamera;

                    if (data != null && data.hasExtra(Constants.IMAGEURI)) {
                        String imagePath = data.getStringExtra(Constants.IMAGEURI);
                        if (imagePath != null && !imagePath.equalsIgnoreCase("")) {
                            cropImage(Uri.fromFile(new File(imagePath)));
                        }
                        break;
                    }

                    if (data != null && data.hasExtra("remove_image")) {
                                /*remove image */
                        Bitmap bitmap = Utils.textAsBitmap(sessionManager.getUserName(), getInstance());

                        circleImageView.setImageBitmap(bitmap);

                        isProfilepicRemoved = true;

                        updateProfilePhotoToserver();

                        return;
                    } else if (data == null) {
                        isCamera = true;
                    } else {
                        final String action = data.getAction();
                        isCamera = action != null;
                    }

                    if (isCamera) {
                        profileUri = outputFileUri;
                    } else {
                        profileUri = data.getData();
                    }

                    cropImage(profileUri);
                    profileUri = null;
                    break;


            }
        } catch (Exception e) {
            writeCrashReport(e.getMessage());
        }
    }

    private void intializeView() throws Exception {

        sessionManager = new SessionManager(activity);

        backImageView = parnetView.findViewById(R.id.profile_back);

        editImageView = parnetView.findViewById(R.id.profile_edit);
        if (!sessionManager.getIsEditProfileIntroComplted()) {
            if (activity instanceof ProfileActivity) {
                ((ProfileActivity) activity).showTutorialScreenView(
                        editImageView,
                        getString(R.string.intro_my_profile_edit),
                        getString(R.string.intro_my_profile_edit_brief),
                        true,
                        new BaseActivity.OnTutorialFinishLisenter() {
                            @Override
                            public void onfinished(boolean isFinished) {
                                sessionManager.setIsEditProfileIntroComplted();
                            }
                        }
                );
            }
        }

        noFeedRl = parnetView.findViewById(R.id.no_feed_available_rl);

        userNameTextView = parnetView.findViewById(R.id.profile_username);

        mediaCountTextView = parnetView.findViewById(R.id.profile_mediacount);

        groupCountTextView = parnetView.findViewById(R.id.profile_groupcount);

        profieCoverImageView = parnetView.findViewById(R.id.profile_coverimage);

        circleImageView = parnetView.findViewById(R.id.profile_user_profile_image);

        progressBar = parnetView.findViewById(R.id.profile_progress_bar);

        editProfileImv = parnetView.findViewById(R.id.profile_user_edit_profile_imv);

        initializeListners();

        getUserDetails();

        getTimelineStories();
    }


    private void initializeListners() throws Exception {

        profileStoryAdapter = new ProfileStoryAdapter(activity, storyLists, this);

        recyclerView = parnetView.findViewById(R.id.profile_recyclerview);

        DisplayMetrics displayMetrics = new DisplayMetrics();
        getActivity().getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);

        DubuquLinearLayoutManager layout = new DubuquLinearLayoutManager(getActivity());
        layout.setExtraLayoutSpace(displayMetrics.heightPixels);
        recyclerView.setLayoutManager(layout);

        recyclerView.setAdapter(profileStoryAdapter);

        editImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openEditProfileActvity();
            }
        });

        backImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.onBackPressed();
            }
        });

        circleImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (profileImaege != null && !profileImaege.equalsIgnoreCase("")) {

                    Intent intent = new Intent(activity, FullImageViewActivity.class);
                    intent.putExtra(Constants.IMAGEURI, profileImaege);

                    Pair<View, String> p2 = Pair.create((View) circleImageView, "user_profile");

                    Pair[] views = new Pair[]{p2};

                    ActivityOptionsCompat options = ActivityOptionsCompat.
                            makeSceneTransitionAnimation(activity, views);

                    ActivityCompat.startActivity(activity, intent, options.toBundle());
                }
            }
        });

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);

            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                try {
                    RecyclerView.LayoutManager layoutManager = recyclerView.getLayoutManager();
                    if (!isPaginating && layoutManager instanceof LinearLayoutManager) {
                        if (((LinearLayoutManager) layoutManager).findLastVisibleItemPosition()
                                == storyLists.size() - 1) {
                            isPaginating = true;
                            paginateResource();
                        }
                    }
                } catch (Exception e) {
                    writeCrashReport(e.getMessage());
                }
            }
        });

        editProfileImv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    openEditProfileImageIntent();
                } catch (Exception e) {
                    writeCrashReport(e.getMessage());
                }
            }
        });
    }


    private void openEditProfileImageIntent() throws Exception {
        // Determine Uri of camera image to save.
        final File root = new File(Utils.getRootFolderForProfilePicture(getInstance()));
        root.mkdirs();

        final String fname = Utils.getAppName(getInstance()) + "_" + System.currentTimeMillis()
                + "." + Utils.getAppName(getInstance());

        final File sdImageMainDirectory = new File(root.getPath(), fname);

        outputFileUri = Uri.fromFile(sdImageMainDirectory);

        Intent chooserIntent = null;

        List<Intent> intentList = new ArrayList<>();

        Intent pickIntent = new Intent(Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

        pickIntent.setType("image/*");

        Intent takePhotoIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        if (!android.os.Build.MANUFACTURER.contains("samsung")) {
            Uri photoURI = FileProvider.getUriForFile(getInstance(),
                    com.dubuqu.BuildConfig.APPLICATION_ID + ".provider",
                    sdImageMainDirectory);

            takePhotoIntent.putExtra("return-data", true);
            takePhotoIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
        }

        intentList = addIntentsToList(getInstance(), intentList, pickIntent);

        intentList = addIntentsToList(getInstance(), intentList, takePhotoIntent);

//        Intent intent = new Intent(getInstance(), CameraPreviewActivity.class);
//        intent.putExtra(Constants.CAPTUREPROFILEIMAGE, true);
//
//        intentList = addIntentsToList(getInstance(), intentList, intent);


        if (Utils.isVaildString(profileImaege)) {
            Intent removeImageIntent = new Intent(getInstance(), RemoveProfileImageActivity.class);
            intentList = addIntentsToList(getInstance(), intentList, removeImageIntent);
        }

        if (intentList.size() > 0) {

            chooserIntent = Intent.createChooser(intentList.remove(intentList.size() - 1),
                    ("Pick image From"));
            chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, intentList.toArray(new Parcelable[]{}));
        }

        startActivityForResult(chooserIntent, Constants.IMAGECPATURE_REQUEST);

    }

    /**
     * add avialable camera nad gallery apps that can provide images
     *
     * @param context {Context of the Activity}
     * @param list    {package name list}
     * @param intent  {intnet to trigger}
     * @return {List}
     */
    private static List<Intent> addIntentsToList(Context context, List<Intent> list, Intent intent) {
        List<ResolveInfo> resInfo = context.getPackageManager().queryIntentActivities(intent, 0);
        for (ResolveInfo resolveInfo : resInfo) {
            String packageName = resolveInfo.activityInfo.packageName;
            Intent targetedIntent = new Intent(intent);
            targetedIntent.setPackage(packageName);
            list.add(targetedIntent);
        }
        return list;
    }


    private void paginateResource() {
        try {
            if (totalMediaCount > storyLists.size())
                getTimelineStories();

        } catch (Exception e) {
            writeCrashReport(e.getMessage());
            isPaginating = false;
        }
    }

    /**
     * get user details to display profile image, media count and gorup count
     *
     * @throws Exception {Runtime Stub Exeption}
     */
    private void getUserDetails() throws Exception {

        userNameTextView.setText(sessionManager.getUserName());

        String data = "{}";
        OkHttpClient okHttpClient = null;

        okHttpClient = RestServiceUtils.getHeader(data, activity);
        Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
        RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
        RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);

        Bitmap bitmap = Utils.textAsBitmap(sessionManager.getUserName(), activity);
        circleImageView.setImageBitmap(bitmap);

        mRetrofitCallBacks.fetchDubuquUserDetails(
                new RestServiceController.ResponseCallBacks() {
                    @Override
                    public void onResponse(Object o) {
                        if (o != null) {

                            final DubuquUserModel userModel =
                                    (DubuquUserModel) o;
                            activity.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    try {
                                        groupCountTextView.setText(String.valueOf(userModel.getGroupCount()));
                                        mediaCountTextView.setText(String.valueOf(userModel.getMediaCount()));
                                    } catch (Exception e) {
                                        writeCrashReport(e.getMessage());
                                    }
                                }
                            });
                        }
                    }

                    @Override
                    public void onFailure(Object o) {
                        handleApiError(o);
                    }
                },
                sessionManager.getUserIdentifier());
    }

    /**
     * get user time line storeis i.e medias that are shared by the user to others
     *
     * @throws Exception
     */
    private void getTimelineStories() throws Exception {
        String data = "{}";
        OkHttpClient okHttpClient = null;

        okHttpClient = RestServiceUtils.getHeader(data, activity);
        Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
        RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
        RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
        mRetrofitCallBacks.getTimelineStories(storyLists.size(), new RestServiceController.ResourceCountCallBack() {
            @Override
            public void mediaResponse(String count) {
                if (count != null && !count.equalsIgnoreCase(""))
                    totalMediaCount = Integer.parseInt(count);
            }
        }, new RestServiceController.ResponseCallBacks() {
            @Override
            public void onResponse(Object o) {
                if (o != null) {
                    final List<GetTimeLineStory> getTimeLineStories = (List<GetTimeLineStory>) o;
                    final int previousPostion = storyLists != null ? storyLists.size() : 0;
                    storyLists.addAll(getTimeLineStories);
                    activity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (storyLists.size() > 0) {
                                profileStoryAdapter.notifyItemRangeInserted(previousPostion, 10);
                                noFeedRl.setVisibility(View.GONE);
                                recyclerView.setVisibility(View.VISIBLE);
                            } else {
                                noFeedRl.setVisibility(View.VISIBLE);
                                recyclerView.setVisibility(View.GONE);
                            }
                            progressBar.setVisibility(View.GONE);
                            isPaginating = false;
                        }
                    });
                }
            }

            @Override
            public void onFailure(Object o) {
                activity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        progressBar.setVisibility(View.GONE);
                    }
                });
                isPaginating = false;
            }
        });
    }

    /**
     * Open Profile Edit Activity
     */
    private void openEditProfileActvity() {

        Pair<View, String> p2 = Pair.create((View) circleImageView, "user_profile");

        Pair<View, String> p1 = Pair.create(editImageView, "edit_profile");

        Pair<View, String> p3 = Pair.create((View) userNameTextView, "user_name");

        Pair[] views = new Pair[]{p2, p1};

        ActivityOptionsCompat options = ActivityOptionsCompat.
                makeSceneTransitionAnimation(activity, views);

        ActivityCompat.startActivity(activity, new Intent(activity, EditProfileActivity.class), options.toBundle());
    }

    private void updateUserProfileImage() throws Exception {

        SessionManager sessionManager = new SessionManager(activity);

        String userName = sessionManager.getUserName();

        final Bitmap bitmap = Utils.textAsBitmap(userName, activity);

        circleImageView.setImageBitmap(bitmap);

        profileImaege = sessionManager.getUserProfileUri();
        if (profileImaege != null && !profileImaege.equalsIgnoreCase("")) {
            File file = new File(profileImaege);
            if (file.exists()) {
                Glide.with(activity).load(file).centerCrop().listener(new RequestListener<File, GlideDrawable>() {
                    @Override
                    public boolean onException(Exception e, File model, Target<GlideDrawable> target, boolean isFirstResource) {
                        try {
                            loadImageFromServer();
                        } catch (Exception e1) {
                            writeCrashReport(e1.getMessage());
                        }
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(GlideDrawable resource, File model, Target<GlideDrawable> target, boolean isFromMemoryCache, boolean isFirstResource) {
                        circleImageView.setImageDrawable(resource);
                        return false;
                    }
                }).into(circleImageView);
            } else {
                loadImageFromServer();
            }
        } else {
            loadImageFromServer();
        }
    }

    private void loadImageFromServer() throws Exception {
        String data = "{}";
        OkHttpClient okHttpClient = null;

        okHttpClient = RestServiceUtils.getHeader(data, activity);
        Retrofit retrofit = RestServiceUtils.makeHttpRequest(okHttpClient);
        RestServiceProvider retrofitNetworkCalls = retrofit.create(RestServiceProvider.class);
        RestServiceController mRetrofitCallBacks = new RestServiceController(retrofitNetworkCalls);
        mRetrofitCallBacks.fetchDubuquUserDetails(
                new RestServiceController.ResponseCallBacks() {
                    @Override
                    public void onResponse(Object o) {
                        if (o != null) {

                            final DubuquUserModel userModel =
                                    (DubuquUserModel) o;

                            activity.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    profileImaege = userModel.getProfileImage();

                                    if (profileImaege != null && !profileImaege.equalsIgnoreCase("")) {
                                        ImageLoader.getInstance().displayImage(profileImaege, circleImageView);
                                    }
                                }
                            });
                        }
                    }

                    @Override
                    public void onFailure(Object o) {

                    }
                },
                sessionManager.getUserIdentifier());
    }

    BroadcastReceiver receive = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String timelineIdentifier = intent.getStringExtra(Constants.TIMELINE_IDENTIFIER);
            String sharedMediasString = intent.getStringExtra(Constants.SELECTEDIMAGES);

            int po = 0;

            if (intent.getBooleanExtra(Constants.ISREPORTEDDATA, false)) {
                for (GetTimeLineStory getallmediatimeline : storyLists) {

                    if (getallmediatimeline.getTimelineIdentifier().equalsIgnoreCase(timelineIdentifier)) {

                        List<SharedMedias> sharedMedias = new Gson().fromJson(sharedMediasString,
                                new TypeToken<List<SharedMedias>>() {
                                }.getType());
                        storyLists.get(po).setSharedMedias(sharedMedias);
                        storyLists.get(po).setSharedMediasCount(intent.getIntExtra(Constants.SHAREDMEDIA_COUNT,
                                4));
                        if (sharedMedias.size() == 0) {
                            storyLists.remove(po);
                        }

                        profileStoryAdapter.notifyDataSetChanged();
                        break;
                    }
                    po++;
                }
            }
        }
    };

    /**
     * Handle API error messages
     *
     * @param o might be Instance of {@link Response} or {@link Throwable}
     */
    private void handleApiError(Object o) {
        if (o != null) {
            if (activity instanceof ProfileActivity) {
                try {
                    if (o instanceof retrofit2.Response) {
                        ResponseBody responseBody = ((Response) o).errorBody();
                        if (responseBody != null) {
                            String value = responseBody.string();
                            ErrorBodyModel errorBodyModel = new Gson().fromJson(value, ErrorBodyModel.class);
                            if (errorBodyModel != null) {
                                ((ProfileActivity) activity).showToastMessage(
                                        errorBodyModel.getMessage(),
                                        false);
                            }

                        }
                    } else if (o instanceof Throwable) {
                        ((ProfileActivity) activity).showToastMessage(
                                getString(R.string.sp_no_internet_connection),
                                false);
                    }

                } catch (Exception e) {
                    writeCrashReport(e.getMessage());
                }
            }

        }
    }

    /**
     * Open Crop Activity which allows user to crop their images.
     *
     * @param cropImageUri {@link Uri} the pic user has picked
     * @throws Exception {Runtime Stub Exception}
     */
    private void cropImage(Uri cropImageUri) throws Exception {

        String destinationFileName = String.valueOf(System.currentTimeMillis());
        destinationFileName += ".png";

        UCrop uCrop = UCrop.of(cropImageUri
                , Uri.fromFile(new File(getInstance().getCacheDir(), destinationFileName)));
        UCrop.Options options = new UCrop.Options();
        options.setCompressionFormat(Bitmap.CompressFormat.PNG);
        options.setCompressionQuality(100);
        options.setHideBottomControls(false);
        options.setFreeStyleCropEnabled(true);
        options.setStatusBarColor(getResources().getColor(R.color.colorPrimaryDark));
        options.setToolbarColor(getResources().getColor(R.color.colorPrimary));
        options.setActiveWidgetColor(getResources().getColor(R.color.colorPrimary));
        uCrop.withOptions(options);
        uCrop.start(getInstance(), ProfileFragment.this);
    }

    /**
     * Write Log Report to console
     *
     * @param message {@link String} message that need to be printed in log
     */
    private void writeCrashReport(String message) {
        if (activity instanceof ProfileActivity) {
            ((ProfileActivity) activity).writeCrashReport(
                    ProfileFragment.class.getName(),
                    message);
        }
    }

    private void updateProfilePhotoToserver() throws Exception {

        if (profileUri != null) {

            //profile picture changed
            RestServiceUtils.updateUserProfilePic(getInstance(), 120,
                    sessionManager.getUserIdentifier(),
                    profileUri.getPath());

            sessionManager.updateUserProfileImage(profileUri.getPath());

            getInstance().sendBroadcast(new Intent(Constants.ONPROFILEPICCHANGED));
        }

        if (profileImaege != null && isProfilepicRemoved) {
            //remvove profile pic
            RestServiceUtils.updateUserProfilePic(getInstance(), 120,
                    sessionManager.getUserIdentifier(),
                    null);
            sessionManager.updateUserProfileImage("");

            getInstance().sendBroadcast(new Intent(Constants.ONPROFILEPICCHANGED));
        }
    }

    public Context getInstance() {
        return getContext();
    }
}
