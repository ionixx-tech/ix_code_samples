package com.dubuqu.dnStorage.upload;

import com.dubuqu.dnConstants.Constants;
import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

/**
 * Created by Yogaraj subramanian on 18/12/17
 */
@DatabaseTable(tableName =
        Constants.UPLOADTABLEMAPER)
public class UploadMapModel {

    @DatabaseField(columnName = Constants.ID, generatedId = true)
    private int id;

    @DatabaseField(columnName = Constants.UPLOAD_STATUS)
    private String uploadStatus;

    @DatabaseField(columnName = Constants.UPLOADIDENTIFIER)
    private String uploadId;

    @DatabaseField(columnName = Constants.USER_IDENTIFIER)
    private String user;

    @DatabaseField(columnName = Constants.SHOULDDELETEMEDIA)
    private boolean shouldDeleteMedia;


    public int getId() {
        return id;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUploadStatus() {
        return uploadStatus;
    }

    public void setUploadStatus(String uploadStatus) {
        this.uploadStatus = uploadStatus;
    }

    public String getUploadId() {
        return uploadId;
    }

    public void setUploadId(String uploadId) {
        this.uploadId = uploadId;
    }

    public boolean isShouldDeleteMedia() {
        return shouldDeleteMedia;
    }

    public void setShouldDeleteMedia(boolean shouldDeleteMedia) {
        this.shouldDeleteMedia = shouldDeleteMedia;
    }
}


