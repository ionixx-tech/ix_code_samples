package com.dubuqu.dnAdapter.uploadandnotification;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.dubuqu.R;
import com.dubuqu.dnConstants.UploadConstants;
import com.dubuqu.dnStorage.upload.UploadDbModel;
import com.dubuqu.dnUtils.Utils;

import java.io.File;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * Created by Yogaraj subramanian on 22/12/17
 */

public class UploadListAdapter extends RecyclerView.Adapter<UploadListAdapter.UploadListViewHolder> {

    private Context context;

    private List<UploadDbModel> uploadDbModels;

    public UploadListAdapter(Context context, List<UploadDbModel> uploadDbModels) {
        this.context = context;
        this.uploadDbModels = uploadDbModels;
    }

    @Override
    public UploadListViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.upload_content_viewholder, parent,
                false);
        return new UploadListViewHolder(view);
    }

    @Override
    public void onBindViewHolder(UploadListViewHolder holder, int position) {
        try {
            holder.bind(position);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return uploadDbModels.size();
    }

    @Override
    public int getItemViewType(int position) {
        return uploadDbModels.get(position).hashCode();
    }

    @Override
    public long getItemId(int position) {
        return uploadDbModels.get(position).hashCode();
    }

    class UploadListViewHolder extends RecyclerView.ViewHolder {

        CircleImageView circleImageView;

        ProgressBar progressBar;

        TextView progressState, uploadState;

        UploadListViewHolder(View itemView) {
            super(itemView);
            circleImageView = itemView.findViewById(R.id.uploadImageiew);
            progressBar = itemView.findViewById(R.id.uploadprogress);
            progressState = itemView.findViewById(R.id.progress_state);
            uploadState = itemView.findViewById(R.id.progress_upload);
        }

        void bind(int position) throws Exception {

            UploadDbModel uploadDbModel = uploadDbModels.get(position);

            if (uploadDbModel != null && Utils.isVaildString(uploadDbModel.getFilePath())){

                Glide.with(context).load(new File(uploadDbModel.getFilePath())).into(circleImageView);
                progressState.setText(uploadDbModel.getUploadStatus());
                progressBar.setProgress(uploadDbModel.getProgressValue());
                setProgressColor(uploadDbModel.getUploadStatus());

                if (UploadConstants.UPLOADSTATUS.valueOf(uploadDbModel.getUploadStatus())
                        == UploadConstants.UPLOADSTATUS.UPLOADING) {

                    String uploadProgress = uploadDbModel.getUploadProgress();

                /*&& !uploadProgress.matches("[0-9]+")*/
                    if (uploadProgress != null) {
                        uploadState.setVisibility(View.VISIBLE);

                        uploadState.setText(" ( ".concat(uploadProgress).concat(" )"));
                    }

                } else {
                    uploadState.setVisibility(View.GONE);
                }
            }
        }

        private void setProgressColor(String uploadStatus) throws Exception {
            switch (UploadConstants.UPLOADSTATUS.valueOf(uploadStatus)) {
                case PAUSE:
                    progressState.setTextColor(Color.BLACK);
                    break;
                case FAILURE:
                    progressState.setTextColor(Color.RED);
                    break;
                case SUCCESS:
                    progressState.setTextColor(Color.BLACK);
                    break;
                case PROGRESS:
                    progressState.setTextColor(Color.BLACK);
                    break;
                case CANCELLED:
                    progressState.setTextColor(Color.RED);
                    break;
                case UPLOADING:
                    progressState.setTextColor(Color.BLACK);
                    break;
                case NOTYETSTARTED:
                    progressState.setTextColor(Color.GRAY);
                    break;
            }
        }
    }
}
