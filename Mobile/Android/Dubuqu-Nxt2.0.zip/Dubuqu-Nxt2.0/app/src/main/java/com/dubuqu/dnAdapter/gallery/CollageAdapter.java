package com.dubuqu.dnAdapter.gallery;

import android.content.Context;
import android.content.res.TypedArray;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.dubuqu.R;


/**
 * Created by Yogaraj subramanian on 27/6/17
 */

public class CollageAdapter extends RecyclerView.Adapter<CollageAdapter.CollageAdapterViewholder> {
    TypedArray collageTemplates;
    Context context;
    OnItemClick onItemClick;

    public interface OnItemClick {
        void getPostion(int postion);
    }

    public CollageAdapter(TypedArray collageTemplates, Context context, OnItemClick onItemClick) {
        this.collageTemplates = collageTemplates;
        this.context = context;
        this.onItemClick = onItemClick;
    }

    @Override
    public CollageAdapterViewholder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.collage_adapter_view, parent, false);
        return new CollageAdapterViewholder(view);
    }

    @Override
    public void onBindViewHolder(CollageAdapterViewholder holder, int position) {
        holder.onBid(position);
    }

    @Override
    public int getItemCount() {
        return 12;
    }

    class CollageAdapterViewholder extends RecyclerView.ViewHolder {
        ImageView imageView;

        CollageAdapterViewholder(View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.collage_viewholder);
        }

        public void onBid(final int position) {
            imageView.setImageResource(collageTemplates.getResourceId(position, -1));
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    onItemClick.getPostion(position);
                }
            });
        }
    }
}
