package com.dubuqu.dnAdapter.uploadandnotification;

import android.content.Context;
import android.net.Uri;
import android.support.v4.view.PagerAdapter;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.dubuqu.dnStorage.upload.UploadDbModel;
import com.dubuqu.dnUtils.Utils;
import com.shuhart.bubblepagerindicator.ViewPagerProvider;

import java.util.List;

/**
 * Created by Yogaraj subramanian on 2/1/18
 */

public class UploadViewPagerAdapter extends PagerAdapter implements ViewPagerProvider {

    List<UploadDbModel> uploadDbModels;

    Context context;

    public UploadViewPagerAdapter(List<UploadDbModel> uploadDbModels, Context context) {
        this.uploadDbModels = uploadDbModels;
        this.context = context;
    }

    @Override
    public int getCount() {
        return uploadDbModels.size();
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        ImageView imageView = new ImageView(context);
        container.addView(imageView);

        if (uploadDbModels.get(position) != null && Utils.isVaildString(uploadDbModels.get(position).getFilePath())) {
            if (uploadDbModels.get(position).getFilePath().contains("content:/")) {
                Uri uri = Uri.parse(uploadDbModels.get(position).getFilePath());
                Glide.with(context).load(uri).asBitmap().into(imageView);
            } else {
                Glide.with(context).load(uploadDbModels.get(position).getFilePath()).into(imageView);
            }
        }
        return imageView;
    }

    @Override
    public int getRealCount() {
        return getCount();
    }

    @Override
    public int getRealPosition(int position) {
        return position;
    }
}
