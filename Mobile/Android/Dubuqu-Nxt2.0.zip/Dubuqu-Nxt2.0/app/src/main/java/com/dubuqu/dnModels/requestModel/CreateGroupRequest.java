package com.dubuqu.dnModels.requestModel;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class CreateGroupRequest {

    @SerializedName("group_name")
    @Expose
    private String groupName;
    @SerializedName("group_type")
    @Expose
    private String groupType;
    @SerializedName("memory_retain")
    @Expose
    private String memoryRetain;
    @SerializedName("members")
    @Expose
    private List<String> members = null;

    @SerializedName("allow_repost")
    @Expose
    private String allow_repost;

    public CreateGroupRequest(String groupName, String groupType, String memoryRetain,
                              List<String> members, String allow_repost) {
        this.groupName = groupName;
        this.groupType = groupType;
        this.memoryRetain = memoryRetain;
        this.members = members;
        this.allow_repost = allow_repost;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getGroupType() {
        return groupType;
    }

    public void setGroupType(String groupType) {
        this.groupType = groupType;
    }

    public String getMemoryRetain() {
        return memoryRetain;
    }

    public void setMemoryRetain(String memoryRetain) {
        this.memoryRetain = memoryRetain;
    }

    public List<String> getMembers() {
        return members;
    }

    public void setMembers(List<String> members) {
        this.members = members;
    }

    public String getAllow_repost() {
        return allow_repost;
    }

    public void setAllow_repost(String allow_repost) {
        this.allow_repost = allow_repost;
    }
}
