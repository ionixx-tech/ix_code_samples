package com.dubuqu.dnModels.commonModel;

/**
 * Created by ionixx on 26/6/17.
 */

import com.dubuqu.dnModels.responseModel.DubuquGetGroupResponse;

import java.util.List;

/**
 * dubuqu social groups binder.
 * DubuquGetGroupResponse
 * List<DubuqContactsShareModel>
 */

public class DubuqGroupDetails {

    private DubuquGetGroupResponse dubuquGetGroupResponse;
    private List<DubuqContactsShareModel> dubuquUserResponseModels;

    public DubuqGroupDetails(DubuquGetGroupResponse dubuquGetGroupResponse, List<DubuqContactsShareModel> dubuquUserResponseModels) {
        this.dubuquGetGroupResponse = dubuquGetGroupResponse;
        this.dubuquUserResponseModels = dubuquUserResponseModels;
    }

    public DubuquGetGroupResponse getDubuquGetGroupResponse() {
        return dubuquGetGroupResponse;
    }

    public void setDubuquGetGroupResponse(DubuquGetGroupResponse dubuquGetGroupResponse) {
        this.dubuquGetGroupResponse = dubuquGetGroupResponse;
    }

    public List<DubuqContactsShareModel> getDubuquUserResponseModels() {
        return dubuquUserResponseModels;
    }

    public void setDubuquUserResponseModels(List<DubuqContactsShareModel> dubuquUserResponseModels) {
        this.dubuquUserResponseModels = dubuquUserResponseModels;
    }
}
