package com.dubuqu.dnViews;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.SurfaceTexture;
import android.hardware.Camera;
import android.media.CamcorderProfile;
import android.media.MediaRecorder;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.TextureView;
import android.view.View;

import com.dubuqu.dnUtils.cam.CameraHelper;

import java.io.IOException;
import java.util.List;

/**
 * Created by Yogaraj subramanian on 6/12/17
 */

public class DubuquCameraPreview extends TextureView implements TextureView.SurfaceTextureListener,
        View.OnTouchListener, Camera.PictureCallback {

    final String TAG = DubuquCameraPreview.class.getName();

    Context context;

    Camera mCamera;

    MediaRecorder mMediaRecorder;

    private boolean isFrontfacting = false;

    String outPutFile;

    onMediaCapturedCallback onMediaCapturedCallback;

    public DubuquCameraPreview(Context context, onMediaCapturedCallback onMediaCapturedCallback) {
        super(context);
        this.context = context;
        mCamera = CameraHelper.getDefaultBackFacingCameraInstance();
        this.setSurfaceTextureListener(this);
        this.onMediaCapturedCallback = onMediaCapturedCallback;
    }

    public DubuquCameraPreview(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public DubuquCameraPreview(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }


    @Override
    public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int i, int i1) {
        try {
            initializeCamera();
        } catch (Exception e) {
            writeCrashReport(e.getMessage());
        }
    }

    @Override
    public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int i, int i1) {

    }

    @Override
    public boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
        return false;
    }

    @Override
    public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {

    }

    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        return false;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        final int width = resolveSize(getSuggestedMinimumWidth(), widthMeasureSpec);
        final int height = resolveSize(getSuggestedMinimumHeight(), heightMeasureSpec);
        setMeasuredDimension(width, height);
    }

    @Override
    public void onPictureTaken(byte[] bytes, Camera camera) {
        try {
            stopCamera();
            onMediaCapturedCallback.onPicturedCaptured(bytes);
        } catch (Exception e) {
            writeCrashReport(e.getMessage());
        }
    }

    /**
     * Intilaize Camera
     */
    public void initializeCamera() throws Exception {
        if (mCamera == null)
            mCamera = CameraHelper.getDefaultBackFacingCameraInstance();

        mCamera.stopPreview();
        mCamera.enableShutterSound(false);

        Camera.Parameters parameters = mCamera.getParameters();
        parameters.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);

        if (this.getResources().getConfiguration().orientation !=
                Configuration.ORIENTATION_LANDSCAPE) {
            parameters.set("orientation", "portrait");
            mCamera.setDisplayOrientation(90);
            if (isFrontfacting)
                parameters.setRotation(270);
            else
                parameters.setRotation(90);
        } else {
            parameters.set("orientation", "landscape");
            mCamera.setDisplayOrientation(0);
            if (isFrontfacting)
                parameters.setRotation(270);
            else
                parameters.setRotation(0);
        }

        List<Camera.Size> mSupportedPreviewSizes = parameters.getSupportedPreviewSizes();
        List<Camera.Size> mSupportedVideoSizes = parameters.getSupportedVideoSizes();

        Camera.Size optimalSize = CameraHelper.
                getOptimalVideoSize(mSupportedVideoSizes,
                        mSupportedPreviewSizes, getWidth(), getHeight());

//        profile = CamcorderProfile.get(CamcorderProfile.QUALITY_HIGH);
//        profile.videoFrameWidth = optimalSize.width;
//        profile.videoFrameHeight = optimalSize.height;

        measure(optimalSize.width, optimalSize.height);

        parameters.setPreviewSize(optimalSize.width, optimalSize.height);
        mCamera.setParameters(parameters);

        mCamera.setPreviewTexture(this.getSurfaceTexture());
        mCamera.startPreview();

    }

    public boolean initlaizeMediaRecorder() throws Exception {
        if (mMediaRecorder == null) {
            mMediaRecorder = new MediaRecorder();

            mCamera.stopPreview();
            mCamera.unlock();
            mMediaRecorder.setCamera(mCamera);

            mMediaRecorder.setAudioSource(MediaRecorder.AudioSource.DEFAULT);
            mMediaRecorder.setVideoSource(MediaRecorder.VideoSource.CAMERA);

            CamcorderProfile profile = CamcorderProfile.get(CamcorderProfile.QUALITY_1080P);
            mMediaRecorder.setProfile(profile);
            if (this.getResources().getConfiguration().orientation !=
                     Configuration.ORIENTATION_LANDSCAPE) {
                if (isFrontfacting)
                    mMediaRecorder.setOrientationHint(270);
                else
                    mMediaRecorder.setOrientationHint(90);
            } else {

                if (isFrontfacting)
                    mMediaRecorder.setOrientationHint(270);
                else
                    mMediaRecorder.setOrientationHint(0);
            }
            outPutFile = context.getCacheDir() + "/" + String.valueOf(System.currentTimeMillis()).concat(".mp4");
            mMediaRecorder.setOutputFile(outPutFile);
            try {
                mMediaRecorder.prepare();
                return true;
            } catch (IllegalStateException | IOException e) {
                releaseMediaRecorder();
                return false;
            }

        }
        return true;
    }

    private void writeCrashReport(String message) {
        Log.e(TAG, message);
    }

    public void swapCamera() throws Exception {
        stopCamera();
        mCamera = null;
        if (isFrontfacting) {
            isFrontfacting = false;
            mCamera = CameraHelper.getDefaultBackFacingCameraInstance();
        } else {
            isFrontfacting = true;
            mCamera = CameraHelper.getDefaultFrontFacingCameraInstance();
        }
        initializeCamera();
    }

    /**
     * set falshmode
     *
     * @throws Exception {Rutime Stub Exception}
     */
    public void setFlashMode(String flashMode) throws Exception {

        if (mCamera != null) {

            mCamera.stopPreview();

            Camera.Parameters parameters = mCamera.getParameters();

            parameters.setFlashMode(flashMode);

            mCamera.setParameters(parameters);
            initializeCamera();
        }
    }

    public List<Integer> getFlashModes() throws Exception {
        return CameraHelper.getSupportedFlashModes(context, mCamera.getParameters());
    }

    public void stopCamera() throws Exception {
        mCamera.stopPreview();
        mCamera.setPreviewCallback(null);
        mCamera.release();
        mCamera = null;
    }

    public void stopMediaRecorder() throws Exception {
        if (mMediaRecorder != null) {
            mMediaRecorder.stop();
            releaseMediaRecorder();
            onMediaCapturedCallback.onMediaCaptured(outPutFile);
        }
    }

    public void releaseMediaRecorder() {
        if (mMediaRecorder != null) {
            mMediaRecorder.reset();
            mMediaRecorder.release();
            mMediaRecorder = null;
            mCamera.lock();
        }
    }

    public void takePicture() throws Exception {
        mCamera.takePicture(null, null, DubuquCameraPreview.this);
    }

    public void startMediaRecorder() throws Exception {
        if (initlaizeMediaRecorder()) {
            mMediaRecorder.start();
        }
    }

    public interface onMediaCapturedCallback {
        void onMediaCaptured(String filePath);

        void onPicturedCaptured(byte[] data);
    }

}
