package com.dubuqu.dnModels.responseModel;

/**
 * Created by ionixx on 18/7/17.
 */

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;


public class FetchAllUserEvent {

    @SerializedName("name")
    @Expose
    private String name;

    @SerializedName("type")
    @Expose
    private String type;

    @SerializedName("group_identifier")
    @Expose
    private String groupIdentifier;

    @SerializedName("shared_medias")
    @Expose
    private List<SharedMedia> sharedMedias = null;

    @SerializedName("profile_image")
    @Expose
    private String profileImage;

    @SerializedName("user_identifier")
    @Expose
    private String userIdentifier;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getGroupIdentifier() {
        return groupIdentifier;
    }

    public void setGroupIdentifier(String groupIdentifier) {
        this.groupIdentifier = groupIdentifier;
    }

    public List<SharedMedia> getSharedMedias() {
        return sharedMedias;
    }

    public void setSharedMedias(List<SharedMedia> sharedMedias) {
        this.sharedMedias = sharedMedias;
    }

    public String getUserIdentifier() {
        return userIdentifier;
    }

    public void setUserIdentifier(String userIdentifier) {
        this.userIdentifier = userIdentifier;
    }

    public String getProfileImage() {
        return profileImage;
    }

    public void setProfileImage(String profileImage) {
        this.profileImage = profileImage;
    }
}