package com.dubuqu.dnCommon;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.transition.Fade;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.dubuqu.R;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnFragments.home.HomeFragment;

import java.util.Arrays;

/**
 * Created by Yogaraj subramanian on 30/10/17
 * <p>
 * Bottom View controller is created to controll the bottom action clicks and
 * maintain an single instance of every fragment so that the fragment doesnt get
 * replaced every time.
 * </p>
 */
public class BottomViewController implements View.OnClickListener {


    private View[] views;

    private Fragment[] fragments;

    private int currentSelectedPostion = 0;

    private int frameLayoutId;

    private Context context;

    private int[] deSelectedList = new int[]{R.drawable.dn_ic_home, R.drawable.dn_ic_gallery,
            R.drawable.dn_ic_social_circle, R.drawable.ic_settings};

    private int[] selectedImageList = new int[]{R.drawable.dn_ic_home_selected, R.drawable.dn_ic_gallery_selected,
            R.drawable.dn_ic_social_circle_selected, R.drawable.ic_settings_selected};

    private final String TAG = BottomViewController.class.getName();

    private OnItemReclickedListener onItemReclickListener;

    private FragmentManager fragmentManager;

    private BottomViewController(BottomViewBuilder bottomViewBuilder) {

        if (this.views == null && this.fragments == null) {

            try {
                views = bottomViewBuilder.view;
                fragments = bottomViewBuilder.fragment;
                frameLayoutId = bottomViewBuilder.frameLayoutId;
                context = bottomViewBuilder.context;
                this.fragmentManager = bottomViewBuilder.fragmentManager;
                this.onItemReclickListener = bottomViewBuilder.onItemReclickedListener;
                initializeOnClickLisenter();

            } catch (Exception e) {
                writeCrashReport(e.getMessage());
            }
        }
    }

    /**
     * initialze onclick listener for the views that has been passed
     *
     * @throws Exception {Runtime stub Exception}
     */
    private void initializeOnClickLisenter() throws Exception {

        for (View iteratorView : this.views) {
            iteratorView.setOnClickListener(this);
        }

        highlightSelectedPostion(views[0]);
    }

    /**
     * When a view is selected the view must be highlighted and other need to be unhighlighted
     *
     * @param view the view that  need to be hightlighted
     * @throws Exception {RunTime Stub Exception}
     */
    public void highlightSelectedPostion(View view) throws Exception {
        int iterator = 0;

        for (View iteratorView : this.views) {
            if (iteratorView.getId() == view.getId()) {
                ImageView imageView = (ImageView) iteratorView;
                imageView.setImageResource(selectedImageList[iterator]);

                imageView.setColorFilter(ContextCompat.getColor(context,
                        R.color.red_color_picker),
                        PorterDuff.Mode.SRC_ATOP);

                addReppleEffectToview(iteratorView);
                imageView.setAlpha(1f);

                setCurrentSelectedPositon(Arrays.asList(views).indexOf(iteratorView));
                onItemReclickListener.onItemClicked(iteratorView.getId());
                YoYo.with(Techniques.Pulse).duration(Constants.ANIMATIONTIME).playOn(iteratorView);

            } else {
                ImageView imageView = (ImageView) iteratorView;
                imageView.setImageResource(deSelectedList[iterator]);
                imageView.setAlpha(1f);
                imageView.setColorFilter(ContextCompat.getColor(context,
                        R.color.black),
                        PorterDuff.Mode.SRC_ATOP);
            }
            iterator++;
        }
    }

    /**
     * set current view position that is selected.
     *
     * @param position Integer that indicates the current positon
     * @throws Exception {Runtime stub Exception}
     */
    private void setCurrentSelectedPositon(int position) throws Exception {
        this.currentSelectedPostion = position;
        replaceFragments();
    }


    /**
     * replace the fragment with respect to view clicked.
     *
     * @throws Exception {RunTime Stub Exception}
     */
    private void replaceFragments() throws Exception {

        FragmentTransaction fragmentTransition = this.fragmentManager.beginTransaction();
        fragmentTransition.replace(frameLayoutId, fragments[currentSelectedPostion]);

        Fade fade = new Fade();
        fade.setDuration(400);

        /*fragments[currentSelectedPostion].setEnterTransition(fade);*/

        fragmentTransition.commit();

       /* if (notificationIndicator.getVisibility() == View.VISIBLE) {
            Fragment fragment = fragments[currentSelectedPostion];
            if (fragment != null) {
                ((HomeFragment) fragment).refreshFragment();
            }
            notificationIndicator.setVisibility(View.GONE);
        }*/
    }


    private void refreshFragment() throws Exception {
        Fragment fragment = this.fragmentManager.findFragmentById(frameLayoutId);
        if (fragment != null && fragment instanceof HomeFragment) {
            ((HomeFragment) fragment).refreshFragment();
        }
    }

    /**
     * Write a log report if need to writen
     *
     * @param message the message that need to be printed in the log.
     */
    private void writeCrashReport(String message) {
        Log.d(TAG, message);
    }


    /**
     * on item click add reppel effect to view
     *
     * @param view the view the reppel effect need to be added
     */
    private void addReppleEffectToview(View view) throws Exception {
        int[] attrs = new int[]{R.attr.selectableItemBackground};

        TypedArray ta = context.obtainStyledAttributes(attrs);

        Drawable drawableFromTheme = ta.getDrawable(0);

        view.setBackground(drawableFromTheme);

        ta.recycle();
    }

    /**
     * Show Red indicator to indicate new media has received.
     *
     * @param postion the postion the media should be shown.
     * @throws Exception{Runtime Excetion or Null pointer Exception}
     */
    public void showIndicator(int postion) throws Exception {
        View currentView = views[postion];
        if (currentView != null) {
            float xPostion = currentView.getRight();
            float yPostion = currentView.getY();
           /* notificationIndicator.setX(xPostion - 70);
            notificationIndicator.setY(yPostion + 30);
            notificationIndicator.setVisibility(View.VISIBLE);*/
        }
    }

    @Override
    public void onClick(View view) {
        try {
            highlightSelectedPostion(view);
        } catch (Exception e) {
            writeCrashReport(e.getMessage());
        }
    }

    public void refreshHomeFragment() throws Exception {
        Fragment fragment = fragments[currentSelectedPostion];
        if (fragment != null && fragment instanceof HomeFragment) {
            ((HomeFragment) fragment).refreshFragment();
        }
    }


    /**
     * BottomView Builder is used to bind objects to BottomViewController
     */
    public static class BottomViewBuilder {

        /**
         * the number of views that comes under the bottom sheet controller.
         */
        View[] view;
        /**
         * the fragments that need to be attached to respective frgaments
         */
        Fragment[] fragment;
        /**
         * the frame container of the fragments
         */
        int frameLayoutId;
        /**
         * fragment manager that used to controll frgamnet transisitons
         */
        FragmentManager fragmentManager;

        /**
         * context of the applicaiton or activity.
         */
        Context context;

        OnItemReclickedListener onItemReclickedListener;

        public View notificatorIndicator;

        public View[] getView() {
            return view;
        }

        public BottomViewBuilder setView(View[] view) {
            this.view = view;
            return this;
        }


        public BottomViewBuilder setFragment(Fragment[] fragment) {
            this.fragment = fragment;
            return this;
        }


        public BottomViewBuilder setFrameLayout(int frameLayoutId) {
            this.frameLayoutId = frameLayoutId;
            return this;
        }


        public BottomViewBuilder setContext(Context context) {
            this.context = context;
            return this;
        }

        public BottomViewBuilder setOnItemClick(OnItemReclickedListener onItemClick) {
            this.onItemReclickedListener = onItemClick;
            return this;
        }


        public BottomViewBuilder setFragmentManager(FragmentManager fragmentManager) {
            this.fragmentManager = fragmentManager;
            return this;
        }

        public BottomViewBuilder setNotificationIndicator(View view) {
            this.notificatorIndicator = view;
            return this;
        }

        /**
         * build the values to the controller objects
         *
         * @return BottomViewController Instance
         * @throws Exception if objects are not properlyintialize @link{NullPointerException is thrown}
         *                   <p>
         *                   if view length and fragment length are not same general exception is thrown.
         *                   </p>
         */
        public BottomViewController build() throws Exception {

            if (this.fragment == null && this.context == null
                    && this.view == null)
                throw new NullPointerException("Objects are not Initalized Properly");

            assert this.fragment != null;
            if (this.fragment.length != this.view.length)
                throw new Exception("Fragment object length and view object length is different");

            return new BottomViewController(this);
        }
    }

    public interface OnItemReclickedListener {
        void onItemClicked(int view);
    }

}