package com.dubuqu.dnFragments.uploadandnotification;

import android.app.Activity;
import android.app.job.JobScheduler;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.dubuqu.R;
import com.dubuqu.dnActivity.uploadandnotification.UploadActivity;
import com.dubuqu.dnActivity.uploadandnotification.UploadAndNotification;
import com.dubuqu.dnAdapter.uploadandnotification.UploadMapAdapter;
import com.dubuqu.dnConstants.Constants;
import com.dubuqu.dnModels.commonModel.ActionConformationDialog;
import com.dubuqu.dnStorage.DbHelper;
import com.dubuqu.dnStorage.upload.UploadMapModel;
import com.dubuqu.dnUtils.Utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Yogaraj subramanian on 2/1/18
 */

public class UploadFragment extends Fragment {

    Context context;

    Activity activity;

    final String TAG = Notificationfragmet.class.getName();

    View parentView;

    TextView noNotificationAvailable;

    RecyclerView recyclerView;

    UploadMapAdapter uploadMapAdapter;

    List<UploadMapModel> uploadMapModelList = new ArrayList<>();

    FloatingActionButton floatingActionButton;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return LayoutInflater.from(getContext()).inflate(R.layout.fragment_notification_and_upload, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        parentView = view;
        try {
            activity = getActivity();

            context = getContext();

            initalizeView();
        } catch (Exception e) {
            writreCrashReport(e.getMessage());
        }
    }

    @Override
    public void onPause() {
        super.onPause();

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        try {
            activity.unregisterReceiver(broadcastReceiver);

        } catch (Exception e) {
            writreCrashReport(e.getMessage());
        }

    }

    @Override
    public void onResume() {
        super.onResume();
        activity.registerReceiver(broadcastReceiver, new IntentFilter(Constants.REFRESH_UPLOAD));
    }

    void initalizeView() throws Exception {

        recyclerView = parentView.findViewById(R.id.fragment_notification_and_upload_rcv);

        uploadMapAdapter = new UploadMapAdapter(uploadMapModelList, context, new UploadMapAdapter.UploadAdapterCallBack() {
            @Override
            public void onClick(int postion) {
                Intent intent = new Intent(activity, UploadActivity.class);
                intent.putExtra(Constants.UPLOADIDENTIFIER, uploadMapModelList.get(postion).getUploadId());
                startActivity(intent);
            }
        });

        parentView.findViewById(R.id.fragment_notification_and_upload_progress).setVisibility(View.GONE);

        recyclerView.setLayoutManager(new GridLayoutManager(context, 2));

        recyclerView.setAdapter(uploadMapAdapter);

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {

                if (newState == RecyclerView.SCROLL_STATE_IDLE) {
                    floatingActionButton.show();
                }
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (dy > 0 || dy < 0 && floatingActionButton.isShown()) {
                    floatingActionButton.hide();
                }

            }
        });

        noNotificationAvailable = parentView.findViewById(R.id.no_notification_available);

        noNotificationAvailable.setText("No Upload Available.");

        floatingActionButton = parentView.findViewById(R.id.clear_upload_list);

        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    showDeleteMediaConformation();
                } catch (Exception e) {
                    writreCrashReport(e.getMessage());
                }
            }
        });

        fetchDatas();

        JobScheduler jobScheduler = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        assert jobScheduler != null;
        if (jobScheduler.getAllPendingJobs().size() < 0)
            context.sendBroadcast(new Intent("com.dubuqu.STARTFILESHARE"));
    }

    private void fetchDatas() throws Exception {
        DbHelper dbHelper = new DbHelper(context);

        List<UploadMapModel> uploadMapModels = dbHelper.fetchAllModels();

        if (uploadMapModels != null && uploadMapModels.size() > 0) {

            if (uploadMapModelList.size() > 0)
                uploadMapModelList.clear();

            if (recyclerView.getVisibility() == View.GONE) {
                floatingActionButton.setVisibility(View.VISIBLE);
                recyclerView.setVisibility(View.VISIBLE);
            }

            if (noNotificationAvailable.getVisibility() == View.VISIBLE)
                noNotificationAvailable.setVisibility(View.GONE);

            uploadMapModelList.addAll(uploadMapModels);

            uploadMapAdapter.notifyDataSetChanged();
        } else {

            if (recyclerView.getVisibility() == View.VISIBLE) {
                recyclerView.setVisibility(View.GONE);
                floatingActionButton.setVisibility(View.GONE);
            }

            if (noNotificationAvailable.getVisibility() == View.GONE)
                noNotificationAvailable.setVisibility(View.VISIBLE);

        }
    }

    /**
     * Write Log Report to the console log
     *
     * @param message the log data that need to printed
     */
    private void writreCrashReport(String message) {
        if (context instanceof UploadAndNotification) {
            ((UploadAndNotification) context).writeCrashReport(TAG, message);
        }
    }

    /**
     * Show delete media popup UI for conformation
     *
     * @throws Exception{Runtime Stub Exception.}
     */
    private void showDeleteMediaConformation() throws Exception {


        new ActionConformationDialog(
                getString(R.string.clear_upload),
                getString(R.string.confirm_clear_upload),
                context,
                new ActionConformationDialog.OnActionCOnformationListner() {
                    @Override
                    public void onConformed() {
                        try {
                            uploadMapModelList.clear();
                            uploadMapAdapter.notifyDataSetChanged();

                            floatingActionButton.setVisibility(View.GONE);

                            noNotificationAvailable.setVisibility(View.VISIBLE);

                            recyclerView.setVisibility(View.GONE);

                            JobScheduler jobScheduler = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);

                            DbHelper dbHelper = new DbHelper(activity);
                            dbHelper.delteAllUploadMapData();

                            assert jobScheduler != null;
                            if (jobScheduler.getAllPendingJobs().size() > 0)
                                jobScheduler.cancelAll();

                        } catch (Exception e) {
                            writreCrashReport(e.getMessage());
                        }
                    }

                    @Override
                    public void onRejected() {

                    }
                });
    }


    private void updateUploadData(String uploadIdentifier, String uploadStatus) throws Exception {

        for (UploadMapModel uploadMapModel : uploadMapModelList) {

            if (String.valueOf(uploadMapModel.getUploadId()).equalsIgnoreCase(uploadIdentifier)) {

                int indexPostion = uploadMapModelList.indexOf(uploadMapModel);

                uploadMapModel.setUploadStatus(uploadStatus);

                uploadMapModelList.set(indexPostion, uploadMapModel);

                uploadMapAdapter.notifyItemChanged(indexPostion);

                break;
            }
        }
    }

    BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            try {

                String uploadId = intent.getStringExtra(Constants.ID);

                String status = intent.getStringExtra(Constants.EXTRASTRINGS);

                if (Utils.isVaildString(uploadId) && Utils.isVaildString(status))
                    updateUploadData(uploadId, status);
                else
                    writreCrashReport("Invalid ID");

            } catch (Exception e) {
                writreCrashReport(e.getMessage());
            }
        }
    };


}
