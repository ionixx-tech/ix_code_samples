package com.dubuqu.dnModels.requestModel;

/**
 * Created by root on 12/7/17.
 */

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import org.json.JSONException;
import org.json.JSONObject;

public class PostMediaComment {

    @SerializedName("comment")
    @Expose
    private String comment;
    @SerializedName("comment_type")
    @Expose
    private String commentType;

    @SerializedName("parent_comment_id")
    @Expose
    private String parentCommentId;

    public PostMediaComment(String comment, String commentType) {
        this.comment = comment;
        this.commentType = commentType;
    }

    public String getParentCommentId() {
        return parentCommentId;
    }

    public void setParentCommentId(String parentCommentId) {
        this.parentCommentId = parentCommentId;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getCommentType() {
        return commentType;
    }

    public void setCommentType(String commentType) {
        this.commentType = commentType;
    }

    public String toJSON(){

        JSONObject jsonObject= new JSONObject();
        try {
            jsonObject.put("comment", getComment());
            jsonObject.put("comment_type", getCommentType());
            jsonObject.put("parent_comment_id", getParentCommentId());

            return jsonObject.toString();
        } catch (JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return "";
        }

    }

}