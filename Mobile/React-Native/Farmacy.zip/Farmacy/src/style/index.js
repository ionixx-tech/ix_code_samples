/**
 * Created by INX on 1/2/18.
 */
import {StyleSheet, Dimensions} from 'react-native';
var WINDOW_WIDTH = Dimensions.get('window').width;
var WINDOW_HIEGHT = Dimensions.get('window').height;

export default StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "white"
    },
    sideMenuContainer: {
        flex: 1.0,
        backgroundColor: "white",

    },
    center: {
        justifyContent: "center",
        alignItems: "center"
    },
    centerX: {
        justifyContent: "center",
    },
    centerY: {
        alignItems: "center"
    },
    horizontalLayout: {
        flexDirection: "row"
    },
    verticleLayout: {
        flexDirection: "column",
    },
    backgroundImage: {
        resizeMode: 'stretch',
        position: 'absolute',
        top: 0, right: 0, bottom: 0, left: 0,
        width: null,
        height: null,
        /* width: '100%',
         height: '100%',*/
    },

    cardStyle: {
        shadowOffset: {width: 0, height: 3,},
        shadowColor: 'gray',
        shadowOpacity: 1,
        shadowRadius: 5,
        elevation: 2,
        borderRadius: 1
    },
    row: {
        flexDirection: 'row'
    },
    column: {
        flexDirection: 'column'
    },
    baseAbsoluteContainer: {
        flex: 1, position: 'absolute', backgroundColor: 'black', opacity: 0.4, width: '100%', height: '100%'
    },
    placeholderStyle: {
        backgroundColor: '#E9EEF1', width: 70, height: 70,
    }, alertModal: {
        height: 180,
        width: WINDOW_WIDTH - 40,
        backgroundColor: "white",
        shadowOffset: {width: 0, height: 3,},
        shadowColor: 'gray',
        shadowOpacity: 1,
        shadowRadius: 5,
        elevation: 5,



    }

})