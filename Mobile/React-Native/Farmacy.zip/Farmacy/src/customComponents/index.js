/**
 * Created by INX on 11/9/17.
 */

import Indicator from  './Indicator';
import VideoPlayerController from  './VideoPlayerController';
import PaginationFlatList from  './PaginationFlatList';
import ButtonBadege from  './ButtonBadege';

import CustomRangeSlider from './CustomRangeSlider'

import NavigationHeader from  './CustomHeader';
import MultiSlider from  './slider/MultiSlider';
import LeftButton from './CustomLeftButton';
import RightButton from  './CustomNavBarRightButton'
import HeaderTitle from './HeaderTabTitle';
import AutoValidateInputText from './AutoValidateInputText';
import CustomHeader from './NavigationHeaderTabBar';
import CustomScalingDrawer from './CustomScalingDrawer'
import AlertDialog from './CustomAlert'
import NoResultView from './NoResultView'
import ShowCustomAlert from './ShowCustomAlert'

export {

    AutoValidateInputText,

}