'strict'
import React, {Component, PureComponent} from 'react';
import Modal from 'react-native-modalbox';
import TimerMixin from 'react-timer-mixin';
import {
    View,
    StyleSheet,
    PropTypes,
    Alert,
    Image,
    ScrollView,
    FlatList,
    Text,
    TextInput,
    TouchableOpacity,
    Video,
    Dimensions
} from 'react-native';
const Validation = {
    NONE: 1,
    NO: 2,
    YES: 3,
};
import propTypes from 'prop-types';
import {
    NetworkManager,
    Utilities,
    HTTP_METHOD,
    API_PATH,
    Navigation,
    HEADER_TITLE,
    ImageAsset,
    renderIfElse,
    COLOR,
    renderIf
} from 'src/utilities/index';
import mainStyle from 'src/style/index.js'


class WarningAlert extends Component {
    static propTypes={
        positiveCallback:propTypes.func,
        negativeCallback:propTypes.func,
        gotItCallback:propTypes.func,
        TopMargin:propTypes.number
    }

    static defaultProps = {};



    constructor(props) {
        super(props);
        this.state = ({
            message: "",
            isError: false,
            isConfirmAlert:this.props.confirmAlert,
            positiveButtonText:this.props.positiveButtonText,
            negativeButtonText:this.props.negativeButtonText,
            // negativeCallBack:this.props.onPressNegativeButton,
            // positiveCallBack:this.props.onPressPostiveButton,
            successImage: ImageAsset.HOORAY_ICN,
            warningImage: ImageAsset.OOPS_ICN,
            confirmImage:ImageAsset.OOPS_ICN,
            successTitle: "Hooray!",
            warningTitle: "Oops!",
            isGotItCallBack:false,

            /*Variables Not Used */
            errorImage: ImageAsset.OOPS_ICN,
            errorTitle: "",
            topMargin:this.props.topMargin,
             isOpen:false

        });

    }

    closeAlert() {
        this.setState({
            isOpen:false
        })
       // Utilities.showToast(gotItCallBack);
        if(this.state.isGotItCallBack)
            gotItCallback();

        this.warningAlert.close();
    }

    showAlert(message, isError) {
        this.setState({
            isOpen:true
        })
        this.setState({message: message, isError: isError,isGotItCallBack:false})
        this.warningAlert.open();

    }
    showCallBackAlert(message, isError,callBack) {

        this.setState({message: message, isError: isError,isGotItCallBack:true})
        this.warningAlert.open();
        gotItCallback=callBack;

    }

    showConfirmAlert(message,positiveButtonText,negativeButtonText,positiveCallBack,negativeCallBack)
    {
        this.setState({message:message,positiveButtonText:positiveButtonText,
        negativeButtonText:negativeButtonText,isGotItCallBack:false});
        positiveCallbackFunction=positiveCallBack;
        positiveCallback=positiveCallBack, negativeCallback=negativeCallBack;
        this.warningAlert.open();
    }

    onPressPositiveButton()
    {
        positiveCallback();
        this.closeAlert();
    }
    onPressNegativeButton(){
        negativeCallback();
        this.closeAlert();
    }


    render() {
        let confirmAlert=this.state.isConfirmAlert;
        let topMargin=this.state.topMargin;
        let message = this.state.message;
        let imageAsset, title, titleColor;
        if(confirmAlert!==true || confirmAlert===undefined) {
            if (this.state.isError !== true || this.state.isError === undefined) {
                imageAsset = this.state.successImage;
                title = this.state.successTitle;
                titleColor = COLOR.THEME_COLOR
            } else {
                imageAsset = this.state.warningImage;
                title = this.state.warningTitle;
                titleColor = COLOR.RED
            }
        }
        else {
            imageAsset=this.state.confirmImage;
            titleColor = COLOR.RED
        }

        if(confirmAlert===true)
        {

            return (
                <Modal style={[mainStyle.alertModal,topMargin===undefined?{marginTop:0}:{marginTop:topMargin}]}
                       entry={'top'}
                       backdrop={true}
                       swipeToClose={false}
                       position={"top"}
                       backdropPressToClose={false}
                    // onClosed={() => {}}
                       ref={(b => {
                           this.warningAlert = b;
                       })}
                       onClosed={()=>{
                           this.setState({
                               isOpen:false
                           })
                       }}
                     onOpened={()=>{
                        this.setState({
                        isOpen:true
                        })
                     }}>


                    <View style={{
                        backgroundColor: 'transparent',
                        flex: 1,
                        flexDirection: 'row'
                    }}>
                        <View style={{
                            flex: .3,
                            alignItems: 'center',
                            justifyContent: 'center',
                            flexDirection: 'row'
                        }}>

                            <View style={{
                                flex: 1,
                                margin: 10,
                                alignItems: 'center',
                                flexDirection: 'column'
                            }}>

                                <Image style={{
                                    alignSelf: 'center',
                                    height: 60,
                                    width: 60,
                                    margin: 10,
                                    resizeMode: 'stretch'
                                }}
                                       source={imageAsset}>
                                </Image>
                            </View>

                        </View>
                        <View style={{
                            flex: .7,
                            backgroundColor: 'white',
                            flexDirection: 'column'
                        }}>
                            <View style={{flex: 1}}>

                                <View style={{
                                    flex: .75,
                                    justifyContent: 'center'
                                }}>
                                    <Text style={{
                                        color: 'gray',
                                        marginTop: 20,
                                        marginBottom: 20,
                                        marginRight: 10,
                                        marginLeft: 10,
                                    }}>{message}

                                    </Text>
                                </View>
                                <View style={{
                                    flex: .25,
                                    justifyContent: 'flex-end',
                                    alignItems:'center',
                                    flexDirection:'row',
                                    marginRight:20
                                }}>
                                    <Text style={{
                                        color: 'gray',
                                        height: 30,
                                        margin: 10,
                                        fontSize: 18,
                                        fontWeight: 'bold',
                                    }} onPress={this.onPressNegativeButton.bind(this)}>{this.state.negativeButtonText}
                                    </Text>

                                    <Text style={{
                                        color: titleColor,
                                        height: 30,
                                        margin: 10,
                                        fontSize: 18,
                                        fontWeight: 'bold',
                                    }} onPress={this.onPressPositiveButton.bind(this)}>{this.state.positiveButtonText}
                                    </Text>


                                </View>
                            </View>

                        </View>
                    </View>
                </Modal>



            );


        }else {
            return (
                <Modal style={[mainStyle.alertModal,topMargin===undefined?{marginTop:0}:{marginTop:topMargin}]}
                       entry={'top'}
                       backdrop={true}
                       swipeToClose={false}
                       position={"top"}
                       backdropPressToClose={false}
                    // onClosed={() => {}}
                       ref={(b => {
                           this.warningAlert = b;
                       })}>
                    <View style={{
                        backgroundColor: 'transparent',
                        flex: 1,
                        flexDirection: 'row'
                    }}>
                        <View style={{
                            flex: .3,
                            alignItems: 'center',
                            justifyContent: 'center',
                            flexDirection: 'row'
                        }}>

                            <View style={{
                                flex: 1,
                                margin: 10,
                                alignItems: 'center',
                                flexDirection: 'column'
                            }}>

                                <Text style={{
                                    color: titleColor,
                                    fontSize: 18,
                                    fontWeight: 'bold'
                                }}>{title}
                                </Text>
                                <Image style={{
                                    alignSelf: 'center',
                                    height: 60,
                                    width: 60,
                                    margin: 10,
                                    resizeMode: 'stretch'
                                }}
                                       source={imageAsset}>
                                </Image>
                            </View>

                        </View>
                        <View style={{
                            flex: .7,
                            backgroundColor: 'white',
                            flexDirection: 'column'
                        }}>
                            <View style={{flex: 1}}>

                                <View style={{
                                    flex: .75,
                                    justifyContent: 'center'
                                }}>
                                    <Text style={{
                                        color: 'gray',
                                        marginTop: 20,
                                        marginBottom: 20,
                                        marginRight: 10,
                                        marginLeft: 10,
                                    }}>{message}

                                    </Text>
                                </View>
                                <View style={{
                                    flex: .25,
                                    justifyContent: 'center'

                                }}>
                                    <Text style={{
                                        color: titleColor,
                                        height: 30,
                                        alignSelf: 'flex-end',
                                        margin: 20,
                                        fontSize: 18,
                                        fontWeight: 'bold',
                                    }} onPress={this.closeAlert.bind(this)}>GOT IT!
                                    </Text>


                                </View>
                            </View>

                        </View>
                    </View>
                </Modal>



            );
        }


    }
}

module.exports = WarningAlert;

/*
 width:rightIconHeight,
 height:rightIconHeight,*/
