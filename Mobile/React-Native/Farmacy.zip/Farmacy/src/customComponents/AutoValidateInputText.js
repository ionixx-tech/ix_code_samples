'strict'
import React, {Component, PureComponent} from 'react';

import {TextInput, StyleSheet, Text, View, PropTypes, Image, Alert} from 'react-native';
import TimerMixin from 'react-timer-mixin';
import {NetworkManager, Utilities, HTTP_METHOD, API_PATH, Navigation, HEADER_TITLE} from 'src/utilities/';

const Validation = {
    NONE: 1,
    NO: 2,
    YES: 3,
};
import text_validation_failed from 'resource/validation/text_validation_failed.png';
import text_validation_sucess from 'resource/validation/text_validation_sucess.png';

class TextField extends Component {
    mixins: [TimerMixin]
    static defaultProps = {
        placeholderColor: 'black',
        errorColor: 'red',
        height: 70,
        isPassword: false
    };

    constructor(props) {
        super(props);
        this.state = ({
            isValid: Validation.NONE,
            text: this.props.value,
            underLineColor: "gray",
            rightIconHeight: 0,
            timePassed: false,
            validationSuccess: false,
            editedOnce: false,

        });
        this.text = this.props.value == undefined ? "" : this.props.value;

    }

    _validateEmail(email) {

        let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        return (reg.test(email));
        // return (email.length>1)
    }


    _validatePassword(pwd) {

        return (pwd.length > 3);
    }


    _validateEmailOrUserName(emailOrUsrname) {

        let USER_NAME_PATTERN = (/^[a-zA-Z0-9.]*$/)
        let EMAIL_PATTERN = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        //  return (reg.test(email));

        return ((USER_NAME_PATTERN.test(emailOrUsrname) || EMAIL_PATTERN.test(emailOrUsrname)) && emailOrUsrname.length >= 4);
    }
    _validateUserName(userName)
    {
        let USER_NAME_PATTERN = (/^[a-zA-Z0-9.]*$/)
        return ((USER_NAME_PATTERN.test(userName)&& userName.length >= 4 ));
    }

    _validateMNumber(mNumber) {
        let usPhonePattern = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4,20})$/
        return (usPhonePattern.test(mNumber)||mNumber.length>10);
    }

    _validateName(name) {
        let USER_NAME_PATTERN = (/^[a-zA-Z_\s/g]*$/)
        return (USER_NAME_PATTERN.test(name) && name.length >= 4);

        //return (name.length>3);
    }
    _validateBankNameOrId(nameOrId) {
        let USER_NAME_PATTERN = (/^[a-zA-Z0-9_\s/g]*$/)
        return (USER_NAME_PATTERN.test(nameOrId));

        //return (name.length>3);
    }

    _validateAddress(adddress) {
        let USER_NAME_PATTERN = (/^[a-zA-Z0-9_.#\s/g]*$/)
        return (USER_NAME_PATTERN.test(adddress) && adddress.length >= 4);

    }

    _validatePhoneExtention(phoneExtension) {
        let PHONE_EXTENSION_PATTERN = (/^[0-9]*$/)
        return (PHONE_EXTENSION_PATTERN.test(phoneExtension));
    }

    _validateZipCode(zipCode) {
        let ZIP_CODE = (/^([0-9]{5}|[A-Z][0-9][A-Z] ?[0-9][A-Z][0-9])$/)
        return (ZIP_CODE.test(zipCode))

    }

    _validateStateCode(stateCode) {
        return (stateCode.length === 2)
    }


    _validateRoutingNumber(routingNumber) {

        let ROUTING_NUMBER=  /^[\s()+-]*([0-9][\s()+-]*){5,20}$/
        return (ROUTING_NUMBER.test(routingNumber))
    }

    _validteAccountNumber(accountNumber)
    {
        let ACCOUNT_NUMBER=  /^[\s()+-]*([0-9][\s()+-]*){5,20}$/
        return (ACCOUNT_NUMBER.test(accountNumber))
    }

    _validateBankId(bankId)
    {
        let BANK_ID_PATTERN=  (/^[a-zA-Z0-9_.#/g]*$/)
        return (BANK_ID_PATTERN.test(bankId)&& bankId.length >= 4)
    }

    _onEndEditing(text) {

        // Alert.alert(this.state.text)
        /* if (this.state.text.length>8) {
         this.setState({isValid:Validation.YES});
         }else{
         this.setState({isValid:Validation.NO});
         }
         */
        /*let automatic = this.props.automaticValidation;

         if (automatic == undefined || automatic == false) {
         return;
         }

         var tmptext = this.state.text;

         if (tmptext == undefined || tmptext == null) {
         tmptext = "";
         }

         let count = tmptext.length;

         let keyboardType = this.props.keyboardType;

         if (keyboardType != undefined && keyboardType == 'email-address') {
         }*/
        /*if (this._validateEmail(this.state.text) === true) {
         this.setState({isValid: Validation.YES});
         } else {
         this.setState({isValid: Validation.NO});
         }*/

    }

    _onChangeText(text) {
        console.log("onText change called");

        // if (this.props.maxLength != null) {
        //     if (this.props.maxLength < text.length){
        //         return;
        //     }
        //     //text
        // }

        

        if (this.props.onChangeText != null) {


            // if ( (this.props.pkeyboardType === 'email-address')  || (this.props.userNameOrEmail === true ))
            // {
            //    text=text;
            //
            // }else {
            //     text = text.replace(".", "");
            // }

            if (this.props.isUserName === true || this.props.isPassword === true) {
                text = text.replace(" ", "")
            }

            if ((this.props.isSateCode !== null && this.props.isSateCode !== undefined)||(this.props.isCountryCode !== null && this.props.isCountryCode !== undefined)) {
                text = text.replace(" ", "")
                // if(text.length>2)
                // {
                //     text=text.substr(0,2);
                // }
                text= text.toUpperCase();
            }

            this.props.onChangeText(text);
        }

        this.text = text[0-9]
        this.setState({text: text});

        let automatic = this.props.automaticValidation;

        if (automatic == undefined || automatic == false) {
            return;
        }

        var tmptext = this.state.text;

        if (tmptext == undefined || tmptext == null) {
            tmptext = "";
        }

        this.setState({editedOnce: true});


        setTimeout(() => {

            let keyboardType = this.props.keyboardType;

            if (keyboardType != undefined && keyboardType == 'email-address') {

                if (this._validateEmail(this.state.text) === true) {
                    this.setState({isValid: Validation.YES, validationSuccess: true});
                } else {
                    this.setState({isValid: Validation.NO, validationSuccess: false});
                }
            }

            if (keyboardType != undefined && keyboardType == 'default') {


                if (this.props.userNameOrEmail !== null && this.props.userNameOrEmail !== undefined) {
                    if (this.props.userNameOrEmail === true) {
                        if (this._validateEmailOrUserName(this.state.text)) {
                            this.setState({isValid: Validation.YES, validationSuccess: true});
                        } else {
                            this.setState({isValid: Validation.NO, validationSuccess: false});
                        }

                    }
                } else if (this.props.isUserName === true) {
                    if (this._validateUserName(this.state.text) === true) {
                        this.setState({isValid: Validation.YES, validationSuccess: true});
                    } else {
                        this.setState({isValid: Validation.NO, validationSuccess: false});
                    }
                }
                else if (this.props.isPassword === true) {
                    if (this._validatePassword(this.state.text) === true) {
                        this.setState({isValid: Validation.YES, validationSuccess: true});
                    } else {
                        this.setState({isValid: Validation.NO, validationSuccess: false});
                    }
                } else if (this.props.isAddress === true) {
                    if (this._validateAddress(this.state.text) === true) {
                        this.setState({isValid: Validation.YES, validationSuccess: true});
                    } else {
                        this.setState({isValid: Validation.NO, validationSuccess: false});
                    }
                } else if (this.props.isSateCode === true) {
                    if (this._validateStateCode(this.state.text) === true) {
                        this.setState({isValid: Validation.YES, validationSuccess: true});
                    } else {
                        this.setState({isValid: Validation.NO, validationSuccess: false});
                    }
                }else if(this.props.isCountryCode===true)
                {
                    if (this._validateStateCode(this.state.text) === true) {
                        this.setState({isValid: Validation.YES, validationSuccess: true});
                    } else {
                        this.setState({isValid: Validation.NO, validationSuccess: false});
                    }

                }else if(this.props.isRoutingNumber===true)
                {
                    if (this._validateRoutingNumber(this.state.text) === true) {
                        this.setState({isValid: Validation.YES, validationSuccess: true});
                    } else {
                        this.setState({isValid: Validation.NO, validationSuccess: false});
                    }

                }else if(this.props.isAccountNumber===true)
                {
                    if (this._validteAccountNumber(this.state.text) === true) {
                        this.setState({isValid: Validation.YES, validationSuccess: true});
                    } else {
                        this.setState({isValid: Validation.NO, validationSuccess: false});
                    }

                } else if(this.props.isBankId===true)
                {
                    if (this._validateBankId(this.state.text) === true) {
                        this.setState({isValid: Validation.YES, validationSuccess: true});
                    } else {
                        this.setState({isValid: Validation.NO, validationSuccess: false});
                    }

                } else if(this.props.isBankNameOrId===true)
            
                {
                    
                    if (this._validateBankNameOrId(this.state.text) === true) {
                        this.setState({isValid: Validation.YES, validationSuccess: true});
                    } else {
                        this.setState({isValid: Validation.NO, validationSuccess: false});
                    }

                } else {
                    if (this._validateName(this.state.text) === true) {
                        this.setState({isValid: Validation.YES, validationSuccess: true});

                    } else {
                        this.setState({isValid: Validation.NO, validationSuccess: false});

                    }
                }


            }

            if (keyboardType != undefined && keyboardType == 'phone-pad') {

                if (this.props.isPhoneExtension !== null && this.props.isPhoneExtension !== undefined) {

                    if (this._validatePhoneExtention(this.state.text) === true) {
                        this.setState({isValid: Validation.YES, validationSuccess: true});

                    } else {

                        this.setState({isValid: Validation.NO, validationSuccess: false});
                    }

                } else {

                    if (this._validateMNumber(this.state.text) === true) {
                        this.setState({isValid: Validation.YES, validationSuccess: true});
                    } else {
                        this.setState({isValid: Validation.NO, validationSuccess: false});
                    }

                }


            } else if (keyboardType != undefined && keyboardType == 'numeric') {
                if (this.props.isZipCode !== null && this.props.isZipCode !== undefined) {

                    if (this._validateZipCode(this.state.text) === true) {

                        this.setState({isValid: Validation.YES, validationSuccess: true});

                    } else {

                        this.setState({isValid: Validation.NO, validationSuccess: false});
                    }

                }
            }


        }, 1000);

    }


    render() {

        let tmptext = this.state.text;

        if (tmptext === undefined) {
            tmptext = "";
        }

        let color = "transparent";
        let underLineColor = "gray";
        let textColor = "black";
        let placeholder = this.props.placeholder;
        let errorMgs = '';
        let pointerEvents=this.props.pointerEvents;
        let topPlaceholderHeight = tmptext.length == 0 ? 0 : 15;
        let icon = text_validation_failed;
        let keyboardType = this.props.keyboardType;
        let maxLength=this.props.maxLength;
        let returnKeyType=this.props.returnKeyType;
        if (keyboardType == undefined) {
            keyboardType = 'default';
        }
        let rightIconHeight = 0;
        let errorMessageHeight = 0;

        switch (this.state.isValid) {
            case Validation.NO:
                //console.log("Not Validated Called");
                color = this.props.errorColor;
                textColor = "black";
                errorMgs = this.props.errorMessage;
                icon = text_validation_failed;
                if (this.state.text.length > 0 && this.state.editedOnce === true) {
                    console.log("Not Validated Called and text length >0");
                    rightIconHeight = 20;
                    errorMessageHeight = 20;
                    underLineColor = this.props.errorColor
                } else {
                    rightIconHeight = 0;
                    errorMessageHeight = 0;
                    underLineColor = 'gray'
                }
                break;
            case Validation.YES:
                color = "green";
                icon = text_validation_sucess;
                rightIconHeight = 20;
                underLineColor = 'gray';
                errorMessageHeight = 0;
                // this.setState({rightIconHeight:20})
                // this.setState({underLineColor:'gray'})

                break;
            default:
                break;
        }

        return (
            <View style={{
                backgroundColor: "transparent",
                height: this.props.height,
                padding: 2,
                margin: 4,
                justifyContent: "center"
            }}>

                <Text
                    style={{
                        height: topPlaceholderHeight,
                        fontSize: 13,
                        color: this.props.placeholderColor,
                        padding: 0
                    }}> {placeholder} </Text>

                <TextInput
                    ref={(input) => {
                        this.textField = input;
                    }}
                    {...this.props}
                    value={this.state.text}
                    keyboardType={keyboardType}
                    underlineColorAndroid="transparent"
                    pointerEvents={pointerEvents}
                    placeholder={placeholder}
                    autoFocus={this.props.autoFocus}
                    style={{
                        flex: 1, padding: 0,
                        paddingLeft: 2,
                        paddingRight: 30,
                        fontSize: 15,
                        height: 30,
                        color: textColor
                    }}
                    maxLength={maxLength}
                    returnKeyType={returnKeyType}
                    onChangeText={(text) => this._onChangeText(text) }
                    /*onEndEditing={(text) => this._onEndEditing(text)}*/
                    /* onSubmitEditing={(text) => this._onEndEditing(text) }*/
                />
                <Image style={{
                    backgroundColor: "transparent",
                    width: rightIconHeight,
                    height: rightIconHeight,
                    right: 10,
                    alignSelf: "flex-end",
                    position: "absolute",
                    resizeMode: 'stretch'
                }}
                       source={icon}/>

                <View
                    style={{
                        borderBottomColor: underLineColor,
                        borderBottomWidth: 1,
                    }}
                />
                <Text style={{
                    height: 15,
                    fontSize: 13,
                    color: this.props.errorColor,
                    padding: 0
                }}>{errorMgs}</Text>

            </View>

        );
    }
}

module.exports = TextField;

/*
 width:rightIconHeight,
 height:rightIconHeight,*/
