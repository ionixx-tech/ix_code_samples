'strict'
/**
 * Created by INX on 11/9/17.
 */

// var AppConfig = require('./AppConfig');

import UserManager from  './UserManager';

export {
    UserManager
}
