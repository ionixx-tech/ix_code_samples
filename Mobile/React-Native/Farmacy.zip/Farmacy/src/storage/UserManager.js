'strict'

import {AsyncStorage} from 'react-native';

let instance: UserManager = null;

let kSTORAGE_USER_INFO_KEY = '@AsyncStorageUserInfo:key';
let CART_KEY='cart_token'
class UserManager {

    constructor() {

        if (!instance) {
            instance = this;
            this.accessToken = null;
            this.username = null;

            this.email = "";
            this.isLoggedIn = false;
            this.currentUser = {};
            this.isVendor = 'false';
            this.values = {};
            this.notificationObject = {}
            this.countryFlag='';
            this.countryList='';
            this.countryId='';
            this.cartToken=''
        }


    }
  getName(){
        if (this.currentUser === null){
            return ""
        }
        return  this.currentUser['name'];
  }
  getProfileURL(){
      if (this.currentUser === null){
          return ""
      }
        return  this.currentUser['profile_image_url'];
  }
    isLogedIn() {

        return this.isLoggedIn;
    }
    getNotificationValue(key){
      console.log('key====>',key);
      console.log('object stored==>',this.notificationObject)
      if(this.notificationObject === null){
          console.log('null');
          return ''
      }
      console.log('values====>',this.notificationObject[key]);
      return this.notificationObject[key]
    }
    saveUser(info,callback) {
        let stringJSON = JSON.stringify(info);
        AsyncStorage.setItem(kSTORAGE_USER_INFO_KEY, stringJSON, () => {
            this.loadUser(function (json) {
                callback();
            });
        });
    }
    saveCartToken(info,callback){
        let stringJSON = JSON.stringify(info);
        AsyncStorage.setItem(CART_KEY, stringJSON, () => {
            this.loadCartToken(function (json) {
                callback();
            });
        });
    }
    loadCartToken(callback){
        AsyncStorage.getItem(CART_KEY, (err, result) => {
            if (err != null) {
                return
            }
            this.cartToken = JSON.parse(result);
            var allowHome = false;
            if (result != null) {

                allowHome = true;

            }

            callback(allowHome);
        });
    }
    getCartToken(){
        return this.cartToken;
    }
    saveData(key, info){
        let stringJSON = JSON.stringify(info);
        AsyncStorage.setItem(key, stringJSON, () => {
            this.getItems(key, (result)=>{
                this.countryFlag=result;
            })
        });
    }
    getData(key, callBack){
        AsyncStorage.getItem(key, (err, result) => {
            if(err !== null){
                return
            }
            callBack(JSON.parse(result));
        });
    }


    saveCountryList(key, info){
        let stringJSON = JSON.stringify(info);
        AsyncStorage.setItem(key, stringJSON, () => {
            this.getCountryList(key, (result)=>{
                this.countryList=result;
            })
        });
    }

    getCountryList(key, callBack){
        AsyncStorage.getItem(key, (err, result) => {
            if(err !== null){
                console.log('error ===>',err)
                return
            }
            console.log('keyinfo===>',result)
            this.countryList=JSON.parse(result);
            callBack(JSON.parse(result));
        });
    }


    saveCountryId(key, info){
        console.log('keyinfo===>',key,info)
        let stringJSON = JSON.stringify(info);
        AsyncStorage.setItem(key, stringJSON, () => {
            this.getCountryId(key, (result)=>{
                this.countryId=JSON.parse(result);
            })
        });
    }

    getCountryId(key, callBack){
        AsyncStorage.getItem(key, (err, result) => {
            if(err !== null){
                console.log('error ===>',err)
                return
            }
            this.countryId=JSON.parse(result);
            console.log('keyinfo===>',result)
            callBack(result);
        });
    }


    saveItems(key, info){
        console.log('keyinfo===>',key, info)
        var stringJSON = JSON.stringify(info);
        console.log('print stringfy===>',stringJSON)
        AsyncStorage.setItem(key, stringJSON, () => {

            this.getItems(key, (result)=>{
                console.log('results ===>',key,result)
                this.notificationObject = result;
            })
        });
    }
    getItems(key, callBack){
        AsyncStorage.getItem(key, (err, result) => {
            if(err !== null){
                return
            }

            callBack(JSON.parse(result));
        });
    }

    loadUser(callback) {
        AsyncStorage.getItem(kSTORAGE_USER_INFO_KEY, (err, result) => {
            if (err != null) {
                return
            }
            this.currentUser = JSON.parse(result);
            this.isLoggedIn = false;
            var allowHome = false;
            if (result != null) {
                this.accessToken = this.currentUser.access_token;
                this.username = this.currentUser.username;
                this.email = this.currentUser.email;
                this.isVendor = this.currentUser.is_vendor;
                //let tmpGuest = this.currentUser["guest_user"];
                //this.isLoggedIn = (tmpGuest == undefined);
                this.isLoggedIn = true;
                allowHome = true;

            }

            callback(allowHome);
        });
    }

    logout(callback) {
        let weakSelf = this;

        AsyncStorage.removeItem(kSTORAGE_USER_INFO_KEY, (err) => {
            weakSelf.currentUser = null;
            weakSelf.accessToken = null;
            weakSelf.username = null;
            weakSelf.email = ""
            weakSelf.isLoggedIn = false;
            weakSelf.isVendor = 'false'
            callback();
        });
    }

    static getInstance() {
        if (instance == null) {
            let user = new UserManager();
            instance = user;
        }
        return instance;
    }
}
module.exports = UserManager;
