/**
 * Created by INX on 11/7/17.
 */
import React, {Component} from 'react'
import {AppRegistry, Platform, TouchableOpacity, Image} from 'react-native';

import {StackNavigator} from 'react-navigation';

import {Screen, ImageAsset, COLOR} from 'src/utilities';
import {
    setCustomView,
    setCustomTextInput,
    setCustomText,
    setCustomImage,
    setCustomTouchableOpacity
} from 'react-native-global-props';
import {FONT} from './utilities/FontConstant';

const customTextProps = {
    style: {
        fontFamily: FONT.THEME_FONT,
    }
};
const customTextInputProps = {
    style: {
        fontFamily: FONT.THEME_FONT,
    }
};

setCustomTextInput(customTextInputProps);
setCustomText(customTextProps);

const App = StackNavigator({
        // SPLASH: {screen: Screen.SPLASH},
        LANDING: {screen: Screen.LANDING},
        HOME: {screen: Screen.HOME},
        LOGIN: {screen: Screen.LOGIN},
        FORGOT: {screen: Screen.FORGOT},
        SIGNUP: {screen: Screen.SIGNUP},
        ALL_STORE: {screen: Screen.ALL_STORE},
        STORE_CONTAINER: {screen: Screen.STORE_CONTAINER},
        // HOME:{screen:AppDrawer},
        MAPSTORE: {screen: Screen.MAPSTORE},
        SETTINGS: {screen: Screen.SETTINGS},
        NOTIFICATION: {screen: Screen.NOTIFICATION},
        VIDEO_DETAIL: {screen: Screen.VIDEO_DETAIL},
        USER_PROFILE: {screen: Screen.USER_PROFILE},
        IMAGE_PICKER: {screen: Screen.IMAGE_PICKER},
        WELCOME: {screen: Screen.WELCOME},
        CHANNEL: {screen: Screen.CHANNEL},
        EPISODE: {screen: Screen.EPISODE},
        VIDEO_PLAYER: {screen: Screen.VIDEO_PLAYER},

        B2C_PRODUCT_DETAIL: {screen: Screen.B2C_PRODUCT_DETAIL},
        B2B_PRODUCT_DETAIL: {screen: Screen.B2B_PRODUCT_DETAIL},
        PRODUCT_FILTER: {screen: Screen.PRODUCT_FILTER},
        PRODUCT_SHOP: {screen: Screen.PRODUCT_SHOP},
        STATE_SELECTOR: {screen: Screen.STATE_SELECTOR},
        CART_SUMMARY: {screen: Screen.CART_SUMMARY},

        ADDRESS_CONTROLLER: {screen: Screen.ADDRESS_CONTROLLER},
        ADDRESS_LIST: {screen: Screen.ADDRESS_LIST},
        CHANGEPASSWORD: {screen: Screen.CHANGEPASSWORD},
        CHANGE_EMAIL: {screen: Screen.CHANGE_EMAIL},
        MY_ORDERS: {screen: Screen.MY_ORDERS},
        CART_LIST: {screen: Screen.CART_LIST},
        ORDER_DETAILS: {screen: Screen.ORDER_DETAILS},
        PAY_SAFE: {screen: Screen.PAY_SAFE},
        MY_SALES: {screen: Screen.MY_SALES},
        MY_SALE: {screen: Screen.MY_SALE},
        MEDICAL_INFO: {screen: Screen.MEDICAL_INFO},
        BANK_AND_MEDICAL_INFO: {screen: Screen.BANK_AND_MEDICAL_INFO},
        BANK_ACCOUNT_INFO: {screen: Screen.BANK_ACCOUNT_INFO},
        GREEN_PAY: {screen: Screen.GREEN_PAY},
        FORUM_DETAILS: {screen: Screen.FORUM_DETAILS},
        MY_FAV: {screen: Screen.MY_FAV},
        FULL_SCREEN_IMAGE: {screen: Screen.FULL_SCREEN_IMAGE},
        MESSAGE_LIST: {screen: Screen.MESSAGE_LIST},
        CREDIT_LIST: {screen: Screen.CREDIT_LIST},
        MESSAGE_DETAIL: {screen: Screen.MESSAGE_DETAIL},
        // CART : {screen: Screen.CART}
        REQUEST_WITHDRAWAL: {screen: Screen.REQUEST_WITHDRAWAL},
        REFER_AND_EARN: {screen: Screen.REFER_AND_EARN},
        REWARD_POINTS: {screen: Screen.REWARD_POINTS},
        MARKETPLACE_FILTER: {screen: Screen.MARKETPLACE_FILTER},
        STORE_MAP: {screen: Screen.STORE_MAP},
        GLOBAL_SEARCH: {screen: Screen.GLOBAL_SEARCH},


    },
    {
        // headerMode: 'screen',
        // mode: 'card',

        navigationOptions: {
            tintColor: 'white',
            headerStyle: {
                backgroundColor: COLOR.HEADER_COLOR,
            },
            headerTitleStyle: {
                color: 'white',
                fontWeight: '300',
                marginTop : Platform.OS === 'ios' ? 8 : 0,
                // alignItems : 'center',
                // justifyContent: 'center',
                textAlign: 'center',
                flex:4,
                alignSelf: 'center',
            },
            headerMode: 'screen',
            headerBackTitle: null,
            headerBackTitleStyle: {
                color: 'white'
            },
            headerLeftStyle:{
                flex:1
            },
            headerRightStyle:{
                flex:1
            }
            // header : {
            //     titleStyle : {
            //         textAlign : 'center'
            //     }
            // }
        }
    });

/*const AppDrawer = DrawerNavigator({
 Home: { screen: Screen.HOME },
 SETTINGS: { screen: Screen.SETTINGS }
 });*/


AppRegistry.registerComponent('Farmacy', () => App);

/* https://reactnavigation.org/docs/navigators/stack */
/*https://reactnavigation.org/docs/intro/basic-app*/

