'strict'

import  UserManager from 'src/storage/UserManager';

import {AppConfig} from './Constants';

import {PropTypes} from 'prop-types';

import {API} from './API';
import {EVENT_NAME} from './EventEmit';
import EventEmitter from "react-native-eventemitter";


export const HTTP_METHOD = {
    GET: "GET",
    POST: "POST",
    PUT: "PUT",
    DELETE: "DELETE",
    PATCH: 'PATCH'

};

export class NetworkManager {


    constructor() {
    }

    _getMethodParam(httpMethod) {

        let data = {
            method: httpMethod,

            headers: {
                // 'Accept':       'application/json',
                'Content-Type': 'application/json',
            }
        }

        let sessionToken = UserManager.getInstance().accessToken;
        let cartToken = UserManager.getInstance().cartToken;
        let username = UserManager.getInstance().username;


        return data;
    }


    async sendRequest(path: PropTypes.string, httpMethod: HTTP_METHOD, param: {}, callback: PropTypes.func) {
        let data = this._getMethodParam(httpMethod);
        data.method = httpMethod;

        if (param !== undefined && param !== null && HTTP_METHOD.GET !== httpMethod) {
            data.body = JSON.stringify(param);
            console.log("param  " + data.body);
        }

        let urlResponse = {};

        let url = AppConfig.BASE_URL + path;

        if (HTTP_METHOD.GET === httpMethod && param !== null) {
            url = url + "?" + NetworkManager.JSONtoQueryString(param);
        }
        console.log("finalUrl", url);

        fetch(url, data)
            .then((response) => {
                urlResponse = response;
                 console.log("network manager respone---->",response);
                return response.json();
            })
            .then((responseData) => {
                let error = responseData["error"];
                // console.log("network manager responeDAta---->",responseData);
                if (responseData["code"] === 401) {
                    EventEmitter.emit(EVENT_NAME.AUTHENTICATION_EXPIRE, '');
                }
                if (error != null) {
                    callback(null, urlResponse, error);
                } else {
                    callback(urlResponse, responseData, null);
                }
            }).catch((error) => {
            //console.log("network manager responeDAta---->",error);
            let err = {"code": 400, "message": "Network request failed, Please try again later."}
            // console.log("network manager image form catch---->",err);
            callback(urlResponse, err, null);
            //callback(urlResponse, null, error);
        }).done();
    }

    sendAsyncRequestWithHeader(path: PropTypes.string, httpMethod: HTTP_METHOD, param: {}) {
        return new Promise((resolve, reject) => {

            let request = new NetworkManager();
            request.sendRequest(path, httpMethod, param, function (response, json, error) {

                if (error == null) {
                    json['header_content'] = response.headers;
                    setTimeout(() => resolve(json), 0);

                } else {
                    setTimeout(() => reject(error), 0);

                }
            });

        });

    }


    sendAsyncRequest(path: PropTypes.string, httpMethod: HTTP_METHOD, param: {}) {
        return new Promise((resolve, reject) => {

            let request = new NetworkManager();
            request.sendRequest(path, httpMethod, param, function (response, json, error) {

                if (error == null) {

                    setTimeout(() => resolve(json), 0);

                } else {
                    setTimeout(() => reject(error), 0);

                }
            });

        });
    }


    sendAsynFormcRequest(path: PropTypes.string, httpMethod: HTTP_METHOD, param: {}) {
        return new Promise((resolve, reject) => {

            let request = new NetworkManager();
            request.sendFormRequest(path, httpMethod, param, function (response, json, error) {

                if (error == null) {

                    setTimeout(() => resolve(json), 0);

                } else {
                    setTimeout(() => reject(error), 0);

                }
            });

        });
    }


    async sendFormRequest(path: PropTypes.string, httpMethod: HTTP_METHOD, param: {}, callback: PropTypes.func) {


        if (param != undefined && param != null) {

            let data = NetworkManager.JSONtoFormData(param)

            let urlResponse = {};

            let url = AppConfig.BASE_URL + path;

            if (HTTP_METHOD.POST == httpMethod) {
                url = url;
            }
            console.log("finalUrl", url);
            fetch(url, {
                method: HTTP_METHOD.POST,
                body: data,
                headers: this._getFormHeader()

            }).then((response) => {
                urlResponse = response;
                // console.log("network manager image form respone---->",response);
                return response.json();
            }).then((responseData) => {
                // console.log("network manager image form respone Data---->",responseData);
                let error = responseData["error"];
                if (error != null) {
                    callback(null, urlResponse, error);
                } else {
                    callback(urlResponse, responseData, null);
                }
            }).catch((error) => {

                let err = {"code": 400, "message": "Network request failed, Please try again later."}
                //  console.log("network manager image form catch---->",err);
                callback(urlResponse, err, null);
            }).done();


        } else {
            console.log("FormDataUpload", "Params is undefined");
        }


    }

    _getFormHeader() {
        let sessionToken = UserManager.getInstance().accessToken;
        let username = UserManager.getInstance().username;

        if (sessionToken != undefined) {
            return (

                {
                    // 'Accept':       'application/json',
                    'Content-Type': 'multipart/form-data',
                    'X-Username': username,
                    'X-Access-Token': sessionToken
                });
        } else {
            return (
                {
                    // 'Accept':       'application/json',
                    'Content-Type': 'multipart/form-data'
                });
        }


    }


    static JSONtoQueryString(json) {
        if (json == null) {
            return "";
        }
        let queryString = "";
        for (let key in json) {
            let value = json[key];
            queryString += key + "=" + value + "&";
        }
        queryString = queryString.substr(0, queryString.length - 1);
        return queryString;
    }

    static JSONtoFormData(json) {
        let data = new FormData();

        if (json == null) {
            return "";
        }

        let IMAGE_PATTERN = (/\.(gif|jpg|jpeg|tiff|png|bmp)$/i)
        let VIDEO_PATTERN = (/\.(mp4|mkv|)$/i)
        let PDF_PATTERN = (/\.(pdf|PDF)$/i)

        for (let key in json) {
            let value = json[key];

            if (IMAGE_PATTERN.test(value)) {
                console.log('IMG_KEY', key);
                console.log('IMG_VALUE', value);

                data.append(key, {
                    uri: value,
                    type: 'image/jpeg', // or photo.type
                    name: 'image.jpeg'
                });

            } else if (PDF_PATTERN.test(value)) {
                console.log('PDF_KEY', key);
                console.log('PDF_VALUE', value);
                data.append(key, {
                    uri: value,
                    type: 'application/pdf', // or pdf.type
                    name: 'medicalProof.pdf'
                });
            }
            else if (VIDEO_PATTERN.test(value)) {
                console.log('VIDEO_KEY', key);
                console.log('VIDEO_VALUE', value);

                data.append(key, {
                    uri: value,
                    type: 'video/mp4',
                    name: "video.mp4",
                });
            } else {
                console.log('KEY', key);
                console.log('VALUE', value);
                data.append(key, value); // you can append anyone.
            }


        }

        return data;
    }
}
Array.prototype.pathComponent = function () {
    return this.join('/');
};
Array.prototype.insertTop = function (top) {
    if (top === null) {
        return this;
    }
    return top.concat(this);
};
String.prototype.capitalize = function () {
    return this.charAt(0).toUpperCase() + this.slice(1);
}
