'strict'


export const ALERT_MESSAGES = {
    CHANGE_PASSWORD_SUCCESS : 'Password changed successfully',
    CHANGE_EMAIL_SUCCESS : 'Email id changed successfully',
    EMPTY_COUNTRY : 'Please choose the country',
    COUNTRY_UNAVAILABLE:"Country list unavailable",
    PRODUCT_ADDED_CART : 'Product Added on Cart',
    SELECT_ONE_PRODUCT:'Please select at least one product',
    IS_ERROR: true,
    IS_SUCCESS:false,
    PASSWORD_SENT:'Password sent to your registered mail id',
    ENTER_QUES:'Please Enter the Question.',
    QUES_POSTED:'Question Posted successfully!',
    CANCEL_REQ:'Order Cancelled Successfully!',
    RETURN_REQ:'Return Request Sent Successfully!',
    REPLACE_REQ:'Replace Request Sent Successfully!',
    WRITE_REVIEW : 'Review posted successfully',
    CONNECTION_FAILURE_MSG:"Please check your internet connection, and try again.",
    REFERENCE_TOKEN_SUCCESS : 'Reference token updated successfully',
    NETWORK_REQEST_FAILED:"Network request failed, Please try again later.",
    UPDATE_SHIPPMENT_NUMBER : 'Shipment number updated successfully',
    UNAUTHORIZE_ERROR : 'User logged in with another device. Please login again',
    WITHDRAWAL_SUCCESS:"Withdrawal Request Sent Successfully !",

};

export const STORAGE_INFO = {
    DEVICE_TOKEN : 'deviceToken',
}
export const NOTIFICATION_TYPE = {
    FORUM_REPORT_TYPE : 'FORUM_REPORT',
    FORUM_COMMENT_VOTES_TYPE : 'FORUM_VOTE',
    FORUM_COMMENT_REPORT_TYPE : 'FORUM_COMMENT_REPORT',
    MESSAGE_RECEIVED_TYPE : 'MESSAGE_RECEIVED',
    FORUM_COMMENTED_TYPE : 'FORUM_COMMENT',
    FORUM_COMMENT_REPLIED_TYPE : 'FORUM_REPLY_COMMENT',
    ORDER_RECEIVED_TYPE : 'ORDER_RECEIVED',
    ORDER_PLACED_TYPE : 'ORDER_PLACED',
    ORDER_SHIPPED_TYPE : 'ORDER_SHIPPED',
    ORDER_CANCELLED_TYPE : 'ORDER_CANCELLED',
    ORDER_DELIVERED_TYPE : 'ORDER_DELIVERED',
    ORDER_CANCEL_REQUESTED_TYPE : 'ORDER_CANCEL_REQUEST',
    ORDER_CANCEL_APPROVED_TYPE : 'ORDER_CANCEL_APPROVED',
    ORDER_RETURN_REQUESTED_TYPE : 'ORDER_RETURN_REQUESTED',
    ORDER_RETURN_APPROVED_TYPE : 'ORDER_RETURN_APPROVED',
    ORDER_PAYLATER_PAYMENT_ADDED : 'ORDER_PAYLATER_PAYMENT_ADDED'

}