/**
 * Created by INX on 11/7/17.
 */


import  Splash from 'src/components/splash/splashController';
import  Login from 'src/components/login/loginController';
import  Forgot from 'src/components/forgot/forgotController';
import  Signup from 'src/components/signup/signupController';

import  TabBarContainerController from 'src/components/TabBarContainer/TabBarContainerController';

import  Home from 'src/components/home/homeController';
import  Entertiment from 'src/components/entertiment/entertainmentController';
import  MapStore from 'src/components/marketPlace/store/mapstore/mapstoreController';
import  Settings from 'src/components/settings/settingsController';
import  Notification from 'src/components/notification/notificationController';
import  VideoDetails from 'src/components/VideoDetails/videoDetailController';
import  UserProfile from 'src/components/userprofile/UserProfileController';
import  ImagePicker from 'src/components/ImagePicker';
import Welcome from 'src/components/Welcome/WelcomeController'
import Cart from 'src/components/cart/CartList/CartListController'
import CartList from 'src/components/cart/CartController';
import MarketPlace from 'src/components/marketPlace/MarketController'
import Products from 'src/components/product/ProductListController'
import ProductFilter from 'src/components/product/filter/ProductFilterController'
import Forum from 'src/components/forum/ForumContainerController'
import MessageList from 'src/components/message/MessageListController'
import Channel from 'src/components/home/Channel/channelController'
import Episode from 'src/components/home/Channel/Episode/episodeController'
import Store from 'src/components/marketPlace/store/storeDetails/storeDetailsController'
import StoreMedia from 'src/components/marketPlace/store/storemedia/storemediaController'
import AllStore from 'src/components/marketPlace/store/allStore/allStoreController'
import StoreContainer from 'src/components/marketPlace/store/storeContainerController'
import {VideoPlayerController} from 'src/customComponents';
import B2CProductDetail from 'src/components/marketPlace/store/storeDetails/b2cProductDetail/B2CProductDetailConroller';
import ProductShop from  'src/components/marketPlace/store/storeDetails/product/ProductShopController'
import B2BProductDetail from 'src/components/marketPlace/store/storeDetails/b2bProductDetail/B2BProductDetailConroller'
import StateSelector from  'src/components/userprofile/StateSelector/StateSelectorController';
import AddressController from 'src/components/address/AddressController'
import CartSummaryController from  'src/components/cart/summary/CartSummaryController'
import ChangePasssword from 'src/components/changepassword/changepwdController';
import CartUmmaryController from  'src/components/cart/summary/CartSummaryController'
import AddressListController from 'src/components/AddressList/AddressListController'
import ChangeEmail from 'src/components/changeEmail/changeEmailController';
import orders from 'src/components/orders/OrderList/OrderController'
import OrderDetails from 'src/components/orders/OrderDetailsController';
import PaySafeController from 'src/components/payment/paySafe/PaySafeController';
import MySale from 'src/components/MySale/MySaleController';
import MedicalController from 'src/components/medicalInfo/MedicalController';
import BankAccountInfoController from 'src/components/BankAccountInfo/BankAccountInfoController';
import BankAndMedicalInfoController from 'src/components/BankAndMedicalInfo/BankAndMedicalInfoController';
import MySales from 'src/components/salesDetails/MySalesController'
import  GreenPay from 'src/components/payment/greenPay/GreenPayController'
import ForumDetails from 'src/components/forum/forumDetails/ForumDetailsController'
import MyFav from 'src/components/MyFavorite/MyFavController'
import FullScreenImage from 'src/customComponents/FullViewImageController'
import CreditList from 'src/components/credits/CreditListController'
import MessageDetail from 'src/components/message/messageDetail/MessageDetailController'
import RequestWithdrawalController from 'src/components/requestWithdrawal/requestWithdrawalController';
import ReferAndEarnController from 'src/components/shareAndEarn/ReferAndEarnController'
import RewardPointsController from 'src/components/rewardPoints/RewardPointsController'
import GlobalSearchController from 'src/components/globalSearch/GlobalSearchController'
import FilterController from 'src/components/marketPlace/filter/FilterController'
import StoreMapController from 'src/components/storemap/StoreMapController'
export const Navigation = {
    SPLASH: "SPLASH",
    LOGIN: "LOGIN",
    FORGOT: "FORGOT",
    SIGNUP: "SIGNUP",
    LANDING: "LANDING",
    HOME: "HOME",
    ENTERTIMENT: "ENTERTIMENT",
    MAPSTORE: "MAPSTORE",
    SETTINGS: "SETTINGS",
    NOTIFICATION: "NOTIFICATION",
    VIDEO_DETAIL: "VIDEO_DETAIL",



};

export const Screen = {

    SPLASH: Splash,
    LOGIN: Login,
    FORGOT: Forgot,
    LANDING: TabBarContainerController,
    HOME: Home,
    ENTERTIMENT: Entertiment,
    SIGNUP: Signup,
    MAPSTORE: MapStore,



}
export const HEADER_TITLE = {
    ADDRESS: 'My Address',
    MY_ORDER: 'My Order',
    ADDRESS_LIST: 'Address List',
    CART_SUMMARY: 'Cart Summary',
    EPISODES: 'Episodes',
    CHANNEL: 'Channels',
    ALL_STORES: 'All Stores',
    STORE_LINKS: 'StoreLinks',
    DEALS: 'Deals',
    STORES_CONTAINER: 'Stores',
    MY_PROFILE: 'My Profile',
    VIDEO_DETAIL: 'Video Details',
    VIDEO_PLAYER: 'Video Player',
    PRODUCT_DETAIL: 'Product Detail',
    HOME: 'Home',
    FORUM: 'Forum',


}
export const RightNavigationButtonType = {
    MENU: 'MENU',
    SEARCH: 'SEARCH',
    CART: 'CART',
}
