import Utilities from '../../utilities/Utilities';
import ViewAllButton from 'src/customComponents/ViewAllButton';
('strict');
/**
 * Created by INX on 11/7/17.
 */

import React, { Component } from 'react';

import {
  View,
  Text,
  Image,
  TextInput,
  TouchableOpacity,
  FlatList,
  ImageBackground,
  Dimensions,
  ScrollView,
  TouchableHighlight,
    Platform
} from 'react-native';

import styles from './homeStyle';
import SectionHeaderGrid from '../SectionHeaderGrid/sectionHeaderGrid';
import { ImageAsset, renderIf } from 'src/utilities';
import Carousel, { Pagination } from 'react-native-snap-carousel';
import { Screen } from 'src/utilities/Screen';
import  AlertDialog from 'src/customComponents/CustomAlert'
import TabNavigator from 'react-native-tab-navigator';

import { TabBar, TabBarItem, CustomHeader,Indicator } from 'src/customComponents';
import SettingsController from '../settings/settingsController';
import Thumbnail from 'react-native-thumbnail-video';
// import TouchableItem from "../../../node_modules/react-navigation/lib-rn/views/TouchableItem";
import Dash from 'react-native-dash';
// import TouchableItem from "../../../node_modules/react-navigation/lib-rn/views/TouchableItem";
import TabBarController
  from 'src/components/TabBarContainer/TabBarContainerController';
export default class HomeView extends Component {
  constructor(props) {
    super(props);
    this.state = {
      index: 0,
      episodes: [],
      storesLinks: [],
      popularChannel: [],
      deals: [],
      browseCategory: [],
      isCategorySelected: false,
      categoryStyle: styles.categoryIcon,
      // categoryCurrentIndex : null,
      categoryPreviousIndex: -1,
      activeSlide: 0,
      categorySelectedStyle: styles.categorySelectedIcon,
      selectedIndex: -1,
        status : true
    };
  }
  dec = true;

  //noinspection JSAnnotator
    greenIndicatorWithHeader(title: string) {
    return (
      <View style={styles.headerTitleView}>
        <View style={styles.greenHeaderIndicator} />
        <Text style={styles.sectionTitleText}>{title}</Text>
        {/* <Dash style={styles.viewDashLine} dashColor="gray" dashLength={2} /> */}
      </View>
    );
  }
  checkIsEmpty() {
    return (
      <View
        style={{
          flex: 1,
          justifyContent: 'center',
          alignItems: 'center',
          width: Dimensions.get('window').width,
        }}>
        <Text style={{ textAlign: 'center' }}>No results</Text>
      </View>
    );
  }
  //noinspection JSAnnotator
    displayFlatListView(id: number, item: {}) {
    if (id === 0) {
      return (
        <TouchableOpacity
          style={styles.subItemView}
          onPress={this.props.didSelectedListAction.bind(this, item, id)}>
          <Image
            source={{ uri: item.thumbnail_url }}
            style={styles.imageList}
          />
        </TouchableOpacity>
      );
    } else if (id === 1) {
      return (
        <TouchableOpacity
          style={styles.subItemView}
          onPress={this.props.didSelectedListAction.bind(this, item, id)}>
          <Image
            source={{ uri: item.thumbnail_url }}
            style={styles.imageList}
          />
          {renderIf(
            item.type === 'link',
            <View
              style={{
                flex: 1,
                position: 'absolute',
                top: 5,
                bottom: 0,
                right: 5,
                elevation: 2,
              }}>
              <Image
                style={{ width: 35, height: 35 }}
                source={ImageAsset.ICN_LINK}
              />
            </View>
          )}
        </TouchableOpacity>
      );
    }
  }
  renderOffer(color, discount, item) {
    return (
      <View style={[styles.offerTextView, { backgroundColor: color }]}>
        <View style={styles.discountView}>
          <Text style={styles.textOffer}>{discount[0] + '%'}</Text>
          <Text style={styles.offerSubText}>Offer</Text>
        </View>
        <Text numberOfLines={1} style={styles.textOfferName}>
          {item.product_name}
        </Text>
        <View style={styles.offerLineView} />
      </View>
    );
  }
  onPressBrowseByCategory() {
    if (this.state.isCategorySelected === false) {
      this.setState({
        isCategorySelected: true,
        categoryStyle: styles.categorySelectedIcon,
      });
    } else {
      this.setState({
        isCategorySelected: false,
        categoryStyle: styles.categoryIcon,
      });
    }
  }
  renderFeatureVideoView() {}
  renderHeaderViewAll(item, index) {
    if (index === 0) {
      return (
        // <TouchableOpacity
        //   style={styles.buttonViewAll}
        //   onPress={this.props.onPressViewAll.bind(this, index)}>
        //   <Text style={styles.textViewAll}>View all</Text>
        // </TouchableOpacity>
        <ViewAllButton onPress={this.props.onPressViewAll.bind(this, index)}/>
      );
    } else if (index === 1) {
      return (
        // <TouchableOpacity
        //   style={styles.buttonViewAll}
        //   onPress={this.props.onPressViewAll.bind(this, index)}>
        //   <Text style={styles.textViewAll}>View all</Text>
        // </TouchableOpacity>
        <ViewAllButton onPress={this.props.onPressViewAll.bind(this, index)}/>
      );
    } else {
      return (
        // <TouchableOpacity
        //   style={styles.buttonViewAll}
        //   onPress={this.props.onPressViewAll.bind(this, index)}>
        //   <Text style={styles.textViewAll}>View all</Text>
        // </TouchableOpacity>
        <ViewAllButton onPress={this.props.onPressViewAll.bind(this,index)}/>
      );
    }
  }
  renderOfferView(item, index) {
    let color;
    if (index % 3 === 0) {
      color = 'rgba(88, 218, 224, 0.70)';
    } else if (index % 3 === 1) {
      color = 'rgba(162, 128, 211, 0.70)';
    } else if (index % 3 === 2) {
      color = 'rgba(194, 211, 128, 0.70)';
    }
    let discountPercentage = item.discount_percentage;
    let discount = ''
      console.log('-------',discountPercentage)
    if(discountPercentage > 0 ){
        discount = item.discount_percentage.split('.');
    }else {
        discount = '0'
    }



    return (
      <TouchableOpacity
        style={styles.offerView}
        onPress={this.props.didSelectedListAction.bind(this, item, 2)}>
        <Image
          source={{ uri: item.banner_url }}
          style={styles.offerImageView}
        />
        {this.renderOffer(color, discount, item)}
      </TouchableOpacity>
    );
  }

  renderVideoView(item, index) {
    let color;
    this.dec ? (this.dec = false) : (this.dec = true);
    if (index % 2 == 0) {
      color = '#96c43ea8';
    } else {
      color = '#90e0f9a8';
    }

    return (
      <View style={{ flex: 1, backgroundColor: color }}>
        <ImageBackground
          style={styles.backgroundImage}
          source={{ uri: item.thumbnail_url }}>
          <View style={{ flex: 1, backgroundColor: color }}>
            <Text style={styles.videoViewHeading}>
              {item.heading}
            </Text>
          </View>
        </ImageBackground>
        <View style={styles.playButton}>
          <Image
            style={styles.playIcon}
            source={ImageAsset.EPISOD_PLAY_BUTTON}
          />

        </View>

      </View>
    );
  }
  render() {
    let itemList = [
      { title: 'Popular Channels', items: this.state.popularChannel },
      { title: 'Stores & Links', items: this.state.storesLinks },
    ];
    // {'title':'Deals', 'items' : this.state.deals}
    // let featured = [{key: ImageAsset.GM_SHOP},{key:ImageAsset.GM_SHOP},{key:ImageAsset.GM_SHOP}];
    let featured = [{ key: '1' }, { key: '3' }, { key: 'df' }];
    return (
      <View style={{ flex: 1, backgroundColor: 'white' }}>
        <CustomHeader isHomeTab={true} {...this.props}
                      globalSearchAction = {this.props.globalSearchAction.bind(this)}
                      menuAction = {this.props.menuAction.bind(this)}

        />
        <View style={styles.browseCategoryView}>
          <Text style={{ textAlign: 'center', marginTop: 20 }}>
            BROWSE BY CATEGORIES
          </Text>
          <View style={styles.lineUnderCategoryText} />
          <View style={{ flex: 1, marginBottom: 10 }}>
            <FlatList
              data={this.state.browseCategory}
              extraData={this.state}
              renderItem={({ item, index }) => (
                <TouchableOpacity
                  style={styles.categoryListView}
                  onPress={this.props.onPressCategory.bind(
                    this,
                    parseInt(index),
                    item.category_name
                  )}>

                  <Image
                    source={{ uri: item.icon_image_url }}
                    style={
                      this.state.selectedIndex === index
                        ? this.state.categorySelectedStyle
                        : this.state.categoryStyle
                    }
                  />
                  <Text style={styles.categoryName}
                  numberOfLines={1}>
                      {item.category_name}</Text>
                </TouchableOpacity>
              )}
              horizontal={true}
              showsHorizontalScrollIndicator={false}
              keyExtractor={(item, index) => index}
            />
          </View>
        </View>

        <ScrollView>
          <View style={styles.featuredView}>
            <View style={styles.renderSectionView}>
              {this.greenIndicatorWithHeader('Featured Videos')}
              <ViewAllButton onPress={this.props.onPressFeaturedViewAll.bind(this)}/>
            </View>
            <Carousel
              ref={c => {
                this._carousel = c;
              }}
              data={this.state.episodes}
              sliderWidth={Utilities.getSliderWidth()}
              itemWidth={Utilities.getItemWidth()+25}
              layout={'default'}
              keyExtractor={(item, index) => index}
              onSnapToItem={index => this.setState({ activeSlide: index })}
              renderItem={({ item, index }) => (
                <TouchableOpacity
                  accessibilityLabel={'videoView'}
                  style={styles.mainVideoContainer}
                  onPress={this.props.onPressFeaturedVideo.bind(this, item)}>
                  {this.renderVideoView(item, index)}
                </TouchableOpacity>
              )}
            />

          </View>
          <View style={styles.categoryContentView}>
            <FlatList
              data={itemList}
              renderItem={({ item, index }) => (
                <View style={styles.renderItemView}>
                  <View style={styles.renderSectionView}>
                    {this.greenIndicatorWithHeader(item.title)}
                    {this.renderHeaderViewAll(item, index)}
                  </View>
                  <View style={styles.subFlatView}>
                    <FlatList
                      data={itemList[index].items}
                      renderItem={({ item }) => (
                        <View>{this.displayFlatListView(index, item)}</View>
                      )}
                      horizontal={true}
                      ListEmptyComponent={this.checkIsEmpty()}
                      showsHorizontalScrollIndicator={false}
                      keyExtractor={(item, index) => index}
                    />
                  </View>

                </View>
              )}
              keyExtractor={(item, index) => index}
            />
            <View style={styles.renderSectionView}>
              {this.greenIndicatorWithHeader('Popular deals')}
              {/* <TouchableOpacity
                style={styles.buttonViewAll}
                onPress={this.props.onPressViewAll.bind(this, 2)}>
                <Text style={styles.textViewAll}>View all</Text>
              </TouchableOpacity> */}
              <ViewAllButton onPress={this.props.onPressViewAll.bind(this, 2)}/>
            </View>
            <View style={{ height: 140, margin: 5 }}>
              <FlatList
                  style={{marginLeft:10}}
                data={this.state.deals}
                renderItem={({ item, index }) => (
                  <View>{this.renderOfferView(item, index)}</View>
                )}
                horizontal={true}
                ListEmptyComponent={this.checkIsEmpty()}
                showsHorizontalScrollIndicator={false}
                keyExtractor={(item, index) => index}
              />
            </View>
          </View>

        </ScrollView>
          <Indicator ref={(o => {
              this.indicator = o
          })}/>
          <AlertDialog
              topMargin = {64}
              ref={(o => {
                  this.alertDialog = o;
              })}>
          </AlertDialog>
      </View>
    );
  }

  //noinspection JSAnnotator
    _featureViewOnScroll(event: Object) {
    console.log('---');
    console.log(event.nativeEvent.contentOffset.x);
  }
}
