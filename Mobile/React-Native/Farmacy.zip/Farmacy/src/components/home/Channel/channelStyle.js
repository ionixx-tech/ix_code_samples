/**
 * Created by INX on 12/29/17.
 */

import { StyleSheet } from 'react-native';

export default StyleSheet.create({

  //channel cell container
  cellContainer : {
        flex:1,
        height: 170,
        margin:10,
        marginBottom:0,
  },
    imageContainer:{
        flex:1,
        backgroundColor :'white',
        borderRadius : 10,
        shadowOffset:{  width: 0,  height: 3,  },
        shadowColor: 'gray',
        shadowOpacity:1,
        shadowRadius : 3,
        elevation:5
    },
    image:{
        borderRadius : 10,
        resizeMode: 'stretch',
        position: 'absolute',
        top:0,right:0,bottom:0,left:0,
        width:'100%',
        height:'100%',
        /* width: '100%',
         height: '100%',*/
    }


})