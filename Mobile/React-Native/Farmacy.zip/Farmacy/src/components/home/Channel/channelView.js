/**
 * Created by INX on 12/29/17.
 */

import React, { PureComponent } from 'react';

import { FlatList,View,Text,Image,TouchableOpacity } from 'react-native';

import styles  from './channelStyle';
import  mainStyles from 'src/style';
import  AlertDialog from 'src/customComponents/CustomAlert'
import { Indicator, PaginationFlatList } from 'src/customComponents';
import { ChannelModel } from  'src/model'

export default class ChannelView extends PureComponent{

    /*
     Params : items for loading data to list view
     return : none
     Description :
     */
    state = {
        items:[]
    }
    constructor(props){
        super(props);
    }
    /*
     Params : ChannelModel
     return : none
     Description : render Flat list cell items, list of channel
     */
    addChannel(newItems: [ChannelModel]){
        const old = this.state.items;
        this.setState({items:old.concat(newItems)});
    }
    /*
     Params :
     return : none
     Description : render Flat list cell items, list of channel
     */
    renderChannelCellItems({item,index}) {
        return(

            <TouchableOpacity  accessibilityLabel={'button'} style={styles.cellContainer} onPress={this.props.didSelectedListAction.bind(this,item,index)}>
            <View  style={[styles.imageContainer]}>
                <Image style={[styles.image]} source={{uri:item.thumbnail_url}}/>
            </View>
        </TouchableOpacity>
        );
    }
    /*
     Override
     Params : none
     return : View
     Description : render Channelview and assign callback to props
    */
    render(){
        return(<View style={[mainStyles.container,{backgroundColor:'#e5e5e5'}]}>
            <PaginationFlatList accessibilityLabel={'flatList'}
                                keyExtractor={(item, index) => index}
                                count={this.state.items.length}
                                pagesize={10}
                data={this.state.items}
                renderItem={this.renderChannelCellItems.bind(this)}
                                paginationEvent={this.props.paginationEvent.bind(this)}
            />
            <Indicator ref={(o => { this.indicator = o})}/>
            <AlertDialog
                ref={(o => {
                    this.alertDialog = o;
                })}>
            </AlertDialog>
        </View>);
    }
}