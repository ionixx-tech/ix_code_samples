/**
 * Created by INX on 12/29/17.
 */

import { StyleSheet } from 'react-native';
import { FONT } from '../../../../utilities/FontConstant';

export default StyleSheet.create({
container:{
    flex:1,
    backgroundColor:"transparent"
},
    cellContainer : {
        height: 240,
        margin:10,
        borderRadius : 5,
        shadowOffset:{  width: 0,  height: 3,  },
        shadowColor: 'gray',
        shadowOpacity:1,
        shadowRadius : 5,
        elevation:2,
    },
    episodImage: {
        flex:1,
        borderRadius : 5,
        backgroundColor:"transparent"
    },

    channelInfoView:{
        bottom:0,
        position:'absolute',
        backgroundColor:"transparent",
        left:0,right:0,
        width:null,
        height:80,
    },
    lineImage:{
        position:'absolute',
        left:0,right:0,bottom:0,top:0,
        resizeMode:'stretch',
        width:null,
        height:null,
    },
    infoView:{
        width:null,
        marginTop:15,
        marginLeft:15,
        position:'absolute',
        backgroundColor:"transparent",
        left:0,right:0,bottom:0,top:0,
    },
    greenLine:{
      height:1,
      width:50,
        margin:5,
        marginLeft:0,
      backgroundColor:"green",

    },
    titleText:{
        color:'gray',
        marginRight:80,
        fontFamily:FONT.THEME_FONT_BOLD
    },

    playButton:{
        position:'absolute',
        justifyContent:"center",
        alignItems:"center",
        bottom:10,
        right:30,
        width:50,
        height:50,
        backgroundColor:"#ace600",
        borderWidth:3,
        borderColor:"white",
        borderRadius:25,
    }

})