/**
 * Created by INX on 12/29/17.
 */
/**
 * Created by INX on 12/29/17.
 */

import React, {PureComponent} from 'react';

import {FlatList, View, Text, Image, TouchableOpacity, NetInfo} from 'react-native';

import ChannelView from  './channelView';
import {ButtonBadege, NavigationHeader, LeftButton, RightButton} from 'src/customComponents';

import {
    NetworkManager, Utilities, HTTP_METHOD,
    API_PATH, Navigation, ImageAsset, RightNavigationButtonType, HEADER_TITLE
} from 'src/utilities';
import {ChannelModel, JSONModel} from 'src/model';


/*
 ChannelComponent : This class is used to display list of channel, for channal list ,
 used fot channel list api. when user tapped channel list navigate to Episode and
 */

export default class ChannelComponent extends PureComponent {

    //customized navigation , set right header navigation button (cart)
    static navigationOptions = ({navigation}) => {
        return {
            title: HEADER_TITLE.CHANNEL,
            headerLeft: <LeftButton navigation={navigation}/>,
            headerRight: <RightButton navigation={navigation}
                                      isGlobalSearch={true}/>



            // headerRight,
            //     header : (<NavigationHeader navigation={navigation}
            //                                 titletext = 'Channels'
            //                                 type={RightNavigationButtonType.CART}
            //                                 leftIcon = {ImageAsset.BACK_ARROW_WHITE}
            // />)
        };
    };

    constructor(props) {
        super(props);

    }

    /*
     Override
     Params :
     return : none
     Description : when component is mounting, after view is rendered. trigger channel list request (one time).
     */
    componentDidMount() {
        this.fetchChannelList(0);
    }

    /*
     Params : none
     return : none
     Description : to get all channel list from server, and updating channelview list
     */
    fetchChannelList(pagenumber) {
        let weakSelf = this;
        NetInfo.isConnected.fetch().then(isConnected => {
            if (isConnected) {
                weakSelf.view.indicator.show();
                let request = new NetworkManager();
                let channelCategory = this.props.navigation.state.params.categoryType;
                console.log('categoryname', channelCategory)
                const param = {'pageno': pagenumber, 'pagesize': 10};
                if (channelCategory !== '' || channelCategory !== undefined) {
                    param['category'] = channelCategory
                }

                request.sendAsyncRequest(API_PATH.GET_CHANNEL_LIST, HTTP_METHOD.GET, param).then((json) => {
                    console.log('Channels--->', json);
                    weakSelf.view.indicator.dismiss();
                    if (json.message === undefined) {
                        // Utilities.showLongToast(JSON.stringify(json));
                        const allitems = ChannelModel.mapping(json);
                        weakSelf.view.addChannel(allitems);
                        weakSelf.view.indicator.dismiss();

                    } else {
                        this.view.indicator.dismiss();
                        this.view.alertDialog.showAlert(json.message, true);
                    }


                }).catch((error) => {
                    console.log(error);
                    this.view.indicator.dismiss();
                    this.view.alertDialog.showAlert(error.message, true);
                });
            } else {
                console.log('not connected to internet')
                weakSelf.view.alertDialog.showAlert(ALERT_MESSAGES.CONNECTION_FAILURE_MSG, ALERT_MESSAGES.IS_ERROR)
            }
        })

    }

    /*
     Callback
     Params : object, Int
     return : none
     Description : When user tapped flat list index, direct to Episods controller
     */
    didSelectedList(item, idx) {
        this.props.navigation.navigate(Navigation.EPISODE, {'channel': item});
    }

    /*
     Callback
     Params : object, Int
     return : none
     Description : When user scrollinf list view ,after 10 items ,this method will be invoked
     */
    paginationEvent(page) {
        this.fetchChannelList(page);
        console.log(page);
    }

    /*
     Override
     Params : none
     return : ChannelView
     Description : render Channelview and assign callback to props
     */
    render() {
        return (<ChannelView ref={(o => {
            this.view = o;
        })}
                             didSelectedListAction={this.didSelectedList.bind(this)}
                             paginationEvent={this.paginationEvent.bind(this)}
        />)
    }
}