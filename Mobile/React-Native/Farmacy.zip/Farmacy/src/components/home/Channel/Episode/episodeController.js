/**
 * Created by INX on 12/29/17.
 */

import React, { PureComponent } from 'react';
import { FlatList,Button,View,Text,Image,TouchableOpacity,Alert ,NetInfo} from 'react-native';
import EpisodeView from  './episodeView';
import { NetworkManager,
    Utilities,
    HTTP_METHOD ,
    API_PATH,
    Screen,
    EVENT_NAME,
    Navigation,
    NavigationActions,
    ImageAsset,
    RightNavigationButtonType,
    HEADER_TITLE } from 'src/utilities';
import EventEmitter from "react-native-eventemitter";
import { EpisodeModel,JSONModel } from 'src/model';
import { ButtonBadege,RightButton,LeftButton } from 'src/customComponents';
/*
EpisodeComponent : This class is used to display list of Episode of selected channel,
 when user tapped Episode  navigate to Video Details
*/
export default class EpisodeComponent extends PureComponent{

    //customized navigation , set right header navigation button (cart)
    static navigationOptions = ({ navigation }) => {
        // static navigationOptions = {
        return{
            title : HEADER_TITLE.EPISODES,
            headerLeft: <LeftButton navigation={navigation}/>,
            headerRight : <RightButton navigation={navigation}
                                       isGlobalSearch={true}/>,
        }
    }

    constructor(props){
        super(props);
        EventEmitter.on(EVENT_NAME.UPDATE_LIKE, this.updateLikeEvent.bind(this))

    }
    /*
     Params : none
     return : none
     Description : life cycle methods
     */
    componentDidMount(){
        this.fetchEpisodeList(0,false);
    }
    updateLikeEvent(){
       // let weakSelf=this;
        console.log("emitted....")
        this.view.setState({items: []});
        this.fetchEpisodeList(0,true);
    }
    /*
     Params :
     return : none
     Description : to get all channel list from server
     */
    fetchEpisodeList(pagenumber,isEventEmitted){
        const weakSelf = this;
        NetInfo.isConnected.fetch().then(isConnected=> {
            if(isConnected){
                if(!isEventEmitted)
                    weakSelf.view.indicator.show();
                let channel = this.props.navigation.state.params.channel;
                let path = [API_PATH.SHOP_DETAILS, channel.shop_id, API_PATH.GET_EPISODE_LIST].pathComponent();
                let param = {'pageno':pagenumber, 'pagesize': 10};
                if(Utilities.isObjectEmpty(channel)) {
                    path =  API_PATH.GET_FEATURED_VIDEO_LIST;
                    param['featured'] = 'true';
                }
                const request =  new NetworkManager();
                request.sendAsyncRequest(path,HTTP_METHOD.GET,param).then((json)=>{

                    if(json.message===undefined)
                    {let modelList = EpisodeModel.mapping(json);
                        weakSelf.view.addEpisods(modelList);
                        weakSelf.view.indicator.dismiss();
                    }else {
                        weakSelf.view.indicator.dismiss();
                        this.view.alertDialog.showAlert(json.message, true);
                    }

                }).catch(  (error)=>{
                    console.log(error);
                    weakSelf.view.indicator.dismiss();
                    weakSelf.view.alertDialog.showAlert(error,true);
                });
            }else {
                weakSelf.view.alertDialog.showAlert(ALERT_MESSAGES.CONNECTION_FAILURE_MSG,ALERT_MESSAGES.IS_ERROR)
            }
        });
    }

    /*
    Callback
     Params : object, Int
     return : none
     Description : When user tapped flat list index, direct to Episods controller
     */
    didSelectedList(item,idx){
        // this.props.navigation.navigate(Navigation.EPISODE,{'channel':item});
        this.props.navigation.navigate(Navigation.VIDEO_DETAIL,{'episode':item});
    }
    //Paginatin Event
    paginationEvent(page){
        this.fetchEpisodeList(page);
    }
    /*
    Button Action
    Params : none
    return : none
    Description : When user tapped play button on episods
    */
    playButtonAction(item,idx){
         // this.props.navigation.goBack();
        this.props.navigation.navigate(Navigation.VIDEO_PLAYER, {'video_url' : item.video_url})
        // this.props.navigation.navigate(Navigation.VIDEO_DETAIL,{'episode':item});
    }

    /*
     Button Action
     Params : object, Int
     return : none
     Description : When user tapped favorite button
     */
    favoriteButtonAction(item,idx){
        // this.props.navigation.navigate(Navigation.EPISODE,{'channel':item});

    }
    /*
    Override
     Params : none
     return : EpisodeView
     Description : render EpisodeView and assign callback to props
     */
    render(){
        return(<EpisodeView ref={(o => { this.view = o; })}
            onPlayAction={this.playButtonAction.bind(this)}
                            favoriteAction={this.favoriteButtonAction.bind(this)}
                            paginationEvent={this.paginationEvent.bind(this)}
                            didSelectedListAction={this.didSelectedList.bind(this)}
        />)
    }
}