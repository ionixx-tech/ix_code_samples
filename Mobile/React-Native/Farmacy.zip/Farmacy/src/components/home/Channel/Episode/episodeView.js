/**
 * Created by INX on 12/29/17.
 */

import React, { PureComponent,Component } from 'react';
import  AlertDialog from 'src/customComponents/CustomAlert'
import { FlatList,View,Text,Image,TouchableOpacity } from 'react-native';
import { ImageAsset } from 'src/utilities'
import styles  from './episodeStyle';
import  mainStyles from 'src/style';
import { Indicator, PaginationFlatList } from 'src/customComponents';

export default class EpisodeView extends PureComponent{

    /*
     Params : items for loading data to list view
     return : none
     Description :
     */
    state = {
        items:[]
    }

    constructor(props){
        super(props);
    }
    /*
     Params : Product Model
     return : none
     Description : render Flat list cell items, list of channel
     */
    addEpisods(newItems: [any]){
        const old = this.state.items;
        this.setState({items:old.concat(newItems)});
    }
    /*
     Params :
     return : none
     Description : render Flat list cell items, list of Episods
     */
    renderChannelCellItems({item,index}) {
        let episode = index+1;
        if(episode<10)
            episode='0'+episode;
        return(<TouchableOpacity style={styles.cellContainer} accessibilityLabel={'button'} onPress={this.props.didSelectedListAction.bind(this,item,index)}>
            <View  style={styles.container}>
                <Image style={styles.episodImage} source={{uri:item.thumbnail_url}}/>
                <View style={styles.channelInfoView}>
                    <Image style={styles.lineImage} source={ImageAsset.EPISODE_BOTTOM}/>
                    <View style={styles.infoView}>
                        <Text style={styles.titleText} >{'Epi-'+ episode}</Text>
                        <View style={styles.greenLine}/>
                        <Text style={styles.titleText} numberOfLines={1} >{item.heading}</Text>
                        <TouchableOpacity style={styles.playButton} accessibilityLabel={'playbutton'} onPress={this.props.onPlayAction.bind(this,item,index)}>
                            <Image style={{width:30,height:30}}  source={ImageAsset.EPISOD_PLAY_BUTTON}/>
                        </TouchableOpacity>
                    </View>
                </View>

            </View>
        </TouchableOpacity>);
    }
    /*
    Override
    Params : none
    return : View
    Description : render Episodeview and assign callback to props
   */
    render(){
        console.log("items--->",this.state.items)
        return(<View style={[mainStyles.container,{backgroundColor:'#e5e5e5'}]}>
            <PaginationFlatList accessibilityLabel={'flatList'}
                                keyExtractor={(item, index) => index}
                                data={this.state.items}
                                count={this.state.items.length}
                                pagesize={10}
                                paginationEvent={this.props.paginationEvent.bind(this)}
                                renderItem={this.renderChannelCellItems.bind(this)}
            />
            <Indicator ref={(o => {
                this.indicator = o;
            })}/>
            <AlertDialog
                ref={(o => {
                    this.alertDialog = o;
                })}>
            </AlertDialog>
        </View>);
    }
}