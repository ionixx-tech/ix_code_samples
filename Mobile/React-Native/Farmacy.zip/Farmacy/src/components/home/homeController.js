'strict'
/**
 * Created by INX on 11/7/17.
 */

import React, {Component} from 'react';

import {
    Text,
    View,
    Button,
    Image,
    Alert,
    BackHandler,
    NetInfo
} from 'react-native';
import HomeView from './homeView';
import  styles from './homeStyle';
import {ImageAsset} from 'src/utilities/ImageAsset';
import {UserManager} from 'src/storage';
import {
    API_PATH,
    HTTP_METHOD,
    NetworkManager,
    Screen,
    Navigation,
    RightNavigationButtonType,
    Utilities,
    EVENT_NAME,
    HEADER_TITLE,
    ALERT_MESSAGES
} from 'src/utilities';
import {HeaderTitle} from 'src/customComponents/'

import EventEmitter from "react-native-eventemitter";
import TabBarController from 'src/components/TabBarContainer/TabBarContainerController'
let backPressCount = 0;
var isRoute = true;
export const VIEW_ALL_TYPE = {
    STORE_LINK: 'stores_link',
    DEALS: 'Deals',
    RELEAD_PRODUCTS: 'Related Products',
    POPULAR_DEALS_SHOP: 'Popular Deals',
    FEATURED_PRODUCTS: 'Featured Products',

};

export default  class HomeController extends Component {


    //This is only needed if you want to set the title from another screen

    constructor(props) {
        super(props);
        this.selectedCategory = '';
        this.isFetch = false;
        EventEmitter.on(EVENT_NAME.AUTHENTICATION_EXPIRE, this.authendicatoinAction.bind(this))
        EventEmitter.on(EVENT_NAME.UPDATE_LIKE, this.handleLike.bind(this))
        EventEmitter.on(EVENT_NAME.REFRESH_HOME, this.refreshHome.bind(this))
    }

    authendicatoinAction() {
        if (this.isFetch === false) {
            let weakSelf = this;
            UserManager.getInstance().logout(function () {
                EventEmitter.emit('CLEAR_DATAS', '');

                weakSelf.props.navigation.navigate(Navigation.LOGIN, {
                    'from_welcome': true,
                    'is_home': true, 'is_unauthorized': true
                });

                this.isFetch = true;

            })
        }
    }

/*
    Life cycle methods
 */
    componentWillMount() {
        this.isRoute = false;
        BackHandler.addEventListener(EVENT_NAME.HARDWARE_BACKPRESS, this.backPressed);
    }
    componentWillUnmount() {
        this.isRoute = false;
        NetInfo.isConnected.removeEventListener('change', this.handleConnectionChange);
        EventEmitter.removeAllListeners(EVENT_NAME.AUTHENTICATION_EXPIRE);
        EventEmitter.removeAllListeners(EVENT_NAME.UPDATE_LIKE);
        EventEmitter.removeAllListeners(EVENT_NAME.REFRESH_HOME);
        BackHandler.removeEventListener(EVENT_NAME.HARDWARE_BACKPRESS, this.backPressed);
    }
    componentDidMount() {
        NetInfo.isConnected.addEventListener('change', this.handleConnectionChange);
        this.getHomeList(false, '');
        this.getCategoryList();

    }

    handleConnectionChange = (isConnected) => {
        this.homeView.setState({ status: isConnected });

    }

    backPressed = () => {




    }
    /*
     Params : none
     return : none
     Description : Refresh home screen
     */
    refreshHome(){
        if(this.homeView.state.status){
             // if (this.selectedCategory !== '') {
            this.selectedCategory = ''
            this.homeView.setState({categoryPreviousIndex: -1, selectedIndex: -1});
            this.getHomeList(false, '', false);
            this.getCategoryList()
            // }
         }else {
            this.homeView.alertDialog.showAlert(ALERT_MESSAGES.CONNECTION_FAILURE_MSG,ALERT_MESSAGES.IS_ERROR)
        }

    }



    handleLike() {
        this.getHomeList(false, '');
    }
    /*
     Params : none
     return : none
     Description : to get all browse by category list from server, and updating homeview list
     */
    getCategoryList() {
        // NetInfo.isConnected.fetch().then(isConnected => {
            if (this.homeView.state.status) {
                let request = new NetworkManager();
                request.sendAsyncRequest(API_PATH.BROWSE_CATEGORY, HTTP_METHOD.GET, {}).then((json) => {

                    if (json.message === undefined) {
                        this.homeView.setState({browseCategory: json})
                    } else {
                        this.homeView.alertDialog.showAlert(json.message, true);
                    }

                }).catch((error) => {
                    this.homeView.alertDialog.showAlert(error.message, true);
                })
            } else {
                weakSelf.homeView.alertDialog.showAlert(ALERT_MESSAGES.CONNECTION_FAILURE_MSG,ALERT_MESSAGES.IS_ERROR)
            }
        // });

    }
    /*
     Params : none
     return : none
     Description : to get all home list from server, and updating homeview list
     */
    getHomeList(isSearch: boolean, categoryName: string) {
        let weakSelf = this;
        // NetInfo.isConnected.fetch().then(isConnected => {
            if (this.homeView.state.status) {
                const url = API_PATH.HOME;
                let request = new NetworkManager();
                let param = {}
                weakSelf.homeView.indicator.show()
                isSearch ? param['category'] = categoryName : {}
                // isSearch ?  url = API_PATH.HOME + API_PATH.CATEGORY_SEARCH + categoryName : url = API_PATH.HOME
                request.sendAsyncRequest(url, HTTP_METHOD.GET, param).then((json) => {
                    console.log('home---->', json)
                    weakSelf.homeView.indicator.dismiss();
                    if (json.message === undefined) {
                        weakSelf.homeView.indicator.dismiss();
                        setTimeout(() => {

                            weakSelf.homeView.setState({
                                episodes: json.episodes, storesLinks: json.links,
                                popularChannel: json.channels, deals: json.deals
                            });
                        }, 1000)

                    } else {
                        console.log('error3')
                        weakSelf.homeView.indicator.dismiss();
                        weakSelf.homeView.alertDialog.showAlert(json.message, true);
                    }


                }).catch((error) => {
                    console.log('error1')
                    this.homeView.indicator.dismiss();
                    this.homeView.alertDialog.showAlert(error, true);
                })
            } else {
                console.log('error2')
                // this.homeView.indicator.dismiss();
                this.homeView.alertDialog.showAlert(ALERT_MESSAGES.CONNECTION_FAILURE_MSG, ALERT_MESSAGES.IS_ERROR)


            }
        // })
    }
    /*
     Params : list index and category name
     return : none
     Description : this will used to filter the home screen list based on category type
     */
    onPressBrowseCategory(index: number, categoryName: string) {
        console.log("index=====>", this.homeView.state.categoryStyle)

        // NetInfo.isConnected.fetch().then(isConnected => {
            console.log('click browse by cat===>', this.homeView.state.status)
            if (this.homeView.state.status) {
                if (index === this.homeView.state.categoryPreviousIndex) {
                    this.selectedCategory = '';
                    console.log('clear category--->', this.selectedCategory)
                    this.homeView.setState({categoryPreviousIndex: -1, selectedIndex: -1});
                    this.getHomeList(false, '');

                } else {
                    this.selectedCategory = categoryName;
                    console.log('updated category name--->', this.selectedCategory)
                    this.homeView.setState({categoryPreviousIndex: index, selectedIndex: index});
                    this.getHomeList(true, categoryName);

                }

            } else {
                console.log('not connected')
                this.homeView.alertDialog.showAlert(ALERT_MESSAGES.CONNECTION_FAILURE_MSG, ALERT_MESSAGES.IS_ERROR)
            }
        // });

    }
    /*
     Params : list index
     return : none
     Description : to show complete items belongs to that category
     */
    onPressViewAllAction(index: number) {

        NetInfo.isConnected.fetch().then(isConnected => {
            if (isConnected) {

                switch (index) {
                    case 0 :
                        this.props.navigation.navigate(Navigation.CHANNEL, {'categoryType': this.selectedCategory});
                        break;
                    case 1 :
                        let params = {'type': VIEW_ALL_TYPE.STORE_LINK, 'categoryType': this.selectedCategory}
                        this.props.navigation.navigate(Navigation.ALL_STORE, {
                            'storeName': params,
                            title: HEADER_TITLE.STORE_LINKS
                        });
                        break;
                    case 2 :
                        let param = {'type': VIEW_ALL_TYPE.DEALS, 'categoryType': ''}
                        this.props.navigation.navigate(Navigation.ALL_STORE, {
                            'storeName': param,
                            title: HEADER_TITLE.DEALS
                        });
                        break;
                    default :
                        break;
                }

            } else {
                this.homeView.alertDialog.showAlert(ALERT_MESSAGES.CONNECTION_FAILURE_MSG, ALERT_MESSAGES.IS_ERROR)
            }
        });


    }
    /*
     Params : videoid
     return : none
     Description : used to play selected video
     */
    onPressFeaturedVideoAction(item) {

        NetInfo.isConnected.fetch().then(isConnected => {
            if (isConnected) {
                if (item.episode_type === 'episode link') {
                    this.props.navigation.navigate(Navigation.VIDEO_DETAIL, {'episode': item});
                } else {
                    this.props.navigation.navigate(Navigation.VIDEO_PLAYER, {'video_url': item.video_url})
                }
            } else {
                this.homeView.alertDialog.showAlert(ALERT_MESSAGES.CONNECTION_FAILURE_MSG, ALERT_MESSAGES.IS_ERROR)
            }
        });


    }

    /*
     Params : item, index
     return : none
     Description : to navigate respective screen with help of the index.
     */
    didSelectedList(item, idx) {
        NetInfo.isConnected.fetch().then(isConnected => {
            if (isConnected) {

                if (idx === 0) {
                    this.props.navigation.navigate(Navigation.EPISODE, {'channel': item});
                } else if (idx === 1) {
                    if (item.type === 'shop') {
                        this.props.navigation.navigate(Navigation.STORE_CONTAINER, {'store': item});
                    } else {
                        this.props.navigation.navigate(Navigation.VIDEO_PLAYER, {'video_url': item.target_url});
                    }
                } else {
                    if (item.shop_type === 'B2C') {
                        this.props.navigation.navigate(Navigation.B2C_PRODUCT_DETAIL, {'productId': item.product_id})
                    } else {
                        this.props.navigation.navigate(Navigation.B2B_PRODUCT_DETAIL, {'productId': item.product_id})
                    }
                }

            } else {
                this.homeView.alertDialog.showAlert(ALERT_MESSAGES.CONNECTION_FAILURE_MSG, ALERT_MESSAGES.IS_ERROR)
            }
        });

    }
    /*
     Params : none
     return : none
     Description : to show complete featured videos
     */
    onPressFeaturedVideoViewAll() {

        NetInfo.isConnected.fetch().then(isConnected => {
            if (isConnected) {
                this.props.navigation.navigate(Navigation.EPISODE, {'channel': {}});
            } else {
                this.homeView.alertDialog.showAlert(ALERT_MESSAGES.CONNECTION_FAILURE_MSG, ALERT_MESSAGES.IS_ERROR)
            }
        });


    }
    /*
     Params : none
     return : none
     Description : Navigating to global search screen
     */
    globalSearchAction() {
        NetInfo.isConnected.fetch().then(isConnected => {
            if (isConnected) {
                this.props.navigation.navigate(Navigation.GLOBAL_SEARCH)
            } else {
                this.homeView.alertDialog.showAlert(ALERT_MESSAGES.CONNECTION_FAILURE_MSG, ALERT_MESSAGES.IS_ERROR)
            }
        });


    }

    render() {

        return (

            <HomeView

                ref={(view => {
                    this.homeView = view
                })}
                onPressCategory={this.onPressBrowseCategory.bind(this)}
                channelAction={this.channelListButtonAction.bind(this)}
                onSearchAction={this.onSearchAction.bind(this)}
                onPressViewAll={this.onPressViewAllAction.bind(this)}
                onPressFeaturedVideo={this.onPressFeaturedVideoAction.bind(this)}
                didSelectedListAction={this.didSelectedList.bind(this)}
                onPressFeaturedViewAll={this.onPressFeaturedVideoViewAll.bind(this)}
                globalSearchAction={this.globalSearchAction.bind(this)}
                menuAction={this.props.menuAction.bind(this)}
            />
        )

    }
    /*
     Params : list index
     return : none
     Description : to search and navigating
     */
    onSearchAction() {
        this.props.navigation.navigate(Navigation.PRODUCT_DETAIL, {title: " "});

    }
}


{/*
 <SideMenu menu={menu}>
 </SideMenu>);*/
}
