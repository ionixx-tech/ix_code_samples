/**
 * Created by INX on 11/7/17.
 */


import {StyleSheet, Dimensions} from  'react-native';
import {COLOR} from 'src/utilities/ColorConstant';
import Utilities from 'src/utilities/Utilities'
import { FONT } from '../../utilities/FontConstant';
let {width, height } = Dimensions.get('window')
export default StyleSheet.create({

    containerView:{
        flex:1.0,
        // backgroundColor:"orange"
    },
    loginContainer:{
        position: 'absolute', top: 0, left: 0, right: 0, bottom: 0,
        justifyContent: 'center', alignItems: 'center'
    },
    centerView:{
        flexDirection:"column",
        backgroundColor:"white",
        width:280,
        height:280,
        borderRadius:6
    },

    labelInput: {
        color: '#673AB7',
    },
    formInput: {
        borderBottomWidth: 1.5,
        height: 40,
        margin:5,
        color:"black",
        borderColor: '#333',
    },
    forgotButton:{
        top:5,
        height:40,
        margin:5,
        alignSelf:"center"
    },
    tabIcon : {
        width:26,
        height : 26,
    },
    topLogoView : {
        flex: 0.3,
    },
    categoryContentView : {
        // flex: 0.55,
        backgroundColor : 'white',
        marginTop : 5,
    },
    logoViewBackground : {
        flex: 0.3,
        resizeMode : 'stretch'
    },
    renderItemView : {
        // justifyContent : 'center',
        marginTop : 10,
        height : 170,
    },
    renderSectionView : {
        height : 35,
        flexDirection : 'row',
        justifyContent: 'space-between',
        alignItems : 'center',
        backgroundColor : 'white',

        // flexDirection : 'space-between'
    },
    sectionTitleText : {
        // flex : 1,
        marginLeft:20,
        fontFamily:FONT.THEME_FONT_BOLD,
        flex : 1,
        // backgroundColor : 'red'
    },
    subFlatView : {
        height : 140,
        padding : 5,
         marginLeft : 10,
        // margin : 10,

        // justifyContent : 'flex-start'
    },
    viewHeaderLine : {
        flex: 1,
        marginLeft : 10,
        marginRight : 0,
        justifyContent : 'center'

    },
    buttonViewAll : {
        width : 60,
        height : 20,
        borderRadius : 10,
        // flexDirection : 'row',
        alignItems : 'center',
        justifyContent : 'center',
        backgroundColor : '#9b9b9b',
        marginRight : 20

    },
    textViewAll : {
        color : 'white',
        backgroundColor : 'transparent',
        fontSize : 10,
        fontFamily:FONT.THEME_FONT_BOLD,

    },
    rightArrow : {
        tintColor : 'gray',
        width : 10,
        height : 10,

    },

    subItemView : {
        width : (width/3)+10,
        marginHorizontal : 10,
        borderRadius : 5,
        backgroundColor :'white',
        shadowOffset:{  width: 0,  height: 3,  },
        shadowColor: 'gray',
        shadowOpacity:1,
        shadowRadius : 5,
        elevation:2
    },
    imageList : {
        resizeMode: 'cover',
        // marginRight : 20,
        borderRadius : 5,
        width : (width/3)+10,
        height : 120,
        // flex :1 ,
        // position:'absolute',
        // top:0,
        // bottom : 0,
        // left : 0,
        // right : 0
    },
    offerImageView : {
        resizeMode: 'stretch',
        // marginRight : 20,

        borderRadius : 5,
        width : (width/2.90)+20,
        height : 100,
    },
    headerView : {
        // height : 150,
        flex : 0.17,
        justifyContent : 'space-between',
        alignItems : 'center',
        flexDirection : 'row',
        backgroundColor : 'white'

    },
    logoImage : {
        resizeMode : 'center'
    },
    headerIconView : {
        justifyContent:'center',
        alignItems : 'center',
        width : 50,
        height : 50,
    },
    headerIconImg : {
        width : 25,
        height : 25,
    },

    featuredView : {
        height : 200,
        backgroundColor : 'white',
        // flexDirection : 'row',
        // justifyContent : 'flex-start'
    },
    featuredListContainter : {
        // flex : 1,
        // flexDirection : 'column',
        // backgroundColor : 'gray',
        // marginLeft : 10,
        // marginRight : 10,
        // borderRadius : 10,
        // justifyContent : 'flex-end',
        // alignItems : 'flex-end',
        // elevation:5,

        // marginRight : 10,
        // marginTop : 40,
        // marginBottom : 20,
        // height : 150,
        alignSelf:'center',
        width : Dimensions.get('window').width - 50
    },
    videoThumbnail : {
        marginLeft : 10,
        marginRight : 10,
        borderRadius : 10,
        height : 150,
        width : Dimensions.get('window').width - 50
    },
    featureVideoView : {
        flex: 1,
        resizeMode : 'stretch',
        borderRadius : 10,
        width : Dimensions.get('window').width - 20
    },
    browseCategoryView: {
        flex : 0.30,
        backgroundColor : 'white',
        flexDirection : 'column',
        // justifyContent : 'center',
        // alignItems : 'center',
        // backgroundColor : 'red',

    },
    subItemContent : {
        height : 150,
        width : 110,
        flexDirection : 'column',
        backgroundColor : 'white',
    },
    popularChannelText : {
        marginLeft : 10,
        marginTop : 5,
        fontSize: 11,
    },
    textOffer : {
        // position : 'absolute',
        backgroundColor : 'transparent',
        color : 'white',
        fontSize : 32,
        fontFamily:FONT.THEME_FONT_BOLD,
        marginLeft : 20,
        fontWeight : 'bold'
    },
    textOfferName : {
        // position : 'absolute',
        // textAlign : 'center',
        backgroundColor : 'transparent',
        color : 'white',
        fontSize : 14,
        fontFamily:FONT.THEME_FONT_BOLD,
        marginLeft : 20,

        // marginTop : 40
    },
    offerView : {
        width : (width/2.90)+20,
        height : 100,
        // borderRadius : 5,

        marginHorizontal: 10,
        //
        // shadowOffset:{  width: 0,  height: 3,  },
        // shadowColor: 'gray',
        // shadowOpacity:1,
        // shadowRadius : 5,
    },

    offerLineView : {
        marginLeft : 20,
        marginTop : 5,
        backgroundColor : 'white',
        height : 2,
        width : 60,
    },
    offerTextView : {
        width : (width/2.90)+20,
        height : 100,
        position : 'absolute',
        justifyContent : 'center',
        alignItems : 'flex-start'
    },
    navView : {
        width: '100%',
        position : 'absolute',
        // position:'absolute',
        top:0,
        bottom : 0,
        left : 0,
        right : 0,
         // flex : 1,
        resizeMode : 'stretch',

    },
    lineUnderCategoryText : {
        height: 2,
        width : 100,
        backgroundColor : COLOR.THEME_COLOR,
        marginTop:10,
        opacity : 0.4,
        alignSelf:'center',
    },
    categoryListView : {
        flex:1,
        width : (width/4.8),
        backgroundColor : 'white',
        justifyContent : 'center',
        alignItems : 'center',
        marginHorizontal:2,
        flexDirection : 'column',

    },
    categoryListViewSelected : {
        width : 90,
        height : 60,
        backgroundColor : 'black',
        justifyContent : 'center',
        alignItems : 'center',
        flexDirection : 'column'
    },
    categoryName : {
        fontSize : 10,
        marginVertical : 5,
        marginHorizontal:5,

        // marginBottom:5,
    },
    categorySelctedName : {
        color : 'yellow',
        fontSize : 10,
    },
    categoryIcon : {
        width : 25,
        height : 25,
        marginTop:10,
        tintColor : 'gray'
    },
    categorySelectedIcon :{
        width : 25,
        height : 25,
        tintColor:COLOR.THEME_COLOR,
        marginTop:10
        // backgroundColor : 'red'
    },
    videoPlayIcon : {
        width : 10,
        height : 10,
    },
    viewDashLine : {
        marginLeft : 20,
        flex :1,
        opacity : 0.5
        // height : 0.5,
    },
    headerTitleView : {
        flex:1,
        flexDirection : 'row',
        alignItems : 'center',
        justifyContent : 'space-between'
    },
    greenHeaderIndicator : {
        // alignItems : 'center',
        height : 20,
        width : 3,
        backgroundColor : COLOR.THEME_COLOR,
    },
    discountView : {
        flexDirection: 'row',
        alignItems : 'flex-end',
        backgroundColor : 'transparent'
    },
    offerSubText : {
        color:'white',
        marginLeft: 5,
        marginBottom: 5
    },
    buttonVideo : {
        marginRight : 10,
        marginBottom : 12,
        width : 25,
        height : 25,
        backgroundColor :'lightgray',
        borderRadius : 12.5,
        alignItems : 'center',
        justifyContent : 'center',
        elevation:2
    },
    scrollContainer : {
        flex : 0.78,
        marginTop : 40,
        backgroundColor : 'blue'

    },mainVideoContainer: {
        flex:1,
        height: 170,
        width : Utilities.getItemWidth()+25,
        shadowOffset: {width: 1, height: 3,},
        shadowColor: 'gray',
        shadowOpacity: 1,
        shadowRadius: 5,
        borderRadius:5,
        backgroundColor: 'transparent'
    },backgroundImage: {
        resizeMode: 'stretch',
        position: 'absolute',
        top: 0, right: 0, bottom: 0, left: 0,
        width: null,
        height: null,
        borderRadius:5,
        backgroundColor: 'transparent'

    },playButton: {
        position: "absolute",
        backgroundColor:'#AEABB2',
        width:35, height: 35,
        borderRadius:20,
        bottom: 10, right: 10,
        alignItems:'center',
        justifyContent:'center'
    },playIcon: {
        width: 20,
        height: 20,

    },
    videoViewHeading:{position:'absolute',bottom:0,color:'white',opacity:1,fontSize:22, padding:10, paddingRight:'20%'}

});