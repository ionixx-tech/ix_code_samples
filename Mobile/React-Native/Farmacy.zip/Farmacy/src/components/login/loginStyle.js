/**
 * Created by INX on 11/7/17.
 */


import {StyleSheet} from  'react-native';
import { FONT } from '../../utilities/FontConstant';

export default StyleSheet.create({

    containerView: {
        flex: 1.0,
        backgroundColor: "orange"
    },
    loginContainer: {
        flex: 1.0,
    },
    topView: {
        marginTop: 30,
        marginBottom: 30,
        marginLeft: 10,
        marginRight: 10,
        justifyContent: 'space-between',
        flexDirection: 'row',
        backgroundColor: "transparent"

    },
    topViewWithoutBack : {
        marginTop: 30,
        marginBottom: 30,
        marginLeft: 10,
        marginRight: 10,
        justifyContent: 'center',
        alignItems : 'center',
        backgroundColor: "transparent"
    },
    centerView: {
        flex: 0.6,
        margin: 20,
        flexDirection: "column",
        backgroundColor: "transparent",
        justifyContent: 'center',
    }, bottomView: {
        flex: .4,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'transparent',

    },

    labelInput: {
        color: '#673AB7',
    },
    formInput: {
        borderBottomWidth: 1,
        height: 40,
        margin: 5,
        color: "black",
        borderColor: '#333',
    },

    loginButton: {
        top: 20,
        height: 50,
        width: 200,
        margin: 5,
        alignSelf: "center",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: '#7CB60C',
        borderRadius: 30
    }
    , textField: {
        borderRadius: 4,
        marginTop: 20,
        padding: 5,
        fontSize: 14,
        height: 20,

    }, backgroundImages: {
        flex: 1.0,
        resizeMode: 'contain',
        position: 'absolute'

    }, loginbuttonText: {
        color: 'white',
        fontSize: 18,
        fontFamily:FONT.THEME_FONT_BOLD
    }, forgotButton: {
        top: 17,
        height: 40,
        marginTop: 10,
        alignSelf: "center",
    },
    signupButton:{
        top: 5,
        height: 40,
        alignSelf: "center"
    },
    forgotbuttonText: {
        color: 'black',
        fontSize: 12,

    }, singUpTitle: {
        color: '#7CB60C',
        fontSize: 22,
        fontFamily:FONT.THEME_FONT_BOLD,
        alignSelf: 'center'
    }

});