'strict'
/**
 * Created by INX on 11/7/17.
 */

import React, {Component} from 'react';
import  {Alert, NetInfo} from 'react-native';
import {NavigationActions} from 'react-navigation'
import LoginView from './loginView';

import {Navigation, API_PATH, Utilities, NetworkManager, HTTP_METHOD, EVENT_NAME} from 'src/utilities';
import {ALERT_MESSAGES} from 'src/utilities/Constants';

import {UserManager} from 'src/storage';
import {ImageAsset, renderIf} from 'src/utilities';
import EventEmitter from 'react-native-eventemitter'
let isFromWelcome;

export default  class LoginController extends Component {

    static navigationOptions = {
        header: null

    };
    constructor(props) {
        super(props);
        this.isHome = false;
    }
    /*
     Params : none
     return : none
     Description : life cycle methods
     */

    componentDidMount(){
        if(this.props.navigation.state.params.is_unauthorized){
            Utilities.showLongToast(ALERT_MESSAGES.UNAUTHORIZE_ERROR)
        }
       this.isHome = this.props.navigation.state.params.is_home;
       console.log('ishome====>',this.isHome)

    }
    /*
     Params : none
     return : none
     Description : Fields validations
     */

    isValidation() {
        let username = this.loginView.state.username;
        let password = this.loginView.state.password;

        let mgs = "";
        if (username.length == 0) {
            mgs = "Please enter  username";
        } else if (username.length < 4) {
            mgs = "User name length must be 4 at least";
        } else if (username.length > 32) {
            mgs = "UserName length exceeded the limit(32).";
        }

        else if (password.length == 0) {
            mgs = "Please enter  password";
        } else if (password.length < 8) {
            mgs = "Password length must be 8 at least";
        } else if (password.length > 16) {
            mgs = "Password length exceeded the limit(16).";
        }
        if (mgs.length > 0) {
            // Utilities.showErrorAlert(mgs);
            // Utilities.showLongToast(mgs)
            return false;
        }

        return true;
    }

    /*
     Params : none
     return : none
     Description : login button action
     */
    onLoginButtonAction() {

        let deviceToken = UserManager.getInstance().getNotificationValue('userId');
        console.log('device Token====>', deviceToken);
        let playerID = deviceToken === undefined ? "kljhjjjkjk" : deviceToken
        console.log('Playerid Token====>', playerID);
        let param = {
            "username": this.loginView.state.username,
            "password": this.loginView.state.password,
            // "device_notification_key" : "dddddd"
            "device_notification_key": playerID

        };
        console.log("inputParams", JSON.stringify(param));

        let isPasswordValidated = this.loginView.textPassword.state.validationSuccess;
        let isEmailValidated = this.loginView.textUserName.state.validationSuccess;

        if (isEmailValidated !== true && this.loginView.state.username.length < 1) {


            Utilities.showLongToast("Enter Username / Email Id")
        } else if (isEmailValidated !== true && this.loginView.state.username.length >= 1) {

            // Utilities.showLongToast("Invalid Username / Email Id")
        }
        else if (isPasswordValidated !== true && this.loginView.state.password.length < 1) {
            Utilities.showLongToast("Enter Password")
        } else if (isPasswordValidated !== true && this.loginView.state.password.length >= 1) {
            //  Utilities.showLongToast("Invalid Password")
        }

        else if (isEmailValidated === true && isPasswordValidated === true) {

            NetInfo.isConnected.fetch().then(isConnected => {
                if (isConnected) {
                    this.loginView.indicator.show();

                    let weakSelf = this;
                    let request = new NetworkManager();
                    request.sendAsyncRequest(API_PATH.LOGIN, HTTP_METHOD.POST, param).then((json) => {
                        console.log(json);
                        weakSelf.loginView.indicator.dismiss();
                        if (json.message == undefined) {
                            if (json.access_token !== undefined) {
                                UserManager.getInstance().saveUser(json, function () {
                                    UserManager.getInstance().saveCartToken('', function () {
                                        console.log('cart token---->', UserManager.getInstance().getCartToken())
                                        console.log('reset action',weakSelf.isHome)
                                        if(weakSelf.isHome){
                                            console.log('reset action')
                                            const resetAction = NavigationActions.reset({
                                                index: 0,
                                                actions: [
                                                    NavigationActions.navigate({ routeName: Navigation.LANDING,
                                                        params: { is_reset: true } })
                                                ]
                                            });
                                            weakSelf.props.navigation.dispatch(resetAction);
                                        }else{
                                            weakSelf.props.navigation.goBack();
                                        }
                                        EventEmitter.emit(EVENT_NAME.UPDATE_PROFILE_INFO, "");
                                        EventEmitter.emit(EVENT_NAME.CART_LIST, '');


                                    });
                                 });

                            } else if (json.code !== undefined) {
                                //Utilities.showErrorAlert(json.message)
                                this.loginView.alertDialog.showAlert(json['message'], ALERT_MESSAGES.IS_ERROR);
                                setTimeout(() => {
                                    this.loginView.setState({
                                        isOpen: this.loginView.alertDialog.state.isOpen
                                    })
                                }, 500)

                            }

                        } else {
                            this.loginView.alertDialog.showAlert(json.message, true);
                        }


                    }).catch((error) => {
                        console.log(error);
                        this.loginView.indicator.dismiss();
                        this.loginView.alertDialog.showAlert(error.message, ALERT_MESSAGES.IS_ERROR)
                    });


                } else {
                    //TODO NETWORK CONNECTION ALERT
                    this.loginView.alertDialog.showAlert(ALERT_MESSAGES.CONNECTION_FAILURE_MSG, true);
                }
            });


        }
    }
    /*
     Params : none
     return : none
     Description : Navigating to Forgot password screen
     */
    onForgotButtonAction() {
        this.props.navigation.navigate(Navigation.FORGOT);
    }
    /*
     Params : none
     return : none
     Description : Navigating to signup screen
     */
    onSignupButtonAction() {
        this.props.navigation.navigate(Navigation.SIGNUP);
    }

    render() {

        isFromWelcome = this.props.navigation.state.params.from_welcome;
        return (<LoginView
            ref={(o => {
                this.loginView = o;
            })} loginAction={this.onLoginButtonAction.bind(this)}
            forgotAction={this.onForgotButtonAction.bind(this)}
            onSignupButtonAction={this.onSignupButtonAction.bind(this)}
            goBack={this.goBack.bind(this)}
        />);
    }
    /*
     Params : none
     return : none
     Description : Clear navigation stack and pop to previous screen
     */
    goBack() {

        if(this.isHome){
            console.log('Reset Home action')
            const resetAction = NavigationActions.reset({
                index: 0,
                actions: [
                    NavigationActions.navigate({ routeName: Navigation.LANDING, params: { is_reset: true } })
                ]
            });
            this.props.navigation.dispatch(resetAction);
         }else {
            this.props.navigation.goBack();
        }
    }
}

