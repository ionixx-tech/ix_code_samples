'strict'
/**
 * Created by INX on 11/7/17.
 */

import React, {Component} from  'react';

import {View, Text, Image, TextInput, TouchableOpacity, Alert, KeyboardAvoidingView, ScrollView} from 'react-native';
/*import { CheckBox } from 'react-native-elements'*/
/*import CheckBox from 'react-native-checkbox';*/
import CheckBox from 'react-native-check-box';
import  styles from './loginStyle';
import {Indicator} from  'src/customComponents';
import  AutoValidateInputText from 'src/customComponents/AutoValidateInputText'
import {ImageAsset,renderIf} from 'src/utilities';
import Video from "react-native-video";
import ForgotView from "../forgot/forgotView";
import  mainStyles from 'src/style';
import {Navigation, API_PATH, Utilities, NetworkManager, HTTP_METHOD} from 'src/utilities';
import  AlertDialog from 'src/customComponents/CustomAlert'
/*import ptrEvent from 'data-pointer-events'*/

export default   class LoginView extends Component {

    constructor(props) {
        super(props);
        this.state = {
            /* username:"lokeshkumars",
             password:"admin123"*/
            username: "",
            password: "",
            secureTextEntry: true,
            showPassword: false,
            userNameErrorMsg:"Enter Email/User name",
            passwordErrorMsg:"Enter Password",
            isHideBackButton : false,
            isOpen:false,
            isHome : false

        };
    }

    onValidateUsername(text) {
        let str = text.split(" ").join("");
        this.setState({username: str});
    }

    onValidatePassword(text) {
        let str = text.split(" ").join("");
        this.setState({password: str});

    }
    renderLoginHeader(){
        if(this.state.isHideBackButton === false){
            return  <View style={styles.topView}>
                <TouchableOpacity onPress={this.props.goBack}>
                    <Image style={{height:30,width:20,resizeMode:'stretch',margin:10,alignSelf:'center'}}
                           source={ImageAsset.BACK_ARROW}/>
                </TouchableOpacity>
                <Text style={styles.singUpTitle}>SIGN IN</Text>
                <Text style={styles.singUpTitle}>       </Text>
            </View>
        }else {
            return  <View style={styles.topViewWithoutBack}>
                {/*<TouchableOpacity onPress={this.props.goBack}>*/}
                    {/*<Image style={{height:30,width:20,resizeMode:'stretch',margin:10,alignSelf:'center'}}*/}
                           {/*source={ImageAsset.BACK_ARROW}/>*/}
                {/*</TouchableOpacity>*/}
                <Text style={styles.singUpTitle}>SIGN IN</Text>
            </View>
        }
    }
    render() {
        let weakslef = this;
        return (
            <KeyboardAvoidingView style={styles.loginContainer}>


                <Image style={mainStyles.backgroundImage}
                       source={ImageAsset.WELCOME_BG}>
                </Image>

                <View style={styles.topView}>
                    <TouchableOpacity onPress={this.props.goBack}>
                    <Image style={{height:30,width:20,resizeMode:'stretch',margin:10,alignSelf:'center'}}
                           source={ImageAsset.BACK_ARROW}/>
                    </TouchableOpacity>
                    <Text style={styles.singUpTitle}>SIGN IN</Text>
                    <Text style={styles.singUpTitle}>       </Text>
                </View>
                <View style={styles.centerView}>

                    <AutoValidateInputText placeholder="Username/Email Id" 

                                           value={this.state.username}
                                           autoFocus={true}
                                           isPassword={false}
                                           isUserName={true}
                                           userNameOrEmail={true}
                                           autoCapitalize = 'none'
                                           accessibilityLabel={'username'}
                                           onChangeText={this.setUserName.bind(this)}
                                           style={styles.textField}
                                           errorMessage={this.state.userNameErrorMsg}
                                           keyboardType="default"
                                           automaticValidation={true}
                                           selectTextOnFocus = {false}
                                           ref={(input) => {
                                               this.textUserName = input;
                                           } }>
                    </AutoValidateInputText>

                        <AutoValidateInputText placeholder="Password"
                                               pointerEvents="box-only"
                                               selectTextOnFocus={false}
                                               value={this.state.password}
                                               multiLine={true}
                                               numberOfLine={2}
                                               accessibilityLabel={'password'}
                                               secureTextEntry={this.state.secureTextEntry}
                                               onChangeText={this.setPassword.bind(this)}
                                               autoCapitalize = 'none'
                                               style={styles.textField}
                                               isPassword={true}
                                               errorMessage={this.state.passwordErrorMsg}
                                               keyboardType="default"
                                               automaticValidation={true}
                                               ref={(input) => {
                                                   this.textPassword = input;
                                               } }>
                        </AutoValidateInputText>






                    <CheckBox
                        style={{ padding: 10, marginBottom: 20}}
                        onClick={() => this._showPasswordAction(this.state.showPassword)}
                        isChecked={this.state.showPassword}
                        rightText={"show password"}
                        checkBoxColor={"gray"}/>
                </View>

                <View style={styles.bottomView}>
                    <TouchableOpacity
                        style={styles.loginButton} onPress={this.props.loginAction}>
                        <Text style={styles.loginbuttonText}>LOGIN</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.forgotButton} onPress={this.props.forgotAction}>
                        <Text style={styles.forgotbuttonText}>FORGOT PASSWORD</Text>
                        <View style={{
                            borderWidth: 0.5,
                            borderRadius: 1,
                            borderColor: 'black',
                            height:0.2,

                        }}>
                        </View>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.signupButton} onPress={this.props.onSignupButtonAction}>
                        <Text style={styles.forgotbuttonText}>SIGN UP</Text>
                        <View style={{
                            borderWidth: 0.5,
                            borderRadius: 1,
                            borderColor: 'black',
                            height:0.2,

                        }}>
                        </View>
                    </TouchableOpacity>
                </View>

                <Indicator ref={(o => {
                    this.indicator = o;
                })}/>
                <AlertDialog
                    ref={(b => {
                        this.alertDialog = b;
                    })}>
                </AlertDialog>
            </KeyboardAvoidingView>

        );
    }

    setUserName(username)
    {
        this.setState({username:username});
        setTimeout(() => {
            if (this.state.username.length<1) {
                this.setState({userNameErrorMsg:"Enter Username / Email Id"});
                //Utilities.showLongToast("Enter Username / Email Id")
                console.log("name update",this.state.username.length);
            }else if(this.state.username.length>=1)
            {
                this.setState({userNameErrorMsg:"Invalid Username / Email Id"});
               // Utilities.showLongToast("Invalid Username / Email Id")
                console.log("name update",this.state.username.length);
            }
        }, 0);

    }



    setPassword(password)
    {
        this.setState({password:password});
        setTimeout(() => {
            if (this.state.password.length<1) {
                this.setState({passwordErrorMsg:"Enter Password"});
                //Utilities.showLongToast("Enter Username / Email Id")
               // console.log("name update",this.state.username.length);
            }else if(this.state.password.length>=1)
            {
                this.setState({passwordErrorMsg:"Invalid Password"});
                // Utilities.showLongToast("Invalid Username / Email Id")
                //console.log("name update",this.state.username.length);
            }
        }, 0);

    }




    _showPasswordAction(isChecked) {

        if (isChecked === true) {
            this.setState({showPassword: false});
            this.setState({secureTextEntry: true});
        } else {
            this.setState({showPassword: true});
           this.setState({secureTextEntry: false});

        }
    }


}


{/* <TextInput
 style={styles.formInput}
 value={this.state.username}
 placeholder={"Username"}
 maxLength= {32}
 underlineColorAndroid="transparent"
 onChangeText={(text)=> this.onValidateUsername(text)}
 onSubmitEditing={(event) => { this.passwordInput.focus() }}
 />*/
}