/**
 * Created by INX on 1/3/18.
 */

import JSONModel from '../JSONModel';

export default  class OrderTrackModel extends JSONModel{

    constructor(json: Object) {
        super(json);
        this.order_received = new OrderReceivedModel(json['order_received']);
        this.tracking = new TrackingModel(json['tracking']);
        this.delivered = new DeliveredModel(json['delivered']);
    }
    static mapping(items: [any]): [OrderTrackModel] {
        return super.mapping(items);
    }
}

class OrderReceivedModel extends JSONModel{
    constructor(json: Object) {
        super(json);
    }
}

class TrackingModel extends JSONModel{
    constructor(json: Object) {
        super(json);
    }
}
class DeliveredModel extends JSONModel{
    constructor(json: Object) {
        super(json);
    }
}