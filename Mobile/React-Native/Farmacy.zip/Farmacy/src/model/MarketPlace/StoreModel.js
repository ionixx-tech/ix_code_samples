/**
 * Created by INX on 1/3/18.
 */

import JSONModel from '../JSONModel';

export default  class StoreModel extends JSONModel{

    constructor(json: Object) {
        super(json);
    }
    coordinate(){
        return {latitude:this.location_latitude,longitude:this.location_longitude};
    }
    static mapping(items: [any]): [StoreModel] {

        return super.mapping(items);
    }
}