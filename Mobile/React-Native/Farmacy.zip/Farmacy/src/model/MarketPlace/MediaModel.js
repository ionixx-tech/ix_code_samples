/**
 * Created by INX on 1/3/18.
 */

import JSONModel from '../JSONModel';

export default  class AllStoreModel extends JSONModel{

    constructor(json: Object) {
        super(json);
    }
    static mapping(items: [any]): [AllStoreModel] {

        return super.mapping(items);
    }
}