/**
 * Created by INX on 12/29/17.
 */

import JSONModel from '../JSONModel';

export default class CartModel extends JSONModel{

    constructor(json: Object) {
        super(json);
    }
    static mapping(items: [any]): [StoreModel] {
        return super.mapping(items);
    }
}

/*

 "thumbnail_url":"https:\/\/brandimage.thefarmacy.co\/421887_vaper.jpg",
 "type":"storeDetails",
 "store_id":"193"
 */