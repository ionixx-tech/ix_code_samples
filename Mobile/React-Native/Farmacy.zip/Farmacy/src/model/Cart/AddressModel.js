/**
 * Created by INX on 12/29/17.
 */

import JSONModel from '../JSONModel';
import Utilities from "../../utilities/Utilities";

export default class AddressModel extends JSONModel{

    constructor(json: Object) {
        super(json);
        this.isSelect = false;
    }
    static mapping(items: [any]): [StoreModel] {
        return super.mapping(items);
    }

    getAddress(){
        let full = "";
        full+=Utilities.OptionalString(this.name,"");
        full+=",";
        full+=Utilities.OptionalString(this.address1,"");
        full+=",";
        full+=Utilities.OptionalString(this.address2,"");
        full+=",";
        full+=Utilities.OptionalString(this['city'],"");
        full+=",";
        full+=Utilities.OptionalString(this['state'],"");
        full+=",";
        full+=Utilities.OptionalString(this['country'],"");
        full+=",";
        full+=Utilities.OptionalString(this['zip'],"");
        return full;
    }
}

/*

 "thumbnail_url":"https:\/\/brandimage.thefarmacy.co\/421887_vaper.jpg",
 "type":"storeDetails",
 "store_id":"193"
 */