/**
 * Created by INX on 1/3/18.
 */

import JSONModel from '../JSONModel';

export default  class PaySafedInfoModel extends JSONModel{

    constructor(json:Object) {
        // noinspection JSAnnotator
        super(json);
    }

    static mapping(items: [any]): [PaySafedInfoModel] {
        return super.mapping(items);
    }
}