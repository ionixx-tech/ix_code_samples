/**
 * Created by INX on 1/3/18.
 */

import JSONModel from '../JSONModel';
const Buffer = require('buffer/').Buffer  // note: the trailing slash is important!

export default  class PaySafeModel extends JSONModel{

    constructor() {
        super({});
        this.countryCode="";
        this.cardNumber="";
        this.cvv="";
        this.month="";
        this.year="";
       // this.cardExpiryDate="";
    }
    // getDateString(){
    //     let month =  this.cardExpiryDate.getMonth() + 1; //Be careful! January is 0 not 1
    //     let year =  this.cardExpiryDate.getFullYear();
    //     return String(month ) +"/"+ String(year);
    // }
    getJSON(){
        let month =  this.month; //Be careful! January is 0 not 1
        let year =  this.year;
        let base64CardNumber =  Buffer.from(this.cardNumber).toString('base64');
        let base64CardCVV =  Buffer.from(this.cvv).toString('base64');
        console.log(base64CardNumber);
        console.log(base64CardCVV);
        const param = {'card_number':base64CardNumber,'card_cvv':base64CardCVV,'card_exp_month':month,'card_exp_year':year};
        return param;
    }
    static mapping(items: [any]): [PaySafeModel] {
        return super.mapping(items);
    }
}