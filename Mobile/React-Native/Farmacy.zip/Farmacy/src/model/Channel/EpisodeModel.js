/**
 * Created by INX on 12/29/17.
 */
import JSONModel from '../JSONModel';

export default  class EpisodeModel extends JSONModel{

    constructor(json: Object) {
        super(json);
    }
    static mapping(items: [any]): [EpisodeModel] {
        return super.mapping(items);
    }
}