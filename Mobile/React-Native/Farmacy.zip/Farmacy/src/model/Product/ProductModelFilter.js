/**
 * Created by INX on 1/3/18.
 */

import JSONModel from '../JSONModel';
import { FILTER } from 'src/components/product/filter/template';

export class ProductModelFilter extends JSONModel{


    static mapping(items: [any]): [ProductModelFilter] {
        return super.mapping(items);
    }
     options: [OptionsModel]

    constructor(json: Object) {
        super(json);
        if(json!==undefined && json!==null)
        {
            let op = json['options'];

            if (Array.isArray(op)){
                if (op.length >0 ){
                    if (typeof op[0] === 'object'){
                        this.options = OptionsModel.mapping(op);}
                }
            }
        }


    }
    static FilterQuery(items: [ProductModelFilter]): object {

        const queryArray = items.map((obj)=>{

            if(FILTER.RANGE === obj.selection_type) {
                return 'min_price=' + obj.minimumValue + '&' + 'max_price=' + obj.maximumValue
            }else if(FILTER.SINGLE_SELECT === obj.selection_type) {
                if (obj.checked === false || obj.checked === undefined){return ''}
                return  obj.filter_name + '=' + (obj.checked ? 'true' : 'false')
            }else if(FILTER.MULTI_SELECT === obj.selection_type) {
                const key = obj.options.filter((oo)=>  {
                    return oo.isSelected;
                });
                if (key.length === 0){return ''}
                const m = key.map((oo)=>{ return oo.value});
                return obj.filter_name + '=' + m.join(',')
            }
            return '';
        });
        const finalQueryString = queryArray.filter((oo)=>  {
            return oo !== '';
        });
        return finalQueryString.join('&');
    }
}


export class OptionsModel  extends JSONModel{
    constructor(json: Object) {
        super(json);
        this.isSelected = false
    }

    static mapping(items: [any]): [OptionsModel] {
        return super.mapping(items);
    }
}
