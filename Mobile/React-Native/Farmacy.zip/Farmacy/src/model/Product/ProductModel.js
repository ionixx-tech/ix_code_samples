/**
 * Created by INX on 1/3/18.
 */

import JSONModel from '../JSONModel';
import Utilities from "../../utilities/Utilities";

export default  class ProductModel extends JSONModel{

    constructor(json: Object) {
        super(json);
    }
    coordinate(){
        return {latitude:this.location_latitude,longitude:this.location_longitude};
    }
    getPrice(){
        if (this.show_price === false || this.show_price === 'false'){
            return 'Contact Price';
        }else if (typeof this.price === 'string') {
            return  '$' + this.price;
        } else if (Array.isArray(this.price)) {
            if (this.price.length > 0){
                return '$' + Utilities.OptionalString(this.price[0].amount,"Contact Price");
            }
         }
        return '-';
    }
    static mapping(items: [any]): [ProductModel] {

        return super.mapping(items);
    }
}