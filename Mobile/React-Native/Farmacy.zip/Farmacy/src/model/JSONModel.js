/**
 * Created by INX on 12/29/17.
 */
'use strict';

export default class JSONModel {
    constructor(json) {
       Object.assign(this, json);
    }

    copy() {
        return new this.constructor(JSON.parse(JSON.stringify(this)));
    }

    //noinspection JSAnnotator
    static mapping(items: [any]): [JSONModel] {

        let resultMapping = [];

        for (let i = 0; i < items.length; i++ ) {
            let item = items[i];
            let object = new this(item);
            resultMapping.push(object);
        }
        return resultMapping;
    }
}