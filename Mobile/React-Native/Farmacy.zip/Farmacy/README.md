# README #

This README would normally document whatever steps are necessary to get your application up and running.

### What is this repository for? ###

* Quick summary
* Version
* [Learn Markdown](https://bitbucket.org/tutorials/markdowndemo)

### How do I get set up? ###

* cd <project path>
* npm install
* open android studio import project
* run on device or emulaor


### Create offline Build
* run  following commend on termianl
* cd <project root path>
  Android :
    react-native bundle --platform android --dev false --entry-file index.js --bundle-output android/app/src/main/assets/index.android.bundle --assets-dest android/app/src/main/res/
  iOS :
     react-native bundle --entry-file index.js --platform ios --dev false --bundle-output ios/main.bundle --assets-dest ios

### Contribution Keystore guidelines ###


---
### Who do I talk to? ###

* Repo owner or admin
* Other community or team contact