//
//  NewsReviewCollectionViewCell.swift
//  IXiOSArchitecture
//
//  Created by Alex Appadurai on 25/05/18.
//  Copyright © 2018 Alex Appadurai. All rights reserved.
//

import UIKit
import IXKit

/// Class for managing cell content and cell selection for LatestCollectionViewCell
class LatestCollectionViewCell: UICollectionViewCell,CellResuable {
    static var reuseIdentifier: String = "LatestCollectionViewCell"
    
    @IBOutlet var imageView:AsyncUIImageView!
    @IBOutlet var titleLabel:UILabel!
    @IBOutlet var userLabel:UILabel!
    @IBOutlet var viewsLabel:UILabel!
    @IBOutlet var dateLabel:UILabel!

    
    func set(newsReview:VehiclesModel){
//        imageView.url = newsReview.imageURL!
        imageView.setURL(newsReview.media?.url)
    }
}
