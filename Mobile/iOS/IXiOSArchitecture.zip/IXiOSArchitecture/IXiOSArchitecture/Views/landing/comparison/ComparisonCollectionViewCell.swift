//
//  NewsReviewCollectionViewCell.swift
//  IXiOSArchitecture
//
//  Created by Alex Appadurai on 25/05/18.
//  Copyright © 2018 Alex Appadurai. All rights reserved.
//

import UIKit
import IXKit

/// Class for managing cell content and cell selection for ComparisonCollectionView
class ComparisonCollectionViewCell: UICollectionViewCell,CellResuable {
    static var reuseIdentifier: String = "ComparisonCollectionViewCell"
    
    @IBOutlet var imageView:UIImageView!
    @IBOutlet var titleLabel:UILabel!
    @IBOutlet var userLabel:UILabel!
    @IBOutlet var viewsLabel:UILabel!
    @IBOutlet var dateLabel:UILabel!
    @IBOutlet weak var compareBtn: UIButton!
    
//    var newsReview:NewsReviewModel{
//        didSet{
//
//        }
//    }
//    override init(frame: CGRect) {
//        super.init(frame: frame)
//    }
//
//    required init?(coder aDecoder: NSCoder) {
//        super.init(coder: aDecoder)
//    }
    func set(car:VehicleComparisonModel){
//        imageView.url = newsReview.imageURL!
//        imageView.setURL(car.media?.url)
    }
}
