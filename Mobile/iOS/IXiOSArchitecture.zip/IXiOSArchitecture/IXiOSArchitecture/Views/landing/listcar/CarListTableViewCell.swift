//
//  CarListTableViewCell.swift
//  IXiOSArchitecture
//
//  Created by Alex Appadurai on 28/05/18.
//  Copyright © 2018 Alex Appadurai. All rights reserved.
//

import UIKit

/// Class for managing cell content and cell selection for CarListTableView
class CarListTableViewCell: UITableViewCell, CellResuable {

    static let reuseIdentifier: String = "CarListTableViewCell"

    
    /// MARK:- lifecyle method
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    
    /// Sets the selected state of the cell
    ///
    /// - Parameters:
    ///   - selected: whether the cell is selected or not
    ///   - animated: whether the cell is animated or not
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }

}
