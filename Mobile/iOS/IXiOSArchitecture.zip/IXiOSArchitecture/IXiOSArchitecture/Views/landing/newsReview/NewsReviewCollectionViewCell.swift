//
//  NewsReviewCollectionViewCell.swift
//  IXiOSArchitecture
//
//  Created by Alex Appadurai on 25/05/18.
//  Copyright © 2018 Alex Appadurai. All rights reserved.
//

import UIKit
import IXKit
/// Class for managing cell content and cell selection for NewsReviewCollectionViewCell
class NewsReviewCollectionViewCell: UICollectionViewCell,CellResuable {
    
    static var reuseIdentifier: String = "NewsReviewCollectionViewCell"
    
    @IBOutlet var imageView:AsyncUIImageView!
    @IBOutlet var titleLabel:UILabel!
    @IBOutlet var userLabel:UILabel!
    @IBOutlet var viewsLabel:UILabel!
    @IBOutlet var dateLabel:UILabel!

    func set(newsReview:NewsReviewModel){
//        imageView.url = newsReview.imageURL!
//        imageView.setURL(newsReview.avatar)
    }
}
