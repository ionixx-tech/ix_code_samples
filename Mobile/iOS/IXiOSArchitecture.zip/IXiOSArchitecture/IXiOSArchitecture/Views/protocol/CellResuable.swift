//
//  CellResuable.swift
//  IXiOSArchitecture
//
//  Created by Alex Appadurai on 25/05/18.
//  Copyright © 2018 Alex Appadurai. All rights reserved.
//

import Foundation

/// set reuseIdentifier on comfortable
protocol CellResuable: class {
    static var reuseIdentifier: String { get }
}
/// storyboard segue protocol comfortable
protocol StoaryboardSegueIdentifier: class {
    static var segueIdentifier: String { get }
}
