//
//  AsyncUIImageView.swift
//  IXiOSArchitecture
//
//  Created by Alex Appadurai on 25/05/18.
//  Copyright © 2018 Alex Appadurai. All rights reserved.
//

import UIKit

/// Class to load image into the image view asynchronously
open class AsyncUIImageView: UIImageView {
    
    private var _activityIndicator:UIActivityIndicatorView!
    
    
    /// start loading
    private var _isLoading = false{
        didSet{
            DispatchQueue.main.async {
                self._isLoading ? self._activityIndicator.startAnimating() : self._activityIndicator.stopAnimating()
            }
        }
    }
    public var url : String? {
        didSet{
            _isLoading = true
            self.setURL(url) { (sucess) in
                self._isLoading = !sucess
            }
        }
    }
    open override var tintColor: UIColor!{
        didSet{
            _activityIndicator.tintColor = tintColor
        }
    }
    public  var style = UIActivityIndicatorViewStyle.white{
        didSet{
            _activityIndicator.activityIndicatorViewStyle = style
        }
    }
    public required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        _activityIndicator = UIActivityIndicatorView.init(activityIndicatorStyle: UIActivityIndicatorViewStyle.white)
        _activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        _activityIndicator.hidesWhenStopped = true
        _activityIndicator.tintColor = tintColor
        self.addSubview(_activityIndicator)
        self.addConstraint(NSLayoutConstraint.init(item: _activityIndicator, attribute: NSLayoutAttribute.centerX, relatedBy: NSLayoutRelation.equal, toItem: self, attribute: NSLayoutAttribute.centerX, multiplier: 1, constant: 0))
        self.addConstraint(NSLayoutConstraint.init(item: _activityIndicator, attribute: NSLayoutAttribute.centerY, relatedBy: NSLayoutRelation.equal, toItem: self, attribute: NSLayoutAttribute.centerY, multiplier: 1, constant: 0))
    }
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
