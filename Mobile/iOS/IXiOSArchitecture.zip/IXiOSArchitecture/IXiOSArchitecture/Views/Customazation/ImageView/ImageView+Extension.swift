//
//  AXColorPicker.swift
//  AXUIKit
//
//  Created by Alex Appadurai on 17/05/16.
//  Copyright © 2016 Alex Appadurai. All rights reserved.
//

import UIKit


// MARK: - Extension for UIImageView
public extension UIImageView{
    
    
    /// To load image from the given URL
    ///
    /// - Parameters:
    ///   - urlString: Image URL
    ///   - handler: To handle session
    /// - Returns: data from the URL
    @discardableResult func setURL(_ urlString:String?, _  handler:((Bool)->Void)?=nil)->URLSessionDataTask?{
        guard let urlstr = urlString else {
            handler?(false)
            return nil
        }
        guard let url = URL.init(string: urlstr) else {
            handler?(false)
            return nil
        }
        let dataTask = URLSession.shared.dataTask(with: url) { (data, response, error) in
            if error == nil && data != nil{
                DispatchQueue.main.async {
                    self.image = UIImage.init(data: data!)
                }
            }
            handler?(error == nil)
        }
        dataTask.resume()
        return dataTask
     }
}
