//
//  AXCardView.swift
//  AXUIKit
//
//  Created by Alex Appadurai on 31/12/16.
//  Copyright © 2016 Alex Appadurai. All rights reserved.
//

import UIKit

/// Add Card style to the UIView, using shaddow
@IBDesignable class CardView: UIView {

    
    @IBInspectable var cornerRadius: CGFloat = 2
    @IBInspectable var borderWidth: CGFloat = 0
    @IBInspectable var borderColor: UIColor? = UIColor.black

    @IBInspectable var shadowOffsetWidth: Int = 0
    @IBInspectable var shadowOffsetHeight: Int = 3
    @IBInspectable var shadowColor: UIColor? = UIColor.black
    @IBInspectable var shadowOpacity: Float = 0.5

    @IBInspectable var masksToBounds = false
    

    /// To add more precise layout for the subviews.
    override func layoutSubviews() {
        layer.cornerRadius = cornerRadius
        layer.borderWidth = borderWidth
        layer.borderColor = borderColor?.cgColor
        let shadowPath = UIBezierPath(roundedRect: bounds, cornerRadius: cornerRadius)
        
        layer.masksToBounds = masksToBounds
        layer.shadowColor = shadowColor?.cgColor
        layer.shadowOffset = CGSize(width: shadowOffsetWidth, height: shadowOffsetHeight);
        layer.shadowOpacity = shadowOpacity
        layer.shadowPath = shadowPath.cgPath
    }

}


