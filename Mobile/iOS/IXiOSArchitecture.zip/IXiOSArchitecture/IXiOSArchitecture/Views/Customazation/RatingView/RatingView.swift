//
//  RatingView.swift
//  IXiOSArchitecture
//
//  Created by Alex Appadurai on 28/05/18.
//  Copyright © 2018 Alex Appadurai. All rights reserved.
//

import UIKit

/// Class to create custom view for Rating
class RatingView: UIView {

    private var titleLabel  = UILabel()
    
    @IBInspectable var rating:Float=0{
        didSet{
            self.titleLabel.text = String(format: "%.1f",rating)
            setNeedsLayout()
        }
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
         self.titleLabel.textAlignment = .center
        self.titleLabel.font = UIFont.init(name: "Avenir-Black", size:10)
        self.titleLabel.textColor = UIColor.white
        self.addSubview(self.titleLabel)
     }
    
    
    /// To add more precise layout for the subviews.
    override func layoutSubviews() {
        super.layoutSubviews()
        self.titleLabel.frame = CGRect.init(x: self.frame.midX-5, y: 0, width: self.frame.width/2, height: self.frame.height)
    }
 
    /// To implement custom drawing
    override func draw(_ rect: CGRect) {
        // Drawing code
        guard let context = UIGraphicsGetCurrentContext() else {
            return
        }
        // draw rating using on draw 
        guard let cgimage = UIImage.init(named: "icn_rating")?.cgImage else {
            return
        }
        context.draw(cgimage, in: rect)
        self.backgroundColor = UIColor.green
        //icn_rating
    }
 

}
