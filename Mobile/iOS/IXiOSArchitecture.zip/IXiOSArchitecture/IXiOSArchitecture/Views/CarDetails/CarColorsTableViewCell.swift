//
//  CarColorsTableViewCell.swift
//  GaadiBazaar
//
//  Created by apple on 28/05/18.
//  Copyright © 2018 Alex Appadurai. All rights reserved.
//

import UIKit

class CarColorsTableViewCell: UITableViewCell {

    @IBOutlet weak var carColorView: UIView!
    @IBOutlet weak var selectedImageView: UIImageView!
    
    static let reuseIdentifier: String = "CarColorableViewCell"
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        carColorView.clipsToBounds = true
        carColorView.layer.cornerRadius = 5
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
