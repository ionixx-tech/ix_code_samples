//
//  DataModel.swift
//  IXiOSArchitecture
//
//  Created by Alex Appadurai on 25/05/18.
//  Copyright © 2018 Alex Appadurai. All rights reserved.
//

import Foundation

protocol DataType {
}


typealias DataModelHandler = ()->Void


/// DataModel to communicate with controller
protocol DataModelDelegate {
    func  dataModelDidCompleted(_ item:Any?,_ type:DataType?)
    func  dataModelDidFailed(_ item:Any?, _ type:DataType?)
}
class DataModel{
    var delegate : DataModelDelegate?
}
