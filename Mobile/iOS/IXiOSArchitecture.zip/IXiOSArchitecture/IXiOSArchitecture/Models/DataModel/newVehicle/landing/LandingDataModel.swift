//
//  LandingDataModel.swift
//  IXiOSArchitecture
//
//  Created by Alex Appadurai on 25/05/18.
//  Copyright © 2018 Alex Appadurai. All rights reserved.
//

import Foundation
import IXNetwork

enum  LandingDataType : DataType{
    case banner
    case latest
    case popular_comparison
    case news
}


/// DataModel to communicate with the LandingController
class LandingDataModel:DataModel{
    
    
    /// API request for the LandingView
    func fetch(){
        landing()
        latest()
        popularComparison()
        newsReview()
    }
    
    
    /// API request for Banner
    private func landing(){
        let connection = NetworkManager.init()
        connection.get(path: APIRoute.landing.banner) { (response:Response<UserModel>) in
            if response.sucess{
                self._complateDelegate(response.results, LandingDataType.banner)
            }
        }
    }
    
    
    /// API request for latest
    private func latest(){
        let connection = NetworkManager.init()
        connection.post(path: APIRoute.landing.latest) { (response:Response<VehiclesModel>) in
            if response.sucess{
                self._complateDelegate(response.results, LandingDataType.latest)
            }
        }
    }
    
    
    /// API request for popular comparision
    private func popularComparison(){
        let connection = NetworkManager.init()
        connection.get(path: APIRoute.landing.popular_comparison) { (response:Response<VehicleComparisonModel>) in
            if response.sucess{
                self._complateDelegate(response.results, LandingDataType.popular_comparison)
            }
        }
    }
    
    
    /// API request for news reviews
    private func newsReview(){
        let connection = NetworkManager.init()
        connection.post(path:APIRoute.landing.news) { (response:Response<NewsReviewModel>) in
            if response.sucess{
                self._complateDelegate(response.results, LandingDataType.news)
            }
        }
    }
    private func _complateDelegate(_ items:Any?,_ type:LandingDataType){
        self.delegate?.dataModelDidCompleted(items,type)
    }
}
