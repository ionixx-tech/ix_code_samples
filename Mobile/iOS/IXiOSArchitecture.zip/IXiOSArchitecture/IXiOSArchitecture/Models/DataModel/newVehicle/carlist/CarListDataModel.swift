//
//  LandingDataModel.swift
//  IXiOSArchitecture
//
//  Created by Alex Appadurai on 25/05/18.
//  Copyright © 2018 Alex Appadurai. All rights reserved.
//

import Foundation
import IXNetwork

/// Datamodel to communicate with the CarListController
class CarListDataModel:DataModel{
  
    private var items = Array<VehiclesModel>()
    
    var count:Int{
        return items.count
    }
    subscript(_ indexPath:IndexPath)->VehiclesModel{
        return self.items[indexPath.row]
    }
    
    
    /// API request for CarList data
    func fetch(){
        let connection = NetworkManager.init()
        connection.get(path: APIRoute.landing.popular_comparison) { (response:Response<VehiclesModel>) in
            if response.sucess{
                self.items = response.results!
                self.delegate?.dataModelDidCompleted(nil, nil)
            }
        }
    }
    
}
