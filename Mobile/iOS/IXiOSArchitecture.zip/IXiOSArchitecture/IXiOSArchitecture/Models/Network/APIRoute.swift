//
//  APIRoute.swift
//  IXiOSArchitecture
//
//  Created by Alex Appadurai on 28/05/18.
//  Copyright © 2018 Alex Appadurai. All rights reserved.
//

import Foundation


/// To handle api path URL
struct APIRoute{
    static let BASEURL = "http://192.168.1.17/IXiOSArchitecture_server/public/api/v1/"
    struct landing{
        static let banner = "banner"
        static let recommend = "recommend"
        static let popular_comparison = "popular-comparison"
        static let latest = "recommend"
        static let news = "article"
    }
    
    struct car{
        
    }
}

// MARK: - <#Description#>
extension APIRoute{
    
}
