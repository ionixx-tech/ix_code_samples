//
//  NetworkManager.swift
//  IXiOSArchitecture
//
//  Created by Alex Appadurai on 28/05/18.
//  Copyright © 2018 Alex Appadurai. All rights reserved.
//

import Foundation
import IXNetwork


/// NetworkManager class to handle network requests
class  NetworkManager{
    var _url:String!
    init() {
        _url = APIRoute.BASEURL
    }
    
    
    /// To handle HTTP get requests
    ///
    /// - Parameters:
    ///   - path: URL path
    ///   - param: params if any
    ///   - handler: handle the response data
    func get<T:ObjectMapper>(path:String,param:Dictionary<String,Any>?=nil,handler:@escaping (Response<T>)->Void){
        _url = _url + path
        if let query_param = param, query_param.count > 0 {
            _url = _url + "?" + query_param.query
        }
        print("URL: \(_url)")
        let network = RequestManager<T>.init( url: URL.init(string: _url)!)
        _addHeader(network)
        network.parse(key: "data").sendRequest(method: HTTPMethod.get) { (response) in
            print("----")
            DispatchQueue.main.async {
                handler(response)
            }
        }
    }
    
    /// To handle HTTP get requests
    ///
    /// - Parameters:
    ///   - path: URL path
    ///   - param: param to be sent in the request body
    ///   - handler: handle the response
    func post<T:ObjectMapper>(path:String,param:Dictionary<String,Any>?=nil,handler:@escaping (Response<T>)->Void){
        _url = _url + path
        let network = RequestManager<T>.init( url: URL.init(string: _url)!)
        _addHeader(network)
        print("URL: \(_url)")

        network.parse(key: "data").sendRequest(method: HTTPMethod.post) { (response) in
            print("----")
            DispatchQueue.main.async {
                handler(response)
            }
        }
    }
    
    
    /// To add header in the HTTP requests
    ///
    /// - Parameter request: request
    private func _addHeader<T:ObjectMapper>(_ request:RequestManager<T>){
        request.addHeader("Content-Type", "application/json")
    }
}
