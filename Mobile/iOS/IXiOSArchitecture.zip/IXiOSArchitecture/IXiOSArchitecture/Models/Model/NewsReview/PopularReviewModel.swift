//
//  NewsReviewModel.swift
//  IXiOSArchitecture
//
//  Created by Alex Appadurai on 25/05/18.
//  Copyright © 2018 Alex Appadurai. All rights reserved.
//

import Foundation
import IXNetwork


/// Model class to map PopularReview data
class PopularReviewModel:ObjectMapper{
    var avg_rating:Float?
    var total_reviews:Int?
    var model_identifier:String?
    var brand_name:String?
    var model_name:String?
    var media_identifier:String?
    var price:Int?
    var media_url:MediaModel?
    var rating_segregation:RatingSegregation?

    
    /// To map the response data
    ///
    /// - Parameter json: response json
    func mapping(json: Dictionary<String, Any>) {
        
    }
}


/// Model class to map RatingSegregation data
class RatingSegregation:ObjectMapper {
    var rating_1:Int?
    var rating_2:Int?
    var rating_3:Int?
    var rating_4:Int?
    var rating_5:Int?
    
    /// To map the response data
    ///
    /// - Parameter json: response json
    func mapping(json: Dictionary<String, Any>) {
        
    }
}
