//
//  NewsReviewModel.swift
//  IXiOSArchitecture
//
//  Created by Alex Appadurai on 25/05/18.
//  Copyright © 2018 Alex Appadurai. All rights reserved.
//

import Foundation
import IXNetwork


/// Model class to map PopularReview data
class NewsReviewModel:ObjectMapper{
    var avg_rating:Float?
    var total_reviews:Int?
    var model_identifier:String?
    var brand_name:String?
    var model_name:String?
    var media_identifier:String?
    var price:Int?
    var media_url:MediaModel?
    
    /// To map the response data
    ///
    /// - Parameter json: response json
    func mapping(json: Dictionary<String, Any>) {
        
    }
}
