//
//  UserModel.swift
//  IXiOSArchitecture
//
//  Created by Alex Appadurai on 25/05/18.
//  Copyright © 2018 Alex Appadurai. All rights reserved.
//

import Foundation
import IXNetwork

/// Model class to map User data
class UserModel:ObjectMapper{
    var id:Int?
    var first_name:String?
    var last_name:String?
    var avatar:String?
   
    /// To map the response data
    ///
    /// - Parameter json: response json
    func mapping(json: Dictionary<String, Any>) {
        
    }
}
