//
//  VehiclesModel.swift
//  IXiOSArchitecture
//
//  Created by Alex Appadurai on 28/05/18.
//  Copyright © 2018 Alex Appadurai. All rights reserved.
//

import Foundation
import IXNetwork

/// Model class to map VehicleComparison data
class VehicleComparisonModel:ObjectMapper{
    
    var popular_comparison_identtifier:String?
    var vehicles:[VehiclesModel]?
    
    /// To map the response data
    ///
    /// - Parameter json: response json
    func mapping(json: Dictionary<String, Any>) {
    }
}
