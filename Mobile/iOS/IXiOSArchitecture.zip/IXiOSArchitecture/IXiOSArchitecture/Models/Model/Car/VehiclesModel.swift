//
//  VehiclesModel.swift
//  IXiOSArchitecture
//
//  Created by Alex Appadurai on 28/05/18.
//  Copyright © 2018 Alex Appadurai. All rights reserved.
//

import Foundation
import IXNetwork

/// Model class to map Vehicles data
class VehiclesModel:ObjectMapper{
    
    var vehicle_identifier:String?
    var brand_identifier:String?
    var brand_name:String?
    
    var model_identifier:String?
    var model_name:String?
    var ex_showroom_price:Float?
    var rating:Float?

    var user_rating_count:Int?
    var user_review_count:Int?
    var offer_available:Bool?
    var emi_start_at:Int?
    var is_favorite:Bool?
    var emi_info:String?

    var media:MediaModel?
    
    
    /// To map the response data
    ///
    /// - Parameter json: response json
    func mapping(json: Dictionary<String, Any>) {
    }
}
