//
//  CarListViewController.swift
//  IXiOSArchitecture
//
//  Created by Alex Appadurai on 28/05/18.
//  Copyright © 2018 Alex Appadurai. All rights reserved.
//

import UIKit

/// Car list screen controller
class CarListViewController: UIViewController {
    
    @IBOutlet var tableView:UITableView!
    
    lazy var dataModel : CarListDataModel = {return CarListDataModel()}()
    
    let kSegueIdentifier = "showCarDetail"
    
    
    /// MARK:- lifecycle method
    override func viewDidLoad() {
        super.viewDidLoad()
        dataModel.delegate = self
        dataModel.fetch()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if (segue.identifier == kSegueIdentifier) {
//            let carDetailController = segue.destination as! CarDetailViewController
//            vc.var_name = "Your Data"
        }
    }
    

}


// MARK: - UITableViewDataSource and UITableViewDelegate for CarListView
extension CarListViewController:UITableViewDataSource,UITableViewDelegate{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataModel.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: CarListTableViewCell.reuseIdentifier, for: indexPath) as! CarListTableViewCell
        
        return cell
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.performSegue(withIdentifier: kSegueIdentifier, sender: self)
    }
}

// MARK: - DataModelDelegate for CarListView
extension CarListViewController:DataModelDelegate{
    func dataModelDidCompleted(_ item: Any?, _ type: DataType?) {
        self.tableView.reloadData()
    }
    func dataModelDidFailed(_ item: Any?, _ type: DataType?) {
        
    }
}
