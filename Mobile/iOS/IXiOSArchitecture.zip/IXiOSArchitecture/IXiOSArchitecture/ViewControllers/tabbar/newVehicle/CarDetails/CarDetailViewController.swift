//
//  CarDetailViewController.swift
//  GaadiBazaar
//
//  Created by apple on 28/05/18.
//  Copyright © 2018 Alex Appadurai. All rights reserved.
//

import UIKit

class CarDetailViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    let colorArray : Array<String> = ["#4286f4","#cec327","#4222f4","#d65215","#86168c"]
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
extension CarDetailViewController : UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return colorArray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: CarColorsTableViewCell.reuseIdentifier, for: indexPath) as! CarColorsTableViewCell
        let color = UIColor(hexString: colorArray[indexPath.row])
        cell.carColorView.backgroundColor = color
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = tableView.cellForRow(at: indexPath) as! CarColorsTableViewCell
        let selectedTintColor = UIColor(hexString: colorArray[indexPath.row])
        cell.selectedImageView.image = UIImage.init(named: "selectedColor")
        cell.selectedImageView.tintColor = selectedTintColor
        
    }
    
}
