//
//  PopularComparisonViewController.swift
//  IXiOSArchitecture
//
//  Created by Alex Appadurai on 25/05/18.
//  Copyright © 2018 Alex Appadurai. All rights reserved.
//

import UIKit


/// Popular comparision in landing
class PopularComparisonViewController: UIViewController ,StoaryboardSegueIdentifier {

    static var segueIdentifier: String = "PopularComparisonViewControllerID"

    @IBOutlet var collectionView:UICollectionView!
    var items = Array<VehicleComparisonModel>(){
        didSet{
            collectionView.reloadData()
        }
    }
    
    
    /// MARK:- lifecycle method
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

// MARK: - UICollectionViewDataSource and aUICollectionViewDelegate for PopularComparisionView
extension PopularComparisonViewController: UICollectionViewDataSource,UICollectionViewDelegate{
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 3//items.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ComparisonCollectionViewCell.reuseIdentifier, for: indexPath) as! ComparisonCollectionViewCell
//        cell.set(car: self.items[indexPath.row])
        return cell
    }
}
