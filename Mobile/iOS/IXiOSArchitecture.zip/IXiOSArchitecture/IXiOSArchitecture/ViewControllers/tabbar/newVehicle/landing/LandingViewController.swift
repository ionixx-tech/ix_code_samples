//
//  LandingViewController.swift
//  IXiOSArchitecture
//
//  Created by Alex Appadurai on 25/05/18.
//  Copyright © 2018 Alex Appadurai. All rights reserved.
//

import UIKit

//Landing View in Home Screen
class LandingViewController: UIViewController{
    
    @IBOutlet var bannerImageView:UIImageView!
    @IBOutlet var bannerLabel:UILabel!

    lazy var dataModel:LandingDataModel = {return LandingDataModel()}()
    
    var latestViewController:LatestViewController!
    var popularComparisonViewController:PopularComparisonViewController!
    var newsReviewViewController:NewsReviewViewController!
    
    // MARK:- Life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        dataModel.delegate = self
        dataModel.fetch()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
     // MARK: - Navigation
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
        if segue.identifier == LatestViewController.segueIdentifier {
            latestViewController = segue.destination as! LatestViewController
        }else if segue.identifier == PopularComparisonViewController.segueIdentifier {
            popularComparisonViewController = segue.destination as! PopularComparisonViewController
        }else if segue.identifier == NewsReviewViewController.segueIdentifier {
            newsReviewViewController = segue.destination as! NewsReviewViewController
        }
     }
}

// MARK: - DataModelDelegate for LandingView
extension LandingViewController:DataModelDelegate{
    func dataModelDidCompleted(_ item: Any?,_  type: DataType?) {
        guard let data_type = type as? LandingDataType  else {
            return
        }
        switch data_type {
        case .banner:
            break
        case .latest:
            // set and reload tableview using didSet
            latestViewController.items = item as! [VehiclesModel]
        case .popular_comparison:
            // set and reload tableview using didSet
            popularComparisonViewController.items = item as! [VehicleComparisonModel]
        case .news:
            // set and reload tableview using didSet
            newsReviewViewController.items = item as! [NewsReviewModel]
        }
    }
    //handle failed case
    func dataModelDidFailed(_ item: Any?,_  type: DataType?) {
        
    }
}
